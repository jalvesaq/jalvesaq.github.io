library("descr")
library("memisc")


# Reordena os levels de um factor, mas somente se o número de levels estiver
# correto:
reordenar <- function(x, nova.ordem) {
    require(gdata)
    xlev <- length(levels(x))
    nlev <- length(nova.ordem)
    if(nlev == xlev)
        x <- gdata::reorder.factor(x, new.order = nova.ordem)
    else
        stop("Erro: reordenar: ", xlev, " ≠ ", nlev, " ", deparse(substitute(x)))
    x
}


load("lepem2010.RData")


# Número de votos de candidatos ao Senado segundo a localização
# Fonte dos dados: TRE-CE.
ntotal <- dim(b)[1]
ninterior <- sum(b$metropt == "Interior")
nmetrop <- ntotal - ninterior
e$interior <- e$municipio != "Fortaleza" & e$municipio != "Maracanaú" & e$municipio != "Caucaia"
tabint <- tapply(e$votos, list(e$interior, e$nome), sum, na.rm = TRUE)
tabint <- tabint[, c("Tasso", "Eunício", "Pimentel")]
tabintp <- tabint
tabintp[1, ] <- tabint[1, ] / neleitmetr
tabintp[2, ] <- tabint[2, ] / neleitinte
tabintp <- format(round(tabintp, 2), decimal.mark = ",")
tabint <- matrix(paste(format(tabint, decimal.mark = ",", big.mark = "."), " (", tabintp, "%)", sep = ""), nrow = 2, ncol = 3)
rownames(tabint) <- c("Reg. Metrop.", "Interior")
colnames(tabint) <- c("Tasso", "Eunício", "Pimentel")
tabint


# Proporção dos votos recebidos pelos candidatos ao Senado em 2010 segundo o
# partido do candidato a prefeito mais votado nas eleições de 2008
# Fonte dos dados: TRE-CE.
cp1 <- compmeans(p$tas, p$part08, plot = FALSE)
cp2 <- compmeans(p$eun, p$part08, plot = FALSE)
cp3 <- compmeans(p$pim, p$part08, plot = FALSE)
tmp <- cbind(cp1[, 1], cp2[, 1], cp3[, c(1, 2)])
pref <- tmp
pref[, 1:3] <- format(round(tmp[, 1:3], 2), decimal.mark = ",")
pref[, 4] <- as.character(tmp[, 4])
rm(tmp, cp1, cp2, cp3)
colnames(pref) <- c("Tasso", "Eunício", "Pimentel", "N")
pref

# Proporção dos votos de candidatos ao Senado em 2010 segundo o partido do
# candidato mais votado para prefeito em 2008
# Fonte: TRE-CE.
par(mfrow = c(1, 3), mar = c(2.1, 2.6, 1.1, 0.1))
boxplot(p$tas ~ p$part08b, col = "lightgray", main = "Tasso",
        ylim = c(0, 0.83))
boxplot(p$eun ~ p$part08b, col = "lightgray", main = "Eunício",
        ylim = c(0, 0.83))
boxplot(p$pim ~ p$part08b, col = "lightgray", main = "Pimentel",
        ylim = c(0, 0.83))



# Correlação entre proporção de votos para deputados do PSDB (em 2006 e 2010) e proporção de votos para senador em 2010 nos  municípios cearenses
# Fonte dos dados: TRE-CE.
m <- matrix(NA, nrow = 4, ncol = 3)
rownames(m) <- c("Dep. Est. 2006", "Dep. Fed. 2006",
                 "Dep. Est. 2010", "Dep. Fed. 2010")
colnames(m) <- c("Tasso", "Eunício", "Pimentel")
tmpi <- list(p$de06, p$df06, p$de10, p$df10)
tmpj <- list(p$tas, p$eun, p$pim)
for(i in 1:4)
    for(j in 1:3)
        m[i, j] <- cor(tmpi[[i]], tmpj[[j]])
rm(tmpi, tmpj, i, j)
mdep <- format(round(m, 2), decimal.mark = ",")
mdep


# Correlações: proporções de votos por urna em 2010 (Interior)
# Fonte dos dados: TRE-CE.
e2 <- subset(e, interior)
e2 <- droplevels(e2)
tab <- tapply(e2$votos, list(secao = e2$chave, candidato = e2$nome), sum, na.rm = TRUE)
tab[is.na(tab)] <- 0
tab <- as.data.frame(tab)
tab$ttsen <- tab$Tasso + tab$Eunício + tab$Pimentel
tab$ttpre <- tab$Dilma + tab$Serra + tab$Marina
tab$ttgov <- tab$Cid + tab$Lúcio + tab$Cals
tab$Cid <- tab$Cid / tab$ttgov
tab$Lúcio <- tab$Lúcio / tab$ttgov
tab$Cals <- tab$Cals / tab$ttgov
tab$Tasso <- tab$Tasso / tab$ttsen
tab$Eunício <- tab$Eunício / tab$ttsen
tab$Pimentel <- tab$Pimentel / tab$ttsen
tab$Dilma <- tab$Dilma / tab$ttpre
tab$Serra <- tab$Serra / tab$ttpre
tab$Marina <- tab$Marina / tab$ttpre
tabi <- tab[, c("Dilma", "Marina", "Serra", "Cid", "Lúcio", "Cals")]
tabj <- tab[, c("Tasso", "Eunício", "Pimentel")]
cor.sen.i <- matrix(NA, nrow = 6, ncol = 3)
rownames(cor.sen.i) <- c("Dilma", "Marina", "Serra", "Cid", "Lúcio", "Cals")
colnames(cor.sen.i) <- c("Tasso", "Eunício", "Pimentel")
for(i in 1:6)
    for(j in 1:3)
        cor.sen.i[i, j] <- cor(tabi[[i]], tabj[[j]])
cor.sen.i <- format(round(cor.sen.i, 2), decimal.mark = ",")
cor.sen.i


# Correlações: proporções de votos por urna em 2010 (Região Metropolitana)
# Fonte dos dados: TRE-CE.
e2 <- subset(e, nome == "Cid" | nome == "Dilma" | nome == "Eunício" | nome == "Pimentel" |
             nome == "Tasso" | nome == "Lúcio" | nome == "Serra" | nome == "Marina" | nome == "Cals", )
e2 <- subset(e, municipio == "Fortaleza" | municipio == "Caucaia" | municipio == "Maracanaú")
e2 <- droplevels(e2)
tab <- tapply(e2$votos, list(secao = e2$chave, candidato = e2$nome), sum, na.rm = TRUE)
tab[is.na(tab)] <- 0
tab <- as.data.frame(tab)
tab$ttsen <- tab$Tasso + tab$Eunício + tab$Pimentel
tab$ttpre <- tab$Dilma + tab$Serra + tab$Marina
tab$ttgov <- tab$Cid + tab$Lúcio + tab$Cals
tab$Cid <- tab$Cid / tab$ttgov
tab$Lúcio <- tab$Lúcio / tab$ttgov
tab$Cals <- tab$Cals / tab$ttgov
tab$Tasso <- tab$Tasso / tab$ttsen
tab$Eunício <- tab$Eunício / tab$ttsen
tab$Pimentel <- tab$Pimentel / tab$ttsen
tab$Dilma <- tab$Dilma / tab$ttpre
tab$Serra <- tab$Serra / tab$ttpre
tab$Marina <- tab$Marina / tab$ttpre
tabi <- tab[, c("Dilma", "Marina", "Serra", "Cid", "Lúcio", "Cals")]
tabj <- tab[, c("Tasso", "Eunício", "Pimentel")]
cor.sen.m <- matrix(NA, nrow = 6, ncol = 3)
rownames(cor.sen.m) <- c("Dilma", "Marina", "Serra", "Cid", "Lúcio", "Cals")
colnames(cor.sen.m) <- c("Tasso", "Eunício", "Pimentel")
for(i in 1:6)
    for(j in 1:3)
        cor.sen.m[i, j] <- cor(tabi[[i]], tabj[[j]])
cor.sen.m <- format(round(cor.sen.m, 2), decimal.mark = ",")
cor.sen.m


# Comparação dos votos declarados por entrevistados para os três candidatos mais votados de cada cargo e os resultados das urnas
# Fonte dos dados: TRE-CE e survey.
vv <- aggregate(list(votos = e$votos), list(nome = e$nome, cargo = e$cargo), sum, na.rm = TRUE)
vv <- vv[vv$votos > 500000, ]
vv <- droplevels(vv)
vv.tt <- tapply(vv$votos, vv$cargo, sum)
vv$total[vv$cargo == "Governador"] <- vv.tt["Governador"]
vv$total[vv$cargo == "Presidente"] <- vv.tt["Presidente"]
vv$total[vv$cargo == "Senador"] <- vv.tt["Senador"]
vv$vval <- round(vv$votos / vv$total, 3) * 100
vv$nome <- as.character(vv$nome)
vv$vsurv[vv$nome == "Cid"] <- sum(b$q52 == "Cid", na.rm = TRUE)
vv$vsurv[vv$nome == "Lúcio"] <- sum(b$q52 == "Lúcio", na.rm = TRUE)
vv$vsurv[vv$nome == "Cals"] <- sum(b$q52 == "Cals", na.rm = TRUE)
vv$vsurv[vv$nome == "Dilma"] <- sum(b$q48 == "Dilma", na.rm = TRUE)
vv$vsurv[vv$nome == "Serra"] <- sum(b$q48 == "Serra", na.rm = TRUE)
vv$vsurv[vv$nome == "Marina"] <- sum(b$q48 == "Marina", na.rm = TRUE)
vv$vsurv[vv$nome == "Tasso"] <- sum(b$senTasso)
vv$vsurv[vv$nome == "Eunício"] <- sum(b$senEunicio)
vv$vsurv[vv$nome == "Pimentel"] <- sum(b$senPimentel)
stt <- tapply(vv$vsurv, vv$cargo, sum)
vv$stotal[vv$cargo == "Presidente"] <- stt["Presidente"]
vv$stotal[vv$cargo == "Governador"] <- stt["Governador"]
vv$stotal[vv$cargo == "Senador"] <- stt["Senador"]
vv$sval <- round(vv$vsurv / vv$stotal, 3) * 100
vv$vdif <- vv$sval - vv$vval
rownames(vv) <- vv$nome
vv <- vv[, c("vsurv", "sval", "votos", "vval", "vdif")]
names(vv) <- c("Survey", "%", "Urnas", "%", "Dif. %")
vv <- vv[c(4, 5, 6, 1, 2, 3, 7, 8, 9), ]
vv <- format(vv, big.mark = ".", decimal.mark = ",")
vv


## ----tablembr,echo=F,results=tex----------------------------------------------
# Número de vezes que os cargos foram lembrados
# Fonte dos dados: survey.
lembr.exata <- sum(b$q6 == "Presidente, Governador, Senador, Deputado Federal, Deputado Estadual", na.rm = TRUE)
lembr <- c(length(grep("Presidente", b$q6)), length(grep("Governador", b$q6)),
           length(grep("Senador", b$q6)), length(grep("Deputado Federal", b$q6)),
           length(grep("Deputado Estadual", b$q6)), length(grep("Prefeito", b$q6)),
           length(grep("Vereador", b$q6)))
names(lembr) <- c("Presidente", "Governador", "Senador", "Deputado Federal",
                  "Deputado Estadual", "Prefeito", "Vereador")
lembr <- cbind(lembr, round(100 * lembr / ntotal, 1))
colnames(lembr) <- c("N", "%")
lembr <- format(lembr, decimal.mark = ",")
lembr[, 1] <- sub(",0", "", lembr[, 1])
lembr[, 2] <- sub(" ", "", lembr[, 2])
lembr


# Frequência dos diferentes tipos de voto para Senado
# Fonte dos dados: survey.
fsen <- freq(b$sen, plot = FALSE)
fsen[, c(2, 3)] <- format(round(fsen[, c(2, 3)], 1), decimal.mark = ",")
fsen <- sub("NA", "", fsen)
fsen


# Voto para o Senado (primeira e segunda opções)
# Fonte dos dados: survey.
sen1sen2 <- cbind(table(b$q56r), table(b$q58r))
colnames(sen1sen2) <- c("1ª Opção", "2ª Opção")
sen1sen2

# Voto para senador versus voto para governador
# Fonte: survey
govsen <- cbind(table(droplevels(b$q52[(b$q52 == "Cid" | b$q52 == "Lúcio" | b$q52 == "Cals")
                                 & b$senTasso])),
                table(droplevels(b$q52[(b$q52 == "Cid" | b$q52 == "Lúcio" | b$q52 == "Cals")
                                 & b$senEunicio])),
                table(droplevels(b$q52[(b$q52 == "Cid" | b$q52 == "Lúcio" | b$q52 == "Cals")
                                 & b$senPimentel])))
colnames(govsen) <- c("Tasso", "Eunício", "Pimentel")
govsentab <- rbind(govsen, apply(govsen, 2, sum))
govsentab <- cbind(govsentab, apply(govsentab, 1, sum))
rownames(govsentab)[4] <- "Total"
colnames(govsentab) <- c("Tasso", "Eunício", "Pimentel", "Total")
par(mfrow = c(1, 1), mar = c(0.1, 1.1, 1.1, 0.1), cex = 0.8)
mosaicplot(govsen, main = "", col = gray.colors(3, start = 0.6, end = 0.9), las = 1)


# Voto para senador versus voto para presidente
# Fonte: Survey.
par(mar = c(0.1, 1.1, 1.1, 0.1), cex = 0.8)
presen <- cbind(table(droplevels(b$q48[(b$q48 == "Dilma" | b$q48 == "Serra" | b$q48 == "Marina")
                                 & b$senTasso])),
                table(droplevels(b$q48[(b$q48 == "Dilma" | b$q48 == "Serra" | b$q48 == "Marina")
                                 & b$senEunicio])),
                table(droplevels(b$q48[(b$q48 == "Dilma" | b$q48 == "Serra" | b$q48 == "Marina")
                                 & b$senPimentel])))
colnames(presen) <- c("Tasso", "Eunício", "Pimentel")
presentab <- rbind(presen, apply(presen, 2, sum))
presentab <- cbind(presentab, apply(presentab, 1, sum))
rownames(presentab)[4] <- "Total"
colnames(presentab) <- c("Tasso", "Eunício", "Pimentel", "Total")
mosaicplot(presen, main = "", col = gray.colors(3, start = 0.6, end = 0.9), las = 1)


# Número de entrevistados que lembraram cada um dos candidatos mais votados
# para o Senado, o Governo e a Presidência
# Fonte: Survey.
lbr.cand <- c(length(grep("Dilma", b$q9)), length(grep("Serra", b$q9)),
              length(grep("Marina", b$q9)), length(grep("Cid", b$q10)),
              length(grep("Lúcio", b$q10)), length(grep("Cals", b$q10)),
              length(grep("Tasso", b$q11)), length(grep("Eunício", b$q11)),
              length(grep("Pimentel", b$q11)))
lbr.cand <- data.frame(quant = lbr.cand, perc = lbr.cand / ntotal)
rownames(lbr.cand) <- c("Dilma", "Serra", "Marina", "Cid", "Lúcio", "Cals", "Tasso", "Eunício", "Pimentel")
lbr.cand$perc <- round(100 * lbr.cand$perc, 1)
lbrc <- lbr.cand$quant
lbr.cand <- format(lbr.cand, decimal.mark = ",")
colnames(lbr.cand) <- c("N", "%")
par(mar = c(2.1, 5.1, 0.1, 0.1), cex = 0.8)
bp <- barplot(lbrc, names.arg = rownames(lbr.cand), las = 1,
              horiz = TRUE, col = c(rep("#999999", 3), rep("#C4C4C4", 3),
                                    rep("#E6E6E6", 3)), xlim = c(0, 850))
text(lbrc + 50, bp, lbrc)



# Avaliação dos Governos Cid e Lula segundo o voto para o Senado
# Fonte dos dados: survey.
crosstab(b$avaliaLula, b$sen2, inv.y = TRUE)
crosstab(b$avaliaCid, b$sen2, inv.y = TRUE)


# Por que votou em ____ para senador?
# Fonte: Survey
pq.tas <- rep(NA, ntotal)
pq.eun <- rep(NA, ntotal)
pq.pim <- rep(NA, ntotal)
pq.tas[b$q56r == "Tasso"] <- b$q57r[b$q56r == "Tasso"]
pq.tas[b$q58r == "Tasso"] <- b$q59r[b$q58r == "Tasso"]
pq.eun[b$q56r == "Eunício"] <- b$q57r[b$q56r == "Eunício"]
pq.eun[b$q58r == "Eunício"] <- b$q59r[b$q58r == "Eunício"]
pq.pim[b$q56r == "Pimentel"] <- b$q57r[b$q56r == "Pimentel"]
pq.pim[b$q58r == "Pimentel"] <- b$q59r[b$q58r == "Pimentel"]
pq.tas <- factor(pq.tas)
pq.eun <- factor(pq.eun)
pq.pim <- factor(pq.pim)
pq.tas <- recode(pq.tas,
                 "Bom candidato" <- c("Bom candidato", "Tradição"),
                 "Oposição" <- "Oposição",
                 "Outros" <- c("Outros", "PSDB", "Serra"))
# Reordenar pq.eun e pq.pim:
pq.eun <- reordenar(pq.eun, c(1, 3, 5, 2, 4, 6))
pq.pim <- reordenar(pq.pim, c(1, 3, 5, 2, 4, 6))
par(mfrow = c(1, 3), mar = c(5.1, 3.1, 3.1, 1.1))
bp <- plot(pq.tas, main = "Tasso?", names = FALSE)
text(bp + 0.3, -5, labels = levels(pq.tas), srt = 45, pos = 2, xpd = TRUE)
bp <- plot(pq.eun, main = "Eunício?", names = FALSE)
text(bp + 0.3, -5, labels = levels(pq.eun), srt = 45, pos = 2, xpd = TRUE)
bp <- plot(pq.pim, main = "Pimentel?", names = FALSE)
text(bp + 0.3, -5, labels = levels(pq.pim), srt = 45, pos = 2, xpd = TRUE)



# Índice de informação sobre política segundo o voto para o Senado
par(mfrow = c(1, 1), mar = c(9.8, 2.1, 0.2, 0.1), cex.axis = 0.7)
bx <- boxplot(b$iip ~ b$sen, col = "lightgray", names = FALSE, xlab = "")
text(1:6 + 0.2, -6, labels = levels(b$sen), pos = 2, cex = 0.7, srt = 45, xpd = TRUE)



# Interesse por política e voto para senador
crosstab(b$q15, b$sen2, inv.y = TRUE)
