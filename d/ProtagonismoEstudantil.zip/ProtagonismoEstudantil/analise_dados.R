# Este script usa UTF-8 como codificacao de caracteres

# Carregar pacotes
library("descr")
library("memisc")

# Carregar dados
load("ProtagonismoEstudantil.RData")
bRot <- lapply(b, function(x) attr(x, "label"))


# Criar variáveis

# Optamos por não apresentar o nome das escolas, denominando-as: P1, P2, P3,
# P4, P5 e M1, M2, R1, R2, R3. São cinco EEEPs e cinco escolas regulares.
# M1 e M2 são escolares militares.

b$ano3 <- b$serie == "3"
b$ano3 <- factor(b$ano3, levels = c(FALSE, TRUE), labels = c("Não", "Sim"))

b$militar <- grepl("M", as.character(b$escola))
b$militar <- factor(b$militar, levels = c(FALSE, TRUE),
                    labels = c("Civil", "Militar"))

b$tipo.escola2 <- 1
b$tipo.escola2[b$militar == "Militar"] <- 2
b$tipo.escola2[b$tipo.escola == "Profissional"] <- 3
b$tipo.escola2 <- factor(b$tipo.escola2, levels  = c(1, 2, 3),
                         labels = c("C", "M", "P"))
b$q13n <- 1
b$q13n[b$q13 == "Sim, página individual"]  <- 2
b$q13n[b$q13 == "Sim, página em grupo"]  <- 3
b$q13n[b$q13 == "Sim, página individual" & b$q13.2 == "Página em grupo"] <- 4
b$q13n <- factor(b$q13n, levels = c(1, 2, 3, 4),
                 labels = c ("Não", "Sim, página individual", "Sim, página em grupo",
                             "Sim, página individual e página em grupo"))

b$tempo.estudo <- b$q2.1 + b$q2.2

b$st.econom <- as.numeric(b$q75)
b$freq.rede <- as.numeric(b$q3)
b$horas.redes <- as.numeric(b$q4)
b$freq.saida <- as.numeric(b$q5)
b$interacao <- b$freq.rede + b$horas.redes + b$freq.saida - 4

b$renda <- as.numeric(b$q76)
tmp <- tapply(b$renda, b$turma, mean, na.rm = TRUE)
tmp <- data.frame(rendamedia = tmp, turma = names(tmp))
tmp2 <- tapply(b$interacao, b$turma, mean, na.rm = TRUE)
tmp2 <- data.frame(interacaomedia = tmp2, turma = names(tmp2))
tmp <- merge(tmp, tmp2)
b <- merge(b, tmp)

for(n in names(bRot))
    attr(b[[n]], "label") <- bRot[[n]]

b$rendarelativa <- b$renda - b$rendamedia

# Foi conveniente fazer uma recodificação da variável trabalho a fim de
# conferir maior significância aos resultados. A nova categoria informa se o
# estudante trabalha ou não. Os que trabalham englobam as categorias: “emprego
# integral”, “emprego meio período”, “autônomo” e os que preencheram o item
# “outros”.

trab <- b$q68outro %in% c("Ajudo Os Meus Pais/ Estudante", "Auxiliar e Meio Que um Trabalho",
                          "Bicos Aos Fins de Semana", "Bicos de Faxineira",
                          "Bicos No Fim de Semana", "Cerimonialista", "Desempregado", "Empreendedor",
                          "Estudante e Baba", "Estudante e Dona de Casa",
                          "Estudante e Ganho Dinheiro Jogando", "Estudio de Beleza da Familia",
                          "Faco Alguns Bicos", "Nao, Escola Integral", "Reforco", "Seguranca",
                          "Sorveteria", "Tenho uma Loja", "Trabalho com Meu Pai",
                          "Vendendor Ambulante")
trab[b$q68outro == "Estagiário" & b$tipo.escola == "Regular"] <- TRUE
b$trabalha <- b$q68 %in% c("emprego integral", "emprego meio período", "autônomo") | trab


# Originalmente, a questão tinha entre as opções: “branco”, “pardo”, “negro”,
# “índio” e “oriental”. A quantidade de estudantes que se identificaram como
# “orientais” (5) e “indígenas” (28) foi pequena. Por isso, após realizar o
# cruzamento entre cor e renda (Figura 5) e observar que negros e indígenas
# estavam em um mesmo nível socioeconômico, assim como orientais e brancos,
# recodificamos a variável, a fim de conferir maior significância às análises
# subsequentes. Sendo assim, “negros” e “índios” foram identificados como
# “negros”; “brancos” e “orientais” como “brancos”, como podemos ver no
# segundo gráfico.

b$cor <- b$q79
b$cor[b$q79 == "Indígena"] <- "Negro"
b$cor[b$q79 == "Oriental"] <- "Branco"
b$cor <- droplevels(b$cor)

b$esc.resp <- b$q65mae
b$esc.resp[is.na(b$esc.resp)] <- b$q66pai[is.na(b$esc.resp)]
b$esc.resp[is.na(b$esc.resp)] <- b$q67responsavel[is.na(b$esc.resp)]
b$esc.resp.n <- as.numeric(b$esc.resp)

# Exemplo de como mudar os nomes das categorias:
tmp <- b$esc.resp
levels(tmp) <- c("Sem", "F. Inc.", "F. Compl.", "M. Inc.", "M. Compl.", "S. Inc.", "S. Compl.")

b$voluntario <- b$q27qual %in%
    c("abrigo de cachorro ", "abrigo de cachorros", "abrigo de idosos e criancas",
      "Abrigo pingo de farias", "abrigo são lásaro/ carmel express",
      "abrigo sao lazaro", "abrigo tia júlia", "Abrigo Tia Júlia",
      "acao de cidadania", "agentes da alegria",
      "ainda existe amor em fortaleza", "ajudando pessoas carentes",
      "aluno educador", "Apae", "artes na periferia", "asilo", "atletas em acao",
      "Atualmente no Natal de amor (esse será meu 4 ano) e eventualmente visito o Lar Torres de Melo",
      "aula de ingles",
      "bercaria", "biblioteca", "bombeiros voluntarios do ceara",
      "canto e coral, campanha de reciclagem", "casa de idosos", "casa do menino jesus",
      "casa espirita, grupos de sopas e lar menino jesus", "catequese",
      "cdvhs e cchs", "ceu, criança esperança", "comunidade",
      "comunidade filhos da rainha da paz",
      "creche amadeu barros leal", "crianca levanta-te", "cuidando de bebê",
      "cuidando de criancas", "curumins", "doacao de alimentos e roupas",
      "doação para hospitais", "em algumas festas beneficentes",
      "escamf", "escola",
      "escola anterior", "escola biblica infantil", "escola de ballet",
      "escola, comunidades", "escola; igreje; projeto Amor que nos faz um",
      "escolinha grande bom jardim", "eslic",
      "evangelizar e preciso", "eventos ciclísticos",
      "festa solidaria de natal", "Força Jovem",
      "fundacao de caridade", "greenpeace",
      "grupo de louvor da igreja", "grupo de pesquisa cientifica unifor",
      "Grupo voluntário Guardião Juvenil",
      "IFMM", "igreja", "Igreja", "igreja batista", "igreja como músico",
      "igreja e escola", "igreja e orfanato", "instituicao de futebol",
      "instituicao moreira para pessoas com sindrome de down", "instituto cristo rei",
      "Instituto do Câncer", "instituto logos, projeto alianca", "instituto mãos ativas",
      "Jar de Jorgianny", "jiu jitsu", "jovens pela diferenca jpd",
      "juventude contra a fome", "laboratorio", "Lar amigos de Jesus / Ainda existe amor em Fortaleza",
      "lar da crianca d. savio", "lar santa monica", "Lar Torres de Melo",
      "lbv legiao da boa vontade", "leo clube",
      "Mãos que ajudam", "Mãos que ajudam igreja Mórmom", "mecesa",
      "missao aposentar e restaurar", "missao vida em foco",
      "Monte Sião, Clínica de reabilitação",
      "movimento escoteiro", "Movimento Luiza",
      "na escola", "Na escola onde eu estudava!", "na igreja", "na igreja com ações",
      "na matéria de empreendedorismo realizei uma ação social",
      "Obra Lúmem/ Natal Branco", "orfanato casa de jeremias",
      "orfanato/igreja", "organizacao de corrida de rua", "pastoral da crianca",
      "PJC", "programa mais medicos",
      "projeto ainda existe amor em Fortaleza", "projeto area verde",
      "projeto com criancas carentes", "projeto crianca feliz", "projeto de empreendedorismo",
      "projeto estudantil", "projeto maria  mae da vida", "projeto qualidade de vida",
      "projeto social", "projeto social com jovens da periferia", "projetos na igreja",
      "tecnico de futebol", "trabalhei como voluntária no Instituto Irmã Guiliana Galci",
      "trabalho comunitario com criancas carentes", "trilhas de ferias",
      "um abrigo de animais",
      "visita a criancas e idosos", "visita a idosos e animais",
      "voluntário de mesa", "voluntarios da alegria")
b$voluntario <- factor(b$voluntario, levels = c(FALSE, TRUE),
                       labels = c("Não", "Sim"))

b$tipofam <- as.numeric(b$q63mae == "Sim" & b$q63pai == "Sim")
b$tipofam[b$q63mae == "Sim" & b$q63pai == "Não"] <- 2
b$tipofam[b$q63mae == "Não" & b$q63pai == "Não"] <- 3
b$tipofam <- factor(b$tipofam, levels = c(1, 2, 3),
                    labels = c("Pai e mãe", "Somente mãe", "Outras pessoas"))

# Número de alunos segundo as categorias de algumas variáveis
table(b$ano3, b$tipo.escola)
table(b$turno, b$tipo.escola)
table(b$q58, b$tipo.escola)
table(b$cor, b$tipo.escola)
table(b$q76, b$tipo.escola)
table(b$esc.resp, b$tipo.escola)
table(b$tipofam, b$tipo.escola)
table(b$voluntario, b$tipo.escola)

# ACP coletivo
mipc <- b[, c("q1", "q6", "q7", "q8", "q9", "q10", "q13n", "q14", "q15", "q16",
              "q17", "q18", "q19", "q21", "q22", "q23", "q24", "q25",
              "q28faesportivo", "q28artista", "q28musica", "q28igreja",
              "q29sindicato", "q29partido", "q29associacao", "q29gremio",
              "q29movimento", "q32", "q33", "q35", "q42")]

mipc$q1 <- mipc$q1 == "estudar em grupo"
mipc$q15 <- 3 - as.numeric(mipc$q15)
mipc$q16 <- 3 - as.numeric(mipc$q16)
mipc$q17 <- 3 - as.numeric(mipc$q17)
mipc$q18 <- 3 - as.numeric(mipc$q18)
mipc$q19 <- 3 - as.numeric(mipc$q19)
mipc$q28faesportivo <- mipc$q28faesportivo == "Sim"
mipc$q28artista <- mipc$q28artista == "Sim"
mipc$q28musica <- mipc$q28musica == "Sim"
mipc$q28igreja <- mipc$q28igreja == "Sim"
mipc$q29sindicato <- mipc$q29sindicato == "Sim"
mipc$q29partido <- mipc$q29partido == "Sim"
mipc$q29associacao <- mipc$q29associacao == "Sim"
mipc$q29gremio <- mipc$q29gremio == "Sim"
mipc$q29movimento <- mipc$q29movimento == "Sim"
mipc$q32 <- mipc$q32 == "Sim"
mipc$q33 <- mipc$q33 == "Sim"
mipc$q35 <- mipc$q35 == "Sim"
mipc$q42 <- mipc$q42 == "Sim"
mipc$q6 <- 3 - as.numeric(mipc$q6)
mipc$q7 <- 3 - as.numeric(mipc$q7)
mipc$q8 <- 3 - as.numeric(mipc$q8)
mipc$q9 <- 3 - as.numeric(mipc$q9)
mipc$q10 <- 3 - as.numeric(mipc$q10)
mipc$q13n <- mipc$q13n != "Não"
mipc$q14 <- mipc$q14 == "Sim"
mipc$q21 <- 3 - as.numeric(mipc$q21)
mipc$q22 <- 3 - as.numeric(mipc$q22)
mipc$q23 <- 3 - as.numeric(mipc$q23)
mipc$q24 <- 3 - as.numeric(mipc$q24)
mipc$q25 <- 3 - as.numeric(mipc$q25)


# Empoderamento
# Nas questões que indagavam o que o estudante pretende fazer após concluir o
# ensino médio, consideramos que os alunos que deixaram alguma questão em
# branco o fizeram por não quererem aquela opção. Portanto, os valores omissos
# foram substituídos por “Não”. Ressaltamos que houve um problema de
# interpretação nessas questões: alguns estudantes entenderam que deveriam
# escolher uma entre as cinco questões, o que corrobora a decisão de
# interpretar que a ausência de marcação significa “Não”.
b$q46[is.na(b$q46)] <- "Não"
b$q47[is.na(b$q47)] <- "Não"
b$q48[is.na(b$q48)] <- "Não"
b$q49[is.na(b$q49)] <- "Não"
b$q50[is.na(b$q50)] <- "Não"

# Matriz para cálculo do índice
mipe <- b [, c("q2.1", "q2.2", "q1", "q46", "q47", "q48", "q49", "q50",
               "q51empregado", "q51gerente", "q51dono", "q51estudando",
               "q52empregado", "q52gerente", "q52estudando", "q52dono",
               "voluntario")]

mipe$q51empregado <- mipe$q51empregado == "Sim"
mipe$q51gerente <- mipe$q51gerente == "Sim"
mipe$q51dono <- mipe$q51dono == "Sim"
mipe$q51estudando <- mipe$q51estudando == "Sim"
mipe$q52empregado <- mipe$q52empregado == "Sim"
mipe$q52gerente <- mipe$q52gerente == "Sim"
mipe$q52dono <- mipe$q52dono == "Sim"
mipe$q52estudando <- mipe$q52estudando == "Sim"
mipe$q1estsozinho <- mipe$q1 == "Estudar sozinho"
mipe$q46 <- mipe$q46 == "Sim"
mipe$q47 <- mipe$q47 == "Sim"
mipe$q48 <- mipe$q48 == "Sim"
mipe$q49 <- mipe$q49 == "Sim"
mipe$q50 <- mipe$q50 == "Sim"
mipe$voluntario <- mipe$voluntario == "Sim"
mipe$q1 <- NULL


# Histogramas dos índices de protagonismo
par(mfrow = c(1, 2), cex = 0.8, cex.axis = 0.8, mar = c(4, 4, 0, 1.2)+0.1)
b$ipc <- apply(mipc, 1, sum)
hist(b$ipc, col = "lightgray", main = "", xlab = "IPC", ylab = "Frequência")

par(mar = c(4, 5, 0, 0.2)+0.1)
b$ipe <- apply(mipe, 1, sum)
hist(b$ipe, col = "lightgray", main = "", xlab = "IPE", ylab = "Frequência")


# Figura: Nível de protagonismo segundo o ano e o tipo de escola
par(cex = 0.8, cex.axis = 0.8, mfrow = c(1, 2), mar = c(2, 2, 3, 1)+0.1)
b$tiposerie <- factor(paste(b$tipo.escola2, b$serie))
tmp <- compmeans(b$ipc, b$tiposerie, ylab = "IPC",
                 xlab = "Tipo de escola e série", main = "IPC")
par(mar = c(2, 3, 3, 0)+0.1)
tmp <- compmeans(b$ipe, b$tiposerie, ylab = "IPE",
                 xlab = "Tipo de escola e série", main = "IPE")


# Regressões
bp <- b[b$tipo.escola2 == "P", ]
bm <- b[b$tipo.escola2 == "M", ]
bc <- b[b$tipo.escola2 == "C", ]

mipc.p1 <- lm(ipc ~ ano3, data = bp)
mipc.m1 <- lm(ipc ~ ano3, data = bm)
mipc.c1 <- lm(ipc ~ ano3, data = bc)

fml <- "~ ano3 + q58 + cor + renda + esc.resp.n + interacaomedia + trabalha"

mipc.p2 <- lm(paste("ipc", fml), data = bp)
mipc.m2 <- lm(paste("ipc", fml), data = bm)
mipc.c2 <- lm(paste("ipc", fml), data = bc)

mipe.p1 <- lm(ipe ~ ano3, data = bp)
mipe.m1 <- lm(ipe ~ ano3, data = bm)
mipe.c1 <- lm(ipe ~ ano3, data = bc)

mipe.p2 <- lm(paste("ipe", fml), data = bp)
mipe.m2 <- lm(paste("ipe", fml), data = bm)
mipe.c2 <- lm(paste("ipe", fml), data = bc)

options(OutDec = ",")
cfp <- formatC(summary(mipe.p1)$coefficients["ano3Sim", "Estimate"],
               digits = 3, format = "f")
cfm <- formatC(summary(mipe.m1)$coefficients["ano3Sim", "Estimate"],
               digits = 3, format = "f")


mt1 <- mtable(mipc.p1, mipc.m1, mipc.c1, mipc.p2, mipc.m2, mipc.c2,
              summary.stats = c("adj. R-squared", "F", "p", "N"))
names(mt1) <- c("EEEP", "Militar", "Civil", "EEEP ", "Militar ", "Civil ")
mt1


mt2 <- mtable(mipe.p1, mipe.m1, mipe.c1, mipe.p2, mipe.m2, mipe.c2,
              summary.stats = c("adj. R-squared", "F", "p", "N"))
names(mt2) <- c("EEEP", "Militar", "Civil", "EEEP ", "Militar ", "Civil ")
mt2



# Sabe Tem Grêmio e Conselho Escolar
b$sabeTemCons <- "Não"
b$sabeTemCons[!is.na(b$q39) & b$q39 == "Sim"] <- "Sim"

b$sabeTemGremio <- "Não"
b$sabeTemGremio[!is.na(b$q31) &
                as.character(b$q31) == as.character(b$temGremio)] <- "Sim"

tab <- rbind("CC" = tapply(b$ipc, b$sabeTemCons, mean, na.rm = TRUE),
             "CG" = tapply(b$ipc, b$sabeTemGremio, mean, na.rm = TRUE),
             "EC" = tapply(b$ipe, b$sabeTemCons, mean, na.rm = TRUE),
             "EG" = tapply(b$ipe, b$sabeTemGremio, mean, na.rm = TRUE))
tab <- formatC(tab, digits = 1, format = "f")
tab <- cbind(tab, "p" = formatC(c(t.test(b$ipc ~ b$sabeTemCons)$p.value,
                                  t.test(b$ipc ~ b$sabeTemGremio)$p.value,
                                  t.test(b$ipe ~ b$sabeTemCons)$p.value,
                                  t.test(b$ipe ~ b$sabeTemGremio)$p.value),
                              digits = 3, format = "f"))


# Quer Grêmio
# A questão sobre o interesse em participar do grêmio apresentava algumas
# alternativas para respostas positivas e negativas, a fim de gerar maior
# significância. Ela foi recodificada em: ter interesse ou não, somando
# todas as questões positivas em uma única variável: “quer grêmio”, que
# indica o interesse em participar de chapa. Ressalto que os valores omissos
# da “q30” foram considerados “não”. Portanto, não compõem a nova variável.

b$querGremio <- b$q30 %in% c("Gostaria, mas a escola não tem grêmio",
                             "Atualmente faço parte da gestão do grêmio",
                             "Sim, porque o grêmio atual não faz nada",
                             "Sim, porque a direção não ouve o grêmio atual",
                             "Sim, para que o grêmio tenha mais voz e espaço na escola")

pqg <- formatC(round(t.test(b$ipc ~ b$querGremio)$p.value, 3),
               digits = 3, format = "f")


# Voluntário
ipcXvol <- formatC(tapply(b$ipc, b$voluntario, mean, na.rm = TRUE),
                   format = "f", digits = 1)
pvol <- formatC(t.test(b$ipc ~ b$voluntario)$p.value,
                digits = 3, format = "f")

