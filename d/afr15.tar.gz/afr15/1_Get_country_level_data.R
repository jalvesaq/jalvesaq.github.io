
library(countrycode)
library(foreign)

###############################################################################
## Penn World Table

# Download the file pwt81.xlsx from www.ggdc.net/pwt and convert it into csv
# with LibreOffice, choosing "Tab" as field separator. Save the csv file in
# the "data" directory.

# The md5sum of pwt81.xlsx is fdd71c5891a185417d0723d099ba066e

penn <- read.table("data/pwt81.csv", sep = "\t", header = TRUE)
penn$iso3c <- countrycode(penn$country, "country.name", "iso3c")
if(!identical(penn$iso3c, as.character(penn$countrycode)))
    cat("\n\nERROR: not same country codes\n\n")
pennTab <- tapply(penn$rgdpna, list(penn$countrycode, penn$year), mean)

# Interpolate data when missing value has valid neighbors:
nc <- ncol(pennTab) - 1
for(i in 1:nrow(pennTab))
    for(j in 2:nc)
        if(is.na(pennTab[i, j]) & !is.na(pennTab[i, j-1]) & !is.na(pennTab[i, j+1]))
        pennTab[i, j] <- (pennTab[i, j-1] + pennTab[i, j+1]) / 2

# Growth rate:
pennGrowthTab <- (pennTab[, 2:(ncol(pennTab))] - pennTab[, 1:(ncol(pennTab) - 1)]) / pennTab[, 1:(ncol(pennTab) - 1)]

# Country growth rate relative to average global growth rate:
pennGrowthTabGM <- sweep(pennGrowthTab, 2, apply(pennGrowthTab, 2, mean, na.rm = TRUE),  "-")

save(pennTab, pennGrowthTabGM, file = "data/growthTab.RData")



###############################################################################
## Polity IV

# Download the file p4v2014.sav from
# http://www.systemicpeace.org/inscrdata.html and save it in the "data"
# directory.
# The md5sum of p4v2014.sav is 413b0eb64be99f42b14783408a19e0f4

piv <- read.spss("data/p4v2014.sav")
piv$iso3c <- countrycode(piv$country, "country.name", "iso3c")

pivTab <- tapply(piv$polity2, list(piv$iso3c, piv$year), function(x) x[1])

binPivTab <- pivTab
binPivTab[pivTab > 5] <- 1
binPivTab[pivTab <= 5] <- -1

# Table of breakdowns of democracy
binDemTab <- matrix(rep(0, nrow(pivTab) * ncol(pivTab)), nrow = nrow(pivTab))
rownames(binDemTab) <- rownames(pivTab)
colnames(binDemTab) <- colnames(pivTab)
for(i in 1:nrow(pivTab)){
    for(j in 2:ncol(pivTab)){
        if(!is.na(pivTab[i, j]) && !is.na(pivTab[i, j-1])){
            if(binPivTab[i, j-1] <= 0 && binPivTab[i, j] > 0)
                binDemTab[i, j] <- 1
        }
    }
}

save(binPivTab, pivTab, binDemTab, file = "data/piv.RData")
