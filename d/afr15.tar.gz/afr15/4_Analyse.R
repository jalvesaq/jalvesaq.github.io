###############################################################################
# Afrobarometer Working Paper No. 160
# The effect of exposure to political institutions and economic events
# on demand for democracy in Africa
# by Jakson Alves de Aquino | September 2015
#
# --- script to replicate the paper results ---
###############################################################################

# List of variable names and labels
# demDem       Demand for democracy
# supplDem     Supply of democracy
# sex          Gender
# educ         Education
# ownership    Individual affluence
# ethOwnership Ethnic affluence
# meanpiv      Mean Polity IV
# ndemyearsI   Years of democracy
# nautyearsI   Years of non-democracy
# age          Age
# meanDxGr     Mean Polity IV * Growth
# rulingparty  Vote for ruling party
# poverty      Lived poverty


# Load Afrobarometer data
load("data/AB_round_5.RData")
varlabels <- lapply(a, attr, "label")
ncases <- ncases[!is.na(ncases)]
initISO <- tapply(a$respno, a$iso3c, function(x) length(x))

load("data/exposure.RData")
a <- merge(a, exposure, all = TRUE)

# Swaziland does not have all three questions of Demand for democracy
a <- a[a$iso3c != "SWZ", ]
a$country <- droplevels(a$country)
finalISO <- tapply(a$respno, a$iso3c, function(x) length(x))

# Countries that have both democratic and authoritarian years
hasdem <- tapply(a$ndemyearsI, a$iso3c, function(x) mean(x) > 0)
hasaut <- tapply(a$nautyearsI, a$iso3c, function(x) mean(x) > 0)
hasautdem <- rownames(hasdem)[hasdem & hasaut]
hasdem <- rownames(hasdem)[hasdem]
hasaut <- rownames(hasaut)[hasaut]

a$ndemyearsI <- a$ndemyearsI / 100
a$nautyearsI <- a$nautyearsI / 100
a$meanpiv    <- a$meanpiv / 10

# Put the variable labels back
for(n in names(varlabels))
    if(!is.null(varlabels[[n]]) && !is.null(a[[n]]))
        attr(a[[n]], "label") <- varlabels[[n]]

rm(n, exposure)

# Create a few numeric variables out of categorical ones
a$sex <- as.numeric(a$q101 == "Female")
a$educ <- a$q97
a$educ <- (as.numeric(droplevels(a$educ)) - 1) / 10

# Scale age:
a$age <- a$q1 / 100

# Recode ethnic group
a$ethnic <- a$q84
notethnic <- c("Don't know", "Not asked", "Others", "Muslim", "Missing", "Refused")
a$ethnic[a$ethnic %in% notethnic] <- "Other"
a$ethnic[a$iso3c == "CPV"] <- "Other"
hasethnic <- tapply(a$ethnic, a$iso3c, function(x) sum(x == "Other") < length(x))

# Figure 1:
# Number of democratic and non-democratic regimes among countries in the 5th
# round of Afrobarometer, according to Polity IV project --- 1950--2013
load("data/piv.RData")
ps <- pivTab[names(initISO), as.character(1950:2013)]
dem <- apply(ps, 2, function(x) sum(x > 5, na.rm = TRUE))
aut <- apply(ps, 2, function(x) sum(x <= 5, na.rm = TRUE))
plot(NULL, xlim = c(1950, 2013), ylim = c(0, 31), ylab = "Number of countries", xlab = "Year")
lines(1950:2013, dem, lty = 1)
lines(1950:2013, aut, lty = 2)
legend("topleft", legend = c("Non-democratic", "Democratic"), lty = c(2, 1), bty = "n")
rm(ps, dem, aut, pivTab, binDemTab, binPivTab)


# Calculate Demand for democracy
m <- a[, c("q32", "q31a", "q31b", "q31c")]
m$q32 <- memisc::recode(m$q32,
                        "1" <- "STATEMENT 1: Democracy preferable.",
                        "0" <- c("STATEMENT 2: Sometimes non-democratic preferable",
                                 "STATEMENT 3: Doesn't matter.", "Don't know"))
m$q31a <- memisc::recode(m$q31a,
                         "1" <- c("Strongly Disapprove", "Disapprove"),
                         "0" <- c("Neither Approve Nor Disapprove", 
                                  "Approve", "Strongly Approve", "Don't Know"))
m$q31b <- memisc::recode(m$q31b,
                         "1" <- c("Strongly Disapprove", "Disapprove"),
                         "0" <- c("Neither Approve Nor Disapprove", 
                                  "Approve", "Strongly Approve", "Don't Know"))
m$q31c <- memisc::recode(m$q31c,
                         "1" <- c("Strongly Disapprove", "Disapprove"),
                         "0" <- c("Neither Approve Nor Disapprove", 
                                  "Approve", "Strongly Approve", "Don't Know"))
m$q32 <- as.numeric(as.character(m$q32))
m$q31a <- as.numeric(as.character(m$q31a))
m$q31b <- as.numeric(as.character(m$q31b))
m$q31c <- as.numeric(as.character(m$q31c))

a$demDem <- apply(m, 1, mean)

maxN <- sum(a$demDem == max(a$demDem, na.rm = TRUE), na.rm = TRUE)
maxP <- sprintf("%.1f", 100 * maxN / sum(!is.na(a$demDem)))
lt20 <- tapply(a$demDem[!is.na(a$demDem)], a$country[!is.na(a$demDem)], function(x) sum(x == 1) / length(x))
lt20 <- sort(lt20)
lt20 <- names(lt20)[lt20 < 0.2]

if(length(lt20) > 3)
    cat("ERROR: lt20 > 3")


# Figure 2:
# Demand for democracy distribution
barplot(table(factor(sprintf("%.2f", a$demDem[!is.na(a$demDem)]))),
        col = "lightgray", main = "", ylab = "Number of respondents", xlab = "Demand for democracy")

# Figure 3:
# Demand for democracy distribution by country
x <- a[!is.na(a$demDem), c("demDem", "country")]
levels(x$country) <- sub("d’Ivoire", "d'Ivoire", levels(x$country))
x$demDem <- factor(sprintf("%.2f", x$demDem))
tab <- table(x$country, x$demDem)
tab <- apply(tab, 1, function(x) x / sum(x) * 100)
tab <- tab[, order(tab[5, ], decreasing = TRUE)]
barplot(as.table(tab), las = 2, col = gray.colors(5), ylab = "%")
legend(41, 100, legend = c("1.00", "0.75", "0.50", "0.25", "0.00"),
       xjust = 0, yjust = 1,
       fill = gray.colors(5)[5:1], xpd = TRUE)
rm(tab, x)

# List countries that only have either democratic years or non-democratic years:
autc <- tapply(a$ndemyearsI, a$country, function(x) sum(x) == 0)
autc <- sort(names(autc)[autc])
autc <- paste(autc, collapse = ", ")
autc <- sub("Togo, Zimbabwe", "Togo and Zimbabwe", autc)
autc
demc <- tapply(a$nautyearsI, a$country, function(x) sum(x) == 0)
demc <- sort(names(demc)[demc])
demc <- paste(demc, collapse = ", ")
demc <- sub("tius, Nam", "tius and Nam", demc)
demc

# Get the number of cases in Algeria
length(a$iso3c[a$iso3c == "DZA"])

# Calculate the Lived Poverty Index
m <- a[, c("q8a", "q8b", "q8c", "q8d", "q8e")]
m <- lapply(m, function(x) {x[x == "Don't Know"] <- NA ; x})
m <- as.data.frame(lapply(m, function(x) as.numeric(x) - 1))
a$poverty <- apply(m, 1, mean) / 4
rm(m)

# Check range of Lived Poverty Index:
if(min(a$poverty, na.rm = TRUE) != 0)
    cat("Error: not == 0\n")
if(max(a$poverty, na.rm = TRUE) != 1)
    cat("Error: not == 8\n")
# Check if the index is identical to what comes with the dataset:
if(sum((a$poverty * 4) - a$livedpoverty, na.rm = TRUE) != 0 || !identical(is.na(a$poverty), is.na(a$livedpoverty)))
    cat("Lived poverty not equal to Lived poverty\n")

# Calculate Individual affluence (Index of ownership of goods)
a$ownership <- ((a$q90a == "Yes, do own") + (a$q90b == "Yes, do own") + (a$q90c == "Yes, do own") + 
    ((a$q92 == "Yes, I use a mobile owned by someone else in my household") |
     (a$q92 == "Yes, I use a mobile phone that I own"))) / 4

# Check range of ownership:
if(min(a$ownership, na.rm = TRUE) != 0)
    cat("\n\n\\textcolor{red}{Error: not == 0}\n\n")
if(max(a$ownership, na.rm = TRUE) != 1)
    cat("\n\n\\textcolor{red}{Error: not == 4}\n\n")

# Calculate Ethnic affluence
calcEthnicOwnership <- function(x)
{
    if(sum(x$ethnic == "Other") == length(x$ethnic)){
        x$ethOwnership <- NA
        return(x[, c("respno", "ethOwnership")])
    }
    gm <- tapply(x$ownership, x$ethnic, mean, na.rm = TRUE)
    gm <- data.frame(ethnic = names(gm), ethOwnership = gm, stringsAsFactors = FALSE)
    x <- merge(x, gm, stringsAsFactors = FALSE)
    x[, c("respno", "ethOwnership")]
}
tmp <- split(a[, c("respno", "ethnic", "ownership")], a$iso3c)
tmp <- lapply(tmp, calcEthnicOwnership)
tmp <- do.call("rbind", tmp)
a <- merge(a, tmp)
# Put the labels back
for(n in names(varlabels))
    if(!is.null(varlabels[[n]]) && !is.null(a[[n]]))
        attr(a[[n]], "label") <- varlabels[[n]]
rm(tmp, calcEthnicOwnership, n)


# Calculate Supply of democracy
x <- a[, c("q42", "q43")]
x$q42 <- memisc::recode(x$q42,
                        "0" <- c("Not a democracy",
                                 "A democracy, with major problems",
                                 "Do not understand question/democracy", 
                                 "Don't know"),
                        "1" <- c("A full democracy",
                                 "A democracy, but with minor problems"))
x$q43 <- memisc::recode(x$q43,
                        "0" <- c("The country is not a democracy",
                                 "Not at all satisfied", 
                                 "Not very satisfied",
                                 "Don't Know"),
                        "1" <- c("Fairly satisfied",
                                 "Very satisfied"))

a$supplDem <- (as.numeric(as.character(x$q42)) + as.numeric(as.character(x$q43))) / 2

rm(x)


# Ruling party according to country and period of research (fill Table A.1 and
# calculate the variable Vote for ruling party at the same time):
rulingRow <- function(ctry, iso, tlab, vlab)
{
    a$rulingparty[a$iso3c == iso & a$q99 == vlab] <<- 1
    if(vlab == "")
        pp <- NA
    else
        pp <- sprintf("%.2f", sum(a$iso3c == iso & a$q99 == vlab) / sum(a$iso3c == iso))
    c(ctry,
      sub(" .*", "", as.character(min(a$dateintr[a$iso3c == iso]), format = "%d/%m/%y")),
      sub(" .*", "", as.character(max(a$dateintr[a$iso3c == iso]), format = "%d/%m/%y")),
      tlab, pp)
  
}
a$rulingparty <- 0
rptab <-
    rbind(rulingRow("Algeria",       "DZA", "National Liberation Front",               "National Liberation Front"),
          rulingRow("Benin",         "BEN", "Cowry Forces for an Emerging Benin",      "Force Cauris pour un bénin Emergent (FCBE de Yayi Boni)"),
          rulingRow("Botswana",      "BWA", "Botswana Democratic Party",               "Botswana Democratic Party (BDP)"),
          rulingRow("Burkina Faso",  "BFA", "Congress for Democracy and Progress",     "CDP de Assimi KOUANDA"),
          rulingRow("Burundi",       "BDI", "Nat. Council for the Defense of Democr.", "Conseil Natinal pour la Défense de la Démocratie-Forces de D"),
          rulingRow("Cameroon",      "CMR", "Cameroon People's Democratic Mov.",       "Cameroon People’s Democratic Movement (CPDM)"),
          rulingRow("Cape Verde",    "CPV", "African Party of Indep. of Cape Verde",   "African Party of Independence of Cape Verde (PAICV)"),
          rulingRow("Cote d’Ivoire", "CIV", "Rally of the Republicans",                "Rassemblement des Républicains (RDR)"),
          rulingRow("Egypt",         "EGY", "Freedom and Justice Party",               "Freedom and Justice Party (Mohammad Morsi)"),
          rulingRow("Ghana",         "GHA", "National Democratic Congress",            "National Democratic Congress (NDC)"),
          rulingRow("Guinea",        "GIN", "Rally of the Guinean People",             "Rassemblement du Peuple de Guinée"),
          rulingRow("Kenya",         "KEN", "Party of National Unity",                 "Party of National Unity (PNU)"),
          rulingRow("Lesotho",       "LSO", "Lesotho Congress for Democracy",          "Lesotho Congress for Democracy (LCD)"),
          rulingRow("Liberia",       "LBR", "Unity Party",                             "Unity Party (UP)"),
          rulingRow("Madagascar",    "MDG", "Young Malagasies Determined",             "TGV (Tanora malaGasy Vonona)"),
          rulingRow("Malawi",        "MWI", "Peoples' Party",                          "People's Party (PP)"),
          rulingRow("Mali",          "MLI", "Alliance for Democracy in Mali",          "ADEMA – PASJ   (Alliance pour la démocratie au Mali) / Dioncounda Traoré"),
          rulingRow("Mauritius",     "MUS", "Labour Party",                            "Mauritian Labour Party"),
          rulingRow("Morocco",       "MAR", "Party of Justice and Development",        "Party of Justice and Development (P.J.D)"),
          rulingRow("Mozambique",    "MOZ", "Mozambique Liberation Front",             "Frelimo"),
          rulingRow("Namibia",       "NAM", "South West Africa People's Organization", "SWAPO (SWAPO Party of Namibia)"),
          rulingRow("Niger",         "NER", "Nigerien Party for Democ. and Socialism", "Parti Nigérien pour la Démocratie et le Socialisme (PNDS Tarayya)"),
          rulingRow("Nigeria",       "NGA", "People's Democratic Party",               "People’s Democratic Party (PDP)"),
          rulingRow("Senegal",       "SEN", "Alliance for the Republic",               "Alliance Pour la République"),
          rulingRow("Sierra Leone",  "SLE", "All People's Congress",                   "APC"),
          rulingRow("South Africa",  "ZAF", "African National Congress",               "African National Congress (ANC)"),
          rulingRow("Sudan",         "SDN", "National Congress Party",                 "National Congress Party"),
          rulingRow("Tanzania",      "TZA", "Chama Cha Mapinduzi",                     "CCM"),
          rulingRow("Togo",          "TGO", "Union for the Republic",                  "UNIR (Union pour la République) de Faure Essozimna Gnassingbé"),
          rulingRow("Tunisia",       "TUN", "Ennahda Movement",                        "An-Nahda"),
          rulingRow("Uganda",        "UGA", "National Resistance Movement",            "National Resistance Movement [NRM]"),
          rulingRow("Zambia",        "ZMB", "Patriotic Front",                         "Patriotic Front (PF)"),
          rulingRow("Zimbabwe",      "ZWE", "Zimbabwe African National Union",         "Zimbabwe African national Union-Patriotic Front (ZANU-PF)"))
colnames(rptab) <- c("Country", "Begin", "End", "Ruling party", "Prop.")

# Get subset of data, including only countries with ethnic group data
e <- a[a$ethnic != "Other", ]
e$country <- factor(e$country)
e <- droplevels(e)

# Get subset of data, including only countries that have both democratic and
# non-democratic years
ad <- a[a$iso3c %in% hasautdem, ]
ad$country <- factor(ad$country)
ad <- droplevels(ad)

# Get subset of data, excluding Algeria because it is not in the Penn World
# Table
ag <- a[a$iso3c != "DZA", ]
ag$country <- factor(ag$country)
ag <- droplevels(ag)

# Get subset of data, including only countries that have ethnic group data and
# that has both democratic and non-democratic years
ead <- e[e$iso3c %in% hasautdem, ]
ead$country <- factor(ead$country)
ead <- droplevels(ead)


# Table 1:
# OLS: Demand for democracy as dependent variable (control variables only)
fml <- "demDem ~ country + rulingparty + supplDem + sex + poverty + ownership +"
summary(lm(paste(fml, "age + educ + ethOwnership"), data = e))
summary(lm(paste(fml, "age + educ"), data = a))
summary(lm(paste(fml, "age"),    data = a))

# Table 2:
# Percent of Don't know responses on components of Demand for democracy by gender
tab <- cbind(tapply(a$q32, a$q101,
                    function(x) 100 * sum(x == "Don't know", na.rm = TRUE) / length(x)),
             tapply(a$q31a, a$q101,
                    function(x) 100 * sum(x == "Don't Know", na.rm = TRUE) / length(x)),
             tapply(a$q31b, a$q101,
                    function(x) 100 * sum(x == "Don't Know", na.rm = TRUE) / length(x)),
             tapply(a$q31c, a$q101,
                    function(x) 100 * sum(x == "Don't Know", na.rm = TRUE) / length(x)))
colnames(tab) <- c("Supp. Democracy", "Reject one-party", "Reject military", "Reject one-man")
tab

# Table 3:
# OLS: Demand for democracy (no control variables)
summary(lm(demDem ~ country + nautyearsI, data = ad))
summary(lm(demDem ~ country + ndemyearsI, data = ad))
summary(lm(demDem ~ country + meanpiv,    data = a))
summary(lm(demDem ~ country + meanDxGr,   data = ag))

# Table 4:
# OLS: Demand for democracy (no Ethnic affluence)
fml <- "demDem ~ country + sex + educ + poverty + ownership + rulingparty + supplDem + age +"
summary(lm(paste(fml, "nautyearsI"), data = ad))
summary(lm(paste(fml, "ndemyearsI"), data = ad))
summary(lm(paste(fml, "meanpiv"),    data = a))
summary(lm(paste(fml, "meanDxGr"),   data = ag))

# Table 5:
# OLS: Demand for democracy (all control variables)")
fml <- "demDem ~ country + sex + educ + poverty + ownership + ethOwnership + rulingparty + supplDem + age +"
summary(lm(paste(fml, "nautyearsI"), data = ead))
summary(lm(paste(fml, "ndemyearsI"), data = ead))
summary(lm(paste(fml, "meanpiv"),    data = e))
summary(lm(paste(fml, "meanDxGr"),   data = e))

# Table A.1:
# Proportion of respondents, by country, who said they would vote for the ruling party
rptab
