library("foreign")
library("countrycode")

# Data available at http://www.afrobarometer.org/data/merged-data
# Downloaded at 23 July, 2015.
# md5sum of merged_r5_data.sav: 017e1b79e5db36b2b003afb542d8a22a
# Please, save it at the "data" directory.
a <- read.spss("data/merged_r5_data.sav")
varlabels <- attr(a, "variable.labels")
names(varlabels) <- tolower(names(varlabels))
names(a) <- tolower(names(a))
a <- as.data.frame(a, stringsAsFactors = FALSE)

# Fix duplicated levels
a$q84 <- as.character(a$q84)
a$q99 <- as.character(a$q99)

a$dateintr <- ISOdate(1582, 10, 14) + a$dateintr

# Add country code
a$iso3c <- countrycode(a$country, "country.name", "iso3c")

# Number of cases before excluding rows with missing age
ncases <- tapply(a$q1, a$country, function(x) length(x))

# Select variables
a <- a[a$q1 > 0 & a$q1 < 111,
       c("respno", "iso3c", "country", "dateintr", "q1", "q101", "q97",
         "urbrur", "q8a", "q8b", "q8c", "q8d", "q8e", "q25a", "q25b", "q26a",
         "q26b", "q26d", "q26e", "q32", "q31a", "q31b", "q31c", "q84", "q90a",
         "q90b", "q90c", "q92", "q42", "q43", "q99", "livedpoverty",
         "demanddemo", "supplydemo", "withinwt")]

cleanVars <- function(x)
{
    if(is.factor(x))
        x[x == "Missing" | x == "Refused" | x == "Not asked"] <- NA
    x
}
a <- droplevels(as.data.frame(lapply(a, cleanVars), stringsAsFactors = FALSE))

# Add variable labels
varlabels <- sub(".*\\. ", "", varlabels)
for(n in names(varlabels))
    if(!is.null(varlabels[[n]]) && !is.null(a[[n]]))
        attr(a[[n]], "label") <- varlabels[[n]]

summary(a)

save(a, ncases, file = "data/AB_round_5.RData")
