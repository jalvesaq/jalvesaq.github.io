
load("data/AB_round_5.RData")
load("data/piv.RData")
load("data/growthTab.RData")

iso3Af <- levels(factor(a$iso3c))

# The Penn Table covers the period from 1951 to 2011.
# We will fill the periods from 1900 to 1950 and from 2012 to 2013 with NAs.
before <- matrix(rep(NA, 51 * nrow(pennGrowthTabGM)), ncol = 51, nrow = nrow(pennGrowthTabGM))
after <- matrix(rep(NA, 2 * nrow(pennGrowthTabGM)), ncol = 2, nrow = nrow(pennGrowthTabGM))
rownames(before) <- rownames(after) <- rownames(pennGrowthTabGM)
colnames(before) <- as.character(1900:1950)
colnames(after) <- c("2012", "2013")
growthTabGMpenn <- cbind(before, pennGrowthTabGM, after)

# Add Algeria
gnames <- rownames(growthTabGMpenn)
growthTabGMpenn <- rbind(growthTabGMpenn, rep(NA, ncol(growthTabGMpenn)))
rownames(growthTabGMpenn) <- c(gnames, "DZA")

bpn <- c(colnames(binPivTab), "2013")
binPivTab <- cbind(binPivTab, rep(NA, nrow(binPivTab)))
colnames(binPivTab) <- bpn

# The tables must have the same countries in the same order and must cover years 1901--2013:
pivTab <- pivTab[iso3Af, as.character(1901:2013)]
binPivTab <- binPivTab[iso3Af, as.character(1901:2013)]
growthTabGMpenn <- growthTabGMpenn[iso3Af, as.character(1901:2013)]
binDemTab <- binDemTab[iso3Af, as.character(1901:2013)]

if(sum(iso3Af %in% rownames(pivTab)) != length(iso3Af))
    cat("Error: Missing countries in pivTab\n")
if(sum(iso3Af %in% rownames(growthTabGMpenn)) != length(iso3Af))
    cat("Error: Missing countries in growthTabGMpenn\n")

if(!identical(colnames(pivTab), colnames(growthTabGMpenn)) ||
   !identical(rownames(pivTab), rownames(growthTabGMpenn)) ||
   !identical(colnames(pivTab), colnames(binPivTab)) ||
   !identical(rownames(pivTab), rownames(binPivTab)))
    cat("ERROR: column or row names mismatch\n")

pivTab5 <- pivTab - 5

DxGrTab <- growthTabGMpenn * pivTab5

a$meanpiv <- rep(NA, nrow(a))
a$meanDxGr <- rep(NA, nrow(a))
a$ndemyearsI <- rep(NA, nrow(a))
a$nautyearsI <- rep(NA, nrow(a))

a$date.n <- as.numeric(as.character(a$dateintr, format = "%Y"))

y13 <- a$date.n - a$q1 + 13
y17 <- a$date.n - a$q1 + 17
y18 <- a$date.n - a$q1 + 18
for(i in 1:nrow(a)){
    a$meanpiv[i] <- mean(pivTab[a$iso3c[i], as.character(y18[i]:a$date.n[i])], na.rm = TRUE)
    a$meanDxGr[i] <- mean(DxGrTab[a$iso3c[i], as.character(y18[i]:a$date.n[i])], na.rm = TRUE)
    a$ndemyearsI[i] <- sum(binPivTab[a$iso3c[i], as.character(y18[i]:a$date.n[i])] > 0, na.rm = TRUE)
    a$nautyearsI[i] <- sum(binPivTab[a$iso3c[i], as.character(y18[i]:a$date.n[i])] <= 0, na.rm = TRUE)
}

# Check missing values by country:
cat("Number of missing values by country\n")
data.frame(meanpiv = tapply(a$meanpiv, a$country, function(x) sum(is.na(x))),
           meanDxGr = tapply(a$meanDxGr, a$country, function(x) sum(is.na(x))),
           ndemyearsI = tapply(a$ndemyearsI, a$country, function(x) sum(is.na(x))),
           nautyearsI = tapply(a$nautyearsI, a$country, function(x) sum(is.na(x))))

exposure <- a[, c("respno", "meanpiv", "meanDxGr", "ndemyearsI", "nautyearsI")]
save(exposure, file = "data/exposure.RData")
