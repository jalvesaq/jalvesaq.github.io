
###############################################################################
###   Os bancos de dados no formato .sav foram obtidos em www.cis.org.br    ###
###   (1988, 1995, 2001 e 2005). O de 1976 foi comprado do IBGE e os        ###
###   demais foram ou obtidos em www.ibge.gov.br (2007 e 2009).             ###
###############################################################################

source("tipofam.R")
library(foreign)
library(descr)
library(gdata)
library(memisc)

###############################################################################
###                                PNAD 1976                                ###
system("awk -F '' '{if($11 == 2) {print $0}}' /tmp/PNAD76BR.DAT > /tmp/pessoas.dat")
pnad76 <- read.fwf(file = "/tmp/pessoas.dat",
                   widths = c(2, 8, -1, 1, -1, 2, -5, 1, -21, 1, -9, 2, -350, 6, -3, 1),
                   col.names = c("uf", "control", "sexo", "idade", "conddom", "casada", "filhos", "peso", "cor"),
                   as.is = TRUE)
pnad76$filhos[pnad76$filhos == 99] <- NA
# Dois NAs nos pesos
pnad76$peso <- as.numeric(pnad76$peso)
pnad76 <- subset(pnad76, is.na(peso) == FALSE)
pnad76$sexo <- factor(pnad76$sexo, levels = c(1, 2), labels = c("Homem", "Mulher"))
pnad76$conddom <- factor(pnad76$conddom,
                         levels = c(1, 2, 3, 4, 5, 6, 7, 8, 9),
                         labels = c("Chefe de família", "Cônjuge", "Filho(a)/enteado", "Pais ou sogros",
                                    "Outros parentes", "Agregado", "Pension/hóspede", "Empregado dom",
                                    "Individual dom. col"))
pnad76$casada <- factor(pnad76$casada,
                        levels = c(1, 2, 3, 4, 5, 6, 7, 8, 9),
                        labels = c("Civil e relig", "Só civil", "Só religioso", "Outra (casado)",
                                   "Solteiro", "Separado", "Desquitado/divorciado", "Viúvo", "Sem declaração"))
pnad76$cor <- factor(pnad76$cor, levels = c(1, 2, 3, 4),
                     labels = c("Branca", "Preta", "Amarela", "Parda"), exclude = 5)
pnad76$uf <- factor(pnad76$uf,
                    levels = c(11, 21, 31, 32, 33, 41, 43, 51, 52, 53, 54, 55, 56, 57, 58, 59, 61, 71, 72, 73, 74, 75, 76, 77, 78),
                    labels = c("RJ", "SP", "PR", "SC", "RS", "MG", "ES", "MA", "PI", "CE", "RN", "PB", "PE", "AL",
                               "SE", "BA", "DF", "RO", "AC", "AM", "RR", "PA", "AP", "MT", "GO"))
save(pnad76, file = "pnad76.RData")

quit(save = "no")
