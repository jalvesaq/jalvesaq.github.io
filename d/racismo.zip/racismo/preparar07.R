
source("tipofam.R")
library(foreign)
library(descr)
library(gdata)
library(memisc)

###############################################################################
###                                PNAD 2007                                ###
pnad07 <- read.fwf(file = "/tmp/PES2007.TXT",
              widths = c(-4, 2, 6, 3, 2, 1, -8, 3, 1, 1, 1, 1, -634, 2, -44, 12, -24, 2, -3, 1, 5, -29, 12),
              col.names = c("uf", "controle", "serie", "ordem", "sexo", "idade", "conddom", "condfam", "numfam",
                            "cor", "estudo", "renda", "tipofam", "urbana", "peso", "rendafam"))

pnad07$uf <- factor(pnad07$uf,
               levels = c(11, 12, 13, 14, 15, 16, 17, 21, 22, 23, 24, 25, 26, 27, 28, 29, 31, 32, 33, 35, 41, 42, 43, 50, 51, 52, 53),
               labels = c("RO", "AC", "AM", "RR", "PA", "AP", "TO", "MA", "PI", "CE", "RN", "PB", "PE", "AL", "SE", "BA",
                          "MG", "ES", "RJ", "SP", "PR", "SC", "RS", "MS", "MT", "GO", "DF"))
pnad07$sexo <- factor(pnad07$sexo, levels = c(2, 4), labels = c("Masculino", "Feminino"))
pnad07$conddom <- factor(pnad07$conddom, levels = c(1, 2, 3, 4, 5, 6, 7, 8),
                    labels = c("Pessoa de referência", "Cônjuge", "Filho", "Outro parente", "Agregado",
                             "Pensionista", "Empregado doméstico", "Parente do empregado doméstico"))
pnad07$condfam <- factor(pnad07$condfam, levels = c(1, 2, 3, 4, 5, 6, 7, 8),
                    labels = c("Pessoa de referência", "Cônjuge", "Filho", "Outro parente", "Agregado",
                             "Pensionista", "Empregado doméstico", "Parente do empregado doméstico"))
pnad07$cor <- factor(pnad07$cor, levels = c(0, 2, 4, 6, 8, 9),
                exclude = 9,
                labels = c("Indígena", "Branca", "Preta", "Amarela", "Parda"))
pnad07$renda[pnad07$renda == 999999999999] <- NA
pnad07$rendafam[pnad07$rendafam == 999999999999] <- NA
pnad07$tipofam <- factor(pnad07$tipofam, levels = c(1, 2, 3, 4, 5, 6, 7, 8, 9, 10),
                    labels = c("Casal sem filhos", "Casal com todos os filhos menores de 14 anos",
                             "Casal com todos os filhos de 14 anos ou mais",
                             "Casal com filhos menores de 14 anos e de 14 anos ou mais",
                             "Casal com filhos sem declaração de idade dos filhos",
                             "Mãe com todos os filhos menores de 14 anos",
                             "Mãe com todos os filhos de 14 anos ou mais",
                             "Mãe com filhos menores de 14 anos e de 14 anos ou mais",
                             "Mãe com filhos sem declaração de idade dos filhos", "Outros tipos de família"))
pnad07$urbana <- recode(pnad07$urbana,
                   "Urbana" <- c(1, 2, 3),
                   "Rural" <- c(4, 5, 6, 7, 8))
pnad07$estudo <- factor(pnad07$estudo, levels = c(1, 2, 3, 4, 5, 6, 7),
                   exclude = 7,
                   labels = c("Sem instrução e menos de 1 ano", "1 a 3 anos", "4 a 7 anos", "8 a 10 anos", "11 a 14 anos", "15 anos ou mais"))
dd <- order(pnad07$uf, pnad07$controle, pnad07$serie, pnad07$numfam)
pnad07 <- pnad07[dd, ]
# Corrigindo um erro no banco de dados da PNAD:
# A PNAD considerou uma empregada doméstica de 27 anos com sua filha de 3
# como constituidoras da segunda família de um domicílio composto por 7
# indivíduos, mas continuou classificando as duas pessoas como "Empregado
# doméstico" e "Parente do empregado doméstico".
pnad07$condfam[290732] <- "Pessoa de referência"
pnad07$condfam[290733] <- "Filho"
idfam <- 100 * pnad07$controle + 10 * pnad07$serie + pnad07$numfam
iddom <- 100 * pnad07$controle + pnad07$serie
pnad07$tf <- TipoFam(iddom, idfam, pnad07$numfam, pnad07$conddom, pnad07$condfam, pnad07$sexo, pnad07$idade)
pnad07$tf <- factor(pnad07$tf)
save(pnad07, file = "pnad07.RData")
rm(dd,iddom,idfam, pnad07)

quit(save = "no")
