
source("tipofam.R")
library(foreign)
library(descr)
library(gdata)
library(memisc)

###############################################################################
###                                PNAD 2005                                ###
b <- read.spss("/tmp/pes2005.sav")
pnad05 <- b[c("UF", "V0102", "V0103", "V0301", "V0302", "V8005", "V0401",
              "V0402", "V0403", "V0404", "V0405", "V0406", "V5030", "V0601",
              "V0607", "V0701", "V9892", "V4704", "V4705", "V4706", "V4707",
              "V4809", "V4810", "V4720", "V4722", "V4723", "V4726", "V4728",
              "V4729", "V4738", "V4742")]
names(pnad05) <- c("uf", "controle", "serie", "ordem", "sexo", "idade",
                   "conddom", "condfam", "numfam", "cor", "maeviva",
                   "maeaqui", "ufnasceu", "alfabet", "escola", "trabalhou",
                   "idadetrab", "pea", "ocupado", "posicao", "horassemana",
                   "atividade", "ocupacao", "renda", "rendafam", "tipofam",
                   "rendafam2", "urbana", "peso", "estudo", "rendadompc")
pnad05 <- toUTF8(pnad05)
pnad05 <- as.data.frame(pnad05)
pnad05 <- trim(pnad05)
pnad05$renda[pnad05$renda == 999999999999] <- NA
pnad05$rendafam[pnad05$rendafam == 999999999999] <- NA
pnad05$rendafam2[pnad05$rendafam2 == 999999999999] <- NA
pnad05$rendadompc[pnad05$rendadompc == 999999999999] <- NA
levels(pnad05$uf) <- c("AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG",
                       "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO")
pnad05$urbana <- recode(pnad05$urbana,
                        "Rural" <- c("RURAL - Aglomerado rural de extensão urbana",
                                     "RURAL - Aglomerado rural, isolado, núcleo",
                                     "RURAL - Aglomerado rural, isolado, outros aglomerados",
                                     "RURAL - Aglomerado rural, isolado, povoado",
                                     "RURAL – Zona rural exclusive aglomerado rural"),
                        "Urbana" <- c("URBANA - Área urbana isolada",
                                      "URBANA - Cidade ou vila, área não-urbanizada",
                                      "URBANA - Cidade ou vila, área urbanizada"))
pnad05$estudo <- recode(pnad05$estudo,
                        "<= 1 ano" <- "Sem instrução e menos de 1 ano",
                        "1 a 3 anos" <- "1 a 3 anos",
                        "4 a 7 anos" <- "4 a 7 anos",
                        "8 a 10 anos" <- "8 a 10 anos",
                        "11 a 14 anos" <- "11 a 14 anos",
                        "15 anos ou mais" <- "15 anos ou mais")
dd <- order(pnad05$uf, pnad05$controle, pnad05$serie, pnad05$numfam)
pnad05 <- pnad05[dd, ]
idfam <- 100 * pnad05$controle + 10 * pnad05$serie + pnad05$numfam
iddom <- 100 * pnad05$controle + pnad05$serie
pnad05$tf <- TipoFam(iddom, idfam, pnad05$numfam, pnad05$conddom, pnad05$condfam, pnad05$sexo, pnad05$idade)
pnad05$tf <- factor(pnad05$tf)
save(pnad05, file = "pnad05.RData")
rm(b, dd,iddom,idfam, pnad05)

quit(save = "no")
