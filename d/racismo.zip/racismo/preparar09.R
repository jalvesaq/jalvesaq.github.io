
source("tipofam.R")
library(foreign)
library(descr)
library(gdata)
library(memisc)

###############################################################################
###                                PNAD 2009                                ###
load("/tmp/dicPNAD2009.RData")
# Há códigos repetidos no dicionário:
dicpes2009$cod[58] <- "V0611a"
dicpes2009$cod[59] <- "V0611b"
fim <- dicpes2009$inicio + dicpes2009$tamanho - 1
fwf2csv("/tmp/PES2009.TXT", "/tmp/pessoas09.txt", dicpes2009$cod, dicpes2009$inicio, fim)
linhas <- readLines("/tmp/pessoas09.txt")
linhas <- gsub(" \t", "\t", linhas)
writeLines(linhas, "pessoas09b.txt")
rm(linhas, dicdom2009, dicpes2009, fim)
gc()

p09 <- read.delim("pessoas09b.txt", as.is = TRUE)

p09$uf <- sub("(..)......", "\\1", p09$V0102)
p09$uf <- as.numeric(p09$uf)

nomes <- c("uf", "controle", "serie", "ordem", "sexo", "idade", "conddom",
           "condfam", "numfam", "cor", "estudo", "renda", "tipofam", "urbana",
           "peso", "rendafam")
colunas <- c("uf", "V0102", "V0103", "V0301", "V0302", "V8005", "V0401",
             "V0402", "V0403", "V0404", "V4803", "V4719", "V4723", "V4728",
             "V4729", "V4750")

# para conferir:
cbind(colunas, nomes)

pnad09 <- p09[, colunas]
names(pnad09) <- nomes

pnad09$uf <- factor(pnad09$uf,
               levels = c(11, 12, 13, 14, 15, 16, 17, 21, 22, 23, 24, 25, 26, 27, 28, 29, 31, 32, 33, 35, 41, 42, 43, 50, 51, 52, 53),
               labels = c("RO", "AC", "AM", "RR", "PA", "AP", "TO", "MA", "PI", "CE", "RN", "PB", "PE", "AL", "SE", "BA",
                          "MG", "ES", "RJ", "SP", "PR", "SC", "RS", "MS", "MT", "GO", "DF"))
pnad09$sexo <- factor(pnad09$sexo, levels = c(2, 4), labels = c("Masculino", "Feminino"))
pnad09$conddom <- factor(pnad09$conddom, levels = c(1, 2, 3, 4, 5, 6, 7, 8),
                    labels = c("Pessoa de referência", "Cônjuge", "Filho", "Outro parente", "Agregado",
                             "Pensionista", "Empregado doméstico", "Parente do empregado doméstico"))
pnad09$condfam <- factor(pnad09$condfam, levels = c(1, 2, 3, 4, 5, 6, 7, 8),
                    labels = c("Pessoa de referência", "Cônjuge", "Filho", "Outro parente", "Agregado",
                             "Pensionista", "Empregado doméstico", "Parente do empregado doméstico"))
pnad09$cor <- factor(pnad09$cor, levels = c(0, 2, 4, 6, 8, 9),
                exclude = 9,
                labels = c("Indígena", "Branca", "Preta", "Amarela", "Parda"))
pnad09$renda[pnad09$renda == 999999999999] <- NA
pnad09$rendafam[pnad09$rendafam == 999999999999] <- NA
pnad09$tipofam <- factor(pnad09$tipofam, levels = c(1, 2, 3, 4, 5, 6, 7, 8, 9, 10),
                    labels = c("Casal sem filhos", "Casal com todos os filhos menores de 14 anos",
                             "Casal com todos os filhos de 14 anos ou mais",
                             "Casal com filhos menores de 14 anos e de 14 anos ou mais",
                             "Casal com filhos sem declaração de idade dos filhos",
                             "Mãe com todos os filhos menores de 14 anos",
                             "Mãe com todos os filhos de 14 anos ou mais",
                             "Mãe com filhos menores de 14 anos e de 14 anos ou mais",
                             "Mãe com filhos sem declaração de idade dos filhos", "Outros tipos de família"))
pnad09$urbana <- recode(pnad09$urbana,
                   "Urbana" <- c(1, 2, 3),
                   "Rural" <- c(4, 5, 6, 7, 8))
pnad09$estudo <- factor(pnad09$estudo, levels = c(1, 2, 3, 4, 5, 6, 7),
                   exclude = 7,
                   labels = c("Sem instrução e menos de 1 ano", "1 a 3 anos", "4 a 7 anos", "8 a 10 anos", "11 a 14 anos", "15 anos ou mais"))
dd <- order(pnad09$uf, pnad09$controle, pnad09$serie, pnad09$numfam)
pnad09 <- pnad09[dd, ]
idfam <- 100 * pnad09$controle + 10 * pnad09$serie + pnad09$numfam
iddom <- 100 * pnad09$controle + pnad09$serie
pnad09$tf <- TipoFam(iddom, idfam, pnad09$numfam, pnad09$conddom, pnad09$condfam, pnad09$sexo, pnad09$idade)
pnad09$tf <- factor(pnad09$tf)
save(pnad09, file = "pnad09.RData")

quit(save = "no")
