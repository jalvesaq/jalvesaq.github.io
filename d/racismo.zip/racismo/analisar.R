library(descr)
library(memisc)
library(xtable)
options(OutDec = ",", descr.plot = FALSE, width = 74)

analisar <- function(b, ano)
{
    sink(paste("tabelas", ano, sep = ""))
    cat("\n\n\\section{PNAD ", ano, "}\n\n", sep = "")
    b$tipom <- vector(mode = "numeric", length = length(b$tf))
    b$tipom[b$tf == "Casal com filhos gr" | b$tf == "Casal com filhos peq" | b$tf == "Casal com filhos peq e gr"] <- 1
    b$tipom[b$tf == "Mãe com filhos peq" | b$tf == "Mãe com filhos gr" |
          b$tf == "Mãe com filhos peq e gr" | b$tf == "Casal homo femi filhos peq" | 
          b$tf == "Casal homo femi filhos gr" | 
          b$tf == "Casal homo femi filhos peq e gr"] <- 2

    # Calculando a razão de sexo:
    b$ufsit <- paste(as.character(b$uf), as.character(b$urbana))
    b$peso1 <- rep(1, length(b$sexo))
    h <- subset(b, sexo == "Masculino" & idade > 15 & idade < 41)
    m <- subset(b, sexo == "Feminino" & idade > 15 & idade < 41)
    nh <- tapply(h$peso1, h$ufsit, sum)
    nm <- tapply(m$peso1, m$ufsit, sum)
    rsexo <- nh / nm
    rsexo <- data.frame(rsexo = rsexo, ufsit = names(rsexo), stringsAsFactors = FALSE)
    b <- merge(b, rsexo)

    print(xtable(rsexo[order(rsexo$rsexo),], caption = "Razão de sexo"), include.rownames = FALSE,
          floating = FALSE, caption.placement = "top", table.placement = "H", tabular.environment = "longtable")
    rm(h, m, nh, nm, rsexo)

    maes <- subset(b, idade < 40 & sexo == "Feminino" & (b$cor == "Branca" | b$cor == "Preta" | b$cor == "Parda") &
                   (condfam == "Pessoa de referência" | condfam == "Cônjuge") & tipom > 0)

    maes$tipom <- factor(maes$tipom, levels = c(1, 2), labels = c("Casada", "Solteira"))
    maes <- droplevels(maes)

    maes$idader <- cut(maes$idade, breaks = c(0, 20, 33, 50), labels = c("<= 20", "21-33", "34-40"))

    maes$cor2 <- recode(maes$cor,
                        "Parda" <- "Parda",
                        "Branca" <- "Branca",
                        "Preta" <- "Preta")
    maes$cor3 <- recode(maes$cor,
                        "Branca" <- "Branca",
                        "Parda" <- "Parda",
                        "Preta" <- "Preta")

    maes$solteira <- (maes$tipom == "Solteira")

    maes$regiao <- recode(as.factor(as.character(maes$uf)),
                          "Norte" <- c("RO", "AC", "AM", "RR", "PA", "AP"),
                          "Nordeste" <- c("MA", "PI", "CE", "RN", "PB", "PE", "AL", "SE", "BA"),
                          "Centro-Oeste" <- c("DF", "MS", "MT", "GO", "TO"),
                          "Sudeste" <- c("RJ", "SP", "MG", "ES"),
                          "Sul" <- c("PR", "SC", "RS"))

    maes$logrenda <- log(maes$renda + 1)
    maes$logrendafam <- log(maes$rendafam + 1)

    cat("\n\nResumo do Banco de Dados \"maes\":\n")
    cat("\n\\begin{verbatim}\n")
    print(summary(maes))
    cat("\n\\end{verbatim}\n")

    attach(maes)

    # Modelos com duas variáveis:
    cat("\n\nCorrelação entre ser sem cônjuge e Razão de sexo:", cor(solteira, rsexo))
    
    cat("\n\n\n")

    tab <- tapply(solteira, list(regiao, cor3), mean, na.rm = TRUE)
    print(xtable(tab,
                 caption = "Proporção de mães sem cônjuge segundo a Região",
                 align = "lrrr", digits = 3), caption.placement = "top", table.placement = "H")
    cat("\n\n")
    tabb <- compmeans(solteira[cor3 == "Branca"], regiao[cor3 == "Branca"], peso[cor3 == "Branca"], sort=TRUE)
    tabd <- compmeans(solteira[cor3 == "Parda"], regiao[cor3 == "Parda"], peso[cor3 == "Parda"], sort=TRUE)
    tabp <- compmeans(solteira[cor3 == "Preta"], regiao[cor3 == "Preta"], peso[cor3 == "Preta"], sort=TRUE)
    tab <- cbind(tabb[, 1], tabd[, 1], tabp[, 1])
    colnames(tab) <- c("Branca", "Parda", "Preta")
    print(xtable(tab,
                 caption = "Proporção de mães sem cônjuge segundo a Região (valores ponderados)",
                 align = "lrrr", digits = 3), caption.placement = "top", table.placement = "H")

    cat("\n\n\n")
    print(xtable(compmeans(solteira, uf, peso, sort=TRUE), 
                 caption = "Proporção de mães sem cônjuge segundo a Unidade da Federação",
                 align = "lrrr", digits = c(0, 3, 0, 3)), caption.placement = "top", table.placement = "H")

    cat("\n\n\n")
    print(xtable(compmeans(solteira, urbana, peso, sort=TRUE),
                 caption = "Proporção de mães sem cônjuge segundo a situação do domicílio",
                 align = "lrrr", digits = c(0, 3, 0, 3)), caption.placement = "top", table.placement = "H")

    cat("\n\n\n")
    print(xtable(compmeans(solteira, estudo, peso, sort=TRUE),
          caption = "Proporção de mães sem cônjuge segundo o grau de instrução",
          align = "lrrr", digits = c(0, 3, 0, 3)), caption.placement = "top", table.placement = "H")

    
    cat("\n\n\n")
    print(xtable(compmeans(renda, tipom, peso, sort=TRUE), caption = "Renda média das mães, segundo sejam sem cônjuge ou não:",
                 align = "lrrr", digits = c(0, 3, 0, 3)), caption.placement = "top", table.placement = "H")

    cat("\n\n\n")
    print(xtable(compmeans(rendafam, tipom, peso, sort=TRUE), caption = "Renda média familiar, segundo seja a mãe sem cônjuge ou não",
                 align = "lrrr", digits = c(0, 3, 0, 3)), caption.placement = "top", table.placement = "H")

    cat("\n\n\n")
    tab <- compmeans(solteira, cor3, peso)
    print(xtable(tab, caption = "Proporção de mães sem cônjuge segundo a cor",
                 align = "lrrr", digits = c(0, 3, 0, 3)), caption.placement = "top", table.placement = "H")
    pparda <- tab["Parda",1]
    pbranca <- tab["Branca",1]
    ppreta <- tab["Preta",1]
    rm(tab)

    cat("\n\n")
    print(xtable(compmeans(solteira, idader, peso, sort=TRUE),
                 caption = "Probabilidade de ser mãe sem marido segundo a idade",
                 align = "lrrr", digits = c(0, 3, 0, 3)), caption.placement = "top", table.placement = "H")

    if(ano == 2005){
        tib <- compmeans(solteira[cor2 == "Branca"], idade[cor2 == "Branca"], peso[cor2 == "Branca"])
        tip <- compmeans(solteira[cor2 == "Preta"], idade[cor2 == "Preta"], peso[cor2 == "Preta"])
        tid <- compmeans(solteira[cor2 == "Parda"], idade[cor2 == "Parda"], peso[cor2 == "Parda"])
        save(tib, tip, tid, file = "tabIdadeSolt.RData")
    }

    cat("\n\n")
    # Regressões:
    levels(estudo) <- sub("(.........................).*", "\\1", levels(estudo))
    m1 <- glm(solteira ~ cor2 + idader + logrenda + urbana + rsexo, family = binomial(link="logit"))
    m2 <- glm(solteira ~ cor2 + idader + logrenda + urbana + rsexo + regiao, family = binomial(link="logit"))
    m3 <- glm(solteira ~ cor2 + idader + logrenda + urbana + rsexo + regiao + estudo, family = binomial(link="logit"))
    write.mtable(mtable(m1, m2, m3), useDcolumn = FALSE, forLaTeX = TRUE)

    detach(maes)
    rm(maes)

    tipop <- vector(mode = "numeric", length = length(b$tf))
    tipop[b$tf == "Casal com filhos gr" | b$tf == "Casal com filhos peq"
          | b$tf == "Casal com filhos peq e gr"] <- 1
    tipop[b$tf == "Pai com filhos peq" | b$tf == "Pai com filhos gr" |
          b$tf == "Pai com filhos peq e gr"] <- 2
    b <- cbind(b, tipop)
    rm(tipop)
    pais <- subset(b, (idade < 40) & (sexo == "Masculino") &
                   ((condfam == "Pessoa de referência") | (condfam == "Cônjuge"))
                   & (tipop > 0),
                   select = c("cor", "tipop", "peso"))

    pais$tipop <- factor(pais$tipop, levels = c(1, 2), labels = c("Casado", "Solteiro"))
    pais$cor2 <- recode(pais$cor,
                        "Branca" <- "Branca",
                        "Parda" <- "Parda",
                        "Preta" <- "Preta")
    pais$solteiro <- (pais$tipop == "Solteiro")

    attach(pais)
    tab <- compmeans(solteiro, cor2, peso)
    print(xtable(tab, caption = "Proporção de pais sem cônjuge segundo a cor",
                 align = "lrrr", digits = c(0, 3, 0, 3)), caption.placement = "top", table.placement = "H")
    ppardo <- tab["Parda",1]
    pbranco <- tab["Branca",1]
    ppreto <- tab["Preta",1]
    rm(tab)
    detach(pais)

    sink()
    rm(b, pais)
    print(ls())
    cbind(ppreta, pparda, pbranca, ppreto, ppardo, pbranco)
}


# PNAD 1976 deve ser analisada separadamente:
load("pnad76.RData")
pnad76$solteira <- vector(mode = "numeric", length = length(pnad76$casada))
pnad76$solteira[pnad76$casada == "Solteiro" | pnad76$casada == "Desquitado/divorciado" | pnad76$casada == "Viúvo" | pnad76$casada == "Separado"] <- 1
pnad76$solteira[pnad76$casada == "Sem declaração"] <- NA
pnad76$solteira[is.na(pnad76$casada)] <- NA
pnad76$solteira <- factor(pnad76$solteira, levels = c(0, 1), labels = c("Casada", "Solteira"))
# A PNAD 1976 contém informações sobre cor para apenas uma subamostra de 19% das
# pessoas.
maes76 <- subset(pnad76, filhos > 0 & sexo == "Mulher" & idade < 40 & is.na(cor) == FALSE)
tab <- compmeans((maes76$solteira == "Solteira"), maes76$cor, maes76$peso)
tabela <- cbind(tab["Preta",1], tab["Parda",1], tab["Branca",1], NA, NA, NA)
rm(pnad76, maes76, tab)


load("pnad88.RData")
tabela <- rbind(tabela, analisar(pnad88, 1988))
rm(pnad88)

load("pnad95.RData")
tabela <- rbind(tabela, analisar(pnad95, 1995))
rm(pnad95)

load("pnad01.RData")
tabela <- rbind(tabela, analisar(pnad01, 2001))
rm(pnad01)

load("pnad05.RData")
tabela <- rbind(tabela, analisar(pnad05, 2005))
rm(pnad05)

load("pnad07.RData")
tabela <- rbind(tabela, analisar(pnad07, 2007))
rm(pnad07)

load("pnad09.RData")
tabela <- rbind(tabela, analisar(pnad09, 2009))
rm(pnad09)

colnames(tabela) <- c("Pretas", "Pardas", "Brancas", "Pretos", "Pardos", "Brancos")
rownames(tabela) <- c(1976, 1988, 1995, 2001, 2005, 2007, 2009)
save(tabela, file = "dados_para_graficos.RData")


sink("tabelas_maeSolt")
print(xtable(tabela), caption.placement = "top", table.placement = "H")
sink()

anos <- c(1976, 1988, 1995, 2001, 2005, 2007, 2009)
branca <- tabela[, "Brancas"]
parda <- tabela[, "Pardas"]
preta <- tabela[, "Pretas"]


pdf(file= "propMaeSolt.pdf", paper = "special", family="Times", width=5.8, height=4)
par(ps = 10, pty = "m", mar = c(4,4,0.2,0.1))
plot(anos, preta, type="o", pch=21, xlab="Ano", ylab="Proporção", xlim = c(1975, 2010), ylim = c(0.05, 0.3))
lines(anos, parda, lty=2, type="o", pch=22)
lines(anos, branca, lty=3, type="o", pch=23)
legend(1976, 0.30, c("Pretas", "Pardas", "Brancas"), cex=0.8, bty="n", lty = c(1, 2, 3), pch=21:23)
dev.off()

png(file= "propMaeSolt.png", width=5.8, height=4, units = "in", res = 600)
par(ps = 10, pty = "m", mar = c(4,4,0.2,0.1))
plot(anos, preta, type="o", pch=21, xlab="Ano", ylab="Proporção", xlim = c(1975, 2010), ylim = c(0.05, 0.3))
lines(anos, parda, lty=2, type="o", pch=22)
lines(anos, branca, lty=3, type="o", pch=23)
legend(1976, 0.30, c("Pretas", "Pardas", "Brancas"), cex=0.8, bty="n", lty = c(1, 2, 3), pch=21:23)
dev.off()

load("tabIdadeSolt.RData")
tib <- as.data.frame(tib)
tip <- as.data.frame(tip)
tid <- as.data.frame(tid)
anos <- 13:39
len <- dim(tib)[1] - 1
propb <- tib[1:len, 1]
propp <- tip[1:len, 1]
propd <- tid[1:len, 1]

pdf(file= "idadeSolt.pdf", paper = "special", family="Times", width=5.8, height=4)
par(ps = 10, pty = "m", mar = c(4,4,0.2,0.3))
plot(anos, propp, type="l", ylim = c(0.1, 0.75), xlim = c(12, 40), xlab="Idade", ylab="Proporção")
lines(anos, propd, lty = 2)
lines(anos, propb, lty = 3)
legend("topright", legend = c("Pretas", "Pardas", "Brancas"), lty = 1:3, bty = "n")
dev.off()

png(file= "idadeSolt.png", units = "in", width=5.8, height=4, res = 600)
par(ps = 10, pty = "m", mar = c(4,4,0.2,0.3))
plot(anos, propp, type="l", ylim = c(0.1, 0.75), xlim = c(12, 40), xlab="Idade", ylab="Proporção")
lines(anos, propd, lty = 2)
lines(anos, propb, lty = 3)
legend("topright", legend = c("Pretas", "Pardas", "Brancas"), lty = 1:3, bty = "n")
dev.off()

quit(save = "no")

