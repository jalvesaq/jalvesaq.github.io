
source("tipofam.R")
library(foreign)
library(descr)
library(gdata)
library(memisc)


###############################################################################
###                                PNAD 1995                                ###
b <- read.spss("/tmp/pessoas_95.sav")
pnad95 <- b[c("UF", "V0102", "V0103", "V0301", "V0302", "V8005", "V0401",
              "V0402", "V0403", "V0404", "V0502", "V5030", "V0601", "V9892",
              "V1001", "V1002", "V1003", "V1004", "V4701", "V4702", "V4703",
              "V4704", "V4720", "V4721", "V4722", "V4723", "V4726", "V4727",
              "V4728", "V4729")]
names(pnad95) <- c("uf", "controle", "serie", "ordem", "sexo", "idade",
                   "conddom", "condfam", "numfam", "cor", "nasceuaqui",
                   "ufnasceu", "alfabet", "idadetrab", "casado", "tipocasamt",
                   "foicasado", "tiposep", "escola", "escola2", "estudo",
                   "horastrab", "renda", "rendadom", "rendafam", "tipofam",
                   "rendafam2", "area", "urbana", "peso")
pnad95 <- toUTF8(pnad95)
pnad95 <- as.data.frame(pnad95)
pnad95 <- trim(pnad95)
pnad95$renda[pnad95$renda == 999999999999] <- NA
pnad95$rendadom[pnad95$rendadom == 999999999999] <- NA
pnad95$rendafam[pnad95$rendafam == 999999999999] <- NA
levels(pnad95$uf) <- c("AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG",
                       "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO")
pnad95$urbana <- recode(pnad95$urbana,
                        "Rural" <- c("RURAL - Aglomerado rural de extensão urbana",
                                     "RURAL - Aglomerado rural, isolado, núcleo",
                                     "RURAL - Aglomerado rural, isolado, outros aglomerados",
                                     "RURAL - Aglomerado rural, isolado, povoado",
                                     "RURAL – Zona rural exclusive aglomerado rural"),
                        "Urbana" <- c("URBANA - Área urbana isolada",
                                      "URBANA - Cidade ou vila, área não urbanizada",
                                      "URBANA -Cidade ou vila, área urbanizada"))
dd <- order(pnad95$uf, pnad95$controle, pnad95$serie, pnad95$numfam)
pnad95 <- pnad95[dd, ]
idfam <- 100 * pnad95$controle + 10 * pnad95$serie + pnad95$numfam
iddom <- 100 * pnad95$controle + pnad95$serie
pnad95$tf <- TipoFam(iddom, idfam, pnad95$numfam, pnad95$conddom, pnad95$condfam, pnad95$sexo, pnad95$idade)
pnad95$tf <- factor(pnad95$tf)
save(pnad95, file = "pnad95.RData")
rm(b, dd,iddom,idfam, pnad95)

quit(save = "no")

