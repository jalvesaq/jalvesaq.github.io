
source("tipofam.R")
library(foreign)
library(descr)
library(gdata)
library(memisc)

###############################################################################
###                                PNAD 1988                                ###
b <- read.spss("/tmp/PES_88.sav")
pnad88 <- b[c("V101", "V10", "V3", "V9991", "V303", "V304", "V305", "V306", "V307", "V805", "V311", "V501", "V505",
              "V318", "V319", "V602", "V5040", "V5030", "V5010", "V2301", "V2302", "V2303", "V2802", "V2901", "V2902",
              "V3121", "V410")]
names(pnad88) <-c("numdom", "uf", "urbana", "peso", "sexo", "cor", "conddom", "condfam", "numfam", "idade", "alfabet",
                  "trabalhou", "posicao", "estudo", "escola", "renda", "atividade", "ocupacao", "rendafam", "estudopai",
                  "estudomae", "idadetrab", "ufnasceu", "temreligiao", "religiao", "separacao", "rendadom")
pnad88 <- toUTF8(pnad88)
pnad88 <- as.data.frame(pnad88)
pnad88 <- trim(pnad88)
pnad88$renda[pnad88$renda == 999999999] <- NA
pnad88$rendafam[pnad88$rendafam == 999999999] <- NA
pnad88$rendadom[pnad88$rendadom == 999999999] <- NA
levels(pnad88$sexo) <- c("Masculino", "Feminino")
pnad88$conddom <- recode(pnad88$conddom,
                         "Pessoa de referência" <- "CHEFE",
                         "Cônjuge" <- "CONJUGE",
                         "Filho" <- "FILHO",
                         "Outro parente" <- "OUTRO PARENTE",
                         "Agregado" <- "AGREGADO",
                         "Pensionista" <- "PENSIONISTA",
                         "Empregado doméstico" <- "EMPREG DOMESTICO",
                         "Parente do empregado doméstico" <- "PARENTE EMPR DOM")
pnad88$condfam <- recode(pnad88$condfam,
                         "Pessoa de referência" <- "CHEFE",
                         "Cônjuge" <- "CONJUGE",
                         "Filho" <- "FILHO",
                         "Outro parente" <- "OUTRO PARENTE",
                         "Agregado" <- "AGREGADO",
                         "Pensionista" <- "PENSIONISTA",
                         "Empregado doméstico" <- "EMPREG DOMESTICO",
                         "Parente do empregado doméstico" <- "PARENTE EMPR DOM")
pnad88$cor <- recode(pnad88$cor,
                    "Amarela" <- "AMARELA",
                    "Branca" <- "BRANCA",
                    "Parda" <- "PARDA",
                    "Preta" <- "PRETA")
pnad88$numfam <- as.character(pnad88$numfam)
pnad88$numfam <- sub("UMA FAMILIA", "1", pnad88$numfam)
pnad88$numfam <- sub("DUAS FAMILIAS", "2", pnad88$numfam)
pnad88$numfam <- sub("QUATRO FAMILIAS", "4", pnad88$numfam)
pnad88$numfam <- sub("CINCO FAMILIAS", "5", pnad88$numfam)
pnad88$numfam <- sub("SEIS FAMILIAS", "6", pnad88$numfam)
pnad88$numfam <- sub("SETE FAMILIAS", "7", pnad88$numfam)
pnad88$numfam <- sub("OITO FAMILIAS", "8", pnad88$numfam)
pnad88$numfam <- sub("TRES FAMILIAS", "8", pnad88$numfam)
pnad88$numfam <- sub("NOVE FAMILIAS", "9", pnad88$numfam)
pnad88$numfam <- as.numeric(pnad88$numfam)
dd <- order(pnad88$uf, pnad88$numdom, pnad88$numfam)
pnad88 <- pnad88[dd, ]
idfam <- 100 * pnad88$numdom + pnad88$numfam
iddom <- pnad88$numdom
pnad88$tf <- TipoFam(iddom, idfam, pnad88$numfam, pnad88$conddom, pnad88$condfam, pnad88$sexo, pnad88$idade)
pnad88$tf <- factor(pnad88$tf)
save(pnad88, file = "pnad88.RData")
rm(b, dd,iddom,idfam, pnad88)

quit(save = "no")

