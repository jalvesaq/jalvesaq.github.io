
source("tipofam.R")
library(foreign)
library(descr)
library(gdata)
library(memisc)


###############################################################################
###                                PNAD 2001                                ###
b <- read.spss("/tmp/pes2001.sav")
pnad01 <- b[c("uf", "v0102", "v0103", "v0301", "v0302", "v8005", "v0401",
              "v0402", "v0403", "v0404", "v0502", "v5030", "v0601", "v9892",
              "v4701", "v4702", "v4703", "v4757", "v4769", "v4770", "v4721",
              "v4722", "v4723", "v4726", "v4727", "v4728", "v4729")]
names(pnad01) <- c("uf", "controle", "serie", "ordem", "sexo", "idade",
                   "conddom", "condfam", "numfam", "cor", "nasceuaqui",
                   "ufnasceu", "alfabet", "idadetrab", "escola", "escola2",
                   "estudo", "horastrab", "rendatrab", "renda", "rendadom",
                   "rendafam", "tipofam", "rendafam2", "area", "urbana",
                   "peso")
pnad01 <- toUTF8(pnad01)
pnad01 <- as.data.frame(pnad01)
pnad01 <- trim(pnad01)
pnad01$rendatrab[pnad01$rendatrab == 999999999999] <- NA
pnad01$renda[pnad01$renda == 999999999999] <- NA
pnad01$rendadom[pnad01$rendadom == 999999999999] <- NA
pnad01$rendafam[pnad01$rendafam == 999999999999] <- NA
levels(pnad01$uf) <- c("AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG",
                       "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO")
pnad01$urbana <- recode(pnad01$urbana,
                        "Rural" <- c("RURAL - Aglomerado rural de extensão urbana",
                                     "RURAL - Aglomerado rural, isolado, núcleo",
                                     "RURAL - Aglomerado rural, isolado, outros aglomerados",
                                     "RURAL - Aglomerado rural, isolado, povoado",
                                     "RURAL – Zona rural exclusive aglomerado rural"),
                        "Urbana" <- c("URBANA - Área urbana isolada",
                                      "URBANA - Cidade ou vila, área não urbanizada",
                                      "URBANA - Cidade ou vila, área urbanizada"))
dd <- order(pnad01$uf, pnad01$controle, pnad01$serie, pnad01$numfam)
pnad01 <- pnad01[dd, ]
idfam <- 100 * pnad01$controle + 10 * pnad01$serie + pnad01$numfam
iddom <- 100 * pnad01$controle + pnad01$serie
pnad01$tf <- TipoFam(iddom, idfam, pnad01$numfam, pnad01$conddom, pnad01$condfam, pnad01$sexo, pnad01$idade)
pnad01$tf <- factor(pnad01$tf)
save(pnad01, file = "pnad01.RData")
rm(b, dd,iddom,idfam, pnad01)

quit(save = "no")
