
# © 2007 Jakson Alves de Aquino -- Qualquer um pode livremente usar, modificar
# e distribuir este código.

# Esta função cria uma variável "Tipo de família" a partir de dados da PNAD.
# Cada domicílio deve ser receber um número de identificação que o distinga
# dos vizinhos (iddom), e cada família dentro do domicílio deve receber um
# número de identificação que a distinga das famílias "vizinhas" (idfam). Esse
# pode ser o número de série da família ou um número único que pode ser criado
# a partir das variáveis "número do domicílio" e "número da família". Por
# exemplo: idfam <- ndom * 100 + nfam

# O banco de dados deverá ter sido previamente ordenado, como no exemplo:
# load("pnad99.RData")
# attach(pnad99)
# dd <- order(uf, controle, serie, numfam)
# p99 <- pnad99[dd,]
# detach(pnad99)
# attach(p99)
# idfam <- 100 * controle + 10 * serie + numfam
# iddom <- 100 * controle + serie
# p99$tf <- TipoFam(iddom, idfam, numfam, conddom, condfam, sexo, idade)
# rm(dd,iddom,idfam)
# detach(p99)
# p99$tf <- factor(p99$tf)
# attach(p99)
# table(as.numeric(tf), as.numeric(tipofam))

TipoFam <- function(iddom, idfam, numfam, conddom, condfam, sexo, idade){
    if(identical(levels(sexo), c("Feminino", "Masculino")) == FALSE && identical(levels(sexo), c("Masculino", "Feminino")) == FALSE)
        stop("Os 'levels' da variável sexo devem ser: 'Masculino' e 'Feminino'")
    if(identical(levels(conddom), c("Pessoa de referência", "Cônjuge", "Filho", "Outro parente", "Agregado", "Pensionista", "Empregado doméstico", "Parente do empregado doméstico")) == FALSE &&
       identical(levels(conddom), c("Agregado", "Cônjuge", "Empregado doméstico", "Filho", "Outro parente", "Parente do empregado doméstico", "Pensionista", "Pessoa de referência")) == FALSE)
        stop("Os 'levels' de conddom estão errados.")
    if(identical(levels(condfam), c("Pessoa de referência", "Cônjuge", "Filho", "Outro parente", "Agregado", "Pensionista", "Empregado doméstico", "Parente do empregado doméstico")) == FALSE &&
       identical(levels(condfam), c("Agregado", "Cônjuge", "Empregado doméstico", "Filho", "Outro parente", "Parente do empregado doméstico", "Pensionista", "Pessoa de referência")) == FALSE)
        stop("Os 'levels' de condfam estão errados.")

  l <- length(idfam)
  tipoFam <- vector(mode = "numeric", length = l)
  fim <- 1
  pedaco <- l/50
  progresso <- pedaco

  pegandofam <- TRUE

  for(k in 1:2){
    while(fim <= l){
      inicio <- fim
      while(fim <= l && idfam[fim] == idfam[inicio]) fim <- fim + 1
      fim <- fim - 1

      # DEBUG
      if(inicio > l || fim > l){
	cat("Erro INICIOFIM:", inicio, fim, l, "\n")
	return(1)
      }

      if(fim > progresso){
	#cat("  ", sprintf("%3.2f", (100*fim/l)), "%\r", sep = "")
	cat("-", sep = "")
	flush.console()
        progresso <- progresso + pedaco
      }

      temFilho <- FALSE
      temConjuge <- FALSE
      temFilhosP <- FALSE
      temFilhosG <- FALSE
      temFilhosS <- FALSE
      temOutroParen <- FALSE
      numpessref <- -1
      numconj <- -1
      if(pegandofam){ # Testes com variável condfam
        for(i in inicio:fim){
	  if(condfam[i] == "Pessoa de referência") numpessref <- i
	  else if(condfam[i] == "Cônjuge"){
	    temConjuge <- TRUE
	      numconj <- i
	  } else if(condfam[i] == "Filho"){
	    temFilho <- TRUE
	      if(is.na(idade[i]) == FALSE){
	        if(idade[i] < 14) temFilhosP <- TRUE
		  if(idade[i] >= 14) temFilhosG <- TRUE
	      } else temFilhosS <- TRUE
	  } else if(condfam[i] == "Outro parente") temOutroParen <- TRUE
        }
      } else{ # Testes com variável conddom
        for(i in inicio:fim){
	  if(conddom[i] == "Pessoa de referência") numpessref <- i
	  else if(conddom[i] == "Cônjuge"){
	    temConjuge <- TRUE
	      numconj <- i
	  } else if(conddom[i] == "Filho"){
	    temFilho <- TRUE
	      if(is.na(idade[i]) == FALSE){
	        if(idade[i] < 14) temFilhosP <- TRUE
		  if(idade[i] >= 14) temFilhosG <- TRUE
	      } else temFilhosS <- TRUE
	  } else if(conddom[i] == "Outro parente") temOutroParen <- TRUE
        }
      }

      # DEBUG
      if(numpessref == -1){
        cat("Erro PESSREF:", inicio, fim, pegandofam, "\n")
        return(0)
      }
      if(temConjuge && numconj == -1){
        cat("Erro CONJUGE:", inicio, fim, pegandofam, "\n")
        return(0)
      }

      tipo <- 99
      if(inicio == fim) tipo <- 1  else{
        if(temConjuge){ # Casais
          if(sexo[numpessref] == sexo[numconj]){ # Casal homossexual
	    if(sexo[numpessref] == "Feminino"){
              if(temFilho){ # Casal homossexual feminino
	        if(temFilhosP && temFilhosG == FALSE && temFilhosS == FALSE) tipo <- 24
	        else if(temFilhosP == FALSE && temFilhosG && temFilhosS == FALSE) tipo <- 25
	        else if(temFilhosP && temFilhosG && temFilhosS == FALSE) tipo <- 26
	        else if(temFilhosS) tipo <- 27
	        else tipo <- 28
	      } else{
	        if((fim - inicio) == 1) tipo <- 29
	        else if(temOutroParen) tipo <- 30
	        else tipo <- 31
	      }
	    } else{ # Casal homossexual masculino
              if(temFilho){
	        if(temFilhosP && temFilhosG == FALSE && temFilhosS == FALSE) tipo <- 32
	        else if(temFilhosP == FALSE && temFilhosG && temFilhosS == FALSE) tipo <- 33
	        else if(temFilhosP && temFilhosG && temFilhosS == FALSE) tipo <- 34
	        else if(temFilhosS) tipo <- 35
	        else tipo <- 36
	      } else{
	        if((fim - inicio) == 1) tipo <- 37
	        else if(temOutroParen) tipo <- 38
	        else tipo <- 39
	      }
	    }
	  } else{ # Casal heterossexual
            if(temFilho){
	      if(temFilhosP && temFilhosG == FALSE && temFilhosS == FALSE) tipo <- 2
	      else if(temFilhosP == FALSE && temFilhosG && temFilhosS == FALSE) tipo <- 3
	      else if(temFilhosP && temFilhosG && temFilhosS == FALSE) tipo <- 4
	      else if(temFilhosS) tipo <- 5
	      else tipo <- 6
	    } else{
	      if((fim - inicio) == 1) tipo <- 7 # Casal sem filhos
	      else if(temOutroParen) tipo <- 8 # Casal sem filhos com outro parente
	      else tipo <- 8
	    }
	  }
        } else{ # Solteiros que não moram só
          if(sexo[numpessref] == "Feminino"){
            if(temFilho){ # Mãe solteira
	      if(temFilhosP && temFilhosG == FALSE && temFilhosS == FALSE) tipo <- 10
	      else if(temFilhosP == FALSE && temFilhosG && temFilhosS == FALSE) tipo <- 11
	      else if(temFilhosP && temFilhosG && temFilhosS == FALSE) tipo <- 12
	      else if(temFilhosS) tipo <- 13
	      else tipo <- 14
	    } else{ # Pessoa de referência é mulher solteira
	      if(temOutroParen) tipo <- 15
	      else tipo <- 16
	    }
	  } else{
            if(temFilho){ # Pai solteiro
	      if(temFilhosP && temFilhosG == FALSE && temFilhosS == FALSE) tipo <- 17
	      else if(temFilhosP == FALSE && temFilhosG && temFilhosS == FALSE) tipo <- 18
	      else if(temFilhosP && temFilhosG && temFilhosS == FALSE) tipo <- 19
	      else if(temFilhosS) tipo <- 20
	      else tipo <- 21
	    } else{ # Pessoa de referência é homem solteiro
	      if(temOutroParen) tipo <- 22
	      else tipo <- 23
	    }
	  }
        }
      }
      for(i in inicio:fim) tipoFam[i] <- tipo
      fim <- fim + 1
    }
    pegandofam <- TRUE
    pedaco <- 500
    fim <- 1
  }
  cat("  ", sprintf("%3.2f", 100), "% \n", sep = "")

  tipoFam <- factor(tipoFam, levels=c(1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
  11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27,
  28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 99), 
  labels=c("Sozinho", "Casal com filhos peq",
  "Casal com filhos gr", "Casal com filhos peq e gr",
  "Casal com filhos idade desc", "Outro tipo de casal com filhos",
  "Casal sem filhos", "Casal sem filhos com outro parente",
  "Outro tipo de casal sem filhos", "Mãe com filhos peq",
  "Mãe com filhos gr", "Mãe com filhos peq e gr",
  "Mãe com filhos idade desc", "Outro tipo de mãe com filhos",
  "Mulher solteira com parentes", "Outro tipo de mulher solteira",
  "Pai com filhos peq", "Pai com filhos gr", "Pai com filhos peq e gr",
  "Pai com filhos idade desc", "Outro tipo de pai com filhos",
  "Homem solteiro com parentes", "Outro tipo de homem solteiro",
  "Casal homo femi filhos peq", "Casal homo femi filhos gr",
  "Casal homo femi filhos peq e gr", "Casal homo femi filhos idade desc",
  "Outro tipos de casal homo femi com filhos", "Casal homo femi sem filhos",
  "Casal homo femi sem filhos com outro parente",
  "Outro tipo de casal homo femi sem filhos", "Casal homo masc filhos peq",
  "Casal homo masc filhos gr", "Casal homo masc filhos peq e gr",
  "Casal homo masc filhos idade desc",
  "Outro tipo de casal homo masc com filhos", "Casal homo masc sem filhos",
  "Casal homo masc sem filhos com outro parente",
  "Outro tipo de casal homo masc sem filhos", "Erro de codificação"))

  tipoFam
}
