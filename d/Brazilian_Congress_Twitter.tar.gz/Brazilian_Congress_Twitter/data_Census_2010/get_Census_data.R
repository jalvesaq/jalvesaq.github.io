# The goal of this script is to extract from 2010 IBGE Sample of the Census
# data the variables that will be useful for the paper.

# The data used in the paper were downloaded on August 06, 2012 from 
# ftp://ftp.ibge.gov.br/Censos/Censo_Demografico_2010/Resultados_Gerais_da_Amostra/Microdados

library(bit64)
library(data.table)

# Data documentation:
if(!file.exists("Documentacao.zip"))
    download.file("ftp://ftp.ibge.gov.br/Censos/Censo_Demografico_2010/Resultados_Gerais_da_Amostra/Microdados/Documentacao.zip", 
                  "Documentacao.zip")

# Files to download:
for(uf in c("AC.zip", "AP.zip", "DF.zip", "MA.zip", "MT.zip", "PE.zip",
            "RJ.zip", "RR.zip", "SE.zip", "TO.zip", "AL.zip", "BA.zip",
            "ES.zip", "MG.zip", "PA.zip", "PI.zip", "RN.zip", "RS.zip",
            "SP1.zip", "AM.zip", "CE.zip", "GO.zip", "MS.zip", "PB.zip",
            "PR.zip", "RO.zip", "SC.zip", "SP2-RM.zip"))
    if(!file.exists(uf))
        download.file(paste0("ftp://ftp.ibge.gov.br/Censos/Censo_Demografico_2010/Resultados_Gerais_da_Amostra/Microdados/", uf),
                      uf)

# Unzip files:
dir.create("/tmp/censo2010")
extractData <- function(nome, numero, compl = "")
{
    arq <- paste0(nome, ".zip")
    if(!file.exists(arq))
        stop(paste("File not found:", arq))
    unzip(arq, paste0(nome, "/Pessoas/Amostra_Pessoas_", numero, compl, ".txt"), exdir = "/tmp/censo2010", junkpaths = TRUE)
}

extractData("AC", 12)
extractData("AL", 27)
extractData("AM", 13)
extractData("AP", 16)
extractData("BA", 29)
extractData("CE", 23)
extractData("DF", 53)
extractData("ES", 32)
extractData("GO", 52)
extractData("MA", 21)
extractData("MG", 31)
extractData("MS", 50)
extractData("MT", 51)
extractData("PA", 15)
extractData("PB", 25)
extractData("PE", 26)
extractData("PI", 22)
extractData("PR", 41)
extractData("RJ", 33)
extractData("RN", 24)
extractData("RO", 11)
extractData("RR", 14)
extractData("RS", 43)
extractData("SC", 42)
extractData("SE", 28)
extractData("SP1", 35, "_outras")
extractData("SP2-RM", 35, "_RMSP")
extractData("TO", 17)

# Concatenate relevant columns of all files (may take some minutes):
system("./createCSV.sh")

br <- fread(paste0("/tmp/censo_brasil_2010.csv"), header = TRUE, sep = ";")

br$sex <- factor(br$sex, levels = c(1, 2), labels = c("Male", "Female"))
br$urb <- factor(br$urb, levels = c(1, 2), labels = c("Urban", "Rural"))
br$educ <- factor(br$educ, levels = c(1, 2, 3, 4, 5),
                   labels = c("No instruction and incomplete basic", "Complete basic and incomplete high school",
                              "Complete high school and incomplete higher education", "Complete higher education", "Undefined"))

br$weight <- br$weight / 10000000000000

br$muni <- paste0(br$uf, gsub(" ", "0", format(br$muni, width = 5)))

br <- br[br$age > 16 & br$age < 80, ]
gc()

br$muni <- as.factor(br$muni)
b <- split(br, br$muni)

calcProp <- function(x)
{
    p <- x$educ == "Complete higher education"
    p[is.na(p)] <- FALSE
    p <- as.numeric(p)
    p <- p * x$weight
    sum(p) / sum(x$weight)
}
propsup <- sapply(b, calcProp)

calcProp <- function(x)
{
    p <- x$urb == "Urban"
    p[is.na(p)] <- FALSE
    p <- as.numeric(p)
    p <- p * x$weight
    sum(p) / sum(x$weight)
}
propurb <- sapply(b, calcProp)

calcAvIncome <- function(x)
{
    x <- x[!is.na(x$income), ]
    x$income <- x$income * x$weight
    sum(x$income) / sum(x$weight)
}
av.income <- sapply(b, calcAvIncome)


muni <- names(propsup)
uf <- sub("^(..).*", "\\1", muni)
br <- data.frame(uf, muni, propsup, propurb, av.income)

save(br, file = "censo2010.RData")

