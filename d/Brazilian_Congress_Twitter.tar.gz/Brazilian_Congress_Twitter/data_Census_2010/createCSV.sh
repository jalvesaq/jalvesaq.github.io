#!/bin/sh

echo "uf;muni;weight;urb;sex;age;educ;income" > /tmp/censo_brasil_2010.csv
cat /tmp/censo2010/*.txt | awk -F '' '{OFS =";"
print $1 $2, $3 $4 $5 $6 $7, $29 $30 $31 $32 $33 $34 $35 $36 $37 $38 $39 $40 $41 $42 $43 $44, $53, $58, $62 $63 $64, $158, $247 $248 $249 $250 $251 $252 $253}' >> /tmp/censo_brasil_2010.csv 

