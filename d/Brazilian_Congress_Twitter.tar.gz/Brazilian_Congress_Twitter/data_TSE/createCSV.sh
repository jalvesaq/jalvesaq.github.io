#!/bin/sh

echo "uf;cod.muni;muni;cargo;nome.urna;nome;fxet;sexo;partido;coligacao;votos" > /tmp/brasil_2010.csv
cat /tmp/br2010/*.txt | dos2unix | sed -e 's/"//g' | awk -F ';' '{OFS =";"
print $8, $9, $10, $13, $15, $16, $24, $26, $28, $30, $35}' >> /tmp/brasil_2010.csv

