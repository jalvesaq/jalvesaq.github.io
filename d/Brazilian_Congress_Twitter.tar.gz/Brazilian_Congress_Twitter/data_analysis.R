# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#                                                                             #
# This script replicates the Figures, Tables and other information presented  #
# in the paper:                                                               #
#                                                                             #
#           CONGRESSMEN IN THE AGE OF THE SOCIAL NETWORK SITES:               #
#               Brazilian Representatives and Twitter Use                     #
#                                                                             #
#                 Francisco Paulo Jamil Almeida Marques                       #
#                         Jakson Alves de Aquino                              #
#                               Edna Miola                                    #
#                                                                             #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #


library(psych)
library(descr)
library(gdata)
library(memisc)
library(car)


###############################################################################
##  I - Data manipulation
###############################################################################

# Deal with address changes:
updateTwitterAddress <- function(x)
{
    x <- sub("^BrunaFurlan_$",     "DepBrunaFurlan",   x)
    x <- sub("^erundinapsb$",      "luiza_erundina",   x)
    x <- sub("^deputadoamauri$",   "DeputadoAmauri",   x)
    x <- sub("^acmneto_25$",       "acmneto_",         x)
    x <- sub("^acmnetodeputado$",  "acmneto_",         x)
    x <- sub("^BrunaFurlan_$",     "DepBrunaFurlan",   x)
    x <- sub("^soumarinho10$",     "dpmarciomarinho",  x)
    x <- sub("^VOLTAJAIRO$",       "JAIROPREFEITO25",  x)
    x <- sub("^depcarlinhos$",     "carlinhos13sjc",   x)
    x <- sub("^CELIAROCHA_AL$",    "CELIAROCHA14",     x)
    x <- sub("^eholandajunior$",   "edvaldoholandaj",  x)
    x <- sub("^depgeorgehilton$",  "GEORGEHILTON10",   x)
    x <- sub("^deputadogilmar$",   "GilmarMachado_",   x)
    x <- sub("^DepJairoAtaide$",   "JAIROPREFEITO25",  x)
    x <- sub("^JoaoPauloPT13$",    "depjoaopaulo",     x)
    x <- sub("^deplelocoimbra$",   "lelocoimbra_",     x)
    x <- sub("^dep_Setim$",        "Setim25",          x)
    x <- sub("^lfm45$",            "lfmfederal",       x)
    x <- sub("^erundinapsb$",      "luiza_erundina",   x)
    x <- sub("^paulinhopdt12$",    "dep_paulinho",     x)
    x <- sub("^SouMaisAmauri$",    "DeputadoAmauri",   x)
    x <- sub("^DeputadoRomero$",   "Romero45CG",       x)
    x <- sub("^teresasurita$",     "Teresa_Surita",    x)
    x <- sub("^TeresaSurita15$",   "Teresa_Surita",    x)
    x <- sub("^Dep_Zoinho$",       "Zoinho__22",       x)
    x <- sub("^pedrotaques123$",   "PedroTaquesMT",    x)
    x <- sub("^vanessasenadora$",  "vanessaprefeita",  x)
    x <- sub("^moka_senador$",     "Senador_Moka",     x)
    x <- sub("^chicodangelo13$",   "chico_dangelo",    x)
    x <- sub("^deputadamanuela$",  "manudeputada",     x)
    x <- sub("^_manuela65$",       "manudeputada",     x)
    x <- sub("^martasenadora$",    "MartaSuplicy_",    x)
    x <- sub("^dep_Audifax$",      "prefeitoAUDIFAX",  x)
    x <- sub("^CELIAROCHA14$",     "PREF_CELIAROCHA",  x)
    x <- sub("^DepOdairCunha$",    "odaircunha_",      x)
    x <- sub("^depsantiago$",      "santiagofederal",  x)
    x
}


pls <- read.csv2("list_of_representatives.csv", stringsAsFactors = FALSE)
pls <- pls[pls$endereco != "-2", ]
pls <- pls[pls$temtwitter != "Teve", ]
xx <- list()

lf <- c("tp_2012-02-23.csv", "tp_2012-03-01.csv", "tp_2012-03-08.csv", "tp_2012-03-15.csv",
        "tp_2012-03-22.csv", "tp_2012-03-29.csv", "tp_2012-04-07.csv", "tp_2012-04-12.csv",
        "tp_2012-04-19.csv", "tp_2012-04-26.csv", "tp_2012-05-03.csv", "tp_2012-05-10.csv",
        "tp_2012-05-17.csv", "tp_2012-05-24.csv", "tp_2012-05-31.csv", "tp_2012-06-07.csv",
        "tp_2012-06-14.csv", "tp_2012-06-21.csv", "tp_2012-06-28.csv", "tp_2012-07-05.csv",
        "tp_2012-07-12.csv", "tp_2012-07-19.csv", "tp_2012-07-26.csv", "tp_2012-08-03.csv",
        "tp_2012-08-09.csv", "tp_2012-08-16.csv", "tp_2012-08-23.csv", "tp_2012-08-30.csv",
        "tp_2012-09-06.csv", "tp_2012-09-13.csv", "tp_2012-09-20.csv", "tp_2012-09-27.csv",
        "tp_2012-10-04.csv", "tp_2012-10-12.csv", "tp_2012-10-18.csv", "tp_2012-10-25.csv",
        "tp_2012-11-02.csv", "tp_2012-11-08.csv", "tp_2012-11-15.csv", "tp_2012-11-22.csv",
        "tp_2012-11-29.csv", "tp_2012-12-06.csv", "tp_2012-12-13.csv", "tp_2012-12-21.csv",
        "tp_2012-12-27.csv", "tp_2013-01-03.csv", "tp_2013-01-10.csv", "tp_2013-01-17.csv",
        "tp_2013-01-24.csv", "tp_2013-01-31.csv", "tp_2013-02-07.csv", "tp_2013-02-14.csv",
        "tp_2013-02-21.csv", "tp_2013-02-28.csv")

for(f in lf){
    x <- read.csv2(paste0("data_Twitter/", f), stringsAsFactors = FALSE)
    x$listed <- NULL
    x$friends <- NULL
    x$favourites <- NULL
    nome <- sub("tp_(.*)\\.csv", "\\1", f)
    xx[[nome]] <- x
}

aaa <- function(x)
{
    x$endereco <- updateTwitterAddress(as.character(x$endereco))
    x
}
xx <- lapply(xx, aaa)

# Rename variables to allow the use of merge().
aaa <- function(x, n)
{
    n <- gsub("-", ".", n)
    colnames(x) <- paste0(names(x), n)
    colnames(x) <- sub("endereco.*", "endereco", names(x))
    x
}
len <- length(xx)
for(i in 1:len){
    xx[[i]] <- aaa(xx[[i]], names(xx)[i])
    err <- pls$endereco %in% xx[[i]]$endereco
    err <- pls$endereco[!err]
    if(length(err) > 0){
        cat("\nERRO", names(xx)[i], "(nome não encontrado em list_of_representatives.csv):",
            paste(err), "\n\n")
    }
}

# Merge data sets
st <- xx[[1]]
for(i in 2:len){
    nrst <- nrow(st)
    oldaddr <- st$endereco
    st <- merge(st, xx[[i]], all = TRUE)
    if(nrst != nrow(st)){
        cat("\n\nERROR: nrow(st)", nrst, nrow(st), names(xx)[i], "\n\n")
        cat(oldaddr, sep = "\n", file = "/tmp/oldaddr")
        cat(st$endereco, sep = "\n", file = "/tmp/newaddr")
    }
}

idx <- grep("statuses", names(st))
stls <- names(st)[idx]
stls <- sub("statuses", "", stls)
ultimodia <- stls[length(stls)]
ultimodiabr <- sub("([0-9][0-9][0-9][0-9])\\.([0-9][0-9])\\.([0-9][0-9])", "\\3/\\2\\/\\1", ultimodia)
primeirodia <- stls[1]
primeirodiabr <- sub("([0-9][0-9][0-9][0-9])\\.([0-9][0-9])\\.([0-9][0-9])", "\\3/\\2\\/\\1", primeirodia)

rm(lf, f, nome, len, aaa, i, x, xx, idx, stls)



# Fill uncollected data with calculated means
st$followers2012.11.29 <- round(st$followers2012.11.22 + (0.33 * (st$followers2012.12.13 - st$followers2012.11.22)))
st$followers2012.12.06 <- round(st$followers2012.11.22 + (0.66 * (st$followers2012.12.13 - st$followers2012.11.22)))
st$statuses2012.11.29 <- round(st$statuses2012.11.22 + (0.33 * (st$statuses2012.12.13 - st$statuses2012.11.22)))
st$statuses2012.12.06 <- round(st$statuses2012.11.22 + (0.66 * (st$statuses2012.12.13 - st$statuses2012.11.22)))



tab <- read.table("representatives.csv", sep = "\t", header = TRUE, quote = "", comment.char = "")
tab$data.inicio <- NULL
tab$sexo <- reorder.factor(tab$sexo, new.order = c(2, 1))
n1 <- nrow(tab)
tab <- tab[tab$casa == "Câmara dos Deputados", ]
n2 <- nrow(tab)
tab$endereco <- updateTwitterAddress(as.character(tab$endereco))



load("props.RData")
votes$unique.name <- iconv(votes$unique.name, to = "ASCII//TRANSLIT")
props$unique.name <- iconv(sub("^...", "", rownames(props)), to = "ASCII//TRANSLIT")

# Build table with unidentified representatives
tab$unique.name <- paste0(as.character(tab$uf), ":", toupper(tab$nome.civil))
tab$unique.name <- iconv(tab$unique.name, to = "ASCII//TRANSLIT")
tmp <- tab$unique.name
civilNameTab <- as.character(tab$nome[is.na(tab$nome.civil)])
if(length(civilNameTab) > 0){
    cat("List of representatives without civil name in data set:\n",
        paste(civilNameTab, collapse = ", "), ".\n", sep = "")
}
tab <- merge(tab, votes)
n3 <- dim(tab)[1]

tab <- merge(tab, props, all.x = TRUE)
n4 <- dim(tab)[1]



# Number of representatives votes by State:
nvd <- data.frame(uf = c("AC", "AL", "AM", "AP", "BA", "CE", "DF", "ES", "GO",
                         "MA", "MG", "MS", "MT", "PA", "PB", "PE", "PI", "PR",
                         "RJ", "RN", "RO", "RR", "RS", "SC", "SE", "SP", "TO"),
                  ndep = c(8, 9, 8, 8, 39, 22, 8, 10, 17, 18, 53, 8, 8, 17,
                           12, 25, 10, 30, 46, 8, 8, 8, 31, 16, 8, 70, 8))
tnv <- data.frame(uf = names(uf.votes), uf.votes = uf.votes)
tnv <- merge(tnv, nvd)
tab <- merge(tab, tnv)



tab$age <- 2012 - tab$ano.de.nascimento
tab$morethanone <- tab$legislaturas.deputados > 1

tab$nome <- as.character(tab$nome)
tab$ldpos <- as.character(tab$cargo.funcao)
tab$cargo.funcao <- NULL
tab$ldpos[tab$ldpos != "Não"] <- "Has"
tab$ldpos[tab$ldpos == "Não"] <- "Doesn't have"
tab$ldpos <- as.factor(tab$ldpos)



ideo <- read.csv2("tarouco_ideology.csv")
ideo$ideo2 <- reorder.factor(ideo$ideo2, new.order = c(3, 1, 2))
ideo$ideo3 <- reorder.factor(ideo$ideo3, new.order = c(5, 3, 1, 2, 4))
tab <- merge(tab, ideo, all.x = TRUE)
tab$ideo1[tab$partido == "PSD"] <- 4.4
tab$ideo2[tab$partido == "PSD"] <- "Centro"
tab$ideo3[tab$partido == "PSD"] <- "Centro"



bc <- tab
bc$hasTwitter <- tab$endereco != "-2"

# Delete representative that don't have Twitter account
tab <- tab[tab$endereco != "-2", ]
n5 <- nrow(tab)

tmp <- tab$endereco
tab <- merge(tab, st)
n6 <- nrow(tab)
nomes6 <- paste(tmp[!(tmp %in% tab$endereco)], collapse = ", ")
if(nomes6 != ""){
    cat("Twitter addresses of representatives deleted while merging data (representative information with Twitter data): ",
        nomes6, ".\n", sep = "")
}

# Delete representatives with too many missing values in Twitter collected data:
ntabna <- apply(tab, 1, function(x) sum(is.na(x)))
nomes5 <- paste(tab$endereco[ntabna > 10], collapse = ", ")
if(nomes5 != ""){
    cat("Twitter addresses of representatives deleted due to high number of missing values on Twitter collected data:\n",
        nomes5, ".\n", sep = "")
}
tab <- tab[ntabna < 11, ]
n7 <- nrow(tab)

# Add date of beginning of Twitter use:
di <- read.table("info_2013-01-29.csv", header = TRUE, sep = ";", stringsAsFactors = FALSE)
di$endereco <- updateTwitterAddress(di$endereco)
di$created <- as.Date(sub(" .*", "", di$created), format = "%Y-%m-%d")
di$twitter.time <- as.numeric((as.Date(ultimodia, format = "%Y.%m.%d") - di$created) / 365)
tmp <- tab$endereco
tab <- merge(tab, di)
n8 <- nrow(tab)
nomes8 <- paste(tmp[!(tmp %in% tab$endereco)], collapse = ", ")
if(nomes8 != ""){
    cat("Twitter addresses of representatives deleted while adding date of creation of Twitter account:\n",
        nomes8, ".\n", sep = "")
}


b <- tab


### Fixing failures in data gathering:
# Congresswoman Manuela:
b <- b[-grep("^manudeputada$", b$endereco), ]
# Congressman Jão Carlos Bacelar:
b <- b[-grep("^JoaoCBacelar$", b$endereco), ]
n9 <- nrow(b)


# Calculus of TPW
tw <- b[, grep("statuses", names(b))]
nna <- apply(tw, 1, function(x) sum(is.na(x)))
if(sum(nna > 5) > 0){
    cat("The following representatives have too many missing values and will be eliminated from the data set:",
        b$endereco[nna > 5], ".\n")
}
b <- b[nna < 6, ]

tw <- b[, grep("statuses", names(b))]
len <- ncol(tw)
tw2 <- tw[, 2:len]
len <- len - 1
tw1 <- tw[, 1:len]
tw <- tw2 - tw1
names(tw) <- sub("statuses", "tuitagem", names(tw))

neglim <- -15
negdep <- b$endereco[apply(tw, 1, function(x) any(x < neglim, na.rm = TRUE))]

tw[tw < 0] <- NA
twm <- apply(tw, 1, mean, na.rm = TRUE)
twsd <- apply(tw, 1, sd, na.rm = TRUE)
b <- cbind(b, tw, twm, twsd)
dias <- names(b)[grep("tuitagem", names(b))]
dias <- sub("tuitagem2012.", "", dias)
dias <- sub("tuitagem2013.", "", dias)
dias <- sub("(..)\\.(..)", "\\2/\\1", dias)
rm(votes, props, tw, twsd, tw1, tw2, len)

# Fix one NA value in followers2013.01.24:
b$followers2013.01.24[is.na(b$followers2013.01.24)] <- b$followers2012.06.28[is.na(b$followers2013.01.24)]

b$logvotes <- log(b$votes)
b$stt <- b[[paste0("statuses", ultimodia)]]
b$logstt <- log(b$stt + 1)
b$logtwm <- log(b$twm + 1)
b$fol <- b[[paste0("followers", ultimodia)]]
b$logfol <- log(b$fol + 1)
b <- droplevels(b)


###############################################################################
##  II - Data analysis
###############################################################################

# Number of representatives with Twitter account on February 28, 2013:
nrow(b)

# Table 1: Summary of average TPW and number of followers
sumDep <- rbind(cbind(min(b$fol), median(b$fol), mean(b$fol), max(b$fol)),
                cbind(min(b$twm), median(b$twm), mean(b$twm), max(b$twm)))
rownames(sumDep) <- c("Number of followers", "Average weekly TPW")
colnames(sumDep) <- c("Minimum", "Median", "Average", "Maximum")
sumDep


# Figure 1: Histograms of absolute and logarithm values of TPW and Number of
# Followers, with kernel density and normal curve
png("fmfigure1.png", width=600, height=225)
par(mfrow = c(1, 4), cex=1)
par(mar = c(4, 4, 1.4, 1)+0.2)
histkdnc(b$twm, xlab = "TPW", main = "", col.cur = c("black", "black"), lty.cur = c(1, 3))
par(mar = c(4, 4, 1.4, 1)+0.2)
histkdnc(b$logtwm, xlab = "log(TPW)", main = "", col.cur = c("black", "black"), lty.cur = c(1, 3))
par(mar = c(4, 4, 1.4, 1)+0.2)
histkdnc(b$fol, xlab = "Followers", main = "", col.cur = c("black", "black"), lty.cur = c(1, 3))
par(mar = c(4, 4, 1.4, 1)+0.2)
histkdnc(b$logfol, xlab = "log(Followers)", main = "", col.cur = c("black", "black"), lty.cur = c(1, 3))
dev.off()

# Number of deputies with TPW of zero:
sum(b$twm == 0)

# Number of individuals with the logarithm of the number of followers two
# standard deviations or more below the mean:
sum(b$logfol < (mean(b$logfol) - 2 * sd(b$logfol)))
# They have 58 followers or less:
max(b$fol[b$logfol < (mean(b$logfol) - 2 * sd(b$logfol))])

# Figure 2: Time series of TPW
png("fmfigure2.png", width = 600, height = 150)
tpw <- b[, grep("tuitagem", names(b))]
ts.tpw <- apply(tpw, 2, mean, na.rm = TRUE)
wk <- sub("tuitagem", "", names(ts.tpw))
wk <- as.Date(wk, format = "%Y.%m.%d")
par(mar = c(4, 4, 0, 0) + 0.2, cex=1)
plot(ts.tpw ~ wk, pch = 20, ylim = c(0, 35), ylab = "Average TPW", xlab = "Time (2012-2013)")
lines(wk, ts.tpw)
dev.off()

# Correlation between TPW and time:
cor(ts.tpw, as.numeric(wk))

# Figure 3: Correlation between number of followers and TPW
png("fmfigure3.png", width = 600, height = 300)
par(mfrow = c(1, 2), mar = c(4, 4, 2, 1)+0.2, cex=1)
plot(b$fol ~ b$twm, xlab = "TPW", ylab = "N. Followers", main = "(a)", col = rgb(0, 0, 0, 0.7))
abline(lm(b$fol ~ b$twm), col = "black")
text(250, 6.8e+5, paste("r =", format(cor(b$fol, b$twm), digits = 2)))
par(mar = c(4, 5, 2, 0)+0.2)
par(lty = 1)
palette("default")
plot(b$logfol ~ b$logtwm, xlab = "log(TPW)", ylab = "log(Followers)", main = "(b)", col = rgb(0, 0, 0, 0.7))
abline(lm(b$logfol ~ b$logtwm), col = "black")
text(1, 13, paste("r =", format(cor(b$logfol, b$logtwm), digits = 2)))
dev.off()

# Scale variables to mean 0 and standard deviation 1:
b3 <- bc
b3$sex <- as.numeric(scale(as.numeric(bc$sexo == "f")))
b3$age <- as.numeric(scale(bc$age))
b3$votes <- as.numeric(scale(bc$votes))
b3$av.income <- as.numeric(scale(bc$av.income))
b3$propsup <- as.numeric(scale(bc$propsup))
b3$propurb <- as.numeric(scale(bc$propurb))
b3$ideo1 <- as.numeric(scale(bc$ideo1))
b3$prop.vote <- as.numeric(scale(bc$votes / bc$uf.votes))
b3$prop.votep <- as.numeric(scale(bc$votes / (bc$uf.votes / bc$ndep)))
b3$morethanone <- as.numeric(scale(as.numeric(bc$morethanone)))
b3$ldpos <- as.numeric(scale(as.numeric(bc$ldpos == "Has")))

mh <- glm(hasTwitter ~ sex + age + morethanone + ldpos + av.income + propsup + propurb + ideo1 + prop.votep,
          data = b3, family = binomial(link = "logit"))


# Scale variables to mean 0 and standard deviation 1:
b2 <- b
tmp <- b$statuses2013.02.28 - b$statuses2012.02.23
b2$logtwm <- as.numeric(scale(b$logtwm))
b2$logfol <- as.numeric(scale(b$logfol))
b2$sex <- as.numeric(scale(as.numeric(b$sexo == "f")))
b2$age <- as.numeric(scale(b$age))
b2$votes <- as.numeric(scale(b$votes))
b2$av.income <- as.numeric(scale(b$av.income))
b2$propsup <- as.numeric(scale(b$propsup))
b2$propurb <- as.numeric(scale(b$propurb))
b2$twitter.time <- as.numeric(scale(b$twitter.time))
b2$ideo1 <- as.numeric(scale(b$ideo1))
b2$prop.vote <- as.numeric(scale(b$votes / b$uf.votes))
b2$prop.votep <- as.numeric(scale(b$votes / (b$uf.votes / b$ndep)))
b2$morethanone <- as.numeric(scale(as.numeric(b$morethanone)))
b2$ldpos <- as.numeric(scale(as.numeric(b$ldpos == "Has")))

mt <- lm(logtwm ~ sex + age + morethanone + ldpos + av.income + propsup +
         propurb + ideo1 + prop.votep + twitter.time, data = b2)
mf <- lm(logfol ~ sex + age + morethanone + ldpos + av.income + propsup +
         propurb + ideo1 + prop.votep + twitter.time, data = b2)


# Table 2: Summaries of regression analyzes
regsum <- mtable("Has Twitter" = mh, "TPW" = mt, "Followers" = mf,
                 summary.stats = c("N", "adj. R-squared", "F"))
regsum <- relabel(regsum,
                  "sex" = "Gender (Female)",
                  "age" = "Age",
                  "morethanone" = "More than one term as deputy (Yes)",
                  "ldpos" = "Has leadership position (Yes)",
                  "av.income" = "Constituency average income",
                  "propsup" = "Constituency with higher education",
                  "propurb" = "Constituency living in urban areas",
                  "ideo1" = "Party ideology",
                  "prop.votep" = "Votes",
                  "twitter.time" = "Time since Twitter account creation")
print(regsum)

# Figure 4: Diagnostic graphics of residuals
png("fmfigure4.png", width = 600, height = 200)
par(mfrow = c(1, 3), cex=1)
par(mar = c(4, 4, 2, 2)+0.2)
plot(cooks.distance(mh), main = "Has Twitter", ylab = "Cook's distance", col = rgb(0, 0, 0, 0.7))
par(mar = c(4, 5, 2, 1)+0.2)
qqPlot(mt, main = "TPW", ylab = "Studentized residuals", col = rgb(0, 0, 0, 0.7), col.lines = "black")
par(mar = c(4, 6, 2, 0)+0.2)
qqPlot(mf, main = "Followers", ylab = "Studentized residuals", col = rgb(0, 0, 0, 0.7), col.lines = "black")
dev.off()


# Correlation between TPW logarithm and average income of constituency:
cor(b$logtwm, b$av.income)

# Correlation between Number of followers logarithm and average income of constituency:
cor(b$logfol, b$av.income)

# For the electorate’s income to have a positive impact and a statistically
# significant effect on Twitter use by parliamentarians, it would be necessary
# to eliminate from the models both the variable indicator of schooling and
# the variable indicator of residence in urban areas:
mh2 <- glm(hasTwitter ~ sex + age + morethanone + ldpos + av.income + ideo1 +
          prop.votep, data = b3, family = binomial(link = "logit"))
mt2 <- lm(logtwm ~ sex + age + morethanone + ldpos + av.income + ideo1 + prop.votep + twitter.time, data = b2)
mf2 <- lm(logfol ~ sex + age + morethanone + ldpos + av.income + ideo1 + prop.votep + twitter.time, data = b2)
print(mtable("Has Twitter" = mh2, "TPW" = mt2, "Followers" = mf2,
             summary.stats = c("N", "adj. R-squared", "F")))

