###############################################################################
# 
#  R script to load the data used at:
#
#  Aquino, Jakson Alves de.
#  The meaning of trust for Brazilians with higher education.
#  Social Indicators Research.
# 
###############################################################################

b <- read.delim("trust.txt", quote = "", as.is = TRUE)

b$tipo <- factor(b$tipo, levels = 1:11,
  labels = c("Amigo (E-mail)", "Amigo (Facebook)", "Cartas entregues no centro", "Centro", "Facebook", 
    "Grupo do Facebook", "Prefeitura", "Rua: Pacoti", "Rua: Redenção", 
    "Universidade", "Via internet"))
b$V4 <- factor(b$V4, levels = 1:4,
  labels = c("Não é importante", "Pouco importante", "Importante", "Muito importante"))
b$V5 <- factor(b$V5, levels = 1:4,
  labels = c("Não é importante", "Pouco importante", "Importante", "Muito importante"))
b$V6 <- factor(b$V6, levels = 1:4,
  labels = c("Não é importante", "Pouco importante", "Importante", "Muito importante"))
b$V7 <- factor(b$V7, levels = 1:4,
  labels = c("Não é importante", "Pouco importante", "Importante", "Muito importante"))
b$V8 <- factor(b$V8, levels = 1:4,
  labels = c("Não é importante", "Pouco importante", "Importante", "Muito importante"))
b$V9 <- factor(b$V9, levels = 1:4,
  labels = c("Não é importante", "Pouco importante", "Importante", "Muito importante"))
b$V10 <- factor(b$V10, levels = 1:4,
  labels = c("Infeliz", "Não muito feliz", "Feliz", "Muito feliz"))
b$V11 <- factor(b$V11, levels = 1:4,
  labels = c("Ruim", "Razoável", "Boa", "Muito boa"))
b$V12 <- factor(b$V12, levels = 1:2,
  labels = c("Não mencionada", "Mencionada"))
b$V13 <- factor(b$V13, levels = 1:2,
  labels = c("Não mencionada", "Mencionada"))
b$V14 <- factor(b$V14, levels = 1:2,
  labels = c("Não mencionada", "Mencionada"))
b$V15 <- factor(b$V15, levels = 1:2,
  labels = c("Não mencionada", "Mencionada"))
b$V16 <- factor(b$V16, levels = 1:2,
  labels = c("Não mencionada", "Mencionada"))
b$V17 <- factor(b$V17, levels = 1:2,
  labels = c("Não mencionada", "Mencionada"))
b$V18 <- factor(b$V18, levels = 1:2,
  labels = c("Não mencionada", "Mencionada"))
b$V19 <- factor(b$V19, levels = 1:2,
  labels = c("Não mencionada", "Mencionada"))
b$V20 <- factor(b$V20, levels = 1:2,
  labels = c("Não mencionada", "Mencionada"))
b$V21 <- factor(b$V21, levels = 1:2,
  labels = c("Não mencionada", "Mencionada"))
b$V23 <- factor(b$V23, levels = 1:2,
  labels = c("É preciso ser muito cuidadoso", "As pessoas são de confiança"))
b$V125a <- factor(b$V125a, levels = 1:4,
  labels = c("Não confia", "Pouco", "Em parte", "Totalmente"))
b$V125 <- factor(b$V125, levels = 1:4,
  labels = c("Não confia", "Pouco", "Em parte", "Totalmente"))
b$V126 <- factor(b$V126, levels = 1:4,
  labels = c("Não confia", "Pouco", "Em parte", "Totalmente"))
b$V127 <- factor(b$V127, levels = 1:4,
  labels = c("Não confia", "Pouco", "Em parte", "Totalmente"))
b$V128 <- factor(b$V128, levels = 1:4,
  labels = c("Não confia", "Pouco", "Em parte", "Totalmente"))
b$V129 <- factor(b$V129, levels = 1:4,
  labels = c("Não confia", "Pouco", "Em parte", "Totalmente"))
b$V130 <- factor(b$V130, levels = 1:4,
  labels = c("Não confia", "Pouco", "Em parte", "Totalmente"))
b$C1apes <- factor(b$C1apes, levels = 1:2,
  labels = c("Não", "Sim"))
b$C1afam <- factor(b$C1afam, levels = 1:2,
  labels = c("Não", "Sim"))
b$C1aami <- factor(b$C1aami, levels = 1:2,
  labels = c("Não", "Sim"))
b$C1acol <- factor(b$C1acol, levels = 1:2,
  labels = c("Não", "Sim"))
b$C1aviz <- factor(b$C1aviz, levels = 1:2,
  labels = c("Não", "Sim"))
b$C1acon <- factor(b$C1acon, levels = 1:2,
  labels = c("Não", "Sim"))
b$C1anin <- factor(b$C1anin, levels = 1:1,
  labels = c("Sim"))
b$C1b <- factor(b$C1b, levels = 1:2,
  labels = c("Experiência própria", "Me ensinaram"))
b$C1c <- factor(b$C1c, levels = 1:7,
  labels = c("Atribuir responsabilidades", "Compartilhar", "Conhecer", "Fidelidade", "Prever", "Sentir-se seguro", "Ter um elo"))
b$C1d <- factor(b$C1d, levels = 1:7,
  labels = c("Amigo guardar segredo", "Companheiro não trair", "Cumprir palavra", "Emprestar coisas", 
    "Estranho realmente ajudar", "Ficar a sós", "Pessoa estar ao lado"))
b$C2ami <- factor(b$C2ami, levels = 1:2,
  labels = c("Não", "Sim"))
b$C2avo <- factor(b$C2avo, levels = 1:2,
  labels = c("Não", "Sim"))
b$C2col <- factor(b$C2col, levels = 1:2,
  labels = c("Não", "Sim"))
b$C2con <- factor(b$C2con, levels = 1:2,
  labels = c("Não", "Sim"))
b$C2cun <- factor(b$C2cun, levels = 1:2,
  labels = c("Não", "Sim"))
b$C2esp <- factor(b$C2esp, levels = 1:2,
  labels = c("Não", "Sim"))
b$C2fil <- factor(b$C2fil, levels = 1:2,
  labels = c("Não", "Sim"))
b$C2gen <- factor(b$C2gen, levels = 1:2,
  labels = c("Não", "Sim"))
b$C2irm <- factor(b$C2irm, levels = 1:2,
  labels = c("Não", "Sim"))
b$C2mae <- factor(b$C2mae, levels = 1:2,
  labels = c("Não", "Sim"))
b$C2nam <- factor(b$C2nam, levels = 1:2,
  labels = c("Não", "Sim"))
b$C2net <- factor(b$C2net, levels = 1:2,
  labels = c("Não", "Sim"))
b$C2nor <- factor(b$C2nor, levels = 1:2,
  labels = c("Não", "Sim"))
b$C2pai <- factor(b$C2pai, levels = 1:2,
  labels = c("Não", "Sim"))
b$C2pes <- factor(b$C2pes, levels = 1:2,
  labels = c("Não", "Sim"))
b$C2pri <- factor(b$C2pri, levels = 1:2,
  labels = c("Não", "Sim"))
b$C2sog <- factor(b$C2sog, levels = 1:2,
  labels = c("Não", "Sim"))
b$C2tio <- factor(b$C2tio, levels = 1:2,
  labels = c("Não", "Sim"))
b$C2viz <- factor(b$C2viz, levels = 1:2,
  labels = c("Não", "Sim"))
b$C3ami <- factor(b$C3ami, levels = 1:2,
  labels = c("Não", "Sim"))
b$C3avo <- factor(b$C3avo, levels = 1:2,
  labels = c("Não", "Sim"))
b$C3col <- factor(b$C3col, levels = 1:2,
  labels = c("Não", "Sim"))
b$C3con <- factor(b$C3con, levels = 1:2,
  labels = c("Não", "Sim"))
b$C3cun <- factor(b$C3cun, levels = 1:2,
  labels = c("Não", "Sim"))
b$C3esp <- factor(b$C3esp, levels = 1:2,
  labels = c("Não", "Sim"))
b$C3fil <- factor(b$C3fil, levels = 1:2,
  labels = c("Não", "Sim"))
b$C3gen <- factor(b$C3gen, levels = 1:2,
  labels = c("Não", "Sim"))
b$C3irm <- factor(b$C3irm, levels = 1:2,
  labels = c("Não", "Sim"))
b$C3mae <- factor(b$C3mae, levels = 1:2,
  labels = c("Não", "Sim"))
b$C3nam <- factor(b$C3nam, levels = 1:2,
  labels = c("Não", "Sim"))
b$C3net <- factor(b$C3net, levels = 1:2,
  labels = c("Não", "Sim"))
b$C3nor <- factor(b$C3nor, levels = 1:2,
  labels = c("Não", "Sim"))
b$C3pai <- factor(b$C3pai, levels = 1:2,
  labels = c("Não", "Sim"))
b$C3pes <- factor(b$C3pes, levels = 1:1,
  labels = c("Não"))
b$C3pri <- factor(b$C3pri, levels = 1:2,
  labels = c("Não", "Sim"))
b$C3sog <- factor(b$C3sog, levels = 1:2,
  labels = c("Não", "Sim"))
b$C3tio <- factor(b$C3tio, levels = 1:2,
  labels = c("Não", "Sim"))
b$C3viz <- factor(b$C3viz, levels = 1:2,
  labels = c("Não", "Sim"))
b$C4ami <- factor(b$C4ami, levels = 1:2,
  labels = c("Não", "Sim"))
b$C4avo <- factor(b$C4avo, levels = 1:2,
  labels = c("Não", "Sim"))
b$C4col <- factor(b$C4col, levels = 1:2,
  labels = c("Não", "Sim"))
b$C4con <- factor(b$C4con, levels = 1:2,
  labels = c("Não", "Sim"))
b$C4cun <- factor(b$C4cun, levels = 1:2,
  labels = c("Não", "Sim"))
b$C4esp <- factor(b$C4esp, levels = 1:2,
  labels = c("Não", "Sim"))
b$C4fil <- factor(b$C4fil, levels = 1:2,
  labels = c("Não", "Sim"))
b$C4gen <- factor(b$C4gen, levels = 1:2,
  labels = c("Não", "Sim"))
b$C4irm <- factor(b$C4irm, levels = 1:2,
  labels = c("Não", "Sim"))
b$C4mae <- factor(b$C4mae, levels = 1:2,
  labels = c("Não", "Sim"))
b$C4nam <- factor(b$C4nam, levels = 1:2,
  labels = c("Não", "Sim"))
b$C4net <- factor(b$C4net, levels = 1:2,
  labels = c("Não", "Sim"))
b$C4nor <- factor(b$C4nor, levels = 1:2,
  labels = c("Não", "Sim"))
b$C4pai <- factor(b$C4pai, levels = 1:2,
  labels = c("Não", "Sim"))
b$C4pes <- factor(b$C4pes, levels = 1:2,
  labels = c("Não", "Sim"))
b$C4pri <- factor(b$C4pri, levels = 1:2,
  labels = c("Não", "Sim"))
b$C4sog <- factor(b$C4sog, levels = 1:2,
  labels = c("Não", "Sim"))
b$C4tio <- factor(b$C4tio, levels = 1:2,
  labels = c("Não", "Sim"))
b$C4viz <- factor(b$C4viz, levels = 1:2,
  labels = c("Não", "Sim"))
b$I1 <- factor(b$I1, levels = 1:5,
  labels = c("Nenhum", "1", "2", "3 a 6", "mais de 6"))
b$I2 <- factor(b$I2, levels = 1:6,
  labels = c("Nunca", "Raramente", "Mensalmente", "Quinzenalmente", "Semanalmente", "Diariamente"))
b$I3 <- factor(b$I3, levels = 1:6,
  labels = c("Nunca", "Raramente", "Mensalmente", "Quinzenalmente", "Semanalmente", "Diariamente"))
b$I4 <- factor(b$I4, levels = 1:6,
  labels = c("Nunca", "Raramente", "Mensalmente", "Quinzenalmente", "Semanalmente", "Diariamente"))
b$I5 <- factor(b$I5, levels = 1:6,
  labels = c("Nunca", "Raramente", "Mensalmente", "Quinzenalmente", "Semanalmente", "Diariamente"))
b$J2 <- factor(b$J2, levels = 1:4,
  labels = c("Nunca", "Às vezes", "Quase sempre", "Sempre"))
b$J3coe <- factor(b$J3coe, levels = 1:2,
  labels = c("Não", "Sim"))
b$J3fal <- factor(b$J3fal, levels = 1:2,
  labels = c("Não", "Sim"))
b$J3idd <- factor(b$J3idd, levels = 1:2,
  labels = c("Não", "Sim"))
b$J3ves <- factor(b$J3ves, levels = 1:2,
  labels = c("Não", "Sim"))
b$V96 <- factor(b$V96, levels = 1:3,
  labels = c("Não faria nunca", "Poderia fazer", "Já fiz"))
b$V96a <- factor(b$V96a, levels = 1:3,
  labels = c("Não faria nunca", "Poderia fazer", "Já fiz"))
b$V97 <- factor(b$V97, levels = 1:3,
  labels = c("Não faria nunca", "Poderia fazer", "Já fiz"))
b$V98 <- factor(b$V98, levels = 1:3,
  labels = c("Não faria nunca", "Poderia fazer", "Já fiz"))
b$V98a <- factor(b$V98a, levels = 1:3,
  labels = c("Não faria nunca", "Poderia fazer", "Já fiz"))
b$V98b <- factor(b$V98b, levels = 1:3,
  labels = c("Não faria nunca", "Poderia fazer", "Já fiz"))
b$A1art <- factor(b$A1art, levels = 1:2,
  labels = c("Não", "Sim"))
b$A1esp <- factor(b$A1esp, levels = 1:2,
  labels = c("Não", "Sim"))
b$A1igr <- factor(b$A1igr, levels = 1:2,
  labels = c("Não", "Sim"))
b$A1mus <- factor(b$A1mus, levels = 1:2,
  labels = c("Não", "Sim"))
b$A1nao <- factor(b$A1nao, levels = 1:1,
  labels = c("Não participa"))
b$A2ass <- factor(b$A2ass, levels = 1:2,
  labels = c("Não", "Sim"))
b$A2nao <- factor(b$A2nao, levels = 1:1,
  labels = c("Não participa"))
b$A2prt <- factor(b$A2prt, levels = 1:2,
  labels = c("Não", "Sim"))
b$A2sin <- factor(b$A2sin, levels = 1:2,
  labels = c("Não", "Sim"))
b$V185 <- factor(b$V185, levels = 1:11,
  labels = c("Africana", "Católico", "Espírita", "Ev.: Adventista", "Evangélico", 
    "Ev.: Assembleia de Deus", "Ev.: Batista", "Ev.: Evangelho Quadrangular", 
    "Judeu", "Mulçumano", "Sem religião"))
b$V186 <- factor(b$V186, levels = 1:8,
  labels = c("Nunca", "Raramente", "Anualmente", "Em dias santos", "Mensalmente", "Quinzenalmente", 
    "Semanalmente", "Mais de uma vez por semana"))
b$V187a <- factor(b$V187a, levels = 1:2,
  labels = c("Não religiosa", "Religiosa"))
b$V187b <- factor(b$V187b, levels = 1:2,
  labels = c("Ateia", "Deísta"))
b$V223 <- factor(b$V223, levels = 1:2,
  labels = c("Não", "Sim"))
b$V224 <- factor(b$V224, levels = 1:2,
  labels = c("Não", "Sim"))
b$V225 <- factor(b$V225, levels = 1:2,
  labels = c("Não", "Sim"))
b$V226 <- factor(b$V226, levels = 1:2,
  labels = c("Não", "Sim"))
b$V227 <- factor(b$V227, levels = 1:2,
  labels = c("Não", "Sim"))
b$V228 <- factor(b$V228, levels = 1:2,
  labels = c("Não", "Sim"))
b$V229 <- factor(b$V229, levels = 1:2,
  labels = c("Não", "Sim"))
b$V230 <- factor(b$V230, levels = 1:2,
  labels = c("Frequentemente", "Raramente"))
b$F1 <- factor(b$F1, levels = 1:2,
  labels = c("Não", "Sim"))
b$F2 <- factor(b$F2, levels = 1:2,
  labels = c("Não", "Sim"))
b$F3 <- factor(b$F3, levels = 1:2,
  labels = c("Não", "Sim"))
b$F4a <- factor(b$F4a, levels = 1:2,
  labels = c("Não", "Sim"))
b$F4b <- factor(b$F4b, levels = 1:2,
  labels = c("Não", "Sim"))
b$V235 <- factor(b$V235, levels = 1:2,
  labels = c("Feminino", "Masculino"))
b$V55 <- factor(b$V55, levels = 1:6,
  labels = c("Casado", "Divorciado", "Morando junto", "Separado", "Solteiro", "Viúvo"))
b$V238 <- factor(b$V238, levels = 1:6,
  labels = c("Fundamental incompleto", "Fundamental completo", "Médio incompleto", "Médio completo", 
    "Superior incompleto", "Superior completo"))
b$V238br <- factor(b$V238br, levels = 1:22,
  labels = c("Administração e Contabilidade", "Arquitetura", "Arquivologia", "Biologia", "Ciências Sociais", "Comunicação", 
    "Design", "Direito", "Economia", "Engenharia", "Estatística", "História", 
    "Filosofia", "Física", "Geografia", "Letras", "Matematica", "Pedagogia", 
    "Psicologia", "Saúde", "Serviço Social", "Não respondeu"))
b$V240 <- factor(b$V240, levels = 1:2,
  labels = c("Não", "Sim"))
b$V241 <- factor(b$V241, levels = 1:6,
  labels = c("Autônomo", "Desempregado", "Estudante", "Integral", "Meio período", "Pensionista"))
b$V242 <- factor(b$V242, levels = 1:9,
  labels = c("Empregador < 10", "Empregador > 10", "Manual especializado", "Manual semi", "Prof. liberal", 
    "Supervisor escritório", "Supervisor manual", "Trabalhador escritório", "Trabalhador rural"))
b$V242a <- factor(b$V242a, levels = 1:3,
  labels = c("Nunca teve emprego", "Nunca trabalhou", "Sim"))
b$V243 <- factor(b$V243, levels = 1:3,
  labels = c("Governo", "ONG", "Privada"))
b$V248 <- factor(b$V248, levels = 1:2,
  labels = c("Não", "Sim"))
b$V249 <- factor(b$V249, levels = 1:2,
  labels = c("Não", "Sim"))
b$V250 <- factor(b$V250, levels = 1:11,
  labels = c("Braçal", "Empregador < 10", "Empregador > 10", "Manual especializado", "Manual semi", 
    "Militar", "Nunca teve emprego", "Prof. liberal", "Supervisor escritório", 
    "Supervisor manual", "Trabalhador escritório"))
b$V251 <- factor(b$V251, levels = 1:4,
  labels = c("Gastou e fez empréstimo", "Gastou", "Ganhou e gastou", "Guardou"))
b$V256 <- factor(b$V256, levels = 1:5,
  labels = c("Branco", "Indígena", "Negro", "Oriental", "Pardo"))
b$fezrede <- factor(b$fezrede, levels = 1:2,
  labels = c("Não", "Sim"))
b$P1 <- factor(b$P1, levels = 1:7,
  labels = c("< 1", "1 a 2", "2 a 5", "5 a 10", "10 a 15", "15 a 20", "> 20"))
b$cidade <- factor(b$cidade, levels = 1:53,
  labels = c("Aracaju", "Aracoia", "Aracoiaba", "Arapiraca", "Barreira", "Belém", "Belo Horizonte", 
    "Betim", "Branquinha", "Brasília", "Cabedelo", "Cachoeira", "Campina Grande", 
    "Campinas", "Caucaia", "Crato", "Dresden", "Eunapolis", "Florianópolis", 
    "Fortaleza", "Fortim", "Horizonte", "Ivaiporã", "João Pessoa", "Lagoa Santa", 
    "Limeira", "Limoeiro", "Maceió", "Magé", "Maracanaú", "Maranguape", 
    "Maravillha", "Natal", "Niterói", "Nova Iguaçu", "Nova Lima", "Olinda", 
    "Palhoça", "Porto de Pedras", "Pouso Alegre", "Recife", "Redenção", 
    "Ribeirão Preto", "Rio", "Rio Claro", "Rio de Janeiro", "Santos", 
    "São Carlos", "São Paulo", "Tianguá", "Timbuctu", "Vassouras", "Viçosa"))
b$S1 <- factor(b$S1, levels = 1:2,
  labels = c("Gostei", "Não gostei"))
b$formtrat <- factor(b$formtrat, levels = 1:3,
  labels = c("ASenhora", "OSenhor", "Você"))
attr(b$tipo, "label") <- "Tipo de contato com respondente"
attr(b$V4, "label") <- "Importância da família"
attr(b$V5, "label") <- "Importância dos amigos"
attr(b$V6, "label") <- "Importância do tempo livre"
attr(b$V7, "label") <- "Importância da política"
attr(b$V8, "label") <- "Importância do trabalho"
attr(b$V9, "label") <- "Importância da religião"
attr(b$V10, "label") <- "Se considera feliz"
attr(b$V11, "label") <- "Como está sua saúde?"
attr(b$V12, "label") <- "Importante ensinar: Independência"
attr(b$V13, "label") <- "Importante ensinar: Ser trabalhador"
attr(b$V14, "label") <- "Importante ensinar: Responsabilidade"
attr(b$V15, "label") <- "Importante ensinar: Criatividade"
attr(b$V16, "label") <- "Importante ensinar: Tolerância e respeito pelos outros"
attr(b$V17, "label") <- "Importante ensinar: Saber economizar (dinheiro e outros bens)"
attr(b$V18, "label") <- "Importante ensinar: Determinação e perseverança"
attr(b$V19, "label") <- "Importante ensinar: Ter fé religiosa"
attr(b$V20, "label") <- "Importante ensinar: Não ser egoísta"
attr(b$V21, "label") <- "Importante ensinar: Obediência"
attr(b$V22, "label") <- "Quão satisfeito com a vida?"
attr(b$V23, "label") <- "Pode confiar na maioria das pessoas?"
attr(b$A47, "label") <- "Quantas pessoas tentariam levar vantagem?"
attr(b$V125a, "label") <- "Confiança: Pessoas em geral"
attr(b$V125, "label") <- "Confiança: Família"
attr(b$V126, "label") <- "Confiança: Seus vizinhos"
attr(b$V127, "label") <- "Confiança: Pessoas que conhece pessoalmente"
attr(b$V128, "label") <- "Confiança: Pessoas que está vendo pela primeira vez"
attr(b$V129, "label") <- "Confiança: Pessoas de outras religiões"
attr(b$V130, "label") <- "Confiança: Pessoas de outros países"
attr(b$C1apes, "label") <- "Maioria inclui: Pessoas que estaria vendo pela primeira vez"
attr(b$C1afam, "label") <- "Maioria inclui: Familiares"
attr(b$C1aami, "label") <- "Maioria inclui: Amigos"
attr(b$C1acol, "label") <- "Maioria inclui: Colegas de trabalho"
attr(b$C1aviz, "label") <- "Maioria inclui: Vizinhos"
attr(b$C1acon, "label") <- "Maioria inclui: Conhecidos com quem não tem amizade"
attr(b$C1anin, "label") <- "Maioria inclui: não pensou em ninguém"
attr(b$C1b, "label") <- "Motivo da resposta à V23"
attr(b$C1c, "label") <- "Confiar é..."
attr(b$C1d, "label") <- "Situação semelhante a V23"
attr(b$C2ami, "label") <- "Ajuda financeira: Amigos"
attr(b$C2avo, "label") <- "Ajuda financeira: Avós"
attr(b$C2col, "label") <- "Ajuda financeira: Colegas"
attr(b$C2con, "label") <- "Ajuda financeira: Conhecidos"
attr(b$C2cun, "label") <- "Ajuda financeira: Cunhados"
attr(b$C2esp, "label") <- "Ajuda financeira: Esposo(a)"
attr(b$C2fil, "label") <- "Ajuda financeira: Filhos"
attr(b$C2gen, "label") <- "Ajuda financeira: Genros"
attr(b$C2irm, "label") <- "Ajuda financeira: Irmãos"
attr(b$C2mae, "label") <- "Ajuda financeira: Mãe"
attr(b$C2nam, "label") <- "Ajuda financeira: Namorado(a)"
attr(b$C2net, "label") <- "Ajuda financeira: Netos"
attr(b$C2nor, "label") <- "Ajuda financeira: Noras"
attr(b$C2pai, "label") <- "Ajuda financeira: Pai"
attr(b$C2pes, "label") <- "Ajuda financeira: Pessoas sendo vistas pela primeira vez"
attr(b$C2pri, "label") <- "Ajuda financeira: Primos"
attr(b$C2sog, "label") <- "Ajuda financeira: Sogros"
attr(b$C2tio, "label") <- "Ajuda financeira: Tios"
attr(b$C2viz, "label") <- "Ajuda financeira: Vizinhos"
attr(b$C3ami, "label") <- "Ajuda em tempo: Amigos"
attr(b$C3avo, "label") <- "Ajuda em tempo: Avós"
attr(b$C3col, "label") <- "Ajuda em tempo: Colegas"
attr(b$C3con, "label") <- "Ajuda em tempo: Conhecidos"
attr(b$C3cun, "label") <- "Ajuda em tempo: Cunhados"
attr(b$C3esp, "label") <- "Ajuda em tempo: Esposo(a)"
attr(b$C3fil, "label") <- "Ajuda em tempo: Filhos"
attr(b$C3gen, "label") <- "Ajuda em tempo: Genros"
attr(b$C3irm, "label") <- "Ajuda em tempo: Irmãos"
attr(b$C3mae, "label") <- "Ajuda em tempo: Mãe"
attr(b$C3nam, "label") <- "Ajuda em tempo: Namorado(a)"
attr(b$C3net, "label") <- "Ajuda em tempo: Netos"
attr(b$C3nor, "label") <- "Ajuda em tempo: Noras"
attr(b$C3pai, "label") <- "Ajuda em tempo: Pai"
attr(b$C3pes, "label") <- "Ajuda em tempo: Pessoas sendo vistas pela primeira vez"
attr(b$C3pri, "label") <- "Ajuda em tempo: Primos"
attr(b$C3sog, "label") <- "Ajuda em tempo: Sogros"
attr(b$C3tio, "label") <- "Ajuda em tempo: Tios"
attr(b$C3viz, "label") <- "Ajuda em tempo: Vizinhos"
attr(b$C4ami, "label") <- "Emprestaria dinheiro: Amigos"
attr(b$C4avo, "label") <- "Emprestaria dinheiro: Avós"
attr(b$C4col, "label") <- "Emprestaria dinheiro: Colegas"
attr(b$C4con, "label") <- "Emprestaria dinheiro: Conhecidos"
attr(b$C4cun, "label") <- "Emprestaria dinheiro: Cunhados"
attr(b$C4esp, "label") <- "Emprestaria dinheiro: Esposo(a)"
attr(b$C4fil, "label") <- "Emprestaria dinheiro: Filhos"
attr(b$C4gen, "label") <- "Emprestaria dinheiro: Genros"
attr(b$C4irm, "label") <- "Emprestaria dinheiro: Irmãos"
attr(b$C4mae, "label") <- "Emprestaria dinheiro: Mãe"
attr(b$C4nam, "label") <- "Emprestaria dinheiro: Namorado(a)"
attr(b$C4net, "label") <- "Emprestaria dinheiro: Netos"
attr(b$C4nor, "label") <- "Emprestaria dinheiro: Noras"
attr(b$C4pai, "label") <- "Emprestaria dinheiro: Pai"
attr(b$C4pes, "label") <- "Emprestaria dinheiro: Pessoas sendo vistas pela primeira vez"
attr(b$C4pri, "label") <- "Emprestaria dinheiro: Primos"
attr(b$C4sog, "label") <- "Emprestaria dinheiro: Sogros"
attr(b$C4tio, "label") <- "Emprestaria dinheiro: Tios"
attr(b$C4viz, "label") <- "Emprestaria dinheiro: Vizinhos"
attr(b$I1, "label") <- "Com quantos vizinhos conversa"
attr(b$I2, "label") <- "Frequência com que recebe visitas de parentes?"
attr(b$I3, "label") <- "Frequência com que faz visitas a parentes?"
attr(b$I4, "label") <- "Frequência com que recebe visitas de amigos?"
attr(b$I5, "label") <- "Frequência com que faz visitas a amigos?"
attr(b$V198, "label") <- "Se justifica: pedir benefícios"
attr(b$V199, "label") <- "Se justifica: Evitar pagar passagem"
attr(b$V200, "label") <- "Se justifica: Não pagar impostos"
attr(b$V201, "label") <- "Se justifica: Aceitar suborno para cumprir seu dever"
attr(b$A198, "label") <- "Quantos fariam: pedir benefícios"
attr(b$A199, "label") <- "Quantos fariam: Evitar pagar passagem"
attr(b$A200, "label") <- "Quantos fariam: Não pagar impostos"
attr(b$A201, "label") <- "Quantos fariam: Aceitar suborno para cumprir seu dever"
attr(b$J1a, "label") <- "Motivo de honestidade: bondade"
attr(b$J1b, "label") <- "Motivo de honestidade: sentimento de culpa"
attr(b$J1c, "label") <- "Motivo de honestidade: preocupação com reputação"
attr(b$J1d, "label") <- "Motivo de honestidade: medo de punição"
attr(b$J2, "label") <- "Reconhece injusto"
attr(b$J3coe, "label") <- "Como reconhece: A coerência do que ela diz"
attr(b$J3fal, "label") <- "Como reconhece: A forma de falar"
attr(b$J3idd, "label") <- "Como reconhece: A idade da pessoa"
attr(b$J3ves, "label") <- "Como reconhece: A forma de se vestir"
attr(b$V96, "label") <- "Participação: abaixo-assinado"
attr(b$V96a, "label") <- "Participação: petição pela internet"
attr(b$V97, "label") <- "Participação: boicotes"
attr(b$V98, "label") <- "Participação: manifestações pacíficas"
attr(b$V98a, "label") <- "Participação: passeatas"
attr(b$V98b, "label") <- "Participação: greves"
attr(b$V99, "label") <- "Participação: outras formas"
attr(b$A1art, "label") <- "Participa: grupo artístico"
attr(b$A1esp, "label") <- "Participa: grupo esportivo"
attr(b$A1igr, "label") <- "Participa: grupo de igreja"
attr(b$A1mus, "label") <- "Participa: grupo musical"
attr(b$A1nao, "label") <- "Participa: Nenhum grupo"
attr(b$A1o, "label") <- "Participa: Outro tipo de grupo"
attr(b$A2ass, "label") <- "Participa: associação"
attr(b$A2nao, "label") <- "Participa: Nenhuma organização"
attr(b$A2o, "label") <- "Participa: Outro tipo de organização"
attr(b$A2prt, "label") <- "Participa: partido político"
attr(b$A2sin, "label") <- "Participa: sindicato"
attr(b$V185, "label") <- "Religião"
attr(b$V185eo, "label") <- "Religião evangélica (outra)"
attr(b$V185o, "label") <- "Religião (outra)"
attr(b$V186, "label") <- "Frequência em atividades religiosas"
attr(b$V187a, "label") <- "É religiosa?"
attr(b$V187b, "label") <- "Acredita em Deus?"
attr(b$V223, "label") <- "Fonte de informação: Jornal impresso"
attr(b$V224, "label") <- "Fonte de informação: Jornais de TV ou rádio"
attr(b$V225, "label") <- "Fonte de informação: Revistas"
attr(b$V226, "label") <- "Fonte de informação: Programas de rádio ou TV"
attr(b$V227, "label") <- "Fonte de informação: Livros"
attr(b$V228, "label") <- "Fonte de informação: Internet e e-mail"
attr(b$V229, "label") <- "Fonte de informação: Conversas com amigos ou colegas"
attr(b$V230, "label") <- "Frequência de uso do computador"
attr(b$F1, "label") <- "Tem Facebook?"
attr(b$F2, "label") <- "Tem Orkut?"
attr(b$F3, "label") <- "Tem Twitter?"
attr(b$F4a, "label") <- "Tem Skype?"
attr(b$F4b, "label") <- "Tem MSN?"
attr(b$F5, "label") <- "Outras redes"
attr(b$V235, "label") <- "Sexo"
attr(b$V236, "label") <- "Idade"
attr(b$V55, "label") <- "Estado civil"
attr(b$V56, "label") <- "Número de filhos"
attr(b$V238, "label") <- "Escolaridade"
attr(b$V238b, "label") <- "Curso de nível superior"
attr(b$V238br, "label") <- "Curso de nível superior (recodificado)"
attr(b$V240, "label") <- "Mora com seus pais?"
attr(b$V241, "label") <- "Está empregado?"
attr(b$V241o, "label") <- "Está empregado? (outra possibilidade)"
attr(b$V242, "label") <- "Profissão ou ocupação?"
attr(b$V242a, "label") <- "Já trabalhou?"
attr(b$V242o, "label") <- "Profissão ou ocupação? (outra possibilidade)"
attr(b$V243, "label") <- "Setor de trabalho?"
attr(b$V248, "label") <- "Recebe o salário mais alto de sua casa?"
attr(b$V249, "label") <- "A pessoa de rendimento mais alto trabalha"
attr(b$V250, "label") <- "Qual a profissão ou ocupação da pessoa de rendimento mais alto"
attr(b$V250o, "label") <- "Qual a profissão ou ocupação da pessoa de rendimento mais alto"
attr(b$V251, "label") <- "Sua família guardou ou gastou dinheiro"
attr(b$V256, "label") <- "Cor"
attr(b$fezrede, "label") <- "Preencheu dados da própria rede social?"
attr(b$P1, "label") <- "Renda familiar mensal"
attr(b$cidade, "label") <- "Cidade"
attr(b$S1, "label") <- "Gostou dos pulos?"
attr(b$rels, "label") <- "Classificação das pessoas na rede social"
attr(b$lsrel, "label") <- "Lista de ligações entre as pessoas na rede social"
attr(b$formtrat, "label") <- "Forma de tratamento"
attr(b$horaini, "label") <- "Início do preenchimento do questionário"
attr(b$tempo2, "label") <- "Início do preenchimento da 2ª página"
attr(b$tempo3, "label") <- "Início do preenchimento da 3ª página"
attr(b$tempo4, "label") <- "Início do preenchimento da 4ª página"
attr(b$tempo5, "label") <- "Início do preenchimento da 5ª página"
attr(b$horafim, "label") <- "Fim do preenchimento da 5ª página"
save(b, file = "trust_pt_BR.RData")
