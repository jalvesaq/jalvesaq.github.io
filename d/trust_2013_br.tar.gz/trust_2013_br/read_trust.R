###############################################################################
# 
#  R script to load the data used at:
#
#  Aquino, Jakson Alves de.
#  The meaning of trust for Brazilians with higher education.
#  Social Indicators Research.
# 
###############################################################################

b <- read.delim("trust.txt", quote = "", as.is = TRUE)

b$tipo <- factor(b$tipo, levels = 1:11,
  labels = c("Friend (E-mail)", "Friend (Facebook)", "Letters given in down town", "Down Town", "Facebook", 
    "Facebook group", "Municipality", "Street: Pacoti", "Street: Redenção", 
    "University", "Via internet"))
b$V4 <- factor(b$V4, levels = 1:4,
  labels = c("Not at all important", "Not very important", "Rather important", "Very important"))
b$V5 <- factor(b$V5, levels = 1:4,
  labels = c("Not at all important", "Not very important", "Rather important", "Very important"))
b$V6 <- factor(b$V6, levels = 1:4,
  labels = c("Not at all important", "Not very important", "Rather important", "Very important"))
b$V7 <- factor(b$V7, levels = 1:4,
  labels = c("Not at all important", "Not very important", "Rather important", "Very important"))
b$V8 <- factor(b$V8, levels = 1:4,
  labels = c("Not at all important", "Not very important", "Rather important", "Very important"))
b$V9 <- factor(b$V9, levels = 1:4,
  labels = c("Not at all important", "Not very important", "Rather important", "Very important"))
b$V10 <- factor(b$V10, levels = 1:4,
  labels = c("Not at all happy", "Not very happy", "Rather happy", "Very happy"))
b$V11 <- factor(b$V11, levels = 1:4,
  labels = c("Poor", "Fair", "Good", "Very good"))
b$V12 <- factor(b$V12, levels = 1:2,
  labels = c("Not mentioned", "Mentioned"))
b$V13 <- factor(b$V13, levels = 1:2,
  labels = c("Not mentioned", "Mentioned"))
b$V14 <- factor(b$V14, levels = 1:2,
  labels = c("Not mentioned", "Mentioned"))
b$V15 <- factor(b$V15, levels = 1:2,
  labels = c("Not mentioned", "Mentioned"))
b$V16 <- factor(b$V16, levels = 1:2,
  labels = c("Not mentioned", "Mentioned"))
b$V17 <- factor(b$V17, levels = 1:2,
  labels = c("Not mentioned", "Mentioned"))
b$V18 <- factor(b$V18, levels = 1:2,
  labels = c("Not mentioned", "Mentioned"))
b$V19 <- factor(b$V19, levels = 1:2,
  labels = c("Not mentioned", "Mentioned"))
b$V20 <- factor(b$V20, levels = 1:2,
  labels = c("Not mentioned", "Mentioned"))
b$V21 <- factor(b$V21, levels = 1:2,
  labels = c("Not mentioned", "Mentioned"))
b$V23 <- factor(b$V23, levels = 1:2,
  labels = c("Need to be very careful", "Most people can be trusted"))
b$V125a <- factor(b$V125a, levels = 1:4,
  labels = c("Don't trust at all", "Don't trust very much", "Trust somewhat", "Trust completely"))
b$V125 <- factor(b$V125, levels = 1:4,
  labels = c("Don't trust at all", "Don't trust very much", "Trust somewhat", "Trust completely"))
b$V126 <- factor(b$V126, levels = 1:4,
  labels = c("Don't trust at all", "Don't trust very much", "Trust somewhat", "Trust completely"))
b$V127 <- factor(b$V127, levels = 1:4,
  labels = c("Don't trust at all", "Don't trust very much", "Trust somewhat", "Trust completely"))
b$V128 <- factor(b$V128, levels = 1:4,
  labels = c("Don't trust at all", "Don't trust very much", "Trust somewhat", "Trust completely"))
b$V129 <- factor(b$V129, levels = 1:4,
  labels = c("Don't trust at all", "Don't trust very much", "Trust somewhat", "Trust completely"))
b$V130 <- factor(b$V130, levels = 1:4,
  labels = c("Don't trust at all", "Don't trust very much", "Trust somewhat", "Trust completely"))
b$C1apes <- factor(b$C1apes, levels = 1:2,
  labels = c("No", "Yes"))
b$C1afam <- factor(b$C1afam, levels = 1:2,
  labels = c("No", "Yes"))
b$C1aami <- factor(b$C1aami, levels = 1:2,
  labels = c("No", "Yes"))
b$C1acol <- factor(b$C1acol, levels = 1:2,
  labels = c("No", "Yes"))
b$C1aviz <- factor(b$C1aviz, levels = 1:2,
  labels = c("No", "Yes"))
b$C1acon <- factor(b$C1acon, levels = 1:2,
  labels = c("No", "Yes"))
b$C1anin <- factor(b$C1anin, levels = 1:1,
  labels = c("Yes"))
b$C1b <- factor(b$C1b, levels = 1:2,
  labels = c("Own experience", "I was taught"))
b$C1c <- factor(b$C1c, levels = 1:7,
  labels = c("To assign responsibilities", "To share", "To know", "Fidelity", "To preview", "To feel safe", "To have a link"))
b$C1d <- factor(b$C1d, levels = 1:7,
  labels = c("Friend to keep secret", "Partner don't betray", "To keep promise", "To loan things", 
    "Stranger really to help", "To get you alone", "Person to be together"))
b$C2ami <- factor(b$C2ami, levels = 1:2,
  labels = c("No", "Yes"))
b$C2avo <- factor(b$C2avo, levels = 1:2,
  labels = c("No", "Yes"))
b$C2col <- factor(b$C2col, levels = 1:2,
  labels = c("No", "Yes"))
b$C2con <- factor(b$C2con, levels = 1:2,
  labels = c("No", "Yes"))
b$C2cun <- factor(b$C2cun, levels = 1:2,
  labels = c("No", "Yes"))
b$C2esp <- factor(b$C2esp, levels = 1:2,
  labels = c("No", "Yes"))
b$C2fil <- factor(b$C2fil, levels = 1:2,
  labels = c("No", "Yes"))
b$C2gen <- factor(b$C2gen, levels = 1:2,
  labels = c("No", "Yes"))
b$C2irm <- factor(b$C2irm, levels = 1:2,
  labels = c("No", "Yes"))
b$C2mae <- factor(b$C2mae, levels = 1:2,
  labels = c("No", "Yes"))
b$C2nam <- factor(b$C2nam, levels = 1:2,
  labels = c("No", "Yes"))
b$C2net <- factor(b$C2net, levels = 1:2,
  labels = c("No", "Yes"))
b$C2nor <- factor(b$C2nor, levels = 1:2,
  labels = c("No", "Yes"))
b$C2pai <- factor(b$C2pai, levels = 1:2,
  labels = c("No", "Yes"))
b$C2pes <- factor(b$C2pes, levels = 1:2,
  labels = c("No", "Yes"))
b$C2pri <- factor(b$C2pri, levels = 1:2,
  labels = c("No", "Yes"))
b$C2sog <- factor(b$C2sog, levels = 1:2,
  labels = c("No", "Yes"))
b$C2tio <- factor(b$C2tio, levels = 1:2,
  labels = c("No", "Yes"))
b$C2viz <- factor(b$C2viz, levels = 1:2,
  labels = c("No", "Yes"))
b$C3ami <- factor(b$C3ami, levels = 1:2,
  labels = c("No", "Yes"))
b$C3avo <- factor(b$C3avo, levels = 1:2,
  labels = c("No", "Yes"))
b$C3col <- factor(b$C3col, levels = 1:2,
  labels = c("No", "Yes"))
b$C3con <- factor(b$C3con, levels = 1:2,
  labels = c("No", "Yes"))
b$C3cun <- factor(b$C3cun, levels = 1:2,
  labels = c("No", "Yes"))
b$C3esp <- factor(b$C3esp, levels = 1:2,
  labels = c("No", "Yes"))
b$C3fil <- factor(b$C3fil, levels = 1:2,
  labels = c("No", "Yes"))
b$C3gen <- factor(b$C3gen, levels = 1:2,
  labels = c("No", "Yes"))
b$C3irm <- factor(b$C3irm, levels = 1:2,
  labels = c("No", "Yes"))
b$C3mae <- factor(b$C3mae, levels = 1:2,
  labels = c("No", "Yes"))
b$C3nam <- factor(b$C3nam, levels = 1:2,
  labels = c("No", "Yes"))
b$C3net <- factor(b$C3net, levels = 1:2,
  labels = c("No", "Yes"))
b$C3nor <- factor(b$C3nor, levels = 1:2,
  labels = c("No", "Yes"))
b$C3pai <- factor(b$C3pai, levels = 1:2,
  labels = c("No", "Yes"))
b$C3pes <- factor(b$C3pes, levels = 1:1,
  labels = c("No"))
b$C3pri <- factor(b$C3pri, levels = 1:2,
  labels = c("No", "Yes"))
b$C3sog <- factor(b$C3sog, levels = 1:2,
  labels = c("No", "Yes"))
b$C3tio <- factor(b$C3tio, levels = 1:2,
  labels = c("No", "Yes"))
b$C3viz <- factor(b$C3viz, levels = 1:2,
  labels = c("No", "Yes"))
b$C4ami <- factor(b$C4ami, levels = 1:2,
  labels = c("No", "Yes"))
b$C4avo <- factor(b$C4avo, levels = 1:2,
  labels = c("No", "Yes"))
b$C4col <- factor(b$C4col, levels = 1:2,
  labels = c("No", "Yes"))
b$C4con <- factor(b$C4con, levels = 1:2,
  labels = c("No", "Yes"))
b$C4cun <- factor(b$C4cun, levels = 1:2,
  labels = c("No", "Yes"))
b$C4esp <- factor(b$C4esp, levels = 1:2,
  labels = c("No", "Yes"))
b$C4fil <- factor(b$C4fil, levels = 1:2,
  labels = c("No", "Yes"))
b$C4gen <- factor(b$C4gen, levels = 1:2,
  labels = c("No", "Yes"))
b$C4irm <- factor(b$C4irm, levels = 1:2,
  labels = c("No", "Yes"))
b$C4mae <- factor(b$C4mae, levels = 1:2,
  labels = c("No", "Yes"))
b$C4nam <- factor(b$C4nam, levels = 1:2,
  labels = c("No", "Yes"))
b$C4net <- factor(b$C4net, levels = 1:2,
  labels = c("No", "Yes"))
b$C4nor <- factor(b$C4nor, levels = 1:2,
  labels = c("No", "Yes"))
b$C4pai <- factor(b$C4pai, levels = 1:2,
  labels = c("No", "Yes"))
b$C4pes <- factor(b$C4pes, levels = 1:2,
  labels = c("No", "Yes"))
b$C4pri <- factor(b$C4pri, levels = 1:2,
  labels = c("No", "Yes"))
b$C4sog <- factor(b$C4sog, levels = 1:2,
  labels = c("No", "Yes"))
b$C4tio <- factor(b$C4tio, levels = 1:2,
  labels = c("No", "Yes"))
b$C4viz <- factor(b$C4viz, levels = 1:2,
  labels = c("No", "Yes"))
b$I1 <- factor(b$I1, levels = 1:5,
  labels = c("None", "1", "2", "3 to 6", "more than 6"))
b$I2 <- factor(b$I2, levels = 1:6,
  labels = c("Never", "Rarely", "Monthly", "Fortnightly", "Weekly", "Daily"))
b$I3 <- factor(b$I3, levels = 1:6,
  labels = c("Never", "Rarely", "Monthly", "Fortnightly", "Weekly", "Daily"))
b$I4 <- factor(b$I4, levels = 1:6,
  labels = c("Never", "Rarely", "Monthly", "Fortnightly", "Weekly", "Daily"))
b$I5 <- factor(b$I5, levels = 1:6,
  labels = c("Never", "Rarely", "Monthly", "Fortnightly", "Weekly", "Daily"))
b$J2 <- factor(b$J2, levels = 1:4,
  labels = c("Never", "Sometimes", "Almost always", "Always"))
b$J3coe <- factor(b$J3coe, levels = 1:2,
  labels = c("No", "Yes"))
b$J3fal <- factor(b$J3fal, levels = 1:2,
  labels = c("No", "Yes"))
b$J3idd <- factor(b$J3idd, levels = 1:2,
  labels = c("No", "Yes"))
b$J3ves <- factor(b$J3ves, levels = 1:2,
  labels = c("No", "Yes"))
b$V96 <- factor(b$V96, levels = 1:3,
  labels = c("Would never do", "Could do", "I already did"))
b$V96a <- factor(b$V96a, levels = 1:3,
  labels = c("Would never do", "Could do", "I already did"))
b$V97 <- factor(b$V97, levels = 1:3,
  labels = c("Would never do", "Could do", "I already did"))
b$V98 <- factor(b$V98, levels = 1:3,
  labels = c("Would never do", "Could do", "I already did"))
b$V98a <- factor(b$V98a, levels = 1:3,
  labels = c("Would never do", "Could do", "I already did"))
b$V98b <- factor(b$V98b, levels = 1:3,
  labels = c("Would never do", "Could do", "I already did"))
b$A1art <- factor(b$A1art, levels = 1:2,
  labels = c("No", "Yes"))
b$A1esp <- factor(b$A1esp, levels = 1:2,
  labels = c("No", "Yes"))
b$A1igr <- factor(b$A1igr, levels = 1:2,
  labels = c("No", "Yes"))
b$A1mus <- factor(b$A1mus, levels = 1:2,
  labels = c("No", "Yes"))
b$A1nao <- factor(b$A1nao, levels = 1:1,
  labels = c("Don't participate"))
b$A2ass <- factor(b$A2ass, levels = 1:2,
  labels = c("No", "Yes"))
b$A2nao <- factor(b$A2nao, levels = 1:1,
  labels = c("Don't participate"))
b$A2prt <- factor(b$A2prt, levels = 1:2,
  labels = c("No", "Yes"))
b$A2sin <- factor(b$A2sin, levels = 1:2,
  labels = c("No", "Yes"))
b$V185 <- factor(b$V185, levels = 1:11,
  labels = c("African", "Catholic", "Spiritism", "Ev.: Adventist", "Evangelical", 
    "Ev.: Assembly of God", "Ev.: Baptist", "Ev.: Foursquare Gospel", 
    "Jew", "Islam", "No religion"))
b$V186 <- factor(b$V186, levels = 1:8,
  labels = c("Never", "Rarely", "Yearly", "In holy days", "Monthly", "Fortnightly", 
    "Weekly", "More than once a week"))
b$V187a <- factor(b$V187a, levels = 1:2,
  labels = c("Not religious", "Religious"))
b$V187b <- factor(b$V187b, levels = 1:2,
  labels = c("Atheist", "Deist"))
b$V223 <- factor(b$V223, levels = 1:2,
  labels = c("No", "Yes"))
b$V224 <- factor(b$V224, levels = 1:2,
  labels = c("No", "Yes"))
b$V225 <- factor(b$V225, levels = 1:2,
  labels = c("No", "Yes"))
b$V226 <- factor(b$V226, levels = 1:2,
  labels = c("No", "Yes"))
b$V227 <- factor(b$V227, levels = 1:2,
  labels = c("No", "Yes"))
b$V228 <- factor(b$V228, levels = 1:2,
  labels = c("No", "Yes"))
b$V229 <- factor(b$V229, levels = 1:2,
  labels = c("No", "Yes"))
b$V230 <- factor(b$V230, levels = 1:2,
  labels = c("Frequently", "Rarely"))
b$F1 <- factor(b$F1, levels = 1:2,
  labels = c("No", "Yes"))
b$F2 <- factor(b$F2, levels = 1:2,
  labels = c("No", "Yes"))
b$F3 <- factor(b$F3, levels = 1:2,
  labels = c("No", "Yes"))
b$F4a <- factor(b$F4a, levels = 1:2,
  labels = c("No", "Yes"))
b$F4b <- factor(b$F4b, levels = 1:2,
  labels = c("No", "Yes"))
b$V235 <- factor(b$V235, levels = 1:2,
  labels = c("Female", "Male"))
b$V55 <- factor(b$V55, levels = 1:6,
  labels = c("Married", "Divorced", "Cohabiting", "Separated", "Single", "Widowed"))
b$V238 <- factor(b$V238, levels = 1:6,
  labels = c("Incomplete primary school", "Complete primary school", "Incomplete secondary school", "Complete secondary school", 
    "Some university-level education, without degree", "University-level education, with degree"))
b$V238br <- factor(b$V238br, levels = 1:22,
  labels = c("Administration and Accountancy", "Architecture", "Archival Science", "Biology", "Social Sciences", "Communication", 
    "Design", "Law", "Economy", "Engineer", "Statistics", "History", 
    "Philosophy", "Physics", "Geography", "Letters", "Mathematics", "Pedagogy", 
    "Psychology", "Health", "Social Work", "No answer"))
b$V240 <- factor(b$V240, levels = 1:2,
  labels = c("No", "Yes"))
b$V241 <- factor(b$V241, levels = 1:6,
  labels = c("Self employed", "Unemployed", "Student", "Full time employee", "Part time employee", "Pensioned"))
b$V242 <- factor(b$V242, levels = 1:9,
  labels = c("Employer with < 10 employees", "Employer with > 10 employees", "Skilled manual worker", "Semi-skilled manual worker", "Professional worker", 
    "Supervisory - office worker", "Supervisory - manual worker", "Non-manual - office worker", "Agricultural worker"))
b$V242a <- factor(b$V242a, levels = 1:3,
  labels = c("Never had a job", "Never worked", "Yes"))
b$V243 <- factor(b$V243, levels = 1:3,
  labels = c("Govern", "NGO", "Private"))
b$V248 <- factor(b$V248, levels = 1:2,
  labels = c("No", "Yes"))
b$V249 <- factor(b$V249, levels = 1:2,
  labels = c("No", "Yes"))
b$V250 <- factor(b$V250, levels = 1:11,
  labels = c("Manual", "Employer with < 10 employees", "Employer with > 10 employees", "Skilled manual worker", "Semi-skilled manual worker", 
    "Military", "Never had a job", "Professional worker", "Supervisory - office worker", 
    "Supervisory - manual worker", "Non-manual - office worker"))
b$V251 <- factor(b$V251, levels = 1:4,
  labels = c("Spent savings and borrowed money", "Spent some savings", "Just get by", "Save money"))
b$V256 <- factor(b$V256, levels = 1:5,
  labels = c("White", "Indigenous", "Black", "Asiatic", "Mixed of black and white"))
b$fezrede <- factor(b$fezrede, levels = 1:2,
  labels = c("No", "Yes"))
b$P1 <- factor(b$P1, levels = 1:7,
  labels = c("< 1", "1 to 2", "2 to 5", "5 to 10", "10 to 15", "15 to 20", "> 20"))
b$cidade <- factor(b$cidade, levels = 1:53,
  labels = c("Aracaju", "Aracoia", "Aracoiaba", "Arapiraca", "Barreira", "Belém", "Belo Horizonte", 
    "Betim", "Branquinha", "Brasília", "Cabedelo", "Cachoeira", "Campina Grande", 
    "Campinas", "Caucaia", "Crato", "Dresden", "Eunapolis", "Florianópolis", 
    "Fortaleza", "Fortim", "Horizonte", "Ivaiporã", "João Pessoa", "Lagoa Santa", 
    "Limeira", "Limoeiro", "Maceió", "Magé", "Maracanaú", "Maranguape", 
    "Maravillha", "Natal", "Niterói", "Nova Iguaçu", "Nova Lima", "Olinda", 
    "Palhoça", "Porto de Pedras", "Pouso Alegre", "Recife", "Redenção", 
    "Ribeirão Preto", "Rio", "Rio Claro", "Rio de Janeiro", "Santos", 
    "São Carlos", "São Paulo", "Tianguá", "Timbuctu", "Vassouras", "Viçosa"))
b$S1 <- factor(b$S1, levels = 1:2,
  labels = c("I liked", "I didn't like"))
b$formtrat <- factor(b$formtrat, levels = 1:3,
  labels = c("ASenhora", "OSenhor", "Você"))
attr(b$tipo, "label") <- "Type of contact with respondent"
attr(b$V4, "label") <- "Importance of family"
attr(b$V5, "label") <- "Importance of friends"
attr(b$V6, "label") <- "Importance of leisure time"
attr(b$V7, "label") <- "Importance of politics"
attr(b$V8, "label") <- "Importance of work"
attr(b$V9, "label") <- "Importance of religion"
attr(b$V10, "label") <- "Are you happy?"
attr(b$V11, "label") <- "State of your health"
attr(b$V12, "label") <- "Important to learn: Independence"
attr(b$V13, "label") <- "Important to learn: Hard work"
attr(b$V14, "label") <- "Important to learn: Responsibility"
attr(b$V15, "label") <- "Important to learn: Imagination"
attr(b$V16, "label") <- "Important to learn: Tolerance and respect"
attr(b$V17, "label") <- "Important to learn: Thrift"
attr(b$V18, "label") <- "Important to learn: Determination, perseverance"
attr(b$V19, "label") <- "Important to learn: Religious faith"
attr(b$V20, "label") <- "Important to learn: Unselfishness"
attr(b$V21, "label") <- "Important to learn: Obedience"
attr(b$V22, "label") <- "How satisfied with life?"
attr(b$V23, "label") <- "Can most people be trusted?"
attr(b$A47, "label") <- "How many people would cheat you?"
attr(b$V125a, "label") <- "Trust: People in general"
attr(b$V125, "label") <- "Trust: Relatives"
attr(b$V126, "label") <- "Trust: Neighbors"
attr(b$V127, "label") <- "Trust: Personally known people"
attr(b$V128, "label") <- "Trust: People seen for the first time"
attr(b$V129, "label") <- "Trust: People of other religion"
attr(b$V130, "label") <- "Trust: People of other countries"
attr(b$C1apes, "label") <- "Most people includes: People seen for the first time"
attr(b$C1afam, "label") <- "Most people includes: Relatives"
attr(b$C1aami, "label") <- "Most people includes: Friends"
attr(b$C1acol, "label") <- "Most people includes: Colleagues"
attr(b$C1aviz, "label") <- "Most people includes: Neighbors"
attr(b$C1acon, "label") <- "Most people includes: Known people with there is no friendship"
attr(b$C1anin, "label") <- "Most people include: Didn't think in anybody"
attr(b$C1b, "label") <- "Reason to answer question V23"
attr(b$C1c, "label") <- "To trust is..."
attr(b$C1d, "label") <- "Situation similar to V23"
attr(b$C2ami, "label") <- "Financial aid: Friends"
attr(b$C2avo, "label") <- "Financial aid: Grandparents"
attr(b$C2col, "label") <- "Financial aid: Colleagues"
attr(b$C2con, "label") <- "Financial aid: Known people"
attr(b$C2cun, "label") <- "Financial aid: Brother-in-law"
attr(b$C2esp, "label") <- "Financial aid: Husband/Wife"
attr(b$C2fil, "label") <- "Financial aid: Children"
attr(b$C2gen, "label") <- "Financial aid: Son-in-law"
attr(b$C2irm, "label") <- "Financial aid: Siblings"
attr(b$C2mae, "label") <- "Financial aid: Mother"
attr(b$C2nam, "label") <- "Financial aid: Boyfriend/Girlfriend"
attr(b$C2net, "label") <- "Financial aid: Grandchildren"
attr(b$C2nor, "label") <- "Financial aid: Daughter-in-law"
attr(b$C2pai, "label") <- "Financial aid: Father"
attr(b$C2pes, "label") <- "Financial aid: People seen for the first time"
attr(b$C2pri, "label") <- "Financial aid: Cousins"
attr(b$C2sog, "label") <- "Financial aid: Father-in-law/Mother-in-law"
attr(b$C2tio, "label") <- "Financial aid: Uncles/Aunts"
attr(b$C2viz, "label") <- "Financial aid: Neighbors"
attr(b$C3ami, "label") <- "Help with time: Friends"
attr(b$C3avo, "label") <- "Help with time: Grandparents"
attr(b$C3col, "label") <- "Help with time: Colleagues"
attr(b$C3con, "label") <- "Help with time: Known people"
attr(b$C3cun, "label") <- "Help with time: Brother-in-law"
attr(b$C3esp, "label") <- "Help with time: Husband/Wife"
attr(b$C3fil, "label") <- "Help with time: Children"
attr(b$C3gen, "label") <- "Help with time: Son-in-law"
attr(b$C3irm, "label") <- "Help with time: Siblings"
attr(b$C3mae, "label") <- "Help with time: Mother"
attr(b$C3nam, "label") <- "Help with time: Boyfriend/Girlfriend"
attr(b$C3net, "label") <- "Help with time: Grandchildren"
attr(b$C3nor, "label") <- "Help with time: Daughter-in-law"
attr(b$C3pai, "label") <- "Help with time: Father"
attr(b$C3pes, "label") <- "Help with time: People seen for the first time"
attr(b$C3pri, "label") <- "Help with time: Cousins"
attr(b$C3sog, "label") <- "Help with time: Father-in-law/Mother-in-law"
attr(b$C3tio, "label") <- "Help with time: Uncles/Aunts"
attr(b$C3viz, "label") <- "Help with time: Neighbors"
attr(b$C4ami, "label") <- "Would loan money: Friends"
attr(b$C4avo, "label") <- "Would loan money: Grandparents"
attr(b$C4col, "label") <- "Would loan money: Colleagues"
attr(b$C4con, "label") <- "Would loan money: Known people"
attr(b$C4cun, "label") <- "Would loan money: Brother-in-law"
attr(b$C4esp, "label") <- "Would loan money: Husband/Wife"
attr(b$C4fil, "label") <- "Would loan money: Children"
attr(b$C4gen, "label") <- "Would loan money: Son-in-law"
attr(b$C4irm, "label") <- "Would loan money: Siblings"
attr(b$C4mae, "label") <- "Would loan money: Mother"
attr(b$C4nam, "label") <- "Would loan money: Boyfriend/Girlfriend"
attr(b$C4net, "label") <- "Would loan money: Grandchildren"
attr(b$C4nor, "label") <- "Would loan money: Daughter-in-law"
attr(b$C4pai, "label") <- "Would loan money: Father"
attr(b$C4pes, "label") <- "Would loan money: People seen for the first time"
attr(b$C4pri, "label") <- "Would loan money: Cousins"
attr(b$C4sog, "label") <- "Would loan money: Father-in-law/Mother-in-law"
attr(b$C4tio, "label") <- "Would loan money: Uncles/Aunts"
attr(b$C4viz, "label") <- "Would loan money: Neighbors"
attr(b$I1, "label") <- "How many neighbors do you talk with?"
attr(b$I2, "label") <- "Frequency of visits by relatives"
attr(b$I3, "label") <- "Frequency of visits to relatives"
attr(b$I4, "label") <- "Frequency of visits by friends"
attr(b$I5, "label") <- "Frequency of visits to friends"
attr(b$V198, "label") <- "Justifiable: claim benefits"
attr(b$V199, "label") <- "Justifiable: avoid a fare"
attr(b$V200, "label") <- "Justifiable: cheat on taxes"
attr(b$V201, "label") <- "Justifiable: accept bribe"
attr(b$A198, "label") <- "How many would do: claim benefits"
attr(b$A199, "label") <- "How many would do: avoid a fare"
attr(b$A200, "label") <- "How many would do: cheat on taxes"
attr(b$A201, "label") <- "How many would do: accept bribe"
attr(b$J1a, "label") <- "Reason of honesty: goodness"
attr(b$J1b, "label") <- "Reason of honesty: guilty"
attr(b$J1c, "label") <- "Reason of honesty: reputation"
attr(b$J1d, "label") <- "Reason of honesty: fear of punishment"
attr(b$J2, "label") <- "Recognize cheater"
attr(b$J3coe, "label") <- "How recognize: coherence of speech"
attr(b$J3fal, "label") <- "How recognize: way of talking"
attr(b$J3idd, "label") <- "How recognize: age"
attr(b$J3ves, "label") <- "How recognize: dressing style"
attr(b$V96, "label") <- "Participation: sign a petition"
attr(b$V96a, "label") <- "Participation: sing online petition"
attr(b$V97, "label") <- "Participation: join boycotts"
attr(b$V98, "label") <- "Participation: pacific manifestation"
attr(b$V98a, "label") <- "Participation: protest in street"
attr(b$V98b, "label") <- "Participation: strikes"
attr(b$V99, "label") <- "Participation: other"
attr(b$A1art, "label") <- "Participate: artistic group"
attr(b$A1esp, "label") <- "Participate: sport group"
attr(b$A1igr, "label") <- "Participate: church group"
attr(b$A1mus, "label") <- "Participate: musical group"
attr(b$A1nao, "label") <- "Participate: no group"
attr(b$A1o, "label") <- "Participate: other"
attr(b$A2ass, "label") <- "Participate: association"
attr(b$A2nao, "label") <- "Participate: no organization"
attr(b$A2o, "label") <- "Participate: other organization"
attr(b$A2prt, "label") <- "Participate: political party"
attr(b$A2sin, "label") <- "Participate: labor union"
attr(b$V185, "label") <- "Religion"
attr(b$V185eo, "label") <- "Evangelical religion (other)"
attr(b$V185o, "label") <- "Religion (other)"
attr(b$V186, "label") <- "Frequency of religious activity"
attr(b$V187a, "label") <- "Are you a religious person?"
attr(b$V187b, "label") <- "Do you believe in God?"
attr(b$V223, "label") <- "Source of information: newspaper"
attr(b$V224, "label") <- "Source of information: TV and radio news"
attr(b$V225, "label") <- "Source of information: magazines"
attr(b$V226, "label") <- "Source of information: TV and radio shows"
attr(b$V227, "label") <- "Source of information: books"
attr(b$V228, "label") <- "Source of information: internet and e-mail"
attr(b$V229, "label") <- "Source of information: talks with friends and colleagues"
attr(b$V230, "label") <- "Frequency of computer usage"
attr(b$F1, "label") <- "Do you have a Facebook account?"
attr(b$F2, "label") <- "Do you have a Orkut account?"
attr(b$F3, "label") <- "Do you have a Twitter account?"
attr(b$F4a, "label") <- "Do you have a Skype account?"
attr(b$F4b, "label") <- "Do you have a MSN account?"
attr(b$F5, "label") <- "Do you have a other online social network account?"
attr(b$V235, "label") <- "Sex"
attr(b$V236, "label") <- "Age"
attr(b$V55, "label") <- "Marital status"
attr(b$V56, "label") <- "Number of children"
attr(b$V238, "label") <- "Education"
attr(b$V238b, "label") <- "Undergraduate course"
attr(b$V238br, "label") <- "Undergraduate course (recoded)"
attr(b$V240, "label") <- "Do you live with your parents?"
attr(b$V241, "label") <- "Are you employed?"
attr(b$V241o, "label") <- "Are you employed? (other possibility)"
attr(b$V242, "label") <- "Profession or occupation"
attr(b$V242a, "label") <- "Have you already worked?"
attr(b$V242o, "label") <- "Profession or occupation (other possibility)"
attr(b$V243, "label") <- "Sector of job"
attr(b$V248, "label") <- "Do you receive the highest income in your household?"
attr(b$V249, "label") <- "Does the person with the highest income work?"
attr(b$V250, "label") <- "What is the job of person with the highest income?"
attr(b$V250o, "label") <- "What is the job of person with the highest income?"
attr(b$V251, "label") <- "Did your family saved money?"
attr(b$V256, "label") <- "Color"
attr(b$fezrede, "label") <- "Did the respondent filled his/her personal social network?"
attr(b$P1, "label") <- "Monthly family income"
attr(b$cidade, "label") <- "City"
attr(b$S1, "label") <- "Did you like the jumps?"
attr(b$rels, "label") <- "Classification of people in the social network"
attr(b$lsrel, "label") <- "List of links between people in the social network"
attr(b$formtrat, "label") <- "How to be treated in the questionnaire"
attr(b$horaini, "label") <- "Begin to fill the questionnaire"
attr(b$tempo2, "label") <- "Begin to fill page 2 of questionnaire"
attr(b$tempo3, "label") <- "Begin to fill page 3 of questionnaire"
attr(b$tempo4, "label") <- "Begin to fill page 4 of questionnaire"
attr(b$tempo5, "label") <- "Begin to fill page 5 of questionnaire"
attr(b$horafim, "label") <- "End to fill page 5 of questionnaire"
save(b, file = "trust.RData")
