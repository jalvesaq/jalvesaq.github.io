*******************************************************************************
* 
*  SPSS script to load the data used at:
*
*  Aquino, Jakson Alves de.
*  The meaning of trust for Brazilians with higher education.
*  Social Indicators Research.
* 
*******************************************************************************

GET DATA
  /TYPE=TXT
  /FILE='trust.txt'
  /DELCASE=LINE
  /DELIMITERS="\t"
  /ARRANGEMENT=DELIMITED
  /FIRSTCASE=2
  /IMPORTCASE=ALL
  /VARIABLES=
  codigoacesso A11
  tipo F2.0
  V4 F1.0
  V5 F1.0
  V6 F1.0
  V7 F1.0
  V8 F1.0
  V9 F1.0
  V10 F1.0
  V11 F1.0
  V12 F1.0
  V13 F1.0
  V14 F1.0
  V15 F1.0
  V16 F1.0
  V17 F1.0
  V18 F1.0
  V19 F1.0
  V20 F1.0
  V21 F1.0
  V22 F2.0
  V23 F1.0
  A47 F2.0
  V125a F1.0
  V125 F1.0
  V126 F1.0
  V127 F1.0
  V128 F1.0
  V129 F1.0
  V130 F1.0
  C1apes F1.0
  C1afam F1.0
  C1aami F1.0
  C1acol F1.0
  C1aviz F1.0
  C1acon F1.0
  C1anin F1.0
  C1b F1.0
  C1c F1.0
  C1d F1.0
  C2ami F1.0
  C2avo F1.0
  C2col F1.0
  C2con F1.0
  C2cun F1.0
  C2esp F1.0
  C2fil F1.0
  C2gen F1.0
  C2irm F1.0
  C2mae F1.0
  C2nam F1.0
  C2net F1.0
  C2nor F1.0
  C2pai F1.0
  C2pes F1.0
  C2pri F1.0
  C2sog F1.0
  C2tio F1.0
  C2viz F1.0
  C3ami F1.0
  C3avo F1.0
  C3col F1.0
  C3con F1.0
  C3cun F1.0
  C3esp F1.0
  C3fil F1.0
  C3gen F1.0
  C3irm F1.0
  C3mae F1.0
  C3nam F1.0
  C3net F1.0
  C3nor F1.0
  C3pai F1.0
  C3pes F1.0
  C3pri F1.0
  C3sog F1.0
  C3tio F1.0
  C3viz F1.0
  C4ami F1.0
  C4avo F1.0
  C4col F1.0
  C4con F1.0
  C4cun F1.0
  C4esp F1.0
  C4fil F1.0
  C4gen F1.0
  C4irm F1.0
  C4mae F1.0
  C4nam F1.0
  C4net F1.0
  C4nor F1.0
  C4pai F1.0
  C4pes F1.0
  C4pri F1.0
  C4sog F1.0
  C4tio F1.0
  C4viz F1.0
  I1 F1.0
  I2 F1.0
  I3 F1.0
  I4 F1.0
  I5 F1.0
  V198 F2.0
  V199 F2.0
  V200 F2.0
  V201 F2.0
  A198 F2.0
  A199 F2.0
  A200 F2.0
  A201 F2.0
  J1a F2.0
  J1b F2.0
  J1c F2.0
  J1d F2.0
  J2 F1.0
  J3coe F1.0
  J3fal F1.0
  J3idd F1.0
  J3ves F1.0
  V96 F1.0
  V96a F1.0
  V97 F1.0
  V98 F1.0
  V98a F1.0
  V98b F1.0
  V99 A92
  A1art F1.0
  A1esp F1.0
  A1igr F1.0
  A1mus F1.0
  A1nao F1.0
  A1o A270
  A2ass F1.0
  A2nao F1.0
  A2o A141
  A2prt F1.0
  A2sin F1.0
  V185 F2.0
  V185eo A11
  V185o A98
  V186 F1.0
  V187a F1.0
  V187b F1.0
  V223 F1.0
  V224 F1.0
  V225 F1.0
  V226 F1.0
  V227 F1.0
  V228 F1.0
  V229 F1.0
  V230 F1.0
  F1 F1.0
  F2 F1.0
  F3 F1.0
  F4a F1.0
  F4b F1.0
  F5 A10
  V235 F1.0
  V236 F2.0
  V55 F1.0
  V56 F2.0
  V238 F1.0
  V238b A87
  V238br F2.0
  V240 F1.0
  V241 F1.0
  V241o A34
  V242 F1.0
  V242a F1.0
  V242o A86
  V243 F1.0
  V248 F1.0
  V249 F1.0
  V250 F2.0
  V250o A28
  V251 F1.0
  V256 F1.0
  fezrede F1.0
  P1 F1.0
  cidade F2.0
  S1 F1.0
  rels A485
  lsrel A1425
  formtrat F1.0
  horaini A19
  tempo2 A19
  tempo3 A19
  tempo4 A19
  tempo5 A19
  horafim A19
  tA47 F7.0
  tC1b F7.0
  tC1c F7.0
  tC1d F7.0
  tI1 F7.0
  tV235 F7.0
  tV238 F7.0
  tV240 F7.0
  tV241 F7.0
  tV242 F6.0
  tV242a F7.0
  tV243 F6.0
  tV248 F7.0
  tV249 F7.0
  tV250 F7.0
  tV251 F7.0
  tV256 F7.0
  tV55 F7.0
  tI2 F7.0
  tI3 F7.0
  tI4 F7.0
  tI5 F7.0
  tV10 F7.0
  tV11 F7.0
  tV125 F7.0
  tV125a F7.0
  tV126 F7.0
  tV127 F7.0
  tV128 F7.0
  tV129 F7.0
  tV130 F7.0
  tV198 F7.0
  tV199 F7.0
  tV200 F7.0
  tV201 F7.0
  tA198 F7.0
  tA199 F7.0
  tA200 F7.0
  tA201 F7.0
  tJ1a F7.0
  tJ1b F7.0
  tJ1c F7.0
  tJ1d F7.0
  tJ2 F7.0
  tV185 F8.0
  tV186 F8.0
  tV187a F8.0
  tV187b F8.0
  tV230 F8.0
  tV96 F8.0
  tV96a F8.0
  tV97 F8.0
  tV98 F8.0
  tV98a F8.0
  tV98b F8.0
  tV22 F7.0
  tV23 F7.0
  tV4 F7.0
  tV5 F7.0
  tV6 F7.0
  tV7 F7.0
  tV8 F7.0
  tV9 F7.0
  tP1 F7.0
  tS1 F7.0
  .
EXECUTE.

VARIABLE LABELS tipo "Type of contact with respondent" .
VARIABLE LABELS V4 "Importance of family" .
VARIABLE LABELS V5 "Importance of friends" .
VARIABLE LABELS V6 "Importance of leisure time" .
VARIABLE LABELS V7 "Importance of politics" .
VARIABLE LABELS V8 "Importance of work" .
VARIABLE LABELS V9 "Importance of religion" .
VARIABLE LABELS V10 "Are you happy?" .
VARIABLE LABELS V11 "State of your health" .
VARIABLE LABELS V12 "Important to learn: Independence" .
VARIABLE LABELS V13 "Important to learn: Hard work" .
VARIABLE LABELS V14 "Important to learn: Responsibility" .
VARIABLE LABELS V15 "Important to learn: Imagination" .
VARIABLE LABELS V16 "Important to learn: Tolerance and respect" .
VARIABLE LABELS V17 "Important to learn: Thrift" .
VARIABLE LABELS V18 "Important to learn: Determination, perseverance" .
VARIABLE LABELS V19 "Important to learn: Religious faith" .
VARIABLE LABELS V20 "Important to learn: Unselfishness" .
VARIABLE LABELS V21 "Important to learn: Obedience" .
VARIABLE LABELS V22 "How satisfied with life?" .
VARIABLE LABELS V23 "Can most people be trusted?" .
VARIABLE LABELS A47 "How many people would cheat you?" .
VARIABLE LABELS V125a "Trust: People in general" .
VARIABLE LABELS V125 "Trust: Relatives" .
VARIABLE LABELS V126 "Trust: Neighbors" .
VARIABLE LABELS V127 "Trust: Personally known people" .
VARIABLE LABELS V128 "Trust: People seen for the first time" .
VARIABLE LABELS V129 "Trust: People of other religion" .
VARIABLE LABELS V130 "Trust: People of other countries" .
VARIABLE LABELS C1apes "Most people includes: People seen for the first time" .
VARIABLE LABELS C1afam "Most people includes: Relatives" .
VARIABLE LABELS C1aami "Most people includes: Friends" .
VARIABLE LABELS C1acol "Most people includes: Colleagues" .
VARIABLE LABELS C1aviz "Most people includes: Neighbors" .
VARIABLE LABELS C1acon "Most people includes: Known people with there is no friendship" .
VARIABLE LABELS C1anin "Most people include: Didn't think in anybody" .
VARIABLE LABELS C1b "Reason to answer question V23" .
VARIABLE LABELS C1c "To trust is..." .
VARIABLE LABELS C1d "Situation similar to V23" .
VARIABLE LABELS C2ami "Financial aid: Friends" .
VARIABLE LABELS C2avo "Financial aid: Grandparents" .
VARIABLE LABELS C2col "Financial aid: Colleagues" .
VARIABLE LABELS C2con "Financial aid: Known people" .
VARIABLE LABELS C2cun "Financial aid: Brother-in-law" .
VARIABLE LABELS C2esp "Financial aid: Husband/Wife" .
VARIABLE LABELS C2fil "Financial aid: Children" .
VARIABLE LABELS C2gen "Financial aid: Son-in-law" .
VARIABLE LABELS C2irm "Financial aid: Siblings" .
VARIABLE LABELS C2mae "Financial aid: Mother" .
VARIABLE LABELS C2nam "Financial aid: Boyfriend/Girlfriend" .
VARIABLE LABELS C2net "Financial aid: Grandchildren" .
VARIABLE LABELS C2nor "Financial aid: Daughter-in-law" .
VARIABLE LABELS C2pai "Financial aid: Father" .
VARIABLE LABELS C2pes "Financial aid: People seen for the first time" .
VARIABLE LABELS C2pri "Financial aid: Cousins" .
VARIABLE LABELS C2sog "Financial aid: Father-in-law/Mother-in-law" .
VARIABLE LABELS C2tio "Financial aid: Uncles/Aunts" .
VARIABLE LABELS C2viz "Financial aid: Neighbors" .
VARIABLE LABELS C3ami "Help with time: Friends" .
VARIABLE LABELS C3avo "Help with time: Grandparents" .
VARIABLE LABELS C3col "Help with time: Colleagues" .
VARIABLE LABELS C3con "Help with time: Known people" .
VARIABLE LABELS C3cun "Help with time: Brother-in-law" .
VARIABLE LABELS C3esp "Help with time: Husband/Wife" .
VARIABLE LABELS C3fil "Help with time: Children" .
VARIABLE LABELS C3gen "Help with time: Son-in-law" .
VARIABLE LABELS C3irm "Help with time: Siblings" .
VARIABLE LABELS C3mae "Help with time: Mother" .
VARIABLE LABELS C3nam "Help with time: Boyfriend/Girlfriend" .
VARIABLE LABELS C3net "Help with time: Grandchildren" .
VARIABLE LABELS C3nor "Help with time: Daughter-in-law" .
VARIABLE LABELS C3pai "Help with time: Father" .
VARIABLE LABELS C3pes "Help with time: People seen for the first time" .
VARIABLE LABELS C3pri "Help with time: Cousins" .
VARIABLE LABELS C3sog "Help with time: Father-in-law/Mother-in-law" .
VARIABLE LABELS C3tio "Help with time: Uncles/Aunts" .
VARIABLE LABELS C3viz "Help with time: Neighbors" .
VARIABLE LABELS C4ami "Would loan money: Friends" .
VARIABLE LABELS C4avo "Would loan money: Grandparents" .
VARIABLE LABELS C4col "Would loan money: Colleagues" .
VARIABLE LABELS C4con "Would loan money: Known people" .
VARIABLE LABELS C4cun "Would loan money: Brother-in-law" .
VARIABLE LABELS C4esp "Would loan money: Husband/Wife" .
VARIABLE LABELS C4fil "Would loan money: Children" .
VARIABLE LABELS C4gen "Would loan money: Son-in-law" .
VARIABLE LABELS C4irm "Would loan money: Siblings" .
VARIABLE LABELS C4mae "Would loan money: Mother" .
VARIABLE LABELS C4nam "Would loan money: Boyfriend/Girlfriend" .
VARIABLE LABELS C4net "Would loan money: Grandchildren" .
VARIABLE LABELS C4nor "Would loan money: Daughter-in-law" .
VARIABLE LABELS C4pai "Would loan money: Father" .
VARIABLE LABELS C4pes "Would loan money: People seen for the first time" .
VARIABLE LABELS C4pri "Would loan money: Cousins" .
VARIABLE LABELS C4sog "Would loan money: Father-in-law/Mother-in-law" .
VARIABLE LABELS C4tio "Would loan money: Uncles/Aunts" .
VARIABLE LABELS C4viz "Would loan money: Neighbors" .
VARIABLE LABELS I1 "How many neighbors do you talk with?" .
VARIABLE LABELS I2 "Frequency of visits by relatives" .
VARIABLE LABELS I3 "Frequency of visits to relatives" .
VARIABLE LABELS I4 "Frequency of visits by friends" .
VARIABLE LABELS I5 "Frequency of visits to friends" .
VARIABLE LABELS V198 "Justifiable: claim benefits" .
VARIABLE LABELS V199 "Justifiable: avoid a fare" .
VARIABLE LABELS V200 "Justifiable: cheat on taxes" .
VARIABLE LABELS V201 "Justifiable: accept bribe" .
VARIABLE LABELS A198 "How many would do: claim benefits" .
VARIABLE LABELS A199 "How many would do: avoid a fare" .
VARIABLE LABELS A200 "How many would do: cheat on taxes" .
VARIABLE LABELS A201 "How many would do: accept bribe" .
VARIABLE LABELS J1a "Reason of honesty: goodness" .
VARIABLE LABELS J1b "Reason of honesty: guilty" .
VARIABLE LABELS J1c "Reason of honesty: reputation" .
VARIABLE LABELS J1d "Reason of honesty: fear of punishment" .
VARIABLE LABELS J2 "Recognize cheater" .
VARIABLE LABELS J3coe "How recognize: coherence of speech" .
VARIABLE LABELS J3fal "How recognize: way of talking" .
VARIABLE LABELS J3idd "How recognize: age" .
VARIABLE LABELS J3ves "How recognize: dressing style" .
VARIABLE LABELS V96 "Participation: sign a petition" .
VARIABLE LABELS V96a "Participation: sing online petition" .
VARIABLE LABELS V97 "Participation: join boycotts" .
VARIABLE LABELS V98 "Participation: pacific manifestation" .
VARIABLE LABELS V98a "Participation: protest in street" .
VARIABLE LABELS V98b "Participation: strikes" .
VARIABLE LABELS V99 "Participation: other" .
VARIABLE LABELS A1art "Participate: artistic group" .
VARIABLE LABELS A1esp "Participate: sport group" .
VARIABLE LABELS A1igr "Participate: church group" .
VARIABLE LABELS A1mus "Participate: musical group" .
VARIABLE LABELS A1nao "Participate: no group" .
VARIABLE LABELS A1o "Participate: other" .
VARIABLE LABELS A2ass "Participate: association" .
VARIABLE LABELS A2nao "Participate: no organization" .
VARIABLE LABELS A2o "Participate: other organization" .
VARIABLE LABELS A2prt "Participate: political party" .
VARIABLE LABELS A2sin "Participate: labor union" .
VARIABLE LABELS V185 "Religion" .
VARIABLE LABELS V185eo "Evangelical religion (other)" .
VARIABLE LABELS V185o "Religion (other)" .
VARIABLE LABELS V186 "Frequency of religious activity" .
VARIABLE LABELS V187a "Are you a religious person?" .
VARIABLE LABELS V187b "Do you believe in God?" .
VARIABLE LABELS V223 "Source of information: newspaper" .
VARIABLE LABELS V224 "Source of information: TV and radio news" .
VARIABLE LABELS V225 "Source of information: magazines" .
VARIABLE LABELS V226 "Source of information: TV and radio shows" .
VARIABLE LABELS V227 "Source of information: books" .
VARIABLE LABELS V228 "Source of information: internet and e-mail" .
VARIABLE LABELS V229 "Source of information: talks with friends and colleagues" .
VARIABLE LABELS V230 "Frequency of computer usage" .
VARIABLE LABELS F1 "Do you have a Facebook account?" .
VARIABLE LABELS F2 "Do you have a Orkut account?" .
VARIABLE LABELS F3 "Do you have a Twitter account?" .
VARIABLE LABELS F4a "Do you have a Skype account?" .
VARIABLE LABELS F4b "Do you have a MSN account?" .
VARIABLE LABELS F5 "Do you have a other online social network account?" .
VARIABLE LABELS V235 "Sex" .
VARIABLE LABELS V236 "Age" .
VARIABLE LABELS V55 "Marital status" .
VARIABLE LABELS V56 "Number of children" .
VARIABLE LABELS V238 "Education" .
VARIABLE LABELS V238b "Undergraduate course" .
VARIABLE LABELS V238br "Undergraduate course (recoded)" .
VARIABLE LABELS V240 "Do you live with your parents?" .
VARIABLE LABELS V241 "Are you employed?" .
VARIABLE LABELS V241o "Are you employed? (other possibility)" .
VARIABLE LABELS V242 "Profession or occupation" .
VARIABLE LABELS V242a "Have you already worked?" .
VARIABLE LABELS V242o "Profession or occupation (other possibility)" .
VARIABLE LABELS V243 "Sector of job" .
VARIABLE LABELS V248 "Do you receive the highest income in your household?" .
VARIABLE LABELS V249 "Does the person with the highest income work?" .
VARIABLE LABELS V250 "What is the job of person with the highest income?" .
VARIABLE LABELS V250o "What is the job of person with the highest income?" .
VARIABLE LABELS V251 "Did your family saved money?" .
VARIABLE LABELS V256 "Color" .
VARIABLE LABELS fezrede "Did the respondent filled his/her personal social network?" .
VARIABLE LABELS P1 "Monthly family income" .
VARIABLE LABELS cidade "City" .
VARIABLE LABELS S1 "Did you like the jumps?" .
VARIABLE LABELS rels "Classification of people in the social network" .
VARIABLE LABELS lsrel "List of links between people in the social network" .
VARIABLE LABELS formtrat "How to be treated in the questionnaire" .
VARIABLE LABELS horaini "Begin to fill the questionnaire" .
VARIABLE LABELS tempo2 "Begin to fill page 2 of questionnaire" .
VARIABLE LABELS tempo3 "Begin to fill page 3 of questionnaire" .
VARIABLE LABELS tempo4 "Begin to fill page 4 of questionnaire" .
VARIABLE LABELS tempo5 "Begin to fill page 5 of questionnaire" .
VARIABLE LABELS horafim "End to fill page 5 of questionnaire" .

VALUE LABELS tipo
  1 "Friend (E-mail)"
  2 "Friend (Facebook)"
  3 "Letters given in down town"
  4 "Down Town"
  5 "Facebook"
  6 "Facebook group"
  7 "Municipality"
  8 "Street: Pacoti"
  9 "Street: Redenção"
  10 "University"
  11 "Via internet" .

VALUE LABELS V4
  1 "Not at all important"
  2 "Not very important"
  3 "Rather important"
  4 "Very important" .

VALUE LABELS V5
  1 "Not at all important"
  2 "Not very important"
  3 "Rather important"
  4 "Very important" .

VALUE LABELS V6
  1 "Not at all important"
  2 "Not very important"
  3 "Rather important"
  4 "Very important" .

VALUE LABELS V7
  1 "Not at all important"
  2 "Not very important"
  3 "Rather important"
  4 "Very important" .

VALUE LABELS V8
  1 "Not at all important"
  2 "Not very important"
  3 "Rather important"
  4 "Very important" .

VALUE LABELS V9
  1 "Not at all important"
  2 "Not very important"
  3 "Rather important"
  4 "Very important" .

VALUE LABELS V10
  1 "Not at all happy"
  2 "Not very happy"
  3 "Rather happy"
  4 "Very happy" .

VALUE LABELS V11
  1 "Poor"
  2 "Fair"
  3 "Good"
  4 "Very good" .

VALUE LABELS V12
  1 "Not mentioned"
  2 "Mentioned" .

VALUE LABELS V13
  1 "Not mentioned"
  2 "Mentioned" .

VALUE LABELS V14
  1 "Not mentioned"
  2 "Mentioned" .

VALUE LABELS V15
  1 "Not mentioned"
  2 "Mentioned" .

VALUE LABELS V16
  1 "Not mentioned"
  2 "Mentioned" .

VALUE LABELS V17
  1 "Not mentioned"
  2 "Mentioned" .

VALUE LABELS V18
  1 "Not mentioned"
  2 "Mentioned" .

VALUE LABELS V19
  1 "Not mentioned"
  2 "Mentioned" .

VALUE LABELS V20
  1 "Not mentioned"
  2 "Mentioned" .

VALUE LABELS V21
  1 "Not mentioned"
  2 "Mentioned" .

VALUE LABELS V23
  1 "Need to be very careful"
  2 "Most people can be trusted" .

VALUE LABELS V125a
  1 "Don't trust at all"
  2 "Don't trust very much"
  3 "Trust somewhat"
  4 "Trust completely" .

VALUE LABELS V125
  1 "Don't trust at all"
  2 "Don't trust very much"
  3 "Trust somewhat"
  4 "Trust completely" .

VALUE LABELS V126
  1 "Don't trust at all"
  2 "Don't trust very much"
  3 "Trust somewhat"
  4 "Trust completely" .

VALUE LABELS V127
  1 "Don't trust at all"
  2 "Don't trust very much"
  3 "Trust somewhat"
  4 "Trust completely" .

VALUE LABELS V128
  1 "Don't trust at all"
  2 "Don't trust very much"
  3 "Trust somewhat"
  4 "Trust completely" .

VALUE LABELS V129
  1 "Don't trust at all"
  2 "Don't trust very much"
  3 "Trust somewhat"
  4 "Trust completely" .

VALUE LABELS V130
  1 "Don't trust at all"
  2 "Don't trust very much"
  3 "Trust somewhat"
  4 "Trust completely" .

VALUE LABELS C1apes
  1 "No"
  2 "Yes" .

VALUE LABELS C1afam
  1 "No"
  2 "Yes" .

VALUE LABELS C1aami
  1 "No"
  2 "Yes" .

VALUE LABELS C1acol
  1 "No"
  2 "Yes" .

VALUE LABELS C1aviz
  1 "No"
  2 "Yes" .

VALUE LABELS C1acon
  1 "No"
  2 "Yes" .

VALUE LABELS C1anin
  1 "Yes" .

VALUE LABELS C1b
  1 "Own experience"
  2 "I was taught" .

VALUE LABELS C1c
  1 "To assign responsibilities"
  2 "To share"
  3 "To know"
  4 "Fidelity"
  5 "To preview"
  6 "To feel safe"
  7 "To have a link" .

VALUE LABELS C1d
  1 "Friend to keep secret"
  2 "Partner don't betray"
  3 "To keep promise"
  4 "To loan things"
  5 "Stranger really to help"
  6 "To get you alone"
  7 "Person to be together" .

VALUE LABELS C2ami
  1 "No"
  2 "Yes" .

VALUE LABELS C2avo
  1 "No"
  2 "Yes" .

VALUE LABELS C2col
  1 "No"
  2 "Yes" .

VALUE LABELS C2con
  1 "No"
  2 "Yes" .

VALUE LABELS C2cun
  1 "No"
  2 "Yes" .

VALUE LABELS C2esp
  1 "No"
  2 "Yes" .

VALUE LABELS C2fil
  1 "No"
  2 "Yes" .

VALUE LABELS C2gen
  1 "No"
  2 "Yes" .

VALUE LABELS C2irm
  1 "No"
  2 "Yes" .

VALUE LABELS C2mae
  1 "No"
  2 "Yes" .

VALUE LABELS C2nam
  1 "No"
  2 "Yes" .

VALUE LABELS C2net
  1 "No"
  2 "Yes" .

VALUE LABELS C2nor
  1 "No"
  2 "Yes" .

VALUE LABELS C2pai
  1 "No"
  2 "Yes" .

VALUE LABELS C2pes
  1 "No"
  2 "Yes" .

VALUE LABELS C2pri
  1 "No"
  2 "Yes" .

VALUE LABELS C2sog
  1 "No"
  2 "Yes" .

VALUE LABELS C2tio
  1 "No"
  2 "Yes" .

VALUE LABELS C2viz
  1 "No"
  2 "Yes" .

VALUE LABELS C3ami
  1 "No"
  2 "Yes" .

VALUE LABELS C3avo
  1 "No"
  2 "Yes" .

VALUE LABELS C3col
  1 "No"
  2 "Yes" .

VALUE LABELS C3con
  1 "No"
  2 "Yes" .

VALUE LABELS C3cun
  1 "No"
  2 "Yes" .

VALUE LABELS C3esp
  1 "No"
  2 "Yes" .

VALUE LABELS C3fil
  1 "No"
  2 "Yes" .

VALUE LABELS C3gen
  1 "No"
  2 "Yes" .

VALUE LABELS C3irm
  1 "No"
  2 "Yes" .

VALUE LABELS C3mae
  1 "No"
  2 "Yes" .

VALUE LABELS C3nam
  1 "No"
  2 "Yes" .

VALUE LABELS C3net
  1 "No"
  2 "Yes" .

VALUE LABELS C3nor
  1 "No"
  2 "Yes" .

VALUE LABELS C3pai
  1 "No"
  2 "Yes" .

VALUE LABELS C3pes
  1 "No" .

VALUE LABELS C3pri
  1 "No"
  2 "Yes" .

VALUE LABELS C3sog
  1 "No"
  2 "Yes" .

VALUE LABELS C3tio
  1 "No"
  2 "Yes" .

VALUE LABELS C3viz
  1 "No"
  2 "Yes" .

VALUE LABELS C4ami
  1 "No"
  2 "Yes" .

VALUE LABELS C4avo
  1 "No"
  2 "Yes" .

VALUE LABELS C4col
  1 "No"
  2 "Yes" .

VALUE LABELS C4con
  1 "No"
  2 "Yes" .

VALUE LABELS C4cun
  1 "No"
  2 "Yes" .

VALUE LABELS C4esp
  1 "No"
  2 "Yes" .

VALUE LABELS C4fil
  1 "No"
  2 "Yes" .

VALUE LABELS C4gen
  1 "No"
  2 "Yes" .

VALUE LABELS C4irm
  1 "No"
  2 "Yes" .

VALUE LABELS C4mae
  1 "No"
  2 "Yes" .

VALUE LABELS C4nam
  1 "No"
  2 "Yes" .

VALUE LABELS C4net
  1 "No"
  2 "Yes" .

VALUE LABELS C4nor
  1 "No"
  2 "Yes" .

VALUE LABELS C4pai
  1 "No"
  2 "Yes" .

VALUE LABELS C4pes
  1 "No"
  2 "Yes" .

VALUE LABELS C4pri
  1 "No"
  2 "Yes" .

VALUE LABELS C4sog
  1 "No"
  2 "Yes" .

VALUE LABELS C4tio
  1 "No"
  2 "Yes" .

VALUE LABELS C4viz
  1 "No"
  2 "Yes" .

VALUE LABELS I1
  1 "None"
  2 "1"
  3 "2"
  4 "3 to 6"
  5 "more than 6" .

VALUE LABELS I2
  1 "Never"
  2 "Rarely"
  3 "Monthly"
  4 "Fortnightly"
  5 "Weekly"
  6 "Daily" .

VALUE LABELS I3
  1 "Never"
  2 "Rarely"
  3 "Monthly"
  4 "Fortnightly"
  5 "Weekly"
  6 "Daily" .

VALUE LABELS I4
  1 "Never"
  2 "Rarely"
  3 "Monthly"
  4 "Fortnightly"
  5 "Weekly"
  6 "Daily" .

VALUE LABELS I5
  1 "Never"
  2 "Rarely"
  3 "Monthly"
  4 "Fortnightly"
  5 "Weekly"
  6 "Daily" .

VALUE LABELS J2
  1 "Never"
  2 "Sometimes"
  3 "Almost always"
  4 "Always" .

VALUE LABELS J3coe
  1 "No"
  2 "Yes" .

VALUE LABELS J3fal
  1 "No"
  2 "Yes" .

VALUE LABELS J3idd
  1 "No"
  2 "Yes" .

VALUE LABELS J3ves
  1 "No"
  2 "Yes" .

VALUE LABELS V96
  1 "Would never do"
  2 "Could do"
  3 "I already did" .

VALUE LABELS V96a
  1 "Would never do"
  2 "Could do"
  3 "I already did" .

VALUE LABELS V97
  1 "Would never do"
  2 "Could do"
  3 "I already did" .

VALUE LABELS V98
  1 "Would never do"
  2 "Could do"
  3 "I already did" .

VALUE LABELS V98a
  1 "Would never do"
  2 "Could do"
  3 "I already did" .

VALUE LABELS V98b
  1 "Would never do"
  2 "Could do"
  3 "I already did" .

VALUE LABELS A1art
  1 "No"
  2 "Yes" .

VALUE LABELS A1esp
  1 "No"
  2 "Yes" .

VALUE LABELS A1igr
  1 "No"
  2 "Yes" .

VALUE LABELS A1mus
  1 "No"
  2 "Yes" .

VALUE LABELS A1nao
  1 "Don't participate" .

VALUE LABELS A2ass
  1 "No"
  2 "Yes" .

VALUE LABELS A2nao
  1 "Don't participate" .

VALUE LABELS A2prt
  1 "No"
  2 "Yes" .

VALUE LABELS A2sin
  1 "No"
  2 "Yes" .

VALUE LABELS V185
  1 "African"
  2 "Catholic"
  3 "Spiritism"
  4 "Ev.: Adventist"
  5 "Evangelical"
  6 "Ev.: Assembly of God"
  7 "Ev.: Baptist"
  8 "Ev.: Foursquare Gospel"
  9 "Jew"
  10 "Islam"
  11 "No religion" .

VALUE LABELS V186
  1 "Never"
  2 "Rarely"
  3 "Yearly"
  4 "In holy days"
  5 "Monthly"
  6 "Fortnightly"
  7 "Weekly"
  8 "More than once a week" .

VALUE LABELS V187a
  1 "Not religious"
  2 "Religious" .

VALUE LABELS V187b
  1 "Atheist"
  2 "Deist" .

VALUE LABELS V223
  1 "No"
  2 "Yes" .

VALUE LABELS V224
  1 "No"
  2 "Yes" .

VALUE LABELS V225
  1 "No"
  2 "Yes" .

VALUE LABELS V226
  1 "No"
  2 "Yes" .

VALUE LABELS V227
  1 "No"
  2 "Yes" .

VALUE LABELS V228
  1 "No"
  2 "Yes" .

VALUE LABELS V229
  1 "No"
  2 "Yes" .

VALUE LABELS V230
  1 "Frequently"
  2 "Rarely" .

VALUE LABELS F1
  1 "No"
  2 "Yes" .

VALUE LABELS F2
  1 "No"
  2 "Yes" .

VALUE LABELS F3
  1 "No"
  2 "Yes" .

VALUE LABELS F4a
  1 "No"
  2 "Yes" .

VALUE LABELS F4b
  1 "No"
  2 "Yes" .

VALUE LABELS V235
  1 "Female"
  2 "Male" .

VALUE LABELS V55
  1 "Married"
  2 "Divorced"
  3 "Cohabiting"
  4 "Separated"
  5 "Single"
  6 "Widowed" .

VALUE LABELS V238
  1 "Incomplete primary school"
  2 "Complete primary school"
  3 "Incomplete secondary school"
  4 "Complete secondary school"
  5 "Some university-level education, without degree"
  6 "University-level education, with degree" .

VALUE LABELS V238br
  1 "Administration and Accountancy"
  2 "Architecture"
  3 "Archival Science"
  4 "Biology"
  5 "Social Sciences"
  6 "Communication"
  7 "Design"
  8 "Law"
  9 "Economy"
  10 "Engineer"
  11 "Statistics"
  12 "History"
  13 "Philosophy"
  14 "Physics"
  15 "Geography"
  16 "Letters"
  17 "Mathematics"
  18 "Pedagogy"
  19 "Psychology"
  20 "Health"
  21 "Social Work"
  22 "No answer" .

VALUE LABELS V240
  1 "No"
  2 "Yes" .

VALUE LABELS V241
  1 "Self employed"
  2 "Unemployed"
  3 "Student"
  4 "Full time employee"
  5 "Part time employee"
  6 "Pensioned" .

VALUE LABELS V242
  1 "Employer with < 10 employees"
  2 "Employer with > 10 employees"
  3 "Skilled manual worker"
  4 "Semi-skilled manual worker"
  5 "Professional worker"
  6 "Supervisory - office worker"
  7 "Supervisory - manual worker"
  8 "Non-manual - office worker"
  9 "Agricultural worker" .

VALUE LABELS V242a
  1 "Never had a job"
  2 "Never worked"
  3 "Yes" .

VALUE LABELS V243
  1 "Govern"
  2 "NGO"
  3 "Private" .

VALUE LABELS V248
  1 "No"
  2 "Yes" .

VALUE LABELS V249
  1 "No"
  2 "Yes" .

VALUE LABELS V250
  1 "Manual"
  2 "Employer with < 10 employees"
  3 "Employer with > 10 employees"
  4 "Skilled manual worker"
  5 "Semi-skilled manual worker"
  6 "Military"
  7 "Never had a job"
  8 "Professional worker"
  9 "Supervisory - office worker"
  10 "Supervisory - manual worker"
  11 "Non-manual - office worker" .

VALUE LABELS V251
  1 "Spent savings and borrowed money"
  2 "Spent some savings"
  3 "Just get by"
  4 "Save money" .

VALUE LABELS V256
  1 "White"
  2 "Indigenous"
  3 "Black"
  4 "Asiatic"
  5 "Mixed of black and white" .

VALUE LABELS fezrede
  1 "No"
  2 "Yes" .

VALUE LABELS P1
  1 "< 1"
  2 "1 to 2"
  3 "2 to 5"
  4 "5 to 10"
  5 "10 to 15"
  6 "15 to 20"
  7 "> 20" .

VALUE LABELS cidade
  1 "Aracaju"
  2 "Aracoia"
  3 "Aracoiaba"
  4 "Arapiraca"
  5 "Barreira"
  6 "Belém"
  7 "Belo Horizonte"
  8 "Betim"
  9 "Branquinha"
  10 "Brasília"
  11 "Cabedelo"
  12 "Cachoeira"
  13 "Campina Grande"
  14 "Campinas"
  15 "Caucaia"
  16 "Crato"
  17 "Dresden"
  18 "Eunapolis"
  19 "Florianópolis"
  20 "Fortaleza"
  21 "Fortim"
  22 "Horizonte"
  23 "Ivaiporã"
  24 "João Pessoa"
  25 "Lagoa Santa"
  26 "Limeira"
  27 "Limoeiro"
  28 "Maceió"
  29 "Magé"
  30 "Maracanaú"
  31 "Maranguape"
  32 "Maravillha"
  33 "Natal"
  34 "Niterói"
  35 "Nova Iguaçu"
  36 "Nova Lima"
  37 "Olinda"
  38 "Palhoça"
  39 "Porto de Pedras"
  40 "Pouso Alegre"
  41 "Recife"
  42 "Redenção"
  43 "Ribeirão Preto"
  44 "Rio"
  45 "Rio Claro"
  46 "Rio de Janeiro"
  47 "Santos"
  48 "São Carlos"
  49 "São Paulo"
  50 "Tianguá"
  51 "Timbuctu"
  52 "Vassouras"
  53 "Viçosa" .

VALUE LABELS S1
  1 "I liked"
  2 "I didn't like" .

VALUE LABELS formtrat
  1 "ASenhora"
  2 "OSenhor"
  3 "Você" .

SAVE OUTFILE="trust.sav"
  /COMPRESSED.
