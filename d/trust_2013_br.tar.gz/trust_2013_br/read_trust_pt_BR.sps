*******************************************************************************
* 
*  SPSS script to load the data used at:
*
*  Aquino, Jakson Alves de.
*  The meaning of trust for Brazilians with higher education.
*  Social Indicators Research.
* 
*******************************************************************************

GET DATA
  /TYPE=TXT
  /FILE='trust.txt'
  /DELCASE=LINE
  /DELIMITERS="\t"
  /ARRANGEMENT=DELIMITED
  /FIRSTCASE=2
  /IMPORTCASE=ALL
  /VARIABLES=
  codigoacesso A11
  tipo F2.0
  V4 F1.0
  V5 F1.0
  V6 F1.0
  V7 F1.0
  V8 F1.0
  V9 F1.0
  V10 F1.0
  V11 F1.0
  V12 F1.0
  V13 F1.0
  V14 F1.0
  V15 F1.0
  V16 F1.0
  V17 F1.0
  V18 F1.0
  V19 F1.0
  V20 F1.0
  V21 F1.0
  V22 F2.0
  V23 F1.0
  A47 F2.0
  V125a F1.0
  V125 F1.0
  V126 F1.0
  V127 F1.0
  V128 F1.0
  V129 F1.0
  V130 F1.0
  C1apes F1.0
  C1afam F1.0
  C1aami F1.0
  C1acol F1.0
  C1aviz F1.0
  C1acon F1.0
  C1anin F1.0
  C1b F1.0
  C1c F1.0
  C1d F1.0
  C2ami F1.0
  C2avo F1.0
  C2col F1.0
  C2con F1.0
  C2cun F1.0
  C2esp F1.0
  C2fil F1.0
  C2gen F1.0
  C2irm F1.0
  C2mae F1.0
  C2nam F1.0
  C2net F1.0
  C2nor F1.0
  C2pai F1.0
  C2pes F1.0
  C2pri F1.0
  C2sog F1.0
  C2tio F1.0
  C2viz F1.0
  C3ami F1.0
  C3avo F1.0
  C3col F1.0
  C3con F1.0
  C3cun F1.0
  C3esp F1.0
  C3fil F1.0
  C3gen F1.0
  C3irm F1.0
  C3mae F1.0
  C3nam F1.0
  C3net F1.0
  C3nor F1.0
  C3pai F1.0
  C3pes F1.0
  C3pri F1.0
  C3sog F1.0
  C3tio F1.0
  C3viz F1.0
  C4ami F1.0
  C4avo F1.0
  C4col F1.0
  C4con F1.0
  C4cun F1.0
  C4esp F1.0
  C4fil F1.0
  C4gen F1.0
  C4irm F1.0
  C4mae F1.0
  C4nam F1.0
  C4net F1.0
  C4nor F1.0
  C4pai F1.0
  C4pes F1.0
  C4pri F1.0
  C4sog F1.0
  C4tio F1.0
  C4viz F1.0
  I1 F1.0
  I2 F1.0
  I3 F1.0
  I4 F1.0
  I5 F1.0
  V198 F2.0
  V199 F2.0
  V200 F2.0
  V201 F2.0
  A198 F2.0
  A199 F2.0
  A200 F2.0
  A201 F2.0
  J1a F2.0
  J1b F2.0
  J1c F2.0
  J1d F2.0
  J2 F1.0
  J3coe F1.0
  J3fal F1.0
  J3idd F1.0
  J3ves F1.0
  V96 F1.0
  V96a F1.0
  V97 F1.0
  V98 F1.0
  V98a F1.0
  V98b F1.0
  V99 A92
  A1art F1.0
  A1esp F1.0
  A1igr F1.0
  A1mus F1.0
  A1nao F1.0
  A1o A270
  A2ass F1.0
  A2nao F1.0
  A2o A141
  A2prt F1.0
  A2sin F1.0
  V185 F2.0
  V185eo A11
  V185o A98
  V186 F1.0
  V187a F1.0
  V187b F1.0
  V223 F1.0
  V224 F1.0
  V225 F1.0
  V226 F1.0
  V227 F1.0
  V228 F1.0
  V229 F1.0
  V230 F1.0
  F1 F1.0
  F2 F1.0
  F3 F1.0
  F4a F1.0
  F4b F1.0
  F5 A10
  V235 F1.0
  V236 F2.0
  V55 F1.0
  V56 F2.0
  V238 F1.0
  V238b A87
  V238br F2.0
  V240 F1.0
  V241 F1.0
  V241o A34
  V242 F1.0
  V242a F1.0
  V242o A86
  V243 F1.0
  V248 F1.0
  V249 F1.0
  V250 F2.0
  V250o A28
  V251 F1.0
  V256 F1.0
  fezrede F1.0
  P1 F1.0
  cidade F2.0
  S1 F1.0
  rels A485
  lsrel A1425
  formtrat F1.0
  horaini A19
  tempo2 A19
  tempo3 A19
  tempo4 A19
  tempo5 A19
  horafim A19
  tA47 F7.0
  tC1b F7.0
  tC1c F7.0
  tC1d F7.0
  tI1 F7.0
  tV235 F7.0
  tV238 F7.0
  tV240 F7.0
  tV241 F7.0
  tV242 F6.0
  tV242a F7.0
  tV243 F6.0
  tV248 F7.0
  tV249 F7.0
  tV250 F7.0
  tV251 F7.0
  tV256 F7.0
  tV55 F7.0
  tI2 F7.0
  tI3 F7.0
  tI4 F7.0
  tI5 F7.0
  tV10 F7.0
  tV11 F7.0
  tV125 F7.0
  tV125a F7.0
  tV126 F7.0
  tV127 F7.0
  tV128 F7.0
  tV129 F7.0
  tV130 F7.0
  tV198 F7.0
  tV199 F7.0
  tV200 F7.0
  tV201 F7.0
  tA198 F7.0
  tA199 F7.0
  tA200 F7.0
  tA201 F7.0
  tJ1a F7.0
  tJ1b F7.0
  tJ1c F7.0
  tJ1d F7.0
  tJ2 F7.0
  tV185 F8.0
  tV186 F8.0
  tV187a F8.0
  tV187b F8.0
  tV230 F8.0
  tV96 F8.0
  tV96a F8.0
  tV97 F8.0
  tV98 F8.0
  tV98a F8.0
  tV98b F8.0
  tV22 F7.0
  tV23 F7.0
  tV4 F7.0
  tV5 F7.0
  tV6 F7.0
  tV7 F7.0
  tV8 F7.0
  tV9 F7.0
  tP1 F7.0
  tS1 F7.0
  .
EXECUTE.

VARIABLE LABELS tipo "Tipo de contato com respondente" .
VARIABLE LABELS V4 "Importância da família" .
VARIABLE LABELS V5 "Importância dos amigos" .
VARIABLE LABELS V6 "Importância do tempo livre" .
VARIABLE LABELS V7 "Importância da política" .
VARIABLE LABELS V8 "Importância do trabalho" .
VARIABLE LABELS V9 "Importância da religião" .
VARIABLE LABELS V10 "Se considera feliz" .
VARIABLE LABELS V11 "Como está sua saúde?" .
VARIABLE LABELS V12 "Importante ensinar: Independência" .
VARIABLE LABELS V13 "Importante ensinar: Ser trabalhador" .
VARIABLE LABELS V14 "Importante ensinar: Responsabilidade" .
VARIABLE LABELS V15 "Importante ensinar: Criatividade" .
VARIABLE LABELS V16 "Importante ensinar: Tolerância e respeito pelos outros" .
VARIABLE LABELS V17 "Importante ensinar: Saber economizar (dinheiro e outros bens)" .
VARIABLE LABELS V18 "Importante ensinar: Determinação e perseverança" .
VARIABLE LABELS V19 "Importante ensinar: Ter fé religiosa" .
VARIABLE LABELS V20 "Importante ensinar: Não ser egoísta" .
VARIABLE LABELS V21 "Importante ensinar: Obediência" .
VARIABLE LABELS V22 "Quão satisfeito com a vida?" .
VARIABLE LABELS V23 "Pode confiar na maioria das pessoas?" .
VARIABLE LABELS A47 "Quantas pessoas tentariam levar vantagem?" .
VARIABLE LABELS V125a "Confiança: Pessoas em geral" .
VARIABLE LABELS V125 "Confiança: Família" .
VARIABLE LABELS V126 "Confiança: Seus vizinhos" .
VARIABLE LABELS V127 "Confiança: Pessoas que conhece pessoalmente" .
VARIABLE LABELS V128 "Confiança: Pessoas que está vendo pela primeira vez" .
VARIABLE LABELS V129 "Confiança: Pessoas de outras religiões" .
VARIABLE LABELS V130 "Confiança: Pessoas de outros países" .
VARIABLE LABELS C1apes "Maioria inclui: Pessoas que estaria vendo pela primeira vez" .
VARIABLE LABELS C1afam "Maioria inclui: Familiares" .
VARIABLE LABELS C1aami "Maioria inclui: Amigos" .
VARIABLE LABELS C1acol "Maioria inclui: Colegas de trabalho" .
VARIABLE LABELS C1aviz "Maioria inclui: Vizinhos" .
VARIABLE LABELS C1acon "Maioria inclui: Conhecidos com quem não tem amizade" .
VARIABLE LABELS C1anin "Maioria inclui: não pensou em ninguém" .
VARIABLE LABELS C1b "Motivo da resposta à V23" .
VARIABLE LABELS C1c "Confiar é..." .
VARIABLE LABELS C1d "Situação semelhante a V23" .
VARIABLE LABELS C2ami "Ajuda financeira: Amigos" .
VARIABLE LABELS C2avo "Ajuda financeira: Avós" .
VARIABLE LABELS C2col "Ajuda financeira: Colegas" .
VARIABLE LABELS C2con "Ajuda financeira: Conhecidos" .
VARIABLE LABELS C2cun "Ajuda financeira: Cunhados" .
VARIABLE LABELS C2esp "Ajuda financeira: Esposo(a)" .
VARIABLE LABELS C2fil "Ajuda financeira: Filhos" .
VARIABLE LABELS C2gen "Ajuda financeira: Genros" .
VARIABLE LABELS C2irm "Ajuda financeira: Irmãos" .
VARIABLE LABELS C2mae "Ajuda financeira: Mãe" .
VARIABLE LABELS C2nam "Ajuda financeira: Namorado(a)" .
VARIABLE LABELS C2net "Ajuda financeira: Netos" .
VARIABLE LABELS C2nor "Ajuda financeira: Noras" .
VARIABLE LABELS C2pai "Ajuda financeira: Pai" .
VARIABLE LABELS C2pes "Ajuda financeira: Pessoas sendo vistas pela primeira vez" .
VARIABLE LABELS C2pri "Ajuda financeira: Primos" .
VARIABLE LABELS C2sog "Ajuda financeira: Sogros" .
VARIABLE LABELS C2tio "Ajuda financeira: Tios" .
VARIABLE LABELS C2viz "Ajuda financeira: Vizinhos" .
VARIABLE LABELS C3ami "Ajuda em tempo: Amigos" .
VARIABLE LABELS C3avo "Ajuda em tempo: Avós" .
VARIABLE LABELS C3col "Ajuda em tempo: Colegas" .
VARIABLE LABELS C3con "Ajuda em tempo: Conhecidos" .
VARIABLE LABELS C3cun "Ajuda em tempo: Cunhados" .
VARIABLE LABELS C3esp "Ajuda em tempo: Esposo(a)" .
VARIABLE LABELS C3fil "Ajuda em tempo: Filhos" .
VARIABLE LABELS C3gen "Ajuda em tempo: Genros" .
VARIABLE LABELS C3irm "Ajuda em tempo: Irmãos" .
VARIABLE LABELS C3mae "Ajuda em tempo: Mãe" .
VARIABLE LABELS C3nam "Ajuda em tempo: Namorado(a)" .
VARIABLE LABELS C3net "Ajuda em tempo: Netos" .
VARIABLE LABELS C3nor "Ajuda em tempo: Noras" .
VARIABLE LABELS C3pai "Ajuda em tempo: Pai" .
VARIABLE LABELS C3pes "Ajuda em tempo: Pessoas sendo vistas pela primeira vez" .
VARIABLE LABELS C3pri "Ajuda em tempo: Primos" .
VARIABLE LABELS C3sog "Ajuda em tempo: Sogros" .
VARIABLE LABELS C3tio "Ajuda em tempo: Tios" .
VARIABLE LABELS C3viz "Ajuda em tempo: Vizinhos" .
VARIABLE LABELS C4ami "Emprestaria dinheiro: Amigos" .
VARIABLE LABELS C4avo "Emprestaria dinheiro: Avós" .
VARIABLE LABELS C4col "Emprestaria dinheiro: Colegas" .
VARIABLE LABELS C4con "Emprestaria dinheiro: Conhecidos" .
VARIABLE LABELS C4cun "Emprestaria dinheiro: Cunhados" .
VARIABLE LABELS C4esp "Emprestaria dinheiro: Esposo(a)" .
VARIABLE LABELS C4fil "Emprestaria dinheiro: Filhos" .
VARIABLE LABELS C4gen "Emprestaria dinheiro: Genros" .
VARIABLE LABELS C4irm "Emprestaria dinheiro: Irmãos" .
VARIABLE LABELS C4mae "Emprestaria dinheiro: Mãe" .
VARIABLE LABELS C4nam "Emprestaria dinheiro: Namorado(a)" .
VARIABLE LABELS C4net "Emprestaria dinheiro: Netos" .
VARIABLE LABELS C4nor "Emprestaria dinheiro: Noras" .
VARIABLE LABELS C4pai "Emprestaria dinheiro: Pai" .
VARIABLE LABELS C4pes "Emprestaria dinheiro: Pessoas sendo vistas pela primeira vez" .
VARIABLE LABELS C4pri "Emprestaria dinheiro: Primos" .
VARIABLE LABELS C4sog "Emprestaria dinheiro: Sogros" .
VARIABLE LABELS C4tio "Emprestaria dinheiro: Tios" .
VARIABLE LABELS C4viz "Emprestaria dinheiro: Vizinhos" .
VARIABLE LABELS I1 "Com quantos vizinhos conversa" .
VARIABLE LABELS I2 "Frequência com que recebe visitas de parentes?" .
VARIABLE LABELS I3 "Frequência com que faz visitas a parentes?" .
VARIABLE LABELS I4 "Frequência com que recebe visitas de amigos?" .
VARIABLE LABELS I5 "Frequência com que faz visitas a amigos?" .
VARIABLE LABELS V198 "Se justifica: pedir benefícios" .
VARIABLE LABELS V199 "Se justifica: Evitar pagar passagem" .
VARIABLE LABELS V200 "Se justifica: Não pagar impostos" .
VARIABLE LABELS V201 "Se justifica: Aceitar suborno para cumprir seu dever" .
VARIABLE LABELS A198 "Quantos fariam: pedir benefícios" .
VARIABLE LABELS A199 "Quantos fariam: Evitar pagar passagem" .
VARIABLE LABELS A200 "Quantos fariam: Não pagar impostos" .
VARIABLE LABELS A201 "Quantos fariam: Aceitar suborno para cumprir seu dever" .
VARIABLE LABELS J1a "Motivo de honestidade: bondade" .
VARIABLE LABELS J1b "Motivo de honestidade: sentimento de culpa" .
VARIABLE LABELS J1c "Motivo de honestidade: preocupação com reputação" .
VARIABLE LABELS J1d "Motivo de honestidade: medo de punição" .
VARIABLE LABELS J2 "Reconhece injusto" .
VARIABLE LABELS J3coe "Como reconhece: A coerência do que ela diz" .
VARIABLE LABELS J3fal "Como reconhece: A forma de falar" .
VARIABLE LABELS J3idd "Como reconhece: A idade da pessoa" .
VARIABLE LABELS J3ves "Como reconhece: A forma de se vestir" .
VARIABLE LABELS V96 "Participação: abaixo-assinado" .
VARIABLE LABELS V96a "Participação: petição pela internet" .
VARIABLE LABELS V97 "Participação: boicotes" .
VARIABLE LABELS V98 "Participação: manifestações pacíficas" .
VARIABLE LABELS V98a "Participação: passeatas" .
VARIABLE LABELS V98b "Participação: greves" .
VARIABLE LABELS V99 "Participação: outras formas" .
VARIABLE LABELS A1art "Participa: grupo artístico" .
VARIABLE LABELS A1esp "Participa: grupo esportivo" .
VARIABLE LABELS A1igr "Participa: grupo de igreja" .
VARIABLE LABELS A1mus "Participa: grupo musical" .
VARIABLE LABELS A1nao "Participa: Nenhum grupo" .
VARIABLE LABELS A1o "Participa: Outro tipo de grupo" .
VARIABLE LABELS A2ass "Participa: associação" .
VARIABLE LABELS A2nao "Participa: Nenhuma organização" .
VARIABLE LABELS A2o "Participa: Outro tipo de organização" .
VARIABLE LABELS A2prt "Participa: partido político" .
VARIABLE LABELS A2sin "Participa: sindicato" .
VARIABLE LABELS V185 "Religião" .
VARIABLE LABELS V185eo "Religião evangélica (outra)" .
VARIABLE LABELS V185o "Religião (outra)" .
VARIABLE LABELS V186 "Frequência em atividades religiosas" .
VARIABLE LABELS V187a "É religiosa?" .
VARIABLE LABELS V187b "Acredita em Deus?" .
VARIABLE LABELS V223 "Fonte de informação: Jornal impresso" .
VARIABLE LABELS V224 "Fonte de informação: Jornais de TV ou rádio" .
VARIABLE LABELS V225 "Fonte de informação: Revistas" .
VARIABLE LABELS V226 "Fonte de informação: Programas de rádio ou TV" .
VARIABLE LABELS V227 "Fonte de informação: Livros" .
VARIABLE LABELS V228 "Fonte de informação: Internet e e-mail" .
VARIABLE LABELS V229 "Fonte de informação: Conversas com amigos ou colegas" .
VARIABLE LABELS V230 "Frequência de uso do computador" .
VARIABLE LABELS F1 "Tem Facebook?" .
VARIABLE LABELS F2 "Tem Orkut?" .
VARIABLE LABELS F3 "Tem Twitter?" .
VARIABLE LABELS F4a "Tem Skype?" .
VARIABLE LABELS F4b "Tem MSN?" .
VARIABLE LABELS F5 "Outras redes" .
VARIABLE LABELS V235 "Sexo" .
VARIABLE LABELS V236 "Idade" .
VARIABLE LABELS V55 "Estado civil" .
VARIABLE LABELS V56 "Número de filhos" .
VARIABLE LABELS V238 "Escolaridade" .
VARIABLE LABELS V238b "Curso de nível superior" .
VARIABLE LABELS V238br "Curso de nível superior (recodificado)" .
VARIABLE LABELS V240 "Mora com seus pais?" .
VARIABLE LABELS V241 "Está empregado?" .
VARIABLE LABELS V241o "Está empregado? (outra possibilidade)" .
VARIABLE LABELS V242 "Profissão ou ocupação?" .
VARIABLE LABELS V242a "Já trabalhou?" .
VARIABLE LABELS V242o "Profissão ou ocupação? (outra possibilidade)" .
VARIABLE LABELS V243 "Setor de trabalho?" .
VARIABLE LABELS V248 "Recebe o salário mais alto de sua casa?" .
VARIABLE LABELS V249 "A pessoa de rendimento mais alto trabalha" .
VARIABLE LABELS V250 "Qual a profissão ou ocupação da pessoa de rendimento mais alto" .
VARIABLE LABELS V250o "Qual a profissão ou ocupação da pessoa de rendimento mais alto" .
VARIABLE LABELS V251 "Sua família guardou ou gastou dinheiro" .
VARIABLE LABELS V256 "Cor" .
VARIABLE LABELS fezrede "Preencheu dados da própria rede social?" .
VARIABLE LABELS P1 "Renda familiar mensal" .
VARIABLE LABELS cidade "Cidade" .
VARIABLE LABELS S1 "Gostou dos pulos?" .
VARIABLE LABELS rels "Classificação das pessoas na rede social" .
VARIABLE LABELS lsrel "Lista de ligações entre as pessoas na rede social" .
VARIABLE LABELS formtrat "Forma de tratamento" .
VARIABLE LABELS horaini "Início do preenchimento do questionário" .
VARIABLE LABELS tempo2 "Início do preenchimento da 2ª página" .
VARIABLE LABELS tempo3 "Início do preenchimento da 3ª página" .
VARIABLE LABELS tempo4 "Início do preenchimento da 4ª página" .
VARIABLE LABELS tempo5 "Início do preenchimento da 5ª página" .
VARIABLE LABELS horafim "Fim do preenchimento da 5ª página" .

VALUE LABELS tipo
  1 "Amigo (E-mail)"
  2 "Amigo (Facebook)"
  3 "Cartas entregues no centro"
  4 "Centro"
  5 "Facebook"
  6 "Grupo do Facebook"
  7 "Prefeitura"
  8 "Rua: Pacoti"
  9 "Rua: Redenção"
  10 "Universidade"
  11 "Via internet" .

VALUE LABELS V4
  1 "Não é importante"
  2 "Pouco importante"
  3 "Importante"
  4 "Muito importante" .

VALUE LABELS V5
  1 "Não é importante"
  2 "Pouco importante"
  3 "Importante"
  4 "Muito importante" .

VALUE LABELS V6
  1 "Não é importante"
  2 "Pouco importante"
  3 "Importante"
  4 "Muito importante" .

VALUE LABELS V7
  1 "Não é importante"
  2 "Pouco importante"
  3 "Importante"
  4 "Muito importante" .

VALUE LABELS V8
  1 "Não é importante"
  2 "Pouco importante"
  3 "Importante"
  4 "Muito importante" .

VALUE LABELS V9
  1 "Não é importante"
  2 "Pouco importante"
  3 "Importante"
  4 "Muito importante" .

VALUE LABELS V10
  1 "Infeliz"
  2 "Não muito feliz"
  3 "Feliz"
  4 "Muito feliz" .

VALUE LABELS V11
  1 "Ruim"
  2 "Razoável"
  3 "Boa"
  4 "Muito boa" .

VALUE LABELS V12
  1 "Não mencionada"
  2 "Mencionada" .

VALUE LABELS V13
  1 "Não mencionada"
  2 "Mencionada" .

VALUE LABELS V14
  1 "Não mencionada"
  2 "Mencionada" .

VALUE LABELS V15
  1 "Não mencionada"
  2 "Mencionada" .

VALUE LABELS V16
  1 "Não mencionada"
  2 "Mencionada" .

VALUE LABELS V17
  1 "Não mencionada"
  2 "Mencionada" .

VALUE LABELS V18
  1 "Não mencionada"
  2 "Mencionada" .

VALUE LABELS V19
  1 "Não mencionada"
  2 "Mencionada" .

VALUE LABELS V20
  1 "Não mencionada"
  2 "Mencionada" .

VALUE LABELS V21
  1 "Não mencionada"
  2 "Mencionada" .

VALUE LABELS V23
  1 "É preciso ser muito cuidadoso"
  2 "As pessoas são de confiança" .

VALUE LABELS V125a
  1 "Não confia"
  2 "Pouco"
  3 "Em parte"
  4 "Totalmente" .

VALUE LABELS V125
  1 "Não confia"
  2 "Pouco"
  3 "Em parte"
  4 "Totalmente" .

VALUE LABELS V126
  1 "Não confia"
  2 "Pouco"
  3 "Em parte"
  4 "Totalmente" .

VALUE LABELS V127
  1 "Não confia"
  2 "Pouco"
  3 "Em parte"
  4 "Totalmente" .

VALUE LABELS V128
  1 "Não confia"
  2 "Pouco"
  3 "Em parte"
  4 "Totalmente" .

VALUE LABELS V129
  1 "Não confia"
  2 "Pouco"
  3 "Em parte"
  4 "Totalmente" .

VALUE LABELS V130
  1 "Não confia"
  2 "Pouco"
  3 "Em parte"
  4 "Totalmente" .

VALUE LABELS C1apes
  1 "Não"
  2 "Sim" .

VALUE LABELS C1afam
  1 "Não"
  2 "Sim" .

VALUE LABELS C1aami
  1 "Não"
  2 "Sim" .

VALUE LABELS C1acol
  1 "Não"
  2 "Sim" .

VALUE LABELS C1aviz
  1 "Não"
  2 "Sim" .

VALUE LABELS C1acon
  1 "Não"
  2 "Sim" .

VALUE LABELS C1anin
  1 "Sim" .

VALUE LABELS C1b
  1 "Experiência própria"
  2 "Me ensinaram" .

VALUE LABELS C1c
  1 "Atribuir responsabilidades"
  2 "Compartilhar"
  3 "Conhecer"
  4 "Fidelidade"
  5 "Prever"
  6 "Sentir-se seguro"
  7 "Ter um elo" .

VALUE LABELS C1d
  1 "Amigo guardar segredo"
  2 "Companheiro não trair"
  3 "Cumprir palavra"
  4 "Emprestar coisas"
  5 "Estranho realmente ajudar"
  6 "Ficar a sós"
  7 "Pessoa estar ao lado" .

VALUE LABELS C2ami
  1 "Não"
  2 "Sim" .

VALUE LABELS C2avo
  1 "Não"
  2 "Sim" .

VALUE LABELS C2col
  1 "Não"
  2 "Sim" .

VALUE LABELS C2con
  1 "Não"
  2 "Sim" .

VALUE LABELS C2cun
  1 "Não"
  2 "Sim" .

VALUE LABELS C2esp
  1 "Não"
  2 "Sim" .

VALUE LABELS C2fil
  1 "Não"
  2 "Sim" .

VALUE LABELS C2gen
  1 "Não"
  2 "Sim" .

VALUE LABELS C2irm
  1 "Não"
  2 "Sim" .

VALUE LABELS C2mae
  1 "Não"
  2 "Sim" .

VALUE LABELS C2nam
  1 "Não"
  2 "Sim" .

VALUE LABELS C2net
  1 "Não"
  2 "Sim" .

VALUE LABELS C2nor
  1 "Não"
  2 "Sim" .

VALUE LABELS C2pai
  1 "Não"
  2 "Sim" .

VALUE LABELS C2pes
  1 "Não"
  2 "Sim" .

VALUE LABELS C2pri
  1 "Não"
  2 "Sim" .

VALUE LABELS C2sog
  1 "Não"
  2 "Sim" .

VALUE LABELS C2tio
  1 "Não"
  2 "Sim" .

VALUE LABELS C2viz
  1 "Não"
  2 "Sim" .

VALUE LABELS C3ami
  1 "Não"
  2 "Sim" .

VALUE LABELS C3avo
  1 "Não"
  2 "Sim" .

VALUE LABELS C3col
  1 "Não"
  2 "Sim" .

VALUE LABELS C3con
  1 "Não"
  2 "Sim" .

VALUE LABELS C3cun
  1 "Não"
  2 "Sim" .

VALUE LABELS C3esp
  1 "Não"
  2 "Sim" .

VALUE LABELS C3fil
  1 "Não"
  2 "Sim" .

VALUE LABELS C3gen
  1 "Não"
  2 "Sim" .

VALUE LABELS C3irm
  1 "Não"
  2 "Sim" .

VALUE LABELS C3mae
  1 "Não"
  2 "Sim" .

VALUE LABELS C3nam
  1 "Não"
  2 "Sim" .

VALUE LABELS C3net
  1 "Não"
  2 "Sim" .

VALUE LABELS C3nor
  1 "Não"
  2 "Sim" .

VALUE LABELS C3pai
  1 "Não"
  2 "Sim" .

VALUE LABELS C3pes
  1 "Não" .

VALUE LABELS C3pri
  1 "Não"
  2 "Sim" .

VALUE LABELS C3sog
  1 "Não"
  2 "Sim" .

VALUE LABELS C3tio
  1 "Não"
  2 "Sim" .

VALUE LABELS C3viz
  1 "Não"
  2 "Sim" .

VALUE LABELS C4ami
  1 "Não"
  2 "Sim" .

VALUE LABELS C4avo
  1 "Não"
  2 "Sim" .

VALUE LABELS C4col
  1 "Não"
  2 "Sim" .

VALUE LABELS C4con
  1 "Não"
  2 "Sim" .

VALUE LABELS C4cun
  1 "Não"
  2 "Sim" .

VALUE LABELS C4esp
  1 "Não"
  2 "Sim" .

VALUE LABELS C4fil
  1 "Não"
  2 "Sim" .

VALUE LABELS C4gen
  1 "Não"
  2 "Sim" .

VALUE LABELS C4irm
  1 "Não"
  2 "Sim" .

VALUE LABELS C4mae
  1 "Não"
  2 "Sim" .

VALUE LABELS C4nam
  1 "Não"
  2 "Sim" .

VALUE LABELS C4net
  1 "Não"
  2 "Sim" .

VALUE LABELS C4nor
  1 "Não"
  2 "Sim" .

VALUE LABELS C4pai
  1 "Não"
  2 "Sim" .

VALUE LABELS C4pes
  1 "Não"
  2 "Sim" .

VALUE LABELS C4pri
  1 "Não"
  2 "Sim" .

VALUE LABELS C4sog
  1 "Não"
  2 "Sim" .

VALUE LABELS C4tio
  1 "Não"
  2 "Sim" .

VALUE LABELS C4viz
  1 "Não"
  2 "Sim" .

VALUE LABELS I1
  1 "Nenhum"
  2 "1"
  3 "2"
  4 "3 a 6"
  5 "mais de 6" .

VALUE LABELS I2
  1 "Nunca"
  2 "Raramente"
  3 "Mensalmente"
  4 "Quinzenalmente"
  5 "Semanalmente"
  6 "Diariamente" .

VALUE LABELS I3
  1 "Nunca"
  2 "Raramente"
  3 "Mensalmente"
  4 "Quinzenalmente"
  5 "Semanalmente"
  6 "Diariamente" .

VALUE LABELS I4
  1 "Nunca"
  2 "Raramente"
  3 "Mensalmente"
  4 "Quinzenalmente"
  5 "Semanalmente"
  6 "Diariamente" .

VALUE LABELS I5
  1 "Nunca"
  2 "Raramente"
  3 "Mensalmente"
  4 "Quinzenalmente"
  5 "Semanalmente"
  6 "Diariamente" .

VALUE LABELS J2
  1 "Nunca"
  2 "Às vezes"
  3 "Quase sempre"
  4 "Sempre" .

VALUE LABELS J3coe
  1 "Não"
  2 "Sim" .

VALUE LABELS J3fal
  1 "Não"
  2 "Sim" .

VALUE LABELS J3idd
  1 "Não"
  2 "Sim" .

VALUE LABELS J3ves
  1 "Não"
  2 "Sim" .

VALUE LABELS V96
  1 "Não faria nunca"
  2 "Poderia fazer"
  3 "Já fiz" .

VALUE LABELS V96a
  1 "Não faria nunca"
  2 "Poderia fazer"
  3 "Já fiz" .

VALUE LABELS V97
  1 "Não faria nunca"
  2 "Poderia fazer"
  3 "Já fiz" .

VALUE LABELS V98
  1 "Não faria nunca"
  2 "Poderia fazer"
  3 "Já fiz" .

VALUE LABELS V98a
  1 "Não faria nunca"
  2 "Poderia fazer"
  3 "Já fiz" .

VALUE LABELS V98b
  1 "Não faria nunca"
  2 "Poderia fazer"
  3 "Já fiz" .

VALUE LABELS A1art
  1 "Não"
  2 "Sim" .

VALUE LABELS A1esp
  1 "Não"
  2 "Sim" .

VALUE LABELS A1igr
  1 "Não"
  2 "Sim" .

VALUE LABELS A1mus
  1 "Não"
  2 "Sim" .

VALUE LABELS A1nao
  1 "Não participa" .

VALUE LABELS A2ass
  1 "Não"
  2 "Sim" .

VALUE LABELS A2nao
  1 "Não participa" .

VALUE LABELS A2prt
  1 "Não"
  2 "Sim" .

VALUE LABELS A2sin
  1 "Não"
  2 "Sim" .

VALUE LABELS V185
  1 "Africana"
  2 "Católico"
  3 "Espírita"
  4 "Ev.: Adventista"
  5 "Evangélico"
  6 "Ev.: Assembleia de Deus"
  7 "Ev.: Batista"
  8 "Ev.: Evangelho Quadrangular"
  9 "Judeu"
  10 "Mulçumano"
  11 "Sem religião" .

VALUE LABELS V186
  1 "Nunca"
  2 "Raramente"
  3 "Anualmente"
  4 "Em dias santos"
  5 "Mensalmente"
  6 "Quinzenalmente"
  7 "Semanalmente"
  8 "Mais de uma vez por semana" .

VALUE LABELS V187a
  1 "Não religiosa"
  2 "Religiosa" .

VALUE LABELS V187b
  1 "Ateia"
  2 "Deísta" .

VALUE LABELS V223
  1 "Não"
  2 "Sim" .

VALUE LABELS V224
  1 "Não"
  2 "Sim" .

VALUE LABELS V225
  1 "Não"
  2 "Sim" .

VALUE LABELS V226
  1 "Não"
  2 "Sim" .

VALUE LABELS V227
  1 "Não"
  2 "Sim" .

VALUE LABELS V228
  1 "Não"
  2 "Sim" .

VALUE LABELS V229
  1 "Não"
  2 "Sim" .

VALUE LABELS V230
  1 "Frequentemente"
  2 "Raramente" .

VALUE LABELS F1
  1 "Não"
  2 "Sim" .

VALUE LABELS F2
  1 "Não"
  2 "Sim" .

VALUE LABELS F3
  1 "Não"
  2 "Sim" .

VALUE LABELS F4a
  1 "Não"
  2 "Sim" .

VALUE LABELS F4b
  1 "Não"
  2 "Sim" .

VALUE LABELS V235
  1 "Feminino"
  2 "Masculino" .

VALUE LABELS V55
  1 "Casado"
  2 "Divorciado"
  3 "Morando junto"
  4 "Separado"
  5 "Solteiro"
  6 "Viúvo" .

VALUE LABELS V238
  1 "Fundamental incompleto"
  2 "Fundamental completo"
  3 "Médio incompleto"
  4 "Médio completo"
  5 "Superior incompleto"
  6 "Superior completo" .

VALUE LABELS V238br
  1 "Administração e Contabilidade"
  2 "Arquitetura"
  3 "Arquivologia"
  4 "Biologia"
  5 "Ciências Sociais"
  6 "Comunicação"
  7 "Design"
  8 "Direito"
  9 "Economia"
  10 "Engenharia"
  11 "Estatística"
  12 "História"
  13 "Filosofia"
  14 "Física"
  15 "Geografia"
  16 "Letras"
  17 "Matematica"
  18 "Pedagogia"
  19 "Psicologia"
  20 "Saúde"
  21 "Serviço Social"
  22 "Não respondeu" .

VALUE LABELS V240
  1 "Não"
  2 "Sim" .

VALUE LABELS V241
  1 "Autônomo"
  2 "Desempregado"
  3 "Estudante"
  4 "Integral"
  5 "Meio período"
  6 "Pensionista" .

VALUE LABELS V242
  1 "Empregador < 10"
  2 "Empregador > 10"
  3 "Manual especializado"
  4 "Manual semi"
  5 "Prof. liberal"
  6 "Supervisor escritório"
  7 "Supervisor manual"
  8 "Trabalhador escritório"
  9 "Trabalhador rural" .

VALUE LABELS V242a
  1 "Nunca teve emprego"
  2 "Nunca trabalhou"
  3 "Sim" .

VALUE LABELS V243
  1 "Governo"
  2 "ONG"
  3 "Privada" .

VALUE LABELS V248
  1 "Não"
  2 "Sim" .

VALUE LABELS V249
  1 "Não"
  2 "Sim" .

VALUE LABELS V250
  1 "Braçal"
  2 "Empregador < 10"
  3 "Empregador > 10"
  4 "Manual especializado"
  5 "Manual semi"
  6 "Militar"
  7 "Nunca teve emprego"
  8 "Prof. liberal"
  9 "Supervisor escritório"
  10 "Supervisor manual"
  11 "Trabalhador escritório" .

VALUE LABELS V251
  1 "Gastou e fez empréstimo"
  2 "Gastou"
  3 "Ganhou e gastou"
  4 "Guardou" .

VALUE LABELS V256
  1 "Branco"
  2 "Indígena"
  3 "Negro"
  4 "Oriental"
  5 "Pardo" .

VALUE LABELS fezrede
  1 "Não"
  2 "Sim" .

VALUE LABELS P1
  1 "< 1"
  2 "1 a 2"
  3 "2 a 5"
  4 "5 a 10"
  5 "10 a 15"
  6 "15 a 20"
  7 "> 20" .

VALUE LABELS cidade
  1 "Aracaju"
  2 "Aracoia"
  3 "Aracoiaba"
  4 "Arapiraca"
  5 "Barreira"
  6 "Belém"
  7 "Belo Horizonte"
  8 "Betim"
  9 "Branquinha"
  10 "Brasília"
  11 "Cabedelo"
  12 "Cachoeira"
  13 "Campina Grande"
  14 "Campinas"
  15 "Caucaia"
  16 "Crato"
  17 "Dresden"
  18 "Eunapolis"
  19 "Florianópolis"
  20 "Fortaleza"
  21 "Fortim"
  22 "Horizonte"
  23 "Ivaiporã"
  24 "João Pessoa"
  25 "Lagoa Santa"
  26 "Limeira"
  27 "Limoeiro"
  28 "Maceió"
  29 "Magé"
  30 "Maracanaú"
  31 "Maranguape"
  32 "Maravillha"
  33 "Natal"
  34 "Niterói"
  35 "Nova Iguaçu"
  36 "Nova Lima"
  37 "Olinda"
  38 "Palhoça"
  39 "Porto de Pedras"
  40 "Pouso Alegre"
  41 "Recife"
  42 "Redenção"
  43 "Ribeirão Preto"
  44 "Rio"
  45 "Rio Claro"
  46 "Rio de Janeiro"
  47 "Santos"
  48 "São Carlos"
  49 "São Paulo"
  50 "Tianguá"
  51 "Timbuctu"
  52 "Vassouras"
  53 "Viçosa" .

VALUE LABELS S1
  1 "Gostei"
  2 "Não gostei" .

VALUE LABELS formtrat
  1 "ASenhora"
  2 "OSenhor"
  3 "Você" .

SAVE OUTFILE='trust_pt_BR.sav'
  /COMPRESSED.
