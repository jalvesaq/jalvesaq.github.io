###############################################################################
# 
#  R script to replicate the results of:
#
#  Aquino, Jakson Alves de.
#  The meaning of trust for Brazilians with higher education.
#  Social Indicators Research.
# 
###############################################################################

library("chron")
library("descr")
library("igraph")
library("memisc")
library("psych")
library("vioplot")
library("vcd")
library("GPArotation")
library("FactoMineR")

source("read_trust.R")

orig.b <- b
nV23na <- sum(is.na(b$V23))
nini <- nrow(b)
b <- b[!is.na(b$V23), ]
for(n in names(b))
    attr(b[[n]], "label") <- attr(orig.b[[n]], "label")
rm(orig.b)

b$typeData <- memisc::recode(b$tipo,
                             "Strangers in street" <- c("Letters given in down town", 
                                                        "Down Town", "Street: Pacoti", 
                                                        "Street: Redenção"),
                             "E-mails to institutions" <- c("Municipality",
                                                            "University"),
                             "Facebook and e-mails to friends" <- c("Friend (E-mail)",
                                                                    "Friend (Facebook)",
                                                                    "Facebook",
                                                                    "Facebook group",
                                                                    "Via internet"))
nStrangers <- sum(b$typeData == "Strangers in street")
b <- b[b$typeData != "Strangers in street", ]
b$typeData <- droplevels(b$typeData)
typeTab <- cbind(levels(b$typeData), table(b$typeData))
colnames(typeTab) <- c("Mode of contact", "N")

# Table 1: Number of respondents according to mode of contact
typeTab

b$V23r <- memisc::recode(b$V23,
                 "Don't trust" <- "Need to be very careful",
                 "Trust" <- "Most people can be trusted")
b$V23l <- b$V23 == "Most people can be trusted"
attr(b$V23r, "label") <- attr(b$V23, "label")
attr(b$V23l, "label") <- attr(b$V23, "label")

rels <- strsplit(b$rels, "#")

countRels <- function(x)
{
    if(length(x) == 1 && is.na(x))
        return(NA)
    if(length(x) == 0)
        return(NA)
    length(x)
}
b$npeople <- sapply(rels, countRels)

# The numbers of fezrede are inconsistent with npeople:
# b[is.na(b$fezrede) & !is.na(b$npeople),  c("codigoacesso", "fezrede", "npeople", "tran", "dens")]
# Reason: some people filled their social network data but didn't
# send the last form page.

# Proportion of atheists:
sum(b$V187b == "Atheist", na.rm = TRUE) / sum(!is.na(b$V187b))

# Proportion with higher education
sum(b$V238 %in% c("Some university-level education, without degree",
                  "University-level education, with degree")) / sum(!is.na(b$V238))

# Fig. 1: How many would take advantage according to trust in most people
par(cex = 0.8, mar = c(2, 4, 0, 0)+0.1)
tt <- b[!is.na(b$A47) , c("V23r", "A47")]
vioplot(tt$A47[tt$V23r == "Don't trust"], tt$A47[tt$V23r == "Trust"],
        pchMed = 18, col = "beige", names = levels(b$V23r))
title(ylab = "How many would take advantage?")

# Fig. 2: Who are the most people for those who trust and for those who do not
# trus most people?
par(mar = c(2, 4, 0.5, 0)+0.1, cex = 0.7)
qpN <- sapply(b[!is.na(b$V23r) & b$V23r == "Don't trust",
              c("C1apes", "C1afam", "C1aami", "C1acol", "C1aviz", "C1acon")],
             function(x) 100 * sum(x == "Yes", na.rm = TRUE) / length(x))
names(qpN) <- c("people", "relatives", "friends", "colleagues", "neighbors", "known")
qpY <- sapply(b[!is.na(b$V23r) & b$V23r == "Trust",
              c("C1apes", "C1afam", "C1aami", "C1acol", "C1aviz", "C1acon")],
             function(x) 100 * sum(x == "Yes", na.rm = TRUE) / length(x))
names(qpY) <- c("people", "relatives", "friends", "colleagues", "neighbors", "known")
par(mfrow = c(2, 1), mar = c(3, 4, 2, 0)+0.1, cex = 0.7)
barplot(qpN, ylab = "%", col = "beige", main = "Don't trust")
par(mar = c(2, 4, 3, 0)+0.1, cex = 0.7)
barplot(qpY, ylab = "%", col = "beige", main = "Trust")
rm(qpY, qpN)

# Fig. 3: Who have you thought of when you have heard the expression most people?
par(mfrow = c(1, 2), mar = c(2, 2, 2, 1.5)+0.1, cex = 0.8)
include <- b$C1aami == "Yes" | b$C1acol == "Yes" | b$C1acon == "Yes" | b$C1afam == "Yes" | b$C1aviz == "Yes"
include <- factor(as.numeric(include), levels = c(0, 1), labels = c("No", "Yes"))
x <- crosstab(b$V23r, include, shade = TRUE, inv.y = TRUE,
              ylab = "Include known people", xlab = "Trust most people")
title("(a)")
par(mar = c(2, 3.5, 2, 0)+0.1)
include <- b$C1aami == "Yes" | b$C1afam == "Yes"
include <- factor(as.numeric(include), levels = c(0, 1), labels = c("No", "Yes"))
x <- crosstab(b$V23r, include, shade = TRUE, inv.y = TRUE,
              ylab = "Include strong links", xlab = "Trust most people")
title("(b)")
rm(x, include)

# Fig. 4: Correspondence analysis: Who is most people?
par(mfrow = c(1, 1), mar = c(5, 4, 4, 4)+0.1, cex = 0.8)
x <- b[, c("C1afam", "C1aami", "C1acol", "C1aviz", "C1apes", "C1acon")]
names(x) <- c("rel", "fri", "col", "nei", "per", "kno")
x <- x[complete.cases(x), ]
m <- MCA(x, ncp = 2, graph = FALSE)
par(cex=0.8, mar = c(4, 4, 0, 0)+0.1)
plot(m, choix = "ind", cex = 0.8,
     col.var = c(rep("darkgreen", 4), rep("blue", 4), rep("red", 4)),
     invisible = "ind", title = "")
rm(x, m)

distant <- b$C1acon == "Yes" | b$C1apes == "Yes"
close <- b$C1aami == "Yes" | b$C1afam == "Yes"
b$typeMost <- rep(NA, nrow(b))
b$typeMost[distant == FALSE & close == FALSE] <- 1
b$typeMost[distant == TRUE  & close == FALSE] <- 2
b$typeMost[distant == FALSE & close == TRUE]  <- 3
b$typeMost[distant == TRUE  & close == TRUE]  <- 4
b$typeMost <- factor(b$typeMost, levels = c(1, 2, 3, 4),
                     labels = c("Restrict", "Impersonal", "Personal", "Comprehensive"))
attr(b$typeMost, "label") <- "Type of understanding of the expression “most people”"
rm(distant, close)

# Fig. 6: Trust in most people according to understanding of the expression most people
par(mar = c(2, 3, 0, 0)+0.1, cex=0.8)
x <- crosstab(b$V23r, b$typeMost, shade = TRUE, main = "",
              ylab = "Understanding of \"most people\"",
              xlab = "Trust most people")

# The variable C1c doesn't have statistically significant relation with V23:
# summary(glm(b$V23l ~ b$C1c, family=binomial()))

# Table 2: Proportion of respondents who trust most people according to
# understanding of trust
compmeans(b$V23l, b$C1c, warn = FALSE, plot = FALSE)

# The variable C1d has statistically significant relation with V23:
summary(glm(b$V23l ~ b$C1d, family=binomial()))

# Table 3: Proportion of respondents who trust most people according to situations
# imagined when answering the question on trust
compmeans(b$V23l, b$C1d, warn = FALSE, plot = FALSE)

# Table 4: Spearman correlation matrix of visit frequencies
x <- b[, c("I2", "I3", "I4", "I5")]
x <- as.data.frame(lapply(x, as.numeric))
names(x) <- c("Receive relatives", "Visit relatives", "Receive friends", "Visit friends")
cor(x, use = "complete.obs", method = "spearman")
rm(x)

b$I2r <- memisc::recode(b$I2,
                        "Low" <- c("Never", "Rarely"),
                        "Average" <- c("Monthly", "Fortnightly"),
                        "High" <- c("Weekly", "Daily"))
attr(b$I2r, "label") <- attr(b$I2, "label")
b$I3r <- memisc::recode(b$I3,
                        "Low" <- c("Never", "Rarely"),
                        "Average" <- c("Monthly", "Fortnightly"),
                        "High" <- c("Weekly", "Daily"))
attr(b$I3r, "label") <- attr(b$I3, "label")
b$I4r <- memisc::recode(b$I4,
                        "Low" <- c("Never", "Rarely"),
                        "Average" <- c("Monthly", "Fortnightly"),
                        "High" <- c("Weekly", "Daily"))
attr(b$I4r, "label") <- attr(b$I4, "label")
b$I5r <- memisc::recode(b$I5,
                        "Low" <- c("Never", "Rarely"),
                        "Average" <- c("Monthly", "Fortnightly"),
                        "High" <- c("Weekly", "Daily"))
attr(b$I5r, "label") <- attr(b$I5, "label")
x <- b[, c("I2r", "I3r", "I4r", "I5r")]
x <- x[complete.cases(x), ]
m <- MCA(x, ncp = 2, graph = FALSE)

# Fig. 7: Multiple correspondence analysis of frequency of visits
par(cex=0.8, mar = c(4, 4, 0, 0)+0.1)
plot(m, choix = "ind", cex = 0.8, invisible = "ind", title = "",
     col.var = c("red", "blue", "darkgreen"))
rm(x, m)

x <- cbind(tapply(b$V23r == "Trust", b$I2, mean, na.rm = TRUE),
           tapply(b$V23r == "Trust", b$I3, mean, na.rm = TRUE),
           tapply(b$V23r == "Trust", b$I4, mean, na.rm = TRUE),
           tapply(b$V23r == "Trust", b$I5, mean, na.rm = TRUE))
colnames(x) <- c("Rec. relatives", "Vis. relatives", "Rec. friends", "Vis. friends")
rownames(x) <- c("Nev", "Rar", "Mon", "For", "Wee", "Day")

# Fig. 8: Proportion who trust most people according to frequency of visits
par(mfrow = c(2, 2), cex = 0.75, mar = c(3, 2, 2, 1)+0.1)
barplot(x[, 1], main = "Receive relatives", ylim = c(0, 0.6), col = "beige")
par(mar = c(3, 3, 2, 0))
barplot(x[, 2], main = "Visit relatives", ylim = c(0, 0.6), col = "beige")
par(mar = c(2, 2, 3, 1))
barplot(x[, 3], main = "Receive friends", ylim = c(0, 0.6), col = "beige")
par(mar = c(2, 3, 3, 0))
barplot(x[, 4], main = "Visit friends", ylim = c(0, 0.6), col = "beige")
rm(x)

b$IRelIdx <- (b$I2 == "Monthly" | b$I2 == "Fortnightly") + (b$I3 == "Monthly" | b$I3 == "Fortnightly")
b$IFriIdx <- (b$I4 == "Monthly" | b$I4 == "Fortnightly") + (b$I5 == "Monthly" | b$I5 == "Fortnightly")
attr(b$IRelIdx, "label") <- "Index of median interaction with relatives"
attr(b$IFriIdx, "label") <- "Index of median interaction with friends"
amitt <- t.test(b$IFriIdx ~ b$V23r)$p.value[[1]]
famtt <- t.test(b$IRelIdx ~ b$V23r)$p.value[[1]]

# Table 5: Mean values of index of median interaction with relatives according
# to trust in most people
compmeans(b$IRelIdx, b$V23r, plot = FALSE, warn = FALSE)

# Table 6: Mean value of index of median interaction with friends according to
# trust in most people
compmeans(b$IFriIdx, b$V23r, plot = FALSE, warn = FALSE)

cq <- chisq.test(b$V23, b$C1b)
pvc1 <- format(cq$p.value, digits = 2)
x2 <- format(cq$statistic, digits = 2)
rm(cq)

# Fig. 9: Cross tabulation of trust in most people and auto evaluation of
# ability to recognize cheater
par(mfrow = c(1, 2), mar = c(2, 2, 2, 1.5)+0.1, cex = 0.8)
x <- crosstab(b$V23r, b$C1b, shade = TRUE,
              xlab = "Trust most people", ylab = "Reason of answer")
title("(a)")
par(mar = c(2, 3.5, 2, 0)+0.1)
x <- crosstab(b$V23r, b$J2, shade = TRUE,
              xlab = "Trust most people", ylab = "Recognize cheaters")
title("(b)")

security <- sum(b$J2 == "Almost always" | b$J2 == "Always", na.rm = TRUE) / sum(!is.na(b$J2))
security <- security * 100

cq <- chisq.test(b$V23, b$J2)
pvj2 <- format(cq$p.value, digits = 2)
x2j2 <- format(cq$statistic, digits = 2)
rm(cq)

cq <- chisq.test(b$V23, b$J3coe)
pvcoe <- format(cq$p.value, digits = 2)
x2coe <- format(cq$statistic, digits = 2)
cq <- chisq.test(b$V23, b$J3fal)
pvfal <- format(cq$p.value, digits = 2)
x2fal <- format(cq$statistic, digits = 2)
rm(cq)

# Fig. 10: How do you recognize a cheater?
par(mfrow = c(1, 2), mar = c(2, 2, 2, 1.5)+0.1, cex = 0.8)
x <- crosstab(b$V23r, b$J3coe, shade = TRUE, inv.y = TRUE,
              xlab = "Trust most people", ylab = "Coherence of speech")
title("(a)")
par(mar = c(2, 3.5, 2, 0)+0.1)
x <- crosstab(b$V23r, b$J3fal, shade = TRUE, inv.y = TRUE, prop.chisq = TRUE,
              xlab = "Trust most people", ylab = "Form of speech")
title("(b)")
rm(x)

# Table 7: Average value assigned to different situations according to trust
# in most people
x <- cbind(tapply(b$V198, b$V23r, mean, na.rm = TRUE),
           tapply(b$V199, b$V23r, mean, na.rm = TRUE),
           tapply(b$V200, b$V23r, mean, na.rm = TRUE),
           tapply(b$V201, b$V23r, mean, na.rm = TRUE))
colnames(x) <- c("Benefit", "Fare", "Tax", "Suborn")
x

# Table 7: Standard deviation of value assigned to different situations
# according to trust in most people
x <- cbind(tapply(b$V198, b$V23r, sd, na.rm = TRUE),
           tapply(b$V199, b$V23r, sd, na.rm = TRUE),
           tapply(b$V200, b$V23r, sd, na.rm = TRUE),
           tapply(b$V201, b$V23r, sd, na.rm = TRUE))
colnames(x) <- c("Benefit", "Fare", "Tax", "Suborn")
x
rm(x)

maxV <- max(b$V198 + b$V199 + b$V200 + b$V201, na.rm = TRUE)

# Table 8: Principal components analysis of situations related to honesty
m <- b[, c("V198", "V199", "V200", "V201")]
# Cronbach's alpha
alpha(m)
pc <- principal(m, nfactors = 1)
loadings(pc)

unclass(pc$loadings)

b$honIdx <- maxV - b$V198 - b$V199 - b$V200 - b$V201
attr(b$honIdx, "label") <- "Index of honesty"
rm(m, pc)

# Table 9: Mean and SD of number of people who would involve themselves in
# diverse situations according
x <- cbind(tapply(b$A198, b$V23r, mean, na.rm = TRUE),
           tapply(b$A199, b$V23r, mean, na.rm = TRUE),
           tapply(b$A200, b$V23r, mean, na.rm = TRUE),
           tapply(b$A201, b$V23r, mean, na.rm = TRUE))
colnames(x) <- c("Benefit", "Fare", "Tax", "Suborn")
x
x <- cbind(tapply(b$A198, b$V23r, sd, na.rm = TRUE),
           tapply(b$A199, b$V23r, sd, na.rm = TRUE),
           tapply(b$A200, b$V23r, sd, na.rm = TRUE),
           tapply(b$A201, b$V23r, sd, na.rm = TRUE))
colnames(x) <- c("Benefit", "Fare", "Tax", "Suborn")
x

maxA <- max(b$A198 + b$A199 + b$A200 + b$A201, na.rm = TRUE)
rm(x)

# Table 10: Principal components analysis of the perceived propensity to
# honesty
m <- b[, c("A198", "A199", "A200", "A201")]
alpha(m)
pc <- principal(m, nfactors = 1)
unclass(pc$loadings)
b$perhonIdx <- maxA - b$A198 - b$A199 - b$A200 - b$A201
attr(b$perhonIdx, "label") <- "Index of perceived honesty"
rm(m, pc)

t.test(b$honIdx ~ b$V23l)
t.test(b$perhonIdx ~ b$V23l)

# Table 11: Spearman correlation matrix of reasons to be just
m <- b[, c("J1a", "J1b", "J1c", "J1d")]
names(m) <- c("Goodness", "Guilt", "Worry", "Fear")
cor(m, use = "pairwise.complete.obs")
rm(m)

# Table 12: Principal component analysis of reasons to be just
m <- b[, c("J1a", "J1b", "J1c", "J1d")]
names(m) <- c("Goodness", "Guilt", "Worry", "Fear")
pc <- principal(m, nfactors = 2)
unclass(pc$loadings)
b$mtvIdx <- b$J1a + b$J1b - b$J1c - b$J1d
attr(b$mtvIdx, "label") <- "Index of perception of internal versus external reasons to be just"
rm(pc, m)

t.test(b$J1d ~ b$V23l)

b$V125r <- memisc::recode(b$V125,
                          "Don't trust" <- c("Don't trust at all",
                                             "Don't trust very much",
                                             "Trust somewhat"),
                          "Trust" <- c("Trust completely"))
attr(b$V125r, "label") <- attr(b$V125, "label")
rec <- function(n)
{
    x <- memisc::recode(b[[n]],
                "Don't trust" <- c("Don't trust at all", "Don't trust very much"),
                "Trust" <- c("Trust somewhat", "Trust completely"))
    attr(x, "label") <- attr(b[[n]], "label")
    x
}
b$V125ar <- rec("V125a")
b$V126r <- rec("V126")
b$V127r <- rec("V127")
b$V128r <- rec("V128")
b$V129r <- rec("V129")
b$V130r <- rec("V130")
rm(rec)

# Fig. 11: Correspondence analysis: trust in different kinds of people
par(mfrow=c(1, 1), cex=0.8, mar = c(4, 4, 0, 0)+0.1)
x <- b[, c("V125ar", "V125r", "V126r", "V127r", "V128r", "V129r", "V130r")]
names(x) <- c("Ppl", "Rlt", "Nb", "Knw", "Unkn", "Rlg", "Cntr")
x <- x[complete.cases(x), ]
m <- MCA(x, ncp = 2, graph = FALSE)
plot(m, choix = "ind", cex = 0.8, invisible = "ind",
     col.var = c("red", "blue"), title = "")
rm(x, m)

b$typeTrust <- rep(0, nrow(b))
b$typeTrust[b$V125r == "Don't trust" & b$V125ar == "Don't trust"] <- 1
b$typeTrust[b$V125r == "Trust" & b$V125ar == "Don't trust"] <- 2
b$typeTrust[b$V125r == "Don't trust" & b$V125ar == "Trust"] <- 3
b$typeTrust[b$V125r == "Trust" & b$V125ar == "Trust"] <- 4
b$typeTrust <- factor(b$typeTrust, levels = c(1, 2, 3, 4),
                     labels = c("Pessimist", "Familist", "Civic", "Optimistic"))
attr(b$typeTrust, "label") <- "Type of truster"

# Table 13: Proportion of respondents who trust most people by type of truster
compmeans(b$V23l, b$typeTrust, plot = FALSE, warn = FALSE)

# Fig. 13: Trust in most people according to type of truster 
par(mar = c(2, 3, 0, 0)+0.1, cex=0.8)
x <- crosstab(b$V23r, b$typeTrust, shade = TRUE,
              ylab = "Type of truster", xlab = "Trust most people")

tmp <- b[, c("C2avo", "C3avo", "C4avo", "C2esp", "C3esp", "C4esp", "C2fil", "C3fil",
             "C4fil", "C2irm", "C3irm", "C4irm", "C2mae", "C3mae", "C4mae", "C2nam",
             "C3nam", "C4nam", "C2net", "C3net", "C4net", "C2pai", "C3pai", "C4pai")]
b$Yrel1 <- apply(tmp, 1, function(x) sum(x == "Yes"))
n.rel1 <- ncol(tmp)
attr(b$Yrel1, "label") <- "Sum of ``Yes'' to close relatives"

tmp <- b[, c("C2cun", "C3cun", "C4cun", "C2gen", "C3gen", "C4gen", "C2nor",
             "C3nor", "C4nor", "C2pri", "C3pri", "C4pri", "C2sog", "C3sog",
             "C4sog", "C2tio", "C3tio", "C4tio")]
b$Yrel2 <- apply(tmp, 1, function(x) sum(x == "Yes"))
n.rel2 <- ncol(tmp)
attr(b$Yrel2, "label") <- "Sum of ``Yes'' to distant relatives"

b$Yfri <- (b$C2ami == "Yes") + (b$C3ami == "Yes") + (b$C4ami == "Yes")
n.fri <- 3
attr(b$Yfri, "label") <- "Sum of ``Yes'' to friends"

tmp <- b[, c("C2col", "C3col", "C4col", "C2con", "C3con", "C4con",
             "C2pes", "C3pes", "C4pes", "C2viz", "C3viz", "C4viz")]
b$Ypeo <- apply(tmp, 1, function(x) sum(x == "Yes"))
attr(b$Ypeo, "label") <- "Sum of ``Yes'' to people in general"
n.peo <- ncol(tmp)

# Summary of sums of ``Yes''
x <- rbind(summary(b$Ypeo),
           summary(b$Yfri),
           summary(b$Yrel2),
           summary(b$Yrel1))
rownames(x) <- c("People in general", "Friends", "Distant relatives", "Close relatives")
x

# Table 14: Proportion of ``Yes'' according to category of people
mean(b$Ypeo / n.peo)   # People in general
mean(b$Yfri / n.fri)   # Friends
mean(b$Yrel2 / n.rel2) # Distant relatives
mean(b$Yrel1 / n.rel1) # Close relatives

d <- b[!is.na(b$typeTrust), c("Ypeo", "Yfri", "Yrel1", "Yrel2", "typeTrust")]
# Fig. 14: Distributions of the sum of ‘‘Yes’’ by type of truster
par(mfrow = c(2, 2), cex=0.7)
par(mar = c(4, 2, 2, 1)+0.1)
vioplot(d$Ypeo[d$typeTrust == "Pessimist"], d$Ypeo[d$typeTrust == "Familist"],
        d$Ypeo[d$typeTrust == "Civic"], d$Ypeo[d$typeTrust == "Optimistic"],
        pchMed = 18, col = "beige", names = levels(d$typeTrust))
title(main = "Yes to people in general")

par(mar = c(4, 3, 2, 0)+0.1)
vioplot(d$Yfri[d$typeTrust == "Pessimist"], d$Yfri[d$typeTrust == "Familist"],
        d$Yfri[d$typeTrust == "Civic"], d$Yfri[d$typeTrust == "Optimistic"],
        pchMed = 18, col = "beige", names = levels(d$typeTrust))
title(main = "Yes to friends")

par(mar = c(2, 2, 4, 1)+0.1)
vioplot(d$Yrel2[d$typeTrust == "Pessimist"], d$Yrel2[d$typeTrust == "Familist"],
        d$Yrel2[d$typeTrust == "Civic"], d$Yrel2[d$typeTrust == "Optimistic"],
        pchMed = 18, col = "beige", names = levels(d$typeTrust))
title(main = "Yes to distant relatives")

par(mar = c(2, 3, 4, 0)+0.1)
vioplot(d$Yrel1[d$typeTrust == "Pessimist"], d$Yrel1[d$typeTrust == "Familist"],
        d$Yrel1[d$typeTrust == "Civic"], d$Yrel1[d$typeTrust == "Optimistic"],
        pchMed = 18, col = "beige", names = levels(d$typeTrust))
title(main = "Yes to close relatives")

# Fig. 15: Distributions of the sum of Yes by trust in most people
par(mfrow = c(2, 2), cex=0.7, mar = c(4, 2, 2, 2)+0.1)
vioplot(b$Ypeo[b$V23l == FALSE], b$Ypeo[b$V23l == TRUE], pchMed = 18,
        col = "beige", names = levels(b$V23r))
ttl <- "Yes to people in general"
Encoding(ttl) <- "UTF-8"
title(main = ttl)

par(mar = c(4, 4, 2, 0)+0.1)
vioplot(b$Yfri[b$V23l == FALSE], b$Yfri[b$V23l == TRUE], pchMed = 18,
        col = "beige", names = levels(b$V23r))
title(main = "Yes to friends")

par(mar = c(2, 2, 4, 2)+0.1)
vioplot(b$Yrel2[b$V23l == FALSE], b$Yrel2[b$V23l == TRUE], pchMed = 18,
        col = "beige", names = levels(b$V23r))
title(main = "Yes to distant relatives")

par(mar = c(2, 4, 4, 0)+0.1)
vioplot(b$Yrel1[b$V23l == FALSE], b$Yrel1[b$V23l == TRUE], pchMed = 18,
        col = "beige", names = levels(b$V23r))
title(main = "Yes to close relatives")

t.test(b$Ypeo ~ b$V23r)
t.test(b$Yrel1 ~ b$V23r)
t.test(b$Yrel2 ~ b$V23r)
t.test(b$Yfri ~ b$V23r)

createM <- function(x)
{
    if(is.na(x))
        return(NA)
    if(x == "")
        return(NA)
    x <- strsplit(x, "#")[[1]]
    x <- x[!grepl("Ego", x)]
    if(length(x) == 0)
        return(NA)
    x <- strsplit(x, "@")
    do.call("rbind", x)
}
lsrel <- lapply(b$lsrel, createM)
createG <- function(x)
{
    if(length(x) == 1 && is.na(x))
        return(NA)
    graph.edgelist(x)
}
lsg <- lapply(lsrel, createG)

rels <- strsplit(b$rels, "#")
contaRels <- function(x)
{
    if(length(x) == 1 && is.na(x))
        return(NA)
    if(length(x) == 0)
        return(NA)
    length(x)
}
b$npeople <- sapply(rels, contaRels)
attr(b$npeople, "label") <- "Number of people in personal social network"

ami <- lapply(rels, function(x) grep("Amigo|Vizinho|Colega", x))
ami <- sapply(ami, length)
b$pfam <- (b$npeople - ami) / b$npeople
attr(b$pfam, "label") <- "Proportion of relatives in personal social network"

b$dens <- sapply(lsg, function(x) if(is.na(x[[1]])) NA else graph.density(x))
attr(b$dens, "label") <- "Density of network"

b$tran <- sapply(lsg, function(x) if(is.na(x[[1]])) NA else transitivity(x))
attr(b$tran, "label") <- "Transitivity of network"

b$reci <- sapply(lsg, function(x) if(is.na(x[[1]])) NA else reciprocity(x))
attr(b$reci, "label") <- "Reciprocity of network"

b$n.clu <- sapply(lsg, function(x) if(is.na(x[[1]])) NA else no.clusters(x))
attr(b$n.clu, "label") <- "Weak cluster coefficient of network"
rm(ami, rels, lsg, lsrel)

# Table 15: Summary of logistic regression: trust in most people as dependent variable
m <- glm(V23l ~ npeople + n.clu:npeople + pfam + dens + tran + reci,
         data = b, family = binomial())
ms <- summary(m)
mn <- rownames(ms$coefficients)
mn <- sub("npeople:n.clu", "Cluster coefficient:N. people", mn)
mn <- sub("npeople", "Number of people", mn)
mn <- sub("pfam", "Proportion of relatives", mn)
mn <- sub("dens", "Density", mn)
mn <- sub("tran", "Transitivity", mn)
mn <- sub("reci", "Reciprocity", mn)
rownames(ms$coefficients) <- mn
ms
rm(m, ms, mn)

renameCoefs <- function(x)
{
    xn <- names(x$coefficients)
    xn <- sub("typeMostImpersonal", "Meaning of most people (Impersonal)", xn)
    xn <- sub("typeMostPersonal", "Meaning of most people (Personal)", xn)
    xn <- sub("typeMostComprehensive", "Meaning of most people (Comprehensive)", xn)
    xn <- sub("IRelIdx", "Index of median interaction with relatives", xn)
    xn <- sub("IFriIdx", "Index of median interaction with friends", xn)
    xn <- sub("C1bI was taught", "Reason for not trusting (I was taught)", xn)
    xn <- sub("J3falYes", "Recognize by the way of speaking (Yes)", xn)
    xn <- sub("perhonIdx", "Index of trust in honesty", xn)
    xn <- sub("typeTrustFamilist", "Type of truster (Familist)", xn)
    xn <- sub("typeTrustCivic", "Type of truster (Civic)", xn)
    xn <- sub("typeTrustOptimistic", "Type of truster (Optimistic)", xn)
    xn <- sub("Yrel1", "Sum of ``Yes'' to close relatives", xn)
    xn <- sub("Yrel2", "Sum of ``Yes'' to distant relatives", xn)
    xn <- sub("Yfri", "Sum of ``Yes'' to friends", xn)
    xn <- sub("Ypeo", "Sum of ``Yes'' to people in general", xn)
    xn <- sub("npeople:n.clu", "Number of people:Cluster coefficient", xn)
    xn <- sub("npeople", "Number of people in social network", xn)
    names(x$coefficients) <- xn
    x
}

# Table 16: Logistic regression analysis with trust in most people as dependent variable
m1 <- glm(V23l ~ typeTrust + perhonIdx + C1b + IFriIdx + IRelIdx + typeMost + J3fal
          + Ypeo + Yfri + Yrel1 + Yrel2, data = b, family=binomial())
summary(renameCoefs(m1))

# Keep only most significant
m2 <- glm(V23l ~ typeTrust + perhonIdx + C1b + IFriIdx, data = b, family=binomial())
summary(renameCoefs(m2))

# Add social network variables
m3 <- glm(V23l ~ typeTrust + perhonIdx + C1b + IFriIdx + npeople + n.clu:npeople,
          data = b, family=binomial())
summary(renameCoefs(m3))
