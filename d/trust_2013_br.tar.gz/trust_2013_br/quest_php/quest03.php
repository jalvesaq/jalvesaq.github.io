<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="pt-BR">
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
<title>Questionário</title>

<meta name="viewport" content="width=device-width">
<link href="estilo.css" rel="stylesheet" type="text/css" media="all">
<? if(isset($_POST["fontsz"])) echo '<style media="screen" type="text/css"> #geral { font-size: ' . $_POST["fontsz"] . " }</style>"; ?>

<script src="funcoes.js" type="text/javascript"></script>

<style media="screen" type="text/css">
   a:link { color: #ff0000; text-decoration: none; font-weight: bold; }
   a:visited { color: #ff0000; text-decoration: none; font-weight: bold; }
</style>

</head>
<body>

<?php
   include "continua.php";
?>


<div id="geral">

<p><span style="color:red">ATENÇÃO: Nenhuma informação será armazenada porque a coleta de dados já foi encerrada!</span></p>

<h2><a id="redesoc"></a>As pessoas mais próximas</h2>

<hr>

<form id="Qform" name="Qform" action="quest04.php" method="post" onsubmit="return validarRede(this)">

<input type="hidden" name="tempo3" value="<?php echo date("Y-m-d H:i:s");?>">
<input type="hidden" id="fontsz" name="fontsz" value="<? echo $_POST["fontsz"] ?>">
<input type="hidden" id="formtrat" name="formtrat" value="<? echo $formtrat ?>">

<p>Vamos agora fazer uma lista incluindo <? echo $tm ?> e as pessoas com
quem <? echo $tm ?> tem mais proximidade, as pessoas em quem <? echo $tm ?> mais
confia.<p>

<p> Qual o seu nome ou apelido (real ou inventado
agora) a ser usado nessa lista? <span class="inst">(preenchimento opcional)</span><br>

<input type="text" name="ego" OnKeyPress="return event.keyCode != 13;"></p>

<p>&nbsp;</p>
<hr>

<p> Clique no botão <b>Adicionar pessoa</b> para
adicionar à sua lista as pessoas com quem <? echo $tm ?> tem mais proximidade
<span class="inst">(no mínimo 1 e no máximo 40 pessoas)</span>. Por favor,
para cada pessoa indique também o tipo de relacionamento que tem com ela.
Algumas dicas:<p>

<ul>
   <li>Não precisa digitar o nome completo das pessoas. Basta o primeiro nome
   ou um apelido.</li>

   <li>Se não quiser digitar os nomes verdadeiros, <b>pode inventar
   apelidos</b>, mas <? echo $tm ?> terá que memorizar os apelidos porque
   na próxima página vamos perguntar quem confia em quem.</li>

   <li>Se necessário, clique no <span style="color:#ff0000"><b>x</b></span>
   para remover uma pessoa.</li>
   
</ul>

<div id="dynamicInput">
</div>
<input type="button" style="font-weight:bold;" value="Adicionar pessoa" onClick="addInput('dynamicInput');">


<p style="text-align:center"><input type="submit" style="font-weight:bold;" value="Enviar e Continuar"></p>
</form>

</div>

<!--
<script language='JavaScript' type='text/javascript'> retirarNumQuest(); </script>
-->

</body>
</html>
