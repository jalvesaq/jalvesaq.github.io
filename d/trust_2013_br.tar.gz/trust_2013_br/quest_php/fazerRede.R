
fazerGrafo <- function(cod, a, b){
    require(igraph)
    if(missing(a))
        try(f <- readLines(paste0("http://www.lepem.ufc.br/conf/ars/", cod, ".a")))
    else
        f <- readLines(a)
    if(!exists("f"))
        stop(paste0("Arquivo 'http://www.lepem.ufc.br/conf/ars/", cod, ".a' não encontrado."))
    idx <- grep(paste0("^", cod), f)
    idx <- idx[length(idx)]
    r1 <- f[idx]
    n1 <- f[idx - 1]
    x <- strsplit(n1, "\t")[[1]]
    y <- strsplit(r1, "\t")[[1]]
    ego <- y[grep("ego", x)]
    pessoas <- y[grep("^pessoa", x)]

    if(missing(b))
        f <- readLines(paste0("http://www.lepem.ufc.br/conf/ars/", cod, ".b"))
    else
        f <- readLines(b)
    idx <- grep(paste0("^", cod), f)
    idx <- idx[length(idx)]
    r2 <- f[idx]
    n2 <- f[idx - 1]
    x <- strsplit(n2, "\t")[[1]]
    y <- strsplit(r2, "\t")[[1]]
    egos <- y[grep("^pessoa[0-9]*$", x)]
    rels <- y[grep("^pessoa[0-9]*rel[0-9]*$", x)]
    rels <- matrix(rels, ncol = 5, byrow = TRUE)

    sink(paste0("igraphformula", cod))
    cat("g <- graph.formula(\n")
    for(p in pessoas)
       cat('"', ego, '" --+ "', p, '", ', sep="")
    for(i in 1:length(egos))
       for(p in rels[i, ])
          if(!is.na(p) && p != "")
             cat('"', egos[i], '" --+ "', p, '", ', sep="")
    cat(")\n")
    sink()
    linhas <- readLines(paste0("igraphformula", cod))
    linhas <- sub(", \\)", ")", linhas)
    writeLines(linhas, con = paste0("igraphformula", cod))
    source(paste0("igraphformula", cod))
    g <- set.graph.attribute(g, "layout", value = layout.fruchterman.reingold(g))
    g <- set.vertex.attribute(g, "size", value = 6)
    g <- set.vertex.attribute(g, "label.dist", value = 0.7)
    g <- set.edge.attribute(g, "arrow.size", value = 0.5)
    png(paste0("img/g", cod, ".png"))
    plot(g)
    dev.off()
    #unlink(paste0("igraphformula", cod))
    return(invisible(NULL))
}
