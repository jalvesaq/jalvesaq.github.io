<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="pt-BR">
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
<title>Questionário</title>

<meta name="viewport" content="width=device-width">
<link href="estilo.css" rel="stylesheet" type="text/css" media="all">
<? if(isset($_POST["fontsz"])) echo '<style media="screen" type="text/css"> #geral { font-size: ' . $_POST["fontsz"] . " }</style>"; ?>

<script src="funcoes.js" type="text/javascript"></script>

</head>
<body>

<?php
   include "continua.php";
?>


<div id="geral">

<p><span style="color:red">ATENÇÃO: Nenhuma informação será armazenada porque a coleta de dados já foi encerrada!</span></p>

<h2><a id="redesoc"></a>As pessoas mais próximas (continuação)</h2>

<form id="Qform" name="Qform" action="quest05.php" method="post">

<input type="hidden" name="tempo4" value="<?php echo date("Y-m-d H:i:s");?>">
<input type="hidden" id="fontsz" name="fontsz" value="<? echo $_POST["fontsz"] ?>">
<input type="hidden" id="formtrat" name="formtrat" value="<? echo $formtrat ?>">

<h3>Os amigos dos seus amigos</h3>

<p> Agora, para cada pessoa da sua rede, diga quem
são as pessoas com quem elas têm maior proximidade, as pessoas da sua própria
rede, incluindo <? echo $tm ?>, em que <? echo $tm ?> acha que cada uma delas
mais confia. <span class="inst">(máximo 5 pessoas para cada)</span>

<table>
<tr><th>Pessoa</th><th>Pessoas mais próximas</th></tr>
<?
$ego = $_POST["ego"];
$plist = array();
foreach($_POST as $k => $v) {
   if(strpos($k, 'pessoa') === 0) {
      $plist[] = $v;
   }
}

foreach($plist as $k => $v){
   echo "<tr><td>$v</td><td>";
   echo '<input type="hidden" name="pessoa' . $k . '" value="' . $v . '">';
   for($i = 0; $i < 5; $i++){
      echo '<select name="pessoa'. $k . 'rel' . $i . '"><option> </option><option>' . $ego . '</option>';
      foreach($plist as $kk => $vv){
         if($v != $vv){
            echo "<option>$vv</option>";
         }
      }
      echo "</select>";
   }
   echo "</td></tr>";
}
?>
</table>

<p style="text-align:center"><input type="submit" style="font-weight:bold;" value="Enviar e Continuar"></p>
</form>

</div>

<!--
<script language='JavaScript' type='text/javascript'> retirarNumQuest(); </script>
-->

</body>
</html>
