<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html lang="pt-BR">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Pesquisa</title>

<meta name="viewport" content="width=device-width">
<link href="estilo.css" rel="stylesheet" type="text/css" media="all">
<? if(isset($_POST["fontsz"])) echo '<style media="screen" type="text/css"> #geral { font-size: ' . $_POST["fontsz"] . " }</style>"; ?>

</head>
<body>

<? include "continua.php" ?>

<div id="geral">

   <p><span style="color:red">ATENÇÃO: para informações atualizadas sobre a pesquisa, acesse:</span><br>
   <a style="color:red" href="http://www.lepem.ufc.br/dados/conf2013/"> http://www.lepem.ufc.br/dados/conf2013/</a></p>

<p>&nbsp;</p>

<p><b>Obrigado por sua participação!</b></p>

<p>Em poucos meses, o resultado da pesquisa será divulgado no <a href='http://www.lepem.ufc.br/'>site do LEPEM</a>.</p>

<?php

   if($_POST["fezrede"] == "Sim"){
      echo "\n\n<form name='formFinal' action='http://pesquisa.no-ip.org/sociograma.php' method='post'>\n";
      echo "<input type='hidden' name='cod' value='$codigoacesso'>\n";
      echo '<script type="text/javascript"> function FazerRede() { document.formFinal.submit(); } </script>';
      echo "\n<p>Como dissemos no início do questionário, os dados não serão ";
      echo "divulgados de forma a permitir a identificação dos entrevistados, mas se $tm ";
      echo " quiser ver agora uma representação gráfica da sua rede pessoal, ";
      echo "clique no botão abaixo:</p>\n\n";
      echo "<center><input type='button' value='Ver sociograma' style='font-weight:bold;' onClick=' alert(\"O sociograma foi produzido somente durante a coleta de dados.\")'></center>\n</form>";
   }
?>

</div>
</body>
</html>
