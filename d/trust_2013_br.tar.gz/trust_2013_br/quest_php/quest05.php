<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="pt-BR">
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
<title>Questionário</title>

<meta name="viewport" content="width=device-width">
<link href="estilo.css" rel="stylesheet" type="text/css" media="all">
<? if(isset($_POST["fontsz"])) echo '<style media="screen" type="text/css"> #geral { font-size: ' . $_POST["fontsz"] . " }</style>"; ?>

<script src="funcoes.js" type="text/javascript"></script>

</head>
<body>

<?php
   include "continua.php";
?>

<div id="geral">

<p><span style="color:red">ATENÇÃO: Nenhuma informação será armazenada porque a coleta de dados já foi encerrada!</span></p>

<form name="Qform" action="fim.php" method="post">

<input type="hidden" name="tempo5" value="<?php echo date("Y-m-d H:i:s");?>">
<input type="hidden" id="fontsz" name="fontsz" value="<? echo $_POST["fontsz"] ?>">
<input type="hidden" id="formtrat" name="formtrat" value="<? echo $formtrat ?>">
<? 
   $achou = false;
   foreach ($_POST as $k => $v) {
      if(strpos($k, "pessoa") === 0){
         $achou = true;
          break;
       }
   }
   if($achou){
      echo '<input type="hidden" name="fezrede" value="Sim">';
   } else {
      echo '<input type="hidden" name="fezrede" value="Não">';
   } 
?>

<h2><a id="perf"></a>Perfil socioeconômico</h2>

<p>Precisamos saber como as diferentes opiniões e atitudes se distribuem entre
os mais diferentes tipos de pessoas. Por isso, nesta última página, fazemos
algumas perguntas sobre seu perfil social e econômico.</p>

<input type="hidden" name="V235" value="NR">

<p><a id="V235"></a> Qual o seu sexo?</p>
<label><input type="radio" name="V235" onClick="ck('tV235'); va('idd'); document.getElementById('V236').focus()" value="Feminino">Feminino</label><br>
<label><input type="radio" name="V235" onClick="ck('tV235'); va('idd'); document.getElementById('V236').focus()" value="Masculino">Masculino</label>

<p>&nbsp;</p>
<a id="idd"></a>
<hr>

<p>Qual sua idade? 
<input type="text" id="V236" name="V236" size=4 maxlength=4 onchange="validarIdade(this, 'inf_idade');" OnKeyPress="return event.keyCode != 13;">
<span style="color:#FF0000;" id="inf_idade">&nbsp;</span></p>

<p>&nbsp;</p>
<hr>

<p>Atualmente, <? echo $tm ?> está:</p>

<input type="hidden" name="V55" value="NR">

<label><input type="radio" name="V55" onClick="ck('tV55'); va('fhls'); document.getElementById('V56').focus()" value="Casado">Casado</label><br>
<label><input type="radio" name="V55" onClick="ck('tV55'); va('fhls'); document.getElementById('V56').focus()" value="Morando junto">Morando junto como casado</label><br>
<label><input type="radio" name="V55" onClick="ck('tV55'); va('fhls'); document.getElementById('V56').focus()" value="Divorciado">Divorciado</label><br>
<label><input type="radio" name="V55" onClick="ck('tV55'); va('fhls'); document.getElementById('V56').focus()" value="Separado">Separado</label><br>
<label><input type="radio" name="V55" onClick="ck('tV55'); va('fhls'); document.getElementById('V56').focus()" value="Viúvo">Viúvo</label><br>
<label><input type="radio" name="V55" onClick="ck('tV55'); va('fhls'); document.getElementById('V56').focus()" value="Solteiro">Solteiro</label>

<p>&nbsp;</p>
<a id="fhls"></a>
<hr>

<p><? echo $ti ?> tem filhos? <span class="inst">(anote a quantidade; digite 0 se não tiver)</span></p>

&nbsp;&nbsp;&nbsp;&nbsp;Quantos? <input id="V56" name="V56" size="2" type="text" maxlength="2" OnKeyPress="return event.keyCode != 13;"><br>

<p>&nbsp;</p>
<hr>

<p>Qual o nível educacional mais alto que <? echo $tm ?> atingiu?</p>

<input type="hidden" name="V238" value="NR">

<label><input type="radio" name="V238" onClick="ck('tV238'); Disp('qualsup', 'none'); va('V240')" value="Não estudou">Não frequentou a escola</label><br>
<label><input type="radio" name="V238" onClick="ck('tV238'); Disp('qualsup', 'none'); va('V240')" value="Fundamental incompleto">Ensino fundamental incompleto</label><br>
<label><input type="radio" name="V238" onClick="ck('tV238'); Disp('qualsup', 'none'); va('V240')" value="Fundamental completo">Ensino fundamental completo</label><br>
<label><input type="radio" name="V238" onClick="ck('tV238'); Disp('qualsup', 'none'); va('V240')" value="Médio incompleto">Ensino médio incompleto</label><br>
<label><input type="radio" name="V238" onClick="ck('tV238'); Disp('qualsup', 'none'); va('V240')" value="Médio completo">Ensino médio completo</label><br>
<label><input type="radio" name="V238" onClick="ck('tV238'); Disp('qualsup', 'block'); va('V238b')" value="Superior incompleto">Ensino superior incompleto</label><br>
<label><input type="radio" name="V238" onClick="ck('tV238'); Disp('qualsup', 'block'); va('V238b')" value="Superior completo">Ensino superior completo</label>

<div id="qualsup" style="display:none">
<p>&nbsp;</p>
<a id="V238b"></a>
<hr>

<p>Qual curso de nível superior? <input type="text" name="V238b" OnKeyPress="return event.keyCode != 13;"></p>
</div>

<p>&nbsp;</p>
<a id="V240"></a>
<hr>

<p><? echo $ti ?> mora com seus pais?</p>

<input type="hidden" name="V240" value="NR">

<label><input type="radio" name="V240" onClick="ck('tV240'); va('V241')" value="Sim">Sim</label><br>
<label><input type="radio" name="V240" onClick="ck('tV240'); va('V241')" value="Não">Não</label>

<p>&nbsp;</p>
<a id="V241"></a>
<hr>

<p><? echo $ti ?> está empregado agora ou não? Se sim, quantas horas por
semana? Se há mais de um emprego, responder somente sobre o emprego principal.</p>

<input type="hidden" name="V241" value="NR">

Sim, tenho emprego remunerado:<br>
<label><input type="radio" name="V241" onClick="ck('tV241'); Disp('naotrab', 'none'); Disp('jatrab', 'block'); va('V243')" value="Integral">Emprego de período integral (30h por semana ou mais)</label><br>
<label><input type="radio" name="V241" onClick="ck('tV241'); Disp('naotrab', 'none'); Disp('jatrab', 'block'); va('V243')" value="Meio período">Emprego de meio período (Menos de 30h por semana)</label><br>
<label><input type="radio" name="V241" onClick="ck('tV241'); Disp('naotrab', 'none'); Disp('jatrab', 'block'); va('V243')" value="Autônomo">Autônomo</label><br>

Não, não tenho emprego remunerado:<br>
<label><input type="radio" name="V241" onClick="ck('tV241'); Disp('naotrab', 'block'); va('V242a')" value="Pensionista">Aposentado ou pensionista</label><br>
<label><input type="radio" name="V241" onClick="ck('tV241'); Disp('naotrab', 'block'); va('V242a')" value="Dona de casa">Dona de casa não remunerada</label><br>
<label><input type="radio" name="V241" onClick="ck('tV241'); Disp('naotrab', 'block'); va('V242a')" value="Estudante">Estudante</label><br>
<label><input type="radio" name="V241" onClick="ck('tV241'); Disp('naotrab', 'block'); va('V242a')" value="Desempregado">Desempregado</label><br>
Outro: <input type="text" name="V241o" OnKeyPress="return event.keyCode != 13;" onFocus="limparRadio('V241')">

<p>&nbsp;</p>
<a id="V242a"></a>
<hr>

<div id="naotrab" style="display:block">
   <p><? echo $ti ?> já trabalhou ou teve emprego?</p>
   <input type="hidden" name="V242a" value="NR">
   <label><input type="radio" name="V242a" onClick="ck('tV242a'); Disp('jatrab', 'block'); va('V243')">Sim</label><br>
   <label><input type="radio" name="V242a" onClick="ck('tV242a'); Disp('jatrab', 'none'); va('V248')" value="Nunca teve emprego">Nunca teve emprego</label><br>
   <label><input type="radio" name="V242a" onClick="ck('tV242a'); Disp('jatrab', 'none'); va('V248')" value="Nunca trabalhou">Nunca trabalhou</label><br>
<p>&nbsp;</p>
<hr>
</div>

<div id="jatrab" style="display:block;">
<p><a id="V243"></a> <? echo $ti ?> está trabalhando ou trabalhou para o governo, para a empresa privada ou para a indústria?</p>

<input type="hidden" name="V243" value="NR">

<label><input type="radio" name="V243" onClick="ck('tV243'); va('V242')" value="Governo">Governo ou instituição pública</label><br>
<label><input type="radio" name="V243" onClick="ck('tV243'); va('V242')" value="Privada">Empresa privada ou indústria</label><br>
<label><input type="radio" name="V243" onClick="ck('tV243'); va('V242')" value="ONG">Organização privada não lucrativa</label>

<p>&nbsp;</p>
<hr>
</div>

<p><a id="V242"></a> Qual sua profissão ou ocupação?
Se tiver mais de uma atividade, qual é a principal? Se não estiver
trabalhando, qual foi o tipo de atividade que desempenhou?
<span class="inst">(digite a ocupação ou assinale de acordo com a lista abaixo)</span></p>

<input type="hidden" name="V242" value="NR">

Profissão ou ocupação: <input type="text" name="V242o" OnKeyPress="return event.keyCode != 13;"><br>
<label><input type="radio" name="V242" onClick="ck('tV242'); va('V248')" value="Empregador > 10">Empregador (sócio, dono) de estabelecimento de mais de 10 funcionários</label><br>
<label><input type="radio" name="V242" onClick="ck('tV242'); va('V248')" value="Empregador < 10">Empregador (sócio, dono) de estabelecimento com menos de 10 funcionários</label><br>
<label><input type="radio" name="V242" onClick="ck('tV242'); va('V248')" value="Prof. liberal">Profissional liberal: advogado, contador, professor etc.</label><br>
<label><input type="radio" name="V242" onClick="ck('tV242'); va('V248')" value="Supervisor escritório">Supervisor de trabalhadores de escritório (não manuais)</label><br>
<label><input type="radio" name="V242" onClick="ck('tV242'); va('V248')" value="Trabalhador escritório">Trabalhador de escritório (e ocupações não manuais)</label><br>
<label><input type="radio" name="V242" onClick="ck('tV242'); va('V248')" value="Supervisor manual">Supervisor de trabalhadores manuais</label><br>
<label><input type="radio" name="V242" onClick="ck('tV242'); va('V248')" value="Manual especializado">Trabalhador manual especializado</label><br>
<label><input type="radio" name="V242" onClick="ck('tV242'); va('V248')" value="Manual semi">Trabalhador manual semiespecializado</label><br>
<label><input type="radio" name="V242" onClick="ck('tV242'); va('V248')" value="Braçal">Trabalhador braçal não especializado</label><br>
<label><input type="radio" name="V242" onClick="ck('tV242'); va('V248')" value="Fazendeiro">Fazendeiro</label><br>
<label><input type="radio" name="V242" onClick="ck('tV242'); va('V248')" value="Trabalhador rural">Trabalhador rural</label><br>
<label><input type="radio" name="V242" onClick="ck('tV242'); va('V248')" value="Militar">Membro das forças armadas, segurança pessoal</label><br>

<p>&nbsp;</p>
<a id="V248"></a>
<hr>

<p><? echo $ti ?> tem o rendimento mais alto de sua casa?</p>

<input type="hidden" name="V248" value="NR">

<label><input type="radio" name="V248" onClick="ck('tV248'); Disp('ehmaisalto', 'none'); va('V251')" value="Sim">Sim</label><br>
<label><input type="radio" name="V248" onClick="ck('tV248'); Disp('ehmaisalto', 'block'); va('V249')" value="Não">Não</label>

<p>&nbsp;</p>
<a id="V249"></a>
<hr>

<div id="ehmaisalto" style="display:block">
<p>A pessoa de sua família que
tem o rendimento mais alto está trabalhando agora ou não?</p>

<input type="hidden" name="V249" value="NR">

<label><input type="radio" name="V249" onClick="ck('tV249'); va('V250')" value="Sim">Sim</label><br>
<label><input type="radio" name="V249" onClick="ck('tV249'); va('V250')" value="Não">Não</label>

<p>&nbsp;</p>
<a id="V250"></a>
<hr>

<p>Qual a profissão ou ocupação
da pessoa que tem o rendimento mais alto? Se tiver mais de uma atividade, qual
é a principal? Se não estiver trabalhando, qual foi o tipo de atividade que
desempenhou?
<span class="inst">(digite a ocupação ou assinale de acordo com a lista abaixo)</span></p>

<input type="hidden" name="V250" value="NR">

Profissão ou ocupação: <input type="text" name="V250o" OnKeyPress="return event.keyCode != 13;"><br>
<label><input type="radio" name="V250" onClick="ck('tV250'); va('V251')" value="Empregador > 10">Empregador (sócio, dono) de estabelecimento de mais de 10 funcionários</label><br>
<label><input type="radio" name="V250" onClick="ck('tV250'); va('V251')" value="Empregador < 10">Empregador (sócio, dono) de estabelecimento com menos de 10 funcionários</label><br>
<label><input type="radio" name="V250" onClick="ck('tV250'); va('V251')" value="Prof. liberal">Profissional liberal: advogado, contador, professor etc.</label><br>
<label><input type="radio" name="V250" onClick="ck('tV250'); va('V251')" value="Supervisor escritório">Supervisor de trabalhadores de escritório (não manuais)</label><br>
<label><input type="radio" name="V250" onClick="ck('tV250'); va('V251')" value="Trabalhador escritório">Trabalhador de escritório (e ocupações não manuais)</label><br>
<label><input type="radio" name="V250" onClick="ck('tV250'); va('V251')" value="Supervisor manual">Supervisor de trabalhadores manuais</label><br>
<label><input type="radio" name="V250" onClick="ck('tV250'); va('V251')" value="Manual especializado">Trabalhador manual especializado</label><br>
<label><input type="radio" name="V250" onClick="ck('tV250'); va('V251')" value="Manual semi">Trabalhador manual semiespecializado</label><br>
<label><input type="radio" name="V250" onClick="ck('tV250'); va('V251')" value="Braçal">Trabalhador braçal não especializado</label><br>
<label><input type="radio" name="V250" onClick="ck('tV250'); va('V251')" value="Fazendeiro">Fazendeiro</label><br>
<label><input type="radio" name="V250" onClick="ck('tV250'); va('V251')" value="Trabalhador rural">Trabalhador rural</label><br>
<label><input type="radio" name="V250" onClick="ck('tV250'); va('V251')" value="Militar">Membro das forças armadas, segurança pessoal</label><br>
<label><input type="radio" name="V250" onClick="ck('tV250'); va('V251')" value="Nunca teve emprego">Nunca teve emprego</label><br>

<p>&nbsp;</p>
<hr>
</div>

<p><a id="V251"></a> No ano passado, a sua família:</p>

<input type="hidden" name="V251" value="NR">

<label><input type="radio" name="V251" onClick="ck('tV251'); va('cAE')" value="Guardou">Guardou dinheiro</label><br>
<label><input type="radio" name="V251" onClick="ck('tV251'); va('cAE')" value="Ganhou e gastou">Ganhou e gastou o dinheiro</label><br>
<label><input type="radio" name="V251" onClick="ck('tV251'); va('cAE')" value="Gastou">Gastou as economias da família</label><br>
<label><input type="radio" name="V251" onClick="ck('tV251'); va('cAE')" value="Gastou e fez empréstimo">Gastou as economias da família e fez empréstimos</label>

<p>&nbsp;</p>
<a id="cAE"></a>
<hr>

<p><? echo $ti ?> poderia nos
dizer qual é aproximadamente a renda mensal do seu domicílio, isto é, a soma
da renda mensal de todos os membros do seu domicílio?</p>

<input type="hidden" name="P1" value="NR">

<p>
<label><input type="radio" name="P1" onClick="ck('tP1'); va('V256')" value="< 1">Até 1 salário mínimo (até R$ 678,00)</label><br>
<label><input type="radio" name="P1" onClick="ck('tP1'); va('V256')" value="1 a 2">Até 2 salários mínimos (de R$ 678,01 até R$ 1.356,00)</label><br>
<label><input type="radio" name="P1" onClick="ck('tP1'); va('V256')" value="2 a 5">De 2 a 5 salários mínimos (de R$ 1.356,01 até R$ 3.390,00)</label><br>
<label><input type="radio" name="P1" onClick="ck('tP1'); va('V256')" value="5 a 10">De 5 a 10 salários mínimos (de R$ 3.390,01 até R$ 6.780,00)</label><br>
<label><input type="radio" name="P1" onClick="ck('tP1'); va('V256')" value="10 a 15">De 10 a 15 salários mínimos (de R$ 6.780,01 a R$ 10.170,00)</label><br>
<label><input type="radio" name="P1" onClick="ck('tP1'); va('V256')" value="15 a 20">De 15 a 20 salários mínimos (de R$ 10.170,01 a R$ 13.560,00)</label><br>
<label><input type="radio" name="P1" onClick="ck('tP1'); va('V256')" value="> 20">Mais de 20 salários mínimos (mais de R$ 13.560,00)</label></p>

<p>&nbsp;</p>
<a id="V256"></a> 
<hr>

<p>Em qual grupo de cor abaixo <? echo $tm ?> se classifica?</p>

<input type="hidden" name="V256" value="NR">

<label><input type="radio" name="V256" onClick="ck('tV256'); va('contato'); document.getElementById('cidade').focus()" value="Branco">Branco</label><br>
<label><input type="radio" name="V256" onClick="ck('tV256'); va('contato'); document.getElementById('cidade').focus()" value="Negro">Negro</label><br>
<label><input type="radio" name="V256" onClick="ck('tV256'); va('contato'); document.getElementById('cidade').focus()" value="Pardo">Pardo</label><br>
<label><input type="radio" name="V256" onClick="ck('tV256'); va('contato'); document.getElementById('cidade').focus()" value="Oriental">Oriental: chinês, japonês, coreano etc.</label><br>
<label><input type="radio" name="V256" onClick="ck('tV256'); va('contato'); document.getElementById('cidade').focus()" value="Indígena">Indígena</label><br>

<p>&nbsp;</p>
<a id="contato"></a>
<hr>

<p><a id="P2"></a> Em qual cidade <? echo $tm ?> você mora? 
<input type="text" id="cidade" name="cidade" maxlength=40 OnKeyPress="return event.keyCode != 13;">

<p>&nbsp;</p>
<hr>

<p> Como <? echo $tm ?> notou, o questionário pula automaticamente de uma
questão para outra. O que <? echo $tm ?> achou disso?</p>

<input type="hidden" name="S1" value="NR">
<label><input type="radio" name="S1" onClick="ck('tS1'); va('contato2')" value="Gostei">Gostei</label><br>
<label><input type="radio" name="S1" onClick="ck('tS1')" value="Não gostei">Não gostei</label><br>

<p>&nbsp;</p>

<h3>Contato</h3>
<a id="contato2"></a>
<hr>

<p> Se <? echo $tm ?> tiver interesse, podemos lhe
enviar notícias sobre os resultados da pesquisa. <? echo $ti ?> gostaria de
informar um e-mail para contato? <span class="inst">(preenchimento opcional)</span></p>

<p>E-mail: <input type="text" size=25 maxlength=80 name="email" OnKeyPress="return event.keyCode != 13;"></p>

<p>Nome ou apelido: <input type="text" size=25 maxlength=80 name="nome" OnKeyPress="return event.keyCode != 13;"></p>

<input type="hidden" id="tV235" name="tV235" value="NA">
<input type="hidden" id="tV55" name="tV55" value="NA">
<input type="hidden" id="tV238" name="tV238" value="NA">
<input type="hidden" id="tV240" name="tV240" value="NA">
<input type="hidden" id="tV241" name="tV241" value="NA">
<input type="hidden" id="tV242a" name="tV242a" value="NA">
<input type="hidden" id="tV242" name="tV242" value="NA">
<input type="hidden" id="tV243" name="tV243" value="NA">
<input type="hidden" id="tV248" name="tV248" value="NA">
<input type="hidden" id="tV249" name="tV249" value="NA">
<input type="hidden" id="tV250" name="tV250" value="NA">
<input type="hidden" id="tV251" name="tV251" value="NA">
<input type="hidden" id="tP1" name="tP1" value="NA">
<input type="hidden" id="tS1" name="tS1" value="NA">
<input type="hidden" id="tV256" name="tV256" value="NA">

<p style="text-align:center"><input type="submit" style="font-weight:bold;" value="Enviar"></p>

</form>

</div>

<!--
<script language='JavaScript' type='text/javascript'> retirarNumQuest(); </script>
-->

</body>
</html>
