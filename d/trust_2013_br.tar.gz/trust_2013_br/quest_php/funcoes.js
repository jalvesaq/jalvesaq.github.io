

function setFocusDelayed()
{
   global_valfield.focus();
}

function setfocus(valfield)
{
   global_valfield = valfield;
   setTimeout( 'setFocusDelayed()', 100 );
}

function trim(x){
    return x.replace(/^\s+/, '').replace(/\s+$/, '');
}

function validarIdade(valfield, infofield)
{
   document.getElementById(infofield).innerHTML = " ";
   var tfld = trim(valfield.value);
   var ageRE = /^[0-9][0-9]$/;
   if (!ageRE.test(tfld)) {
      document.getElementById(infofield).innerHTML = "ERRO: Idade inválida.";
      setfocus(valfield);
      return false;
   }
   if (tfld < "16")
      document.getElementById(infofield).innerHTML = "ERRO: Muito jovem.";
   return true;
}

function limparRadio(objName) {
   var arr = new Array();
   arr = document.getElementsByName(objName);
   for (var i = 0; i < arr.length; i++) {
      var obj = arr[i];
      obj.checked = false;
   }
}

function va(dest)
{
   window.location.hash = dest;
}

var tempoini = new Date().getTime();
function ck(dest)
{
   var agora = new Date().getTime() - tempoini;
   document.getElementById(dest).value = agora;
}

var vqn = ["V12", "V13", "V14", "V15", "V16", "V17", "V18", "V19", "V20", "V21"];
var vqt = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
var vavis = false;
function contaQuali(qual)
{
   var agora = new Date().getTime();
   var isegun = -1;
   var tsegun = 0;
   var nchecked = 0;
   for(i = 0; i < 10; i++){
      if(document.getElementById(vqn[i]).checked == false)
         vqt[i] = 0;
      else
         if(vqn[i] == qual)
            vqt[i] = agora;
      if(vqt[i] != agora && vqt[i] > tsegun){
         tsegun = vqt[i];
         isegun = i;
      }
      nchecked += vqt[i] > 0;
   }
   if(nchecked > 5){
      if(vavis == false){
         alert("Foi ultrapassado o limite de cinco opções. Desmarque alguma antes de escolher outra.");
         vavis = true;
      }
      document.getElementById(vqn[isegun]).checked = false;
   }
}

function respV23(qual)
{
   if(qual == 1){
      document.getElementById("v23r").innerHTML = "A maioria das pessoas é de confiança";
      document.getElementById("rV23").innerHTML = "A maioria das pessoas é de confiança";
   } else {
      document.getElementById("v23r").innerHTML = "É preciso ser muito cuidadoso";
      document.getElementById("rV23").innerHTML = "É preciso ser muito cuidadoso";
   }
}

var counter = 1;
var npessoas = 1;
var limit = 40;
function addInput(divName){
     if (npessoas == limit)  {
          alert("O limite de " + limit + " pessoas que podem ser adicionadas à rede foi atingido.");
     }
     else {
          var newdiv = document.createElement('div');
          newdiv.id = "ndiv" + counter;
          newdiv.innerHTML = "<table><tr><td colspan='2'>Nome ou apelido:</td><td>Tipo de relacionamento:</td></tr><tr><td><a title='Remover esta pessoa' href='javascript: deleteInput(\"ndiv" + counter + "\")'>x</a></td><td><input type='text' size='12' name='pessoa" + counter + "' id='pessoa" + counter + "'></td><td><select name='rel" + counter + "'><option>...</option><option>Mãe</option><option>Pai</option><option>Filho(a)</option><option>Esposo(a) ou Namorado(a)</option><option>Irmão(ã)</option><option>Primo(a)</option><option>Tio(a)</option><option>Avô(ó)</option><option>Neto(a)</option><option>Genro ou nora</option><option>Cunhado(a)</option><option>Amigo(a)</option><option>Vizinho(a)</option><option>Colega (trabalho ou estudo)</option></select></td></tr></table><br>";
          document.getElementById(divName).appendChild(newdiv);
          document.getElementById('pessoa' + counter).focus();
          counter++;
          npessoas++;
     }
}

function deleteInput(divId)
{
   thediv = document.getElementById(divId);
   document.getElementById("dynamicInput").removeChild(thediv);
   npessoas--;
}

function validarRede(form){
    for(var i = 0; i < form.elements.length; i++){
        if(form.elements[i].name == "ego"){
           if(trim(form.elements[i].value) == ""){
              form.elements[i].value = "Eu";
           }
        }
        if(form.elements[i].name.indexOf("pessoa") == 0){
            form.elements[i].value = trim(form.elements[i].value);
            if(form.elements[i].value == ""){
                alert('Por favor, digite um nome ou apelido de cada uma das pessoas.');
                form.elements[i].focus();
                return false;
            }
        }
        if(form.elements[i].name.indexOf("rel") == 0 && form.elements[i].value == "..."){
            alert('Por favor, informe o tipo de relacionamento de cada uma das pessoas.');
            form.elements[i].focus();
            return false;
        }
    }
    for(var i = 0; i < form.elements.length; i++){
        for(var j = 0; j < form.elements.length; j++){
            if(i != j && form.elements[i].value == form.elements[j].value && form.elements[i].type == "text" && form.elements[j].type == "text"){
                alert('Nome repetido: "' + form.elements[j].value + '". Por favor, use um nome ou apelido diferente ou remova a pessoa repetida.');
                form.elements[j].focus();
                return false;
            }
        }
    }
    return true;
}

function retirarNumQuest() {
   var elems = document.getElementsByClassName('qt');
   for (var i = 0; i < elems.length; i++) {
      elems[i].innerHTML = '&bull;';
   }
}

var fontam = 1.0;
function MudarFonte(como){
   if(como == "maior")
      fontam = Math.round(fontam * 11) / 10;
   else
      fontam = Math.round(fontam * 9) / 10;
   document.getElementById('fontsz').value = fontam + "em";
   document.getElementById("geral").style.fontSize = fontam + "em";
}

function Disp(e, s){
   document.getElementById(e).style.display = s;
}
