<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="pt-BR">
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
<title>Questionário</title>

<meta name="viewport" content="width=device-width">
<link href="estilo.css" rel="stylesheet" type="text/css" media="all">
<? if(isset($_POST["fontsz"])) echo '<style media="screen" type="text/css"> #geral { font-size: ' . $_POST["fontsz"] . " }</style>"; ?>

<script src="funcoes.js" type="text/javascript"></script>

</head>
<body>

<? include "continua.php" ?>

<div id="geral">

<p><span style="color:red">ATENÇÃO: Nenhuma informação será armazenada porque a coleta de dados já foi encerrada!</span></p>

<form name="Qform" action="quest02.php" method="post">

<h2>Valores e atitudes sociais</h2>

<input type="hidden" name="horaini" value="<?php echo date("Y-m-d H:i:s");?>">
<input type="hidden" id="fontsz" name="fontsz" value="<? echo $_POST["fontsz"] ?>">
<input type="hidden" id="formtrat" name="formtrat" value="<? echo $formtrat ?>">

<hr>

<p>Por favor, para cada um dos itens seguintes, indique em que medida eles são
importantes em sua vida:</p>

<input type="hidden" name="V4" value="NR">
<input type="hidden" name="V5" value="NR">
<input type="hidden" name="V6" value="NR">
<input type="hidden" name="V7" value="NR">
<input type="hidden" name="V8" value="NR">
<input type="hidden" name="V9" value="NR">

<p>Família<br>
<label><input type="radio" name="V4" onClick="ck('tV4'); va('V5')" value="Muito importante">Muito importante</label><br>
<label><input type="radio" name="V4" onClick="ck('tV4'); va('V5')" value="Importante">Importante</label><br>
<label><input type="radio" name="V4" onClick="ck('tV4'); va('V5')" value="Pouco importante">Pouco importante</label><br>
<label><input type="radio" name="V4" onClick="ck('tV4'); va('V5')" value="Não é importante">Não é importante</label>
</p>

<a id="V5"></a>Amigos<br>
<label><input type="radio" name="V5" onClick="ck('tV5'); va('V6')" value="Muito importante">Muito importante</label><br>
<label><input type="radio" name="V5" onClick="ck('tV5'); va('V6')" value="Importante">Importante</label><br>
<label><input type="radio" name="V5" onClick="ck('tV5'); va('V6')" value="Pouco importante">Pouco importante</label><br>
<label><input type="radio" name="V5" onClick="ck('tV5'); va('V6')" value="Não é importante">Não é importante</label>

<p><a id="V6"></a>Tempo livre</p>
<label><input type="radio" name="V6" onClick="ck('tV6'); va('V7')" value="Muito importante">Muito importante</label><br>
<label><input type="radio" name="V6" onClick="ck('tV6'); va('V7')" value="Importante">Importante</label><br>
<label><input type="radio" name="V6" onClick="ck('tV6'); va('V7')" value="Pouco importante">Pouco importante</label><br>
<label><input type="radio" name="V6" onClick="ck('tV6'); va('V7')" value="Não é importante">Não é importante</label>

<p><a id="V7"></a>Política</p>
<label><input type="radio" name="V7" onClick="ck('tV7'); va('V8')" value="Muito importante">Muito importante</label><br>
<label><input type="radio" name="V7" onClick="ck('tV7'); va('V8')" value="Importante">Importante</label><br>
<label><input type="radio" name="V7" onClick="ck('tV7'); va('V8')" value="Pouco importante">Pouco importante</label><br>
<label><input type="radio" name="V7" onClick="ck('tV7'); va('V8')" value="Não é importante">Não é importante</label>

<p><a id="V8"></a>Trabalho</p>
<label><input type="radio" name="V8" onClick="ck('tV8'); va('V9')" value="Muito importante">Muito importante</label><br>
<label><input type="radio" name="V8" onClick="ck('tV8'); va('V9')" value="Importante">Importante</label><br>
<label><input type="radio" name="V8" onClick="ck('tV8'); va('V9')" value="Pouco importante">Pouco importante</label><br>
<label><input type="radio" name="V8" onClick="ck('tV8'); va('V9')" value="Não é importante">Não é importante</label>

<p><a id="V9"></a>Religião</p>
<label><input type="radio" name="V9" onClick="ck('tV9'); va('V10')" value="Muito importante">Muito importante</label><br>
<label><input type="radio" name="V9" onClick="ck('tV9'); va('V10')" value="Importante">Importante</label><br>
<label><input type="radio" name="V9" onClick="ck('tV9'); va('V10')" value="Pouco importante">Pouco importante</label><br>
<label><input type="radio" name="V9" onClick="ck('tV9'); va('V10')" value="Não é importante">Não é importante</label>

<p>&nbsp;</p>
<a id="V10"></a>
<hr>
<p>Em geral, <? echo $tm ?> se considera uma pessoa:</p>

<input type="hidden" name="V10" value="NR">

<label><input type="radio" name="V10" onClick="ck('tV10'); va('V11')" value="Muito feliz">Muito feliz</label><br>
<label><input type="radio" name="V10" onClick="ck('tV10'); va('V11')" value="Feliz">Feliz</label><br>
<label><input type="radio" name="V10" onClick="ck('tV10'); va('V11')" value="Não muito feliz">Não muito feliz</label><br>
<label><input type="radio" name="V10" onClick="ck('tV10'); va('V11')" value="Infeliz">Infeliz</label><br>

<p>&nbsp;</p>
<a id="V11"></a>
<hr>

<p>Em geral, como está sua saúde?</p>

<input type="hidden" name="V11" value="NR">

<label><input type="radio" name="V11" onClick="ck('tV11'); va('qquali')" value="Muito boa">Muito boa</label><br>
<label><input type="radio" name="V11" onClick="ck('tV11'); va('qquali')" value="Boa">Boa</label><br>
<label><input type="radio" name="V11" onClick="ck('tV11'); va('qquali')" value="Razoável">Razoável</label><br>
<label><input type="radio" name="V11" onClick="ck('tV11'); va('qquali')" value="Ruim">Ruim</label><br>

<p>&nbsp;</p>
<a id="qquali"></a>
<hr>

<p>Aqui está uma lista de qualidades que as crianças podem aprender em casa.
Entre essas qualidades, quais <? echo $tm ?> acha que são as mais importantes para
estimular e ensinar aos seus filhos? <span class="inst">(escolha, no máximo, cinco opções)</span></p>

<input type="hidden" value="Não mencionada" name="V12">
<input type="hidden" value="Não mencionada" name="V13">
<input type="hidden" value="Não mencionada" name="V14">
<input type="hidden" value="Não mencionada" name="V15">
<input type="hidden" value="Não mencionada" name="V16">
<input type="hidden" value="Não mencionada" name="V17">
<input type="hidden" value="Não mencionada" name="V18">
<input type="hidden" value="Não mencionada" name="V19">
<input type="hidden" value="Não mencionada" name="V20">
<input type="hidden" value="Não mencionada" name="V21">

<p>
<label><input type="checkbox" id="V12" name="V12" value="Mencionada" onClick="contaQuali('V12')"> Independência</label><br>
<label><input type="checkbox" id="V13" name="V13" value="Mencionada" onClick="contaQuali('V13')"> Ser trabalhador</label><br>
<label><input type="checkbox" id="V14" name="V14" value="Mencionada" onClick="contaQuali('V14')"> Responsabilidade</label><br>
<label><input type="checkbox" id="V15" name="V15" value="Mencionada" onClick="contaQuali('V15')"> Criatividade</label><br>
<label><input type="checkbox" id="V16" name="V16" value="Mencionada" onClick="contaQuali('V16')"> Tolerância e respeito pelos outros</label><br>
<label><input type="checkbox" id="V17" name="V17" value="Mencionada" onClick="contaQuali('V17')"> Saber economizar (dinheiro e outros bens)</label><br>
<label><input type="checkbox" id="V18" name="V18" value="Mencionada" onClick="contaQuali('V18')"> Determinação e perseverança</label><br>
<label><input type="checkbox" id="V19" name="V19" value="Mencionada" onClick="contaQuali('V19')"> Ter fé religiosa</label><br>
<label><input type="checkbox" id="V20" name="V20" value="Mencionada" onClick="contaQuali('V20')"> Não ser egoísta</label><br>
<label><input type="checkbox" id="V21" name="V21" value="Mencionada" onClick="contaQuali('V21')"> Obediência</label></p>

<p>&nbsp;</p>
<hr>

<p> Em geral, em que medida <? echo $tm ?> está
satisfeito ou insatisfeito com sua vida ultimamente? No quadro abaixo, em
que 1 quer dizer “completamente insatisfeito” e 10 quer dizer “completamente
satisfeito”, em que ponto <? echo $tm ?> colocaria sua satisfação com a
vida?</p>

<input type="hidden" name="V22" value="NA">

<div class="temumdez">
<table class="umdez">
   <tr>
      <td colspan=10>
         <table class="cabecalho">
            <tr>
               <td class="esq">Completamente insatisfeito</td>
               <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
               <td class="dir">Completamente satisfeito</td>
            </tr>
         </table>
      </td>
   </tr>
   <tr><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td></tr>
   <tr>
      <td><input type="radio" name="V22" onClick="ck('tV22'); va('confianca')" value="1"></td>
      <td><input type="radio" name="V22" onClick="ck('tV22'); va('confianca')" value="2"></td>
      <td><input type="radio" name="V22" onClick="ck('tV22'); va('confianca')" value="3"></td>
      <td><input type="radio" name="V22" onClick="ck('tV22'); va('confianca')" value="4"></td>
      <td><input type="radio" name="V22" onClick="ck('tV22'); va('confianca')" value="5"></td>
      <td><input type="radio" name="V22" onClick="ck('tV22'); va('confianca')" value="6"></td>
      <td><input type="radio" name="V22" onClick="ck('tV22'); va('confianca')" value="7"></td>
      <td><input type="radio" name="V22" onClick="ck('tV22'); va('confianca')" value="8"></td>
      <td><input type="radio" name="V22" onClick="ck('tV22'); va('confianca')" value="9"></td>
      <td><input type="radio" name="V22" onClick="ck('tV22'); va('confianca')" value="10"></td>
   </tr>
</table>
</div>

<p>&nbsp;</p>

<a id="confianca"></a>
<h3>Confiança</h3>
<a id="V23"></a> 
<hr>

<p>De modo geral, <? echo $tm ?> diria que pode confiar na maioria das
pessoas ou precisa ser muito cuidadoso com elas?</p>

<input type="hidden" name="V23" value="NR">

<label><input type="radio" name="V23" onClick="ck('tV23'); va('A47'); respV23(1)" value="As pessoas são de confiança">A maioria das pessoas é de confiança.</label><br>
<label><input type="radio" name="V23" onClick="ck('tV23'); va('A47'); respV23(0)" value="É preciso ser muito cuidadoso">É preciso ser muito cuidadoso.</label><br>

<p>&nbsp;</p>
<a id="A47"></a>
<hr>

<p>Algumas pessoas tentam levar
vantagens sobre as outras enquanto outras tentam ser justas. De cada 10
pessoas não conhecidas com quem <? echo $tm ?> se
encontrasse, quantas tentariam levar vantagem sobre <? echo $tm ?>?</p>

<input type="hidden" name="A47" value="NA">

<div class="temumdez">
<table class="umdez">
   <tr>
      <td colspan=11>
         <table class="cabecalho">
            <tr>
               <td class="esq">Nenhuma</td>
               <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
               <td class="dir">Todas</td>
            </tr>
         </table>
      </td>
   </tr>
   <tr><td>0</td><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td></tr>
   <tr>
      <td><input type="radio" name="A47" onClick="ck('tA47'); va('cS1')" value="0"></td>
      <td><input type="radio" name="A47" onClick="ck('tA47'); va('cS1')" value="1"></td>
      <td><input type="radio" name="A47" onClick="ck('tA47'); va('cS1')" value="2"></td>
      <td><input type="radio" name="A47" onClick="ck('tA47'); va('cS1')" value="3"></td>
      <td><input type="radio" name="A47" onClick="ck('tA47'); va('cS1')" value="4"></td>
      <td><input type="radio" name="A47" onClick="ck('tA47'); va('cS1')" value="5"></td>
      <td><input type="radio" name="A47" onClick="ck('tA47'); va('cS1')" value="6"></td>
      <td><input type="radio" name="A47" onClick="ck('tA47'); va('cS1')" value="7"></td>
      <td><input type="radio" name="A47" onClick="ck('tA47'); va('cS1')" value="8"></td>
      <td><input type="radio" name="A47" onClick="ck('tA47'); va('cS1')" value="9"></td>
      <td><input type="radio" name="A47" onClick="ck('tA47'); va('cS1')" value="10"></td>
   </tr>
</table>
</div>

<p>&nbsp;</p>
<a id="cS1"></a>
<hr>

<p>Gostaria de perguntar em
que medida <? echo $tm ?> confia nos seguintes grupos. <? echo $ti ?> poderia
me dizer se confia totalmente, em parte, pouco ou não confia nas pessoas dos
grupos abaixo. <span class="inst">(assinale uma resposta para cada item)</span></p>

<input type="hidden" name="V125" value="NR">
<input type="hidden" name="V125a" value="NR">
<input type="hidden" name="V126" value="NR">
<input type="hidden" name="V127" value="NR">
<input type="hidden" name="V128" value="NR">
<input type="hidden" name="V129" value="NR">
<input type="hidden" name="V130" value="NR">

<p><a id="V125a"></a>Pessoas em geral</p>
<label><input type="radio" name="V125a" onClick="ck('tV125a'); va('V125')" value="Totalmente">Confia totalmente</label><br>
<label><input type="radio" name="V125a" onClick="ck('tV125a'); va('V125')" value="Em parte">Confia em parte</label><br>
<label><input type="radio" name="V125a" onClick="ck('tV125a'); va('V125')" value="Pouco">Confia pouco</label><br>
<label><input type="radio" name="V125a" onClick="ck('tV125a'); va('V125')" value="Não confia">Não confia</label>

<p><a id="V125"></a>Sua família</p>
<label><input type="radio" name="V125" onClick="ck('tV125'); va('V126')" value="Totalmente">Confia totalmente</label><br>
<label><input type="radio" name="V125" onClick="ck('tV125'); va('V126')" value="Em parte">Confia em parte</label><br>
<label><input type="radio" name="V125" onClick="ck('tV125'); va('V126')" value="Pouco">Confia pouco</label><br>
<label><input type="radio" name="V125" onClick="ck('tV125'); va('V126')" value="Não confia">Não confia</label>

<p><a id="V126"></a>Seus vizinhos</p>
<label><input type="radio" name="V126" onClick="ck('tV126'); va('V127')" value="Totalmente">Confia totalmente</label><br>
<label><input type="radio" name="V126" onClick="ck('tV126'); va('V127')" value="Em parte">Confia em parte</label><br>
<label><input type="radio" name="V126" onClick="ck('tV126'); va('V127')" value="Pouco">Confia pouco</label><br>
<label><input type="radio" name="V126" onClick="ck('tV126'); va('V127')" value="Não confia">Não confia</label>

<p><a id="V127"></a>Pessoas que <? echo $tm ?> conhece pessoalmente</p>
<label><input type="radio" name="V127" onClick="ck('tV127'); va('V128')" value="Totalmente">Confia totalmente</label><br>
<label><input type="radio" name="V127" onClick="ck('tV127'); va('V128')" value="Em parte">Confia em parte</label><br>
<label><input type="radio" name="V127" onClick="ck('tV127'); va('V128')" value="Pouco">Confia pouco</label><br>
<label><input type="radio" name="V127" onClick="ck('tV127'); va('V128')" value="Não confia">Não confia</label>

<p><a id="V128"></a>Pessoas que <? echo $tm ?> está vendo pela primeira vez</p>
<label><input type="radio" name="V128" onClick="ck('tV128'); va('V129')" value="Totalmente">Confia totalmente</label><br>
<label><input type="radio" name="V128" onClick="ck('tV128'); va('V129')" value="Em parte">Confia em parte</label><br>
<label><input type="radio" name="V128" onClick="ck('tV128'); va('V129')" value="Pouco">Confia pouco</label><br>
<label><input type="radio" name="V128" onClick="ck('tV128'); va('V129')" value="Não confia">Não confia</label>

<p><a id="V129"></a>Pessoas de outras religiões</p>
<label><input type="radio" name="V129" onClick="ck('tV129'); va('V130')" value="Totalmente">Confia totalmente</label><br>
<label><input type="radio" name="V129" onClick="ck('tV129'); va('V130')" value="Em parte">Confia em parte</label><br>
<label><input type="radio" name="V129" onClick="ck('tV129'); va('V130')" value="Pouco">Confia pouco</label><br>
<label><input type="radio" name="V129" onClick="ck('tV129'); va('V130')" value="Não confia">Não confia</label>

<p><a id="V130"></a>Pessoas de outros países</p>
<label><input type="radio" name="V130" onClick="ck('tV130'); va('confver')" value="Totalmente">Confia totalmente</label><br>
<label><input type="radio" name="V130" onClick="ck('tV130'); va('confver')" value="Em parte">Confia em parte</label><br>
<label><input type="radio" name="V130" onClick="ck('tV130'); va('confver')" value="Pouco">Confia pouco</label><br>
<label><input type="radio" name="V130" onClick="ck('tV130'); va('confver')" value="Não confia">Não confia</label>

<p>&nbsp;</p>

<a id="confver"></a>
<h3>Detalhes sobre uma pergunta</h3>
<hr>

<p>Na pergunta que fizemos acima:</p>

<blockquote><i>De modo geral, <? echo $tm ?> diria que pode confiar na maioria das
      pessoas ou precisa ser muito cuidadoso com elas?</i></blockquote>

<p><a id="C1a"></a> Em relação à <b>maioria das pessoas</b>,
em quais tipos de pessoas <? echo $tm ?> pensou? <span class="inst">(pode marcar mais de uma)</span></p>

<input type="hidden" name="C1apes" value="Não">
<input type="hidden" name="C1afam" value="Não">
<input type="hidden" name="C1aami" value="Não">
<input type="hidden" name="C1acol" value="Não">
<input type="hidden" name="C1aviz" value="Não">
<input type="hidden" name="C1acon" value="Não">
<input type="hidden" name="C1anin" value="NA">

<p>
<label><input type="checkbox" name="C1apes" value="Sim">Pessoas que estaria vendo pela primeira vez</label><br>
<label><input type="checkbox" name="C1afam" value="Sim">Familiares</label><br>
<label><input type="checkbox" name="C1aami" value="Sim">Amigos</label><br>
<label><input type="checkbox" name="C1acol" value="Sim">Colegas de trabalho</label><br>
<label><input type="checkbox" name="C1aviz" value="Sim">Vizinhos</label><br>
<label><input type="checkbox" name="C1acon" value="Sim">Conhecidos com quem não tem amizade</label><br>
<label><input type="checkbox" name="C1anin" value="Sim">Não pensou em ninguém</label></p>

<p>&nbsp;</p>
<hr>

<p> <? echo $ti ?> respondeu que
<i><span id="v23r">...</span></i>. O principal motivo para <? echo $tm ?> dizer isso foi:</p>

<input type="hidden" name="C1b" value="NR">

<p><label><input type="radio" name="C1b" onClick="ck('tC1b'); va('C1c')" value="Experiência própria">Por experiência própria</label><br>
<label><input type="radio" name="C1b" onClick="ck('tC1b'); va('C1c')" value="Me ensinaram">Porque foi o que lhe ensinaram</label></p>

<p>&nbsp;</p>
<a id="C1c"></a>
<hr>

<p>Ainda sobre a mesma pergunta, das afirmações
abaixo, qual mais se aproxima do que <? echo $tm ?> entendeu por
<b>confiar</b>?</p>

<input type="hidden" name="C1c" value="NR">

<p><label><input type="radio" name="C1c" onClick="ck('tC1c'); va('C1d')" value="Conhecer">Confiar é conhecer.</label><br>
<label><input type="radio" name="C1c" onClick="ck('tC1c'); va('C1d')" value="Prever">Confiar é prever o que o outro fará em determinadas situações.</label><br>
<label><input type="radio" name="C1c" onClick="ck('tC1c'); va('C1d')" value="Fidelidade">Confiar é acreditar na fidelidade da pessoa.</label><br>
<label><input type="radio" name="C1c" onClick="ck('tC1c'); va('C1d')" value="Compartilhar">Confiar é compartilhar.</label><br>
<label><input type="radio" name="C1c" onClick="ck('tC1c'); va('C1d')" value="Sentir-se seguro">Confiar é sentir-se seguro ao lado da pessoa.</label><br>
<label><input type="radio" name="C1c" onClick="ck('tC1c'); va('C1d')" value="Atribuir responsabilidades">Confiar é atribuir responsabilidades.</label><br>
<label><input type="radio" name="C1c" onClick="ck('tC1c'); va('C1d')" value="Ter um elo">Confiar é ter uma ligação, um elo.</label></p>

<p>&nbsp;</p>
<a id="C1d"></a>
<hr>

<p>Das situações abaixo, qual mais se
aproxima do que <? echo $tm ?> pensou para afirmar que <i><span id="rV23">...</span></i>?</p>

<input type="hidden" name="C1d" value="NR">

<p><label><input type="radio" name="C1d" onClick="ck('tC1d'); va('maisconf')" value="Estranho realmente ajudar">Um estranho que lhe oferece ajuda quer realmente lhe ajudar.</label><br>
<label><input type="radio" name="C1d" onClick="ck('tC1d'); va('maisconf')" value="Amigo guardar segredo">Um amigo seria capaz de guardar um segredo.</label><br>
<label><input type="radio" name="C1d" onClick="ck('tC1d'); va('maisconf')" value="Cumprir palavra">O outro cumprir sua palavra.</label><br>
<label><input type="radio" name="C1d" onClick="ck('tC1d'); va('maisconf')" value="Companheiro não trair">Seu companheiro(a) não lhe trair.</label><br>
<label><input type="radio" name="C1d" onClick="ck('tC1d'); va('maisconf')" value="Emprestar coisas">Emprestar coisas de valor material e/ou sentimental.</label><br>
<label><input type="radio" name="C1d" onClick="ck('tC1d'); va('maisconf')" value="Ficar a sós">Ficar sozinha com uma pessoa e ela não lhe fazer nada de ruim.</label><br>
<label><input type="radio" name="C1d" onClick="ck('tC1d'); va('maisconf')" value="Pessoa estar ao lado">Pessoa estar ao seu lado mesmo na dificuldade, inclusive dificuldade financeira.</label></p>

<p>&nbsp;</p>

<a id="maisconf"></a>
<h3>Mais algumas perguntas sobre confiança</h3>

<hr>

<p>Em caso de problema de saúde, quem <? echo $tm ?> acredita que lhe ajudaria
financeiramente (lhe daria ou emprestaria dinheiro)? <span class="inst">(pode marcar mais de um)</span></p>

<input type="hidden" name="C2mae" value="Não">
<input type="hidden" name="C2pai" value="Não">
<input type="hidden" name="C2fil" value="Não">
<input type="hidden" name="C2irm" value="Não">
<input type="hidden" name="C2avo" value="Não">
<input type="hidden" name="C2net" value="Não">
<input type="hidden" name="C2esp" value="Não">
<input type="hidden" name="C2nam" value="Não">
<input type="hidden" name="C2cun" value="Não">
<input type="hidden" name="C2gen" value="Não">
<input type="hidden" name="C2nor" value="Não">
<input type="hidden" name="C2tio" value="Não">
<input type="hidden" name="C2pri" value="Não">
<input type="hidden" name="C2sog" value="Não">
<input type="hidden" name="C2ami" value="Não">
<input type="hidden" name="C2col" value="Não">
<input type="hidden" name="C2con" value="Não">
<input type="hidden" name="C2viz" value="Não">
<input type="hidden" name="C2pes" value="Não">

<p>
<table class="quem">
   <tr>
      <td><label><input type="checkbox" name="C2mae" value="Sim">Mãe</label></td>
      <td><label><input type="checkbox" name="C2pai" value="Sim">Pai</label></td>
      <td><label><input type="checkbox" name="C2fil" value="Sim">Filhos</label></td>
   </tr>
   <tr>
      <td><label><input type="checkbox" name="C2esp" value="Sim">Esposo(a)</label></td>
      <td><label><input type="checkbox" name="C2nam" value="Sim">Namorado(a)</label></td>
      <td><label><input type="checkbox" name="C2irm" value="Sim">Irmãos</label></td>
   </tr>
   <tr>
      <td><label><input type="checkbox" name="C2avo" value="Sim">Avós</label></td>
      <td><label><input type="checkbox" name="C2net" value="Sim">Netos</label></td>
      <td><label><input type="checkbox" name="C2tio" value="Sim">Tios</label></td>
   </tr>
   <tr>
      <td><label><input type="checkbox" name="C2pri" value="Sim">Primos</label></td>
      <td><label><input type="checkbox" name="C2sog" value="Sim">Sogros</label></td>
      <td><label><input type="checkbox" name="C2cun" value="Sim">Cunhados</label></td>
   </tr>
   <tr>
      <td><label><input type="checkbox" name="C2gen" value="Sim">Genros</label></td>
      <td><label><input type="checkbox" name="C2nor" value="Sim">Noras</label></td>
      <td><label><input type="checkbox" name="C2ami" value="Sim">Amigos</label></td>
   </tr>
   <tr>
      <td><label><input type="checkbox" name="C2viz" value="Sim">Vizinhos</label></td>
      <td><label><input type="checkbox" name="C2col" value="Sim">Colegas</label></td>
      <td><label><input type="checkbox" name="C2con" value="Sim">Conhecidos</label></td>
   </tr>
   <tr>
      <td colspan="4"><label><input type="checkbox" name="C2pes" value="Sim">Pessoas sendo vistas pela primeira vez</label></td>
   </tr>
</table>

<p>&nbsp;</p>
<hr>

<p><a id="C3"></a> Em caso de problema de saúde,
quem <? echo $tm ?> acredita que se disporia a ficar alguns dias com <? echo $tm ?> no
hospital? <span class="inst">(pode marcar mais de um)</span></p>

<input type="hidden" name="C3mae" value="Não">
<input type="hidden" name="C3pai" value="Não">
<input type="hidden" name="C3fil" value="Não">
<input type="hidden" name="C3irm" value="Não">
<input type="hidden" name="C3avo" value="Não">
<input type="hidden" name="C3net" value="Não">
<input type="hidden" name="C3esp" value="Não">
<input type="hidden" name="C3nam" value="Não">
<input type="hidden" name="C3cun" value="Não">
<input type="hidden" name="C3gen" value="Não">
<input type="hidden" name="C3nor" value="Não">
<input type="hidden" name="C3tio" value="Não">
<input type="hidden" name="C3pri" value="Não">
<input type="hidden" name="C3sog" value="Não">
<input type="hidden" name="C3ami" value="Não">
<input type="hidden" name="C3col" value="Não">
<input type="hidden" name="C3con" value="Não">
<input type="hidden" name="C3viz" value="Não">
<input type="hidden" name="C3pes" value="Não">

<p>
<table class="quem">
   <tr>
      <td><label><input type="checkbox" name="C3mae" value="Sim">Mãe</label></td>
      <td><label><input type="checkbox" name="C3pai" value="Sim">Pai</label></td>
      <td><label><input type="checkbox" name="C3fil" value="Sim">Filhos</label></td>
   </tr>
   <tr>
      <td><label><input type="checkbox" name="C3esp" value="Sim">Esposo(a)</label></td>
      <td><label><input type="checkbox" name="C3nam" value="Sim">Namorado(a)</label></td>
      <td><label><input type="checkbox" name="C3irm" value="Sim">Irmãos</label></td>
   </tr>
   <tr>
      <td><label><input type="checkbox" name="C3avo" value="Sim">Avós</label></td>
      <td><label><input type="checkbox" name="C3net" value="Sim">Netos</label></td>
      <td><label><input type="checkbox" name="C3tio" value="Sim">Tios</label></td>
   </tr>
   <tr>
      <td><label><input type="checkbox" name="C3pri" value="Sim">Primos</label></td>
      <td><label><input type="checkbox" name="C3sog" value="Sim">Sogros</label></td>
      <td><label><input type="checkbox" name="C3cun" value="Sim">Cunhados</label></td>
   </tr>
   <tr>
      <td><label><input type="checkbox" name="C3gen" value="Sim">Genros</label></td>
      <td><label><input type="checkbox" name="C3nor" value="Sim">Noras</label></td>
      <td><label><input type="checkbox" name="C3ami" value="Sim">Amigos</label></td>
   </tr>
   <tr>
      <td><label><input type="checkbox" name="C3viz" value="Sim">Vizinhos</label></td>
      <td><label><input type="checkbox" name="C3col" value="Sim">Colegas</label></td>
      <td><label><input type="checkbox" name="C3con" value="Sim">Conhecidos</label></td>
   </tr>
   <tr>
      <td colspan="4"><label><input type="checkbox" name="C3pes" value="Sim">Pessoas sendo vistas pela primeira vez</label></td>
   </tr>
</table>

<p>&nbsp;</p>
<hr>

<p><a id="C4"></a> A quem <? echo $tm ?> emprestaria dinheiro
sem cobrar juros, acreditando que a pessoa devolveria o dinheiro logo que
tivesse condições para isso? <span class="inst">(pode marcar mais de um)</span></p>

<input type="hidden" name="C4mae" value="Não">
<input type="hidden" name="C4pai" value="Não">
<input type="hidden" name="C4fil" value="Não">
<input type="hidden" name="C4irm" value="Não">
<input type="hidden" name="C4avo" value="Não">
<input type="hidden" name="C4net" value="Não">
<input type="hidden" name="C4esp" value="Não">
<input type="hidden" name="C4nam" value="Não">
<input type="hidden" name="C4cun" value="Não">
<input type="hidden" name="C4gen" value="Não">
<input type="hidden" name="C4nor" value="Não">
<input type="hidden" name="C4tio" value="Não">
<input type="hidden" name="C4pri" value="Não">
<input type="hidden" name="C4sog" value="Não">
<input type="hidden" name="C4ami" value="Não">
<input type="hidden" name="C4col" value="Não">
<input type="hidden" name="C4con" value="Não">
<input type="hidden" name="C4viz" value="Não">
<input type="hidden" name="C4pes" value="Não">

<p>
<table class="quem">
   <tr>
      <td><label><input type="checkbox" name="C4mae" value="Sim">Mãe</label></td>
      <td><label><input type="checkbox" name="C4pai" value="Sim">Pai</label></td>
      <td><label><input type="checkbox" name="C4fil" value="Sim">Filhos</label></td>
   </tr>
   <tr>
      <td><label><input type="checkbox" name="C4esp" value="Sim">Esposo(a)</label></td>
      <td><label><input type="checkbox" name="C4nam" value="Sim">Namorado(a)</label></td>
      <td><label><input type="checkbox" name="C4irm" value="Sim">Irmãos</label></td>
   </tr>
   <tr>
      <td><label><input type="checkbox" name="C4avo" value="Sim">Avós</label></td>
      <td><label><input type="checkbox" name="C4net" value="Sim">Netos</label></td>
      <td><label><input type="checkbox" name="C4tio" value="Sim">Tios</label></td>
   </tr>
   <tr>
      <td><label><input type="checkbox" name="C4pri" value="Sim">Primos</label></td>
      <td><label><input type="checkbox" name="C4sog" value="Sim">Sogros</label></td>
      <td><label><input type="checkbox" name="C4cun" value="Sim">Cunhados</label></td>
   </tr>
   <tr>
      <td><label><input type="checkbox" name="C4gen" value="Sim">Genros</label></td>
      <td><label><input type="checkbox" name="C4nor" value="Sim">Noras</label></td>
      <td><label><input type="checkbox" name="C4ami" value="Sim">Amigos</label></td>
   </tr>
   <tr>
      <td><label><input type="checkbox" name="C4viz" value="Sim">Vizinhos</label></td>
      <td><label><input type="checkbox" name="C4col" value="Sim">Colegas</label></td>
      <td><label><input type="checkbox" name="C4con" value="Sim">Conhecidos</label></td>
   </tr>
   <tr>
      <td colspan="4"><label><input type="checkbox" name="C4pes" value="Sim">Pessoas sendo vistas pela primeira vez</label></td>
   </tr>
</table>

<p>&nbsp;</p>

<h3>Interação</h3>

<hr>

<p> Sem contar os parentes que moram próximo da sua
casa, com quantos vizinhos <? echo $tm ?> costuma conversar pelo menos uma vez
por semana?</p>

<input type="hidden" name="I1" value="NR">

<p><label><input type="radio" name="I1" onClick="ck('tI1'); va('I2')" value="Nenhum">Nenhum</label><br>
<label><input type="radio" name="I1" onClick="ck('tI1'); va('I2')" value="1">1</label><br>
<label><input type="radio" name="I1" onClick="ck('tI1'); va('I2')" value="2">2</label><br>
<label><input type="radio" name="I1" onClick="ck('tI1'); va('I2')" value="3 a 6">3 a 6</label><br>
<label><input type="radio" name="I1" onClick="ck('tI1'); va('I2')" value="mais de 6">mais de 6</label></p>

<p>&nbsp;</p>
<a id="I2"></a>
<hr>

<p>Com que frequência <? echo $tm ?> costuma <b>receber</b> visitas de <b>parentes</b>?</p>

<input type="hidden" name="I2" value="NR">

<p><label><input type="radio" name="I2" onClick="ck('tI2'); va('I3')" value="Diariamente">Todos os dias</label><br>
<label><input type="radio" name="I2" onClick="ck('tI2'); va('I3')" value="Semanalmente">Em torno de uma vez por semana</label><br>
<label><input type="radio" name="I2" onClick="ck('tI2'); va('I3')" value="Quinzenalmente">Quinzenalmente</label><br>
<label><input type="radio" name="I2" onClick="ck('tI2'); va('I3')" value="Mensalmente">Em torno de uma vez por mês</label><br>
<label><input type="radio" name="I2" onClick="ck('tI2'); va('I3')" value="Raramente">Raramente</label><br>
<label><input type="radio" name="I2" onClick="ck('tI2'); va('I3')" value="Nunca">Nunca</label></p>

<p>&nbsp;</p>
<a id="I3"></a>
<hr>

<p>Com que frequência <? echo $tm ?> costuma <b>fazer</b> visitas a <b>parentes</b>?</p>

<input type="hidden" name="I3" value="NR">

<p><label><input type="radio" name="I3" onClick="ck('tI3'); va('I4')" value="Diariamente">Todos os dias</label><br>
<label><input type="radio" name="I3" onClick="ck('tI3'); va('I4')" value="Semanalmente">Em torno de uma vez por semana</label><br>
<label><input type="radio" name="I3" onClick="ck('tI3'); va('I4')" value="Quinzenalmente">Quinzenalmente</label><br>
<label><input type="radio" name="I3" onClick="ck('tI3'); va('I4')" value="Mensalmente">Em torno de uma vez por mês</label><br>
<label><input type="radio" name="I3" onClick="ck('tI3'); va('I4')" value="Raramente">Raramente</label><br>
<label><input type="radio" name="I3" onClick="ck('tI3'); va('I4')" value="Nunca">Nunca</label></p>

<p>&nbsp;</p>
<a id="I4"></a>
<hr>

<p>Com que frequência <? echo $tm ?> costuma <b>receber</b> visitas de <b>amigos</b>?</p>

<input type="hidden" name="I4" value="NR">

<p><label><input type="radio" name="I4" onClick="ck('tI4'); va('I5')" value="Diariamente">Todos os dias</label><br>
<label><input type="radio" name="I4" onClick="ck('tI4'); va('I5')" value="Semanalmente">Em torno de uma vez por semana</label><br>
<label><input type="radio" name="I4" onClick="ck('tI4'); va('I5')" value="Quinzenalmente">Quinzenalmente</label><br>
<label><input type="radio" name="I4" onClick="ck('tI4'); va('I5')" value="Mensalmente">Em torno de uma vez por mês</label><br>
<label><input type="radio" name="I4" onClick="ck('tI4'); va('I5')" value="Raramente">Raramente</label><br>
<label><input type="radio" name="I4" onClick="ck('tI4'); va('I5')" value="Nunca">Nunca</label></p>

<p>&nbsp;</p>
<a id="I5"></a>
<hr>

<p>Com que frequência <? echo $tm ?> costuma <b>fazer</b> visitas a <b>amigos</b>?</p>

<input type="hidden" name="I5" value="NR">

<p><label><input type="radio" name="I5" onClick="ck('tI5'); va('sitesp')" value="Diariamente">Todos os dias</label><br>
<label><input type="radio" name="I5" onClick="ck('tI5'); va('sitesp')" value="Semanalmente">Em torno de uma vez por semana</label><br>
<label><input type="radio" name="I5" onClick="ck('tI5'); va('sitesp')" value="Quinzenalmente">Quinzenalmente</label><br>
<label><input type="radio" name="I5" onClick="ck('tI5'); va('sitesp')" value="Mensalmente">Em torno de uma vez por mês</label><br>
<label><input type="radio" name="I5" onClick="ck('tI5'); va('sitesp')" value="Raramente">Raramente</label><br>
<label><input type="radio" name="I5" onClick="ck('tI5'); va('sitesp')" value="Nunca">Nunca</label></p>

<p>&nbsp;</p>

<a id="sitesp"></a>
<h3>Situações especiais</h3>

<p>Diga em que medida as afirmativas abaixo podem ser justificadas, não podem
ser justificadas ou alguma opinião entre essas duas. Na escala de 1 a 10, 1
significa “nunca se justifica” e 10 significa “sempre se justifica”</p>

<input type="hidden" name="V198" value="NA">
<input type="hidden" name="V199" value="NA">
<input type="hidden" name="V200" value="NA">
<input type="hidden" name="V201" value="NA">

<p><a id="V198"></a> Pedir benefícios do governo sem ter direito.</p>

<div class="temumdez">
<table class="umdez">
   <tr>
      <td colspan=10>
         <table class="cabecalho">
            <tr>
               <td class="esq">Nunca se justifica</td>
               <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
               <td class="dir">Sempre se justifica</td>
            </tr>
         </table>
      </td>
   </tr>
   <tr><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td></tr>
   <tr>
      <td><input type="radio" name="V198" onClick="ck('tV198'); va('V199')" value="1"></td>
      <td><input type="radio" name="V198" onClick="ck('tV198'); va('V199')" value="2"></td>
      <td><input type="radio" name="V198" onClick="ck('tV198'); va('V199')" value="3"></td>
      <td><input type="radio" name="V198" onClick="ck('tV198'); va('V199')" value="4"></td>
      <td><input type="radio" name="V198" onClick="ck('tV198'); va('V199')" value="5"></td>
      <td><input type="radio" name="V198" onClick="ck('tV198'); va('V199')" value="6"></td>
      <td><input type="radio" name="V198" onClick="ck('tV198'); va('V199')" value="7"></td>
      <td><input type="radio" name="V198" onClick="ck('tV198'); va('V199')" value="8"></td>
      <td><input type="radio" name="V198" onClick="ck('tV198'); va('V199')" value="9"></td>
      <td><input type="radio" name="V198" onClick="ck('tV198'); va('V199')" value="10"></td>
   </tr>
</table>
</div>

<p>&nbsp;</p>

<p><a id="V199"></a> Evitar pagar passagem em transporte público.</p>

<div class="temumdez">
<table class="umdez">
   <tr>
      <td colspan=10>
         <table class="cabecalho">
            <tr>
               <td class="esq">Nunca se justifica</td>
               <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
               <td class="dir">Sempre se justifica</td>
            </tr>
         </table>
      </td>
   </tr>
   <tr><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td></tr>
   <tr>
      <td><input type="radio" name="V199" onClick="ck('tV199'); va('V200')" value="1"></td>
      <td><input type="radio" name="V199" onClick="ck('tV199'); va('V200')" value="2"></td>
      <td><input type="radio" name="V199" onClick="ck('tV199'); va('V200')" value="3"></td>
      <td><input type="radio" name="V199" onClick="ck('tV199'); va('V200')" value="4"></td>
      <td><input type="radio" name="V199" onClick="ck('tV199'); va('V200')" value="5"></td>
      <td><input type="radio" name="V199" onClick="ck('tV199'); va('V200')" value="6"></td>
      <td><input type="radio" name="V199" onClick="ck('tV199'); va('V200')" value="7"></td>
      <td><input type="radio" name="V199" onClick="ck('tV199'); va('V200')" value="8"></td>
      <td><input type="radio" name="V199" onClick="ck('tV199'); va('V200')" value="9"></td>
      <td><input type="radio" name="V199" onClick="ck('tV199'); va('V200')" value="10"></td>
   </tr>
</table>
</div>

<p>&nbsp;</p>

<p><a id="V200"></a> Não pagar impostos se tiver a chance.</p>

<div class="temumdez">
<table class="umdez">
   <tr>
      <td colspan=10>
         <table class="cabecalho">
            <tr>
               <td class="esq">Nunca se justifica</td>
               <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
               <td class="dir">Sempre se justifica</td>
            </tr>
         </table>
      </td>
   </tr>
   <tr><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td></tr>
   <tr>
      <td><input type="radio" name="V200" onClick="ck('tV200'); va('V201')" value="1"></td>
      <td><input type="radio" name="V200" onClick="ck('tV200'); va('V201')" value="2"></td>
      <td><input type="radio" name="V200" onClick="ck('tV200'); va('V201')" value="3"></td>
      <td><input type="radio" name="V200" onClick="ck('tV200'); va('V201')" value="4"></td>
      <td><input type="radio" name="V200" onClick="ck('tV200'); va('V201')" value="5"></td>
      <td><input type="radio" name="V200" onClick="ck('tV200'); va('V201')" value="6"></td>
      <td><input type="radio" name="V200" onClick="ck('tV200'); va('V201')" value="7"></td>
      <td><input type="radio" name="V200" onClick="ck('tV200'); va('V201')" value="8"></td>
      <td><input type="radio" name="V200" onClick="ck('tV200'); va('V201')" value="9"></td>
      <td><input type="radio" name="V200" onClick="ck('tV200'); va('V201')" value="10"></td>
   </tr>
</table>
</div>

<p>&nbsp;</p>

<p><a id="V201"></a> Aceitar suborno para cumprir seu dever.</p>

<div class="temumdez">
<table class="umdez">
   <tr>
      <td colspan=10>
         <table class="cabecalho">
            <tr>
               <td class="esq">Nunca se justifica</td>
               <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
               <td class="dir">Sempre se justifica</td>
            </tr>
         </table>
      </td>
   </tr>
   <tr><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td></tr>
   <tr>
      <td><input type="radio" name="V201" onClick="ck('tV201')" value="1"></td>
      <td><input type="radio" name="V201" onClick="ck('tV201')" value="2"></td>
      <td><input type="radio" name="V201" onClick="ck('tV201')" value="3"></td>
      <td><input type="radio" name="V201" onClick="ck('tV201')" value="4"></td>
      <td><input type="radio" name="V201" onClick="ck('tV201')" value="5"></td>
      <td><input type="radio" name="V201" onClick="ck('tV201')" value="6"></td>
      <td><input type="radio" name="V201" onClick="ck('tV201')" value="7"></td>
      <td><input type="radio" name="V201" onClick="ck('tV201')" value="8"></td>
      <td><input type="radio" name="V201" onClick="ck('tV201')" value="9"></td>
      <td><input type="radio" name="V201" onClick="ck('tV201')" value="10"></td>
   </tr>
</table>
</div>

<input type="hidden" id="tV4" name="tV4" value="NA">
<input type="hidden" id="tV5" name="tV5" value="NA">
<input type="hidden" id="tV6" name="tV6" value="NA">
<input type="hidden" id="tV7" name="tV7" value="NA">
<input type="hidden" id="tV8" name="tV8" value="NA">
<input type="hidden" id="tV9" name="tV9" value="NA">
<input type="hidden" id="tV10" name="tV10" value="NA">
<input type="hidden" id="tV11" name="tV11" value="NA">
<input type="hidden" id="tV22" name="tV22" value="NA">
<input type="hidden" id="tV23" name="tV23" value="NA">
<input type="hidden" id="tA47" name="tA47" value="NA">
<input type="hidden" id="tV125a" name="tV125a" value="NA">
<input type="hidden" id="tV125" name="tV125" value="NA">
<input type="hidden" id="tV126" name="tV126" value="NA">
<input type="hidden" id="tV127" name="tV127" value="NA">
<input type="hidden" id="tV128" name="tV128" value="NA">
<input type="hidden" id="tV129" name="tV129" value="NA">
<input type="hidden" id="tV130" name="tV130" value="NA">
<input type="hidden" id="tC1b" name="tC1b" value="NA">
<input type="hidden" id="tC1c" name="tC1c" value="NA">
<input type="hidden" id="tC1d" name="tC1d" value="NA">
<input type="hidden" id="tI1" name="tI1" value="NA">
<input type="hidden" id="tI2" name="tI2" value="NA">
<input type="hidden" id="tI3" name="tI3" value="NA">
<input type="hidden" id="tI4" name="tI4" value="NA">
<input type="hidden" id="tI5" name="tI5" value="NA">
<input type="hidden" id="tV198" name="tV198" value="NA">
<input type="hidden" id="tV199" name="tV199" value="NA">
<input type="hidden" id="tV200" name="tV200" value="NA">
<input type="hidden" id="tV201" name="tV201" value="NA">

<p style="text-align:center"><input type="submit" style="font-weight:bold;" value="Enviar e Continuar"></p>
</form>

</div>

<!--
<script language='JavaScript' type='text/javascript'> retirarNumQuest(); </script>
-->

</body>
</html>
