<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="pt-BR">
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
<title>Questionário</title>

<meta name="viewport" content="width=device-width" />

<link href="estilo.css" rel="stylesheet" type="text/css" media="all" />

<script src="funcoes.js" type="text/javascript"></script>

</head>

<body>
   <div id="geral">
   <center><img src="header.jpg" width="320" height="129" alt="Logo LEPEM"></center>

<p><span style="color:red">ATENÇÃO: Nenhuma informação será armazenada porque a coleta de dados já foi encerrada!</span></p>

<h2>Apresentação da pesquisa</h2>

<p>Obrigado por participar de nossa pesquisa!</P>

<p>Somos do
<a href="http://www.lepem.ufc.br">Laboratório de Estudos sobre Política, Eleições e Mídia</a> do
<a href="http://www.cienciassociais.ufc.br">Departamento de Ciências Sociais</a> da
<a href="http://www.ufc.br">Universidade Federal do Ceará</a> e estamos
realizando uma pesquisa sobre confiança. Quando a pesquisa estiver concluída, os
resultados serão divulgados de modo que os entrevistados não serão
identificados. Ressaltamos que não existe resposta errada porque o nosso
objetivo é conhecer a sua opinião.</p>

<p><span class="inst">Escolha a forma de tratamento a ser utilizada:</span></p>


<form name="Primform" action="quest01.php" method="post">

<input type="hidden" name="userag" value="<? echo $_SERVER["HTTP_USER_AGENT"]; ?>">

<p><label><input type="radio" name="formtrat" onClick="document.getElementById('vc').innerHTML='você'" value="Você" checked="checked">Você</label>&nbsp;&nbsp;&nbsp;&nbsp;
   <label><input type="radio" name="formtrat" onClick="document.getElementById('vc').innerHTML='o Sr.'" value="OSenhor">Senhor</label>&nbsp;&nbsp;&nbsp;&nbsp;
   <label><input type="radio" name="formtrat" onClick="document.getElementById('vc').innerHTML='a Sra.'" value="ASenhora">Senhora</label></p>

   <input type="hidden" id="fontsz" name="fontsz" value="1em">
   <p>Mudar o tamanho da fonte:
   <input type="button" value="+" style="width: 4em; font-weight:bold;" onClick="MudarFonte('maior')"> ou
   <input type="button" value="&ndash;" style="width: 4em; font-weight:bold;" onClick="MudarFonte('menor')"></p>

<p><b>Observações</b>:</p>

<ul>
   <li>Nas questões que não são de múltipla escolha, assim que uma opção for
   escolhida, o questionário saltará para a questão seguinte.</li>
   <li>Com o preenchimento completo do questionário, ao final, <span id="vc">você</span>
   poderá visualizar uma representação gráfica do seu conjunto de relações pessoais semelhante à
   figura abaixo:<br><br>
   <center><img src="grafo.png" width="300" height="150" alt="Exemplo de sociograma"></center>
   </li>

<p style="text-align:center"><input type="submit" style="font-weight:bold;" value="Responder o Questionário"></p>
</form>

</div>

</body>
</html>
