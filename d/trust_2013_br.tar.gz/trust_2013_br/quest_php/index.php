<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="pt-BR">
<head>
   <meta http-equiv="content-type" content="text/html; charset=utf-8">
   <title>Questionário</title>
   <link href="estilo.css" rel="stylesheet" type="text/css" media="all" />
</head>

<body>

<div id="geral">


   <p>Obrigado por seu interesse em participar da pesquisa, mas a coleta de
   dados já foi encerrada. Se quiser conhecer o questionário que foi
   utilizado (nenhum dado será armazenado), clique
<a href="http://www.lepem.ufc.br/conf/intro.php">aqui</a>.</p>

</div>

</body>
</html>
