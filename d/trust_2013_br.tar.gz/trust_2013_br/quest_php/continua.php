
<?php
   if(isset($_POST["formtrat"])){
      $formtrat = $_POST["formtrat"];
   } else {
      $formtrat = "Você";
   }
   if($formtrat == "Você"){
      $ti = "Você";
      $tm = "você";
   } else if($formtrat == "OSenhor"){
      $ti = "O Sr.";
      $tm = "o Sr.";
   } else if($formtrat == "ASenhora"){
      $ti = "A Sra.";
      $tm = "a Sra.";
   } else {
      $ti = "Você";
      $tm = "você";
   }
?>

