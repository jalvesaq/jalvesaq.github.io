<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="pt-BR">
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
<title>Questionário</title>

<meta name="viewport" content="width=device-width">
<link href="estilo.css" rel="stylesheet" type="text/css" media="all">
<? if(isset($_POST["fontsz"])) echo '<style media="screen" type="text/css"> #geral { font-size: ' . $_POST["fontsz"] . " }</style>"; ?>

<script src="funcoes.js" type="text/javascript"></script>

</head>
<body>

<?php
   include "continua.php";
?>


<div id="geral">

<p><span style="color:red">ATENÇÃO: Nenhuma informação será armazenada porque a coleta de dados já foi encerrada!</span></p>


<form name="Qform" action="quest03.php" method="post">

<input type="hidden" name="tempo2" value="<?php echo date("Y-m-d H:i:s");?>">
<input type="hidden" id="fontsz" name="fontsz" value="<? echo $_POST["fontsz"] ?>">
<input type="hidden" id="formtrat" name="formtrat" value="<? echo $formtrat ?>">


<h2>Valores sociais e políticos (continuação)</h2>

<h3>Situações especiais</h3>

<hr>

<p>Agora, em relação às mesmas situações, gostaria de saber
sua opinião sobre quantos de cada 10 brasileiros tomariam as atitudes listadas
a seguir:</p>

<input type="hidden" name="A198" value="NA">
<input type="hidden" name="A199" value="NA">
<input type="hidden" name="A200" value="NA">
<input type="hidden" name="A201" value="NA">

<p><a id="A198"></a> Pedir benefícios do governo sem ter direito:</p>

<div class="temumdez">
<table class="umdez">
   <tr>
      <td colspan=11>
         <table class="cabecalho">
            <tr>
               <td class="esq">Nenhum</td>
               <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
               <td class="dir">Todos</td>
            </tr>
         </table>
      </td>
   </tr>
   <tr><td>0</td><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td></tr>
   <tr>
      <td><input type="radio" name="A198" onClick="ck('tA198'); va('A199')" value="0"></td>
      <td><input type="radio" name="A198" onClick="ck('tA198'); va('A199')" value="1"></td>
      <td><input type="radio" name="A198" onClick="ck('tA198'); va('A199')" value="2"></td>
      <td><input type="radio" name="A198" onClick="ck('tA198'); va('A199')" value="3"></td>
      <td><input type="radio" name="A198" onClick="ck('tA198'); va('A199')" value="4"></td>
      <td><input type="radio" name="A198" onClick="ck('tA198'); va('A199')" value="5"></td>
      <td><input type="radio" name="A198" onClick="ck('tA198'); va('A199')" value="6"></td>
      <td><input type="radio" name="A198" onClick="ck('tA198'); va('A199')" value="7"></td>
      <td><input type="radio" name="A198" onClick="ck('tA198'); va('A199')" value="8"></td>
      <td><input type="radio" name="A198" onClick="ck('tA198'); va('A199')" value="9"></td>
      <td><input type="radio" name="A198" onClick="ck('tA198'); va('A199')" value="10"></td>
   </tr>
</table>
</div>

<p><a id="A199"></a> Evitar pagar passagem em transporte público:</p>

<div class="temumdez">
<table class="umdez">
   <tr>
      <td colspan=11>
         <table class="cabecalho">
            <tr>
               <td class="esq">Nenhum</td>
               <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
               <td class="dir">Todos</td>
            </tr>
         </table>
      </td>
   </tr>
   <tr><td>0</td><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td></tr>
   <tr>
      <td><input type="radio" name="A199" onClick="ck('tA199'); va('A200')" value="0"></td>
      <td><input type="radio" name="A199" onClick="ck('tA199'); va('A200')" value="1"></td>
      <td><input type="radio" name="A199" onClick="ck('tA199'); va('A200')" value="2"></td>
      <td><input type="radio" name="A199" onClick="ck('tA199'); va('A200')" value="3"></td>
      <td><input type="radio" name="A199" onClick="ck('tA199'); va('A200')" value="4"></td>
      <td><input type="radio" name="A199" onClick="ck('tA199'); va('A200')" value="5"></td>
      <td><input type="radio" name="A199" onClick="ck('tA199'); va('A200')" value="6"></td>
      <td><input type="radio" name="A199" onClick="ck('tA199'); va('A200')" value="7"></td>
      <td><input type="radio" name="A199" onClick="ck('tA199'); va('A200')" value="8"></td>
      <td><input type="radio" name="A199" onClick="ck('tA199'); va('A200')" value="9"></td>
      <td><input type="radio" name="A199" onClick="ck('tA199'); va('A200')" value="10"></td>
   </tr>
</table>
</div>

<p><a id="A200"></a> Não pagar impostos se tiver a chance:</p>

<div class="temumdez">
<table class="umdez">
   <tr>
      <td colspan=11>
         <table class="cabecalho">
            <tr>
               <td class="esq">Nenhum</td>
               <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
               <td class="dir">Todos</td>
            </tr>
         </table>
      </td>
   </tr>
   <tr><td>0</td><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td></tr>
   <tr>
      <td><input type="radio" name="A200" onClick="ck('tA200'); va('A201')" value="0"></td>
      <td><input type="radio" name="A200" onClick="ck('tA200'); va('A201')" value="1"></td>
      <td><input type="radio" name="A200" onClick="ck('tA200'); va('A201')" value="2"></td>
      <td><input type="radio" name="A200" onClick="ck('tA200'); va('A201')" value="3"></td>
      <td><input type="radio" name="A200" onClick="ck('tA200'); va('A201')" value="4"></td>
      <td><input type="radio" name="A200" onClick="ck('tA200'); va('A201')" value="5"></td>
      <td><input type="radio" name="A200" onClick="ck('tA200'); va('A201')" value="6"></td>
      <td><input type="radio" name="A200" onClick="ck('tA200'); va('A201')" value="7"></td>
      <td><input type="radio" name="A200" onClick="ck('tA200'); va('A201')" value="8"></td>
      <td><input type="radio" name="A200" onClick="ck('tA200'); va('A201')" value="9"></td>
      <td><input type="radio" name="A200" onClick="ck('tA200'); va('A201')" value="10"></td>
   </tr>
</table>
</div>

<p><a id="A201"></a> Aceitar suborno para cumprir seu dever:</p>

<div class="temumdez">
<table class="umdez">
   <tr>
      <td colspan=11>
         <table class="cabecalho">
            <tr>
               <td class="esq">Nenhum</td>
               <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
               <td class="dir">Todos</td>
            </tr>
         </table>
      </td>
   </tr>
   <tr><td>0</td><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td></tr>
   <tr>
      <td><input type="radio" name="A201" onClick="ck('tA201'); va('pjust')" value="0"></td>
      <td><input type="radio" name="A201" onClick="ck('tA201'); va('pjust')" value="1"></td>
      <td><input type="radio" name="A201" onClick="ck('tA201'); va('pjust')" value="2"></td>
      <td><input type="radio" name="A201" onClick="ck('tA201'); va('pjust')" value="3"></td>
      <td><input type="radio" name="A201" onClick="ck('tA201'); va('pjust')" value="4"></td>
      <td><input type="radio" name="A201" onClick="ck('tA201'); va('pjust')" value="5"></td>
      <td><input type="radio" name="A201" onClick="ck('tA201'); va('pjust')" value="6"></td>
      <td><input type="radio" name="A201" onClick="ck('tA201'); va('pjust')" value="7"></td>
      <td><input type="radio" name="A201" onClick="ck('tA201'); va('pjust')" value="8"></td>
      <td><input type="radio" name="A201" onClick="ck('tA201'); va('pjust')" value="9"></td>
      <td><input type="radio" name="A201" onClick="ck('tA201'); va('pjust')" value="10"></td>
   </tr>
</table>
</div>

<p>&nbsp;</p>

<a id="pjust"></a>
<h3>Pessoas justas e injustas</h3>

<hr>
<input type="hidden" name="J1a" value="NA">
<input type="hidden" name="J1b" value="NA">
<input type="hidden" name="J1c" value="NA">
<input type="hidden" name="J1d" value="NA">

<p>De uma maneira geral, de cada 10 pessoas que são honestas e que não tentam
levar vantagem sobre as outras, quantas <? echo $tm ?> acha que agem assim
porque:</p>

<p><a id="J1a"></a> São bondosas:</p>
<div class="temumdez">
<table class="umdez">
   <tr>
      <td colspan=11>
         <table class="cabecalho">
            <tr>
               <td class="esq">Nenhuma</td>
               <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
               <td class="dir">Todas</td>
            </tr>
         </table>
      </td>
   </tr>
   <tr><td>0</td><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td></tr>
   <tr>
      <td><input type="radio" name="J1a" onClick="ck('tJ1a'); va('J1b')" value="0"></td>
      <td><input type="radio" name="J1a" onClick="ck('tJ1a'); va('J1b')" value="1"></td>
      <td><input type="radio" name="J1a" onClick="ck('tJ1a'); va('J1b')" value="2"></td>
      <td><input type="radio" name="J1a" onClick="ck('tJ1a'); va('J1b')" value="3"></td>
      <td><input type="radio" name="J1a" onClick="ck('tJ1a'); va('J1b')" value="4"></td>
      <td><input type="radio" name="J1a" onClick="ck('tJ1a'); va('J1b')" value="5"></td>
      <td><input type="radio" name="J1a" onClick="ck('tJ1a'); va('J1b')" value="6"></td>
      <td><input type="radio" name="J1a" onClick="ck('tJ1a'); va('J1b')" value="7"></td>
      <td><input type="radio" name="J1a" onClick="ck('tJ1a'); va('J1b')" value="8"></td>
      <td><input type="radio" name="J1a" onClick="ck('tJ1a'); va('J1b')" value="9"></td>
      <td><input type="radio" name="J1a" onClick="ck('tJ1a'); va('J1b')" value="10"></td>
   </tr>
</table>
</div>

<p><a id="J1b"></a> Se sentiriam culpadas se fossem injustas:</p>

<div class="temumdez">
<table class="umdez">
   <tr>
      <td colspan=11>
         <table class="cabecalho">
            <tr>
               <td class="esq">Nenhuma</td>
               <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
               <td class="dir">Todas</td>
            </tr>
         </table>
      </td>
   </tr>
   <tr><td>0</td><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td></tr>
   <tr>
      <td><input type="radio" name="J1b" onClick="ck('tJ1b'); va('J1c')" value="0"></td>
      <td><input type="radio" name="J1b" onClick="ck('tJ1b'); va('J1c')" value="1"></td>
      <td><input type="radio" name="J1b" onClick="ck('tJ1b'); va('J1c')" value="2"></td>
      <td><input type="radio" name="J1b" onClick="ck('tJ1b'); va('J1c')" value="3"></td>
      <td><input type="radio" name="J1b" onClick="ck('tJ1b'); va('J1c')" value="4"></td>
      <td><input type="radio" name="J1b" onClick="ck('tJ1b'); va('J1c')" value="5"></td>
      <td><input type="radio" name="J1b" onClick="ck('tJ1b'); va('J1c')" value="6"></td>
      <td><input type="radio" name="J1b" onClick="ck('tJ1b'); va('J1c')" value="7"></td>
      <td><input type="radio" name="J1b" onClick="ck('tJ1b'); va('J1c')" value="8"></td>
      <td><input type="radio" name="J1b" onClick="ck('tJ1b'); va('J1c')" value="9"></td>
      <td><input type="radio" name="J1b" onClick="ck('tJ1b'); va('J1c')" value="10"></td>
   </tr>
</table>
</div>

<p><a id="J1c"></a> Se preocupam com o que as pessoas pensam sobre delas:</p>

<div class="temumdez">
<table class="umdez">
   <tr>
      <td colspan=11>
         <table class="cabecalho">
            <tr>
               <td class="esq">Nenhuma</td>
               <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
               <td class="dir">Todas</td>
            </tr>
         </table>
      </td>
   </tr>
   <tr><td>0</td><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td></tr>
   <tr>
      <td><input type="radio" name="J1c" onClick="ck('tJ1c'); va('J1d')" value="0"></td>
      <td><input type="radio" name="J1c" onClick="ck('tJ1c'); va('J1d')" value="1"></td>
      <td><input type="radio" name="J1c" onClick="ck('tJ1c'); va('J1d')" value="2"></td>
      <td><input type="radio" name="J1c" onClick="ck('tJ1c'); va('J1d')" value="3"></td>
      <td><input type="radio" name="J1c" onClick="ck('tJ1c'); va('J1d')" value="4"></td>
      <td><input type="radio" name="J1c" onClick="ck('tJ1c'); va('J1d')" value="5"></td>
      <td><input type="radio" name="J1c" onClick="ck('tJ1c'); va('J1d')" value="6"></td>
      <td><input type="radio" name="J1c" onClick="ck('tJ1c'); va('J1d')" value="7"></td>
      <td><input type="radio" name="J1c" onClick="ck('tJ1c'); va('J1d')" value="8"></td>
      <td><input type="radio" name="J1c" onClick="ck('tJ1c'); va('J1d')" value="9"></td>
      <td><input type="radio" name="J1c" onClick="ck('tJ1c'); va('J1d')" value="10"></td>
   </tr>
</table>
</div>

<p><a id="J1d"></a> Têm medo de ser punidas:</p>

<div class="temumdez">
<table class="umdez">
   <tr>
      <td colspan=11>
         <table class="cabecalho">
            <tr>
               <td class="esq">Nenhuma</td>
               <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
               <td class="dir">Todas</td>
            </tr>
         </table>
      </td>
   </tr>
   <tr><td>0</td><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td></tr>
   <tr>
      <td><input type="radio" name="J1d" onClick="ck('tJ1d'); va('J2')" value="0"></td>
      <td><input type="radio" name="J1d" onClick="ck('tJ1d'); va('J2')" value="1"></td>
      <td><input type="radio" name="J1d" onClick="ck('tJ1d'); va('J2')" value="2"></td>
      <td><input type="radio" name="J1d" onClick="ck('tJ1d'); va('J2')" value="3"></td>
      <td><input type="radio" name="J1d" onClick="ck('tJ1d'); va('J2')" value="4"></td>
      <td><input type="radio" name="J1d" onClick="ck('tJ1d'); va('J2')" value="5"></td>
      <td><input type="radio" name="J1d" onClick="ck('tJ1d'); va('J2')" value="6"></td>
      <td><input type="radio" name="J1d" onClick="ck('tJ1d'); va('J2')" value="7"></td>
      <td><input type="radio" name="J1d" onClick="ck('tJ1d'); va('J2')" value="8"></td>
      <td><input type="radio" name="J1d" onClick="ck('tJ1d'); va('J2')" value="9"></td>
      <td><input type="radio" name="J1d" onClick="ck('tJ1d'); va('J2')" value="10"></td>
   </tr>
</table>
</div>


<p>&nbsp;</p>
<a id="J2"></a>
<hr>

<p>Com que frequência <? echo $tm ?> acha
que consegue saber se uma pessoa desconhecida está querendo levar
vantagem sobre <? echo $tm ?>?</p>

<input type="hidden" name="J2" value="NR">

<p>
<label><input type="radio" name="J2" onClick="ck('tJ2'); va('J3')" value="Nunca"> Nunca tenho certeza sobre as intenções da pessoa</label><br>
<label><input type="radio" name="J2" onClick="ck('tJ2'); va('J3')" value="Às vezes"> Às vezes sei quando a pessoa está mal intencionada</label><br>
<label><input type="radio" name="J2" onClick="ck('tJ2'); va('J3')" value="Quase sempre"> Quase sempre sei quando a pessoa está mal intencionada</label><br>
<label><input type="radio" name="J2" onClick="ck('tJ2'); va('J3')" value="Sempre"> Sempre sei quando a pessoa está mal intencionada</label></p>

<p>&nbsp;</p>
<a id="J3"></a>
<hr>
<p>O que lhe ajuda a saber se uma
pessoa está mal intencionada? <span class="inst">(pode marcar mais de uma)</span></p>

<input type="hidden" name="J3coe" value="Não">
<input type="hidden" name="J3fal" value="Não">
<input type="hidden" name="J3ves" value="Não">
<input type="hidden" name="J3idd" value="Não">

<p>
<label><input type="checkbox" name="J3coe" value="Sim"> A coerência do que ela diz</label><br>
<label><input type="checkbox" name="J3fal" value="Sim"> A forma de falar</label><br>
<label><input type="checkbox" name="J3ves" value="Sim"> A forma de se vestir</label><br>
<label><input type="checkbox" name="J3idd" value="Sim"> A idade da pessoa</label></p>

<p>&nbsp;</p>


<h3>Participação</h3>
<hr>
<p>Agora, gostaria que <? echo
$tm ?> olhasse o quadro abaixo com algumas formas de atuação política que as
pessoas podem ter e gostaria que dissesse se já fez alguma dessas coisas, se
poderia vir a fazer ou se não faria nunca.</p>

<input type="hidden" name="V96a" value="NR">
<input type="hidden" name="V96" value="NR">
<input type="hidden" name="V97" value="NR">
<input type="hidden" name="V98" value="NR">
<input type="hidden" name="V98a" value="NR">
<input type="hidden" name="V98b" value="NR">

<p>Assinar uma petição pela internet.</p>
<label><input type="radio" name="V96a" onClick="ck('tV96a'); va('V96')" value="Já fiz">Já fiz</label><br>
<label><input type="radio" name="V96a" onClick="ck('tV96a'); va('V96')" value="Poderia fazer">Poderia fazer</label><br>
<label><input type="radio" name="V96a" onClick="ck('tV96a'); va('V96')" value="Não faria nunca">Não faria nunca</label><br>

<p>Assinar um abaixo-assinado.</p>
<label><input type="radio" name="V96" onClick="ck('tV96'); va('V97')" value="Já fiz">Já fiz</label><br>
<label><input type="radio" name="V96" onClick="ck('tV96'); va('V97')" value="Poderia fazer">Poderia fazer</label><br>
<label><input type="radio" name="V96" onClick="ck('tV96'); va('V97')" value="Não faria nunca">Não faria nunca</label><br>


<p><a id="V97"></a>Participar de boicotes.</p>
<label><input type="radio" name="V97" onClick="ck('tV97'); va('V98')" value="Já fiz">Já fiz</label><br>
<label><input type="radio" name="V97" onClick="ck('tV97'); va('V98')" value="Poderia fazer">Poderia fazer</label><br>
<label><input type="radio" name="V97" onClick="ck('tV97'); va('V98')" value="Não faria nunca">Não faria nunca</label><br>


<p><a id="V98"></a>Participar de manifestações pacíficas.</p>
<label><input type="radio" name="V98" onClick="ck('tV98'); va('V98a')" value="Já fiz">Já fiz</label><br>
<label><input type="radio" name="V98" onClick="ck('tV98'); va('V98a')" value="Poderia fazer">Poderia fazer</label><br>
<label><input type="radio" name="V98" onClick="ck('tV98'); va('V98a')" value="Não faria nunca">Não faria nunca</label><br>


<p><a id="V98a"></a>Participar de passeatas.</p>
<label><input type="radio" name="V98a" onClick="ck('tV98a'); va('V98b')" value="Já fiz">Já fiz</label><br>
<label><input type="radio" name="V98a" onClick="ck('tV98a'); va('V98b')" value="Poderia fazer">Poderia fazer</label><br>
<label><input type="radio" name="V98a" onClick="ck('tV98a'); va('V98b')" value="Não faria nunca">Não faria nunca</label><br>


<p><a id="V98b"></a>Participar de greves.</p>
<label><input type="radio" name="V98b" onClick="ck('tV98b'); va('oPart')" value="Já fiz">Já fiz</label><br>
<label><input type="radio" name="V98b" onClick="ck('tV98b'); va('oPart')" value="Poderia fazer">Poderia fazer</label><br>
<label><input type="radio" name="V98b" onClick="ck('tV98b'); va('oPart')" value="Não faria nunca">Não faria nunca</label><br>

<a id="oPart"></a>
<p>Outra forma de participação:
<input name="V99" type="text" OnKeyPress="return event.keyCode != 13;"></p>

<p>&nbsp;</p>
<hr>

<p><? echo $ti ?> participa
voluntariamente, sem receber remuneração, de organizações recreativas,
esportivas ou artísticas como uma das listadas abaixo?
<span class="inst">(pode marcar mais de um)</span></p>

<input type="hidden" value="Não" name="A1esp">
<input type="hidden" value="Não" name="A1art">
<input type="hidden" value="Não" name="A1mus">
<input type="hidden" value="Não" name="A1igr">
<input type="hidden" value="NA" name="A1nao">

<p>
<label><input type="checkbox" name="A1esp" value="Sim"> Fã clube esportivo</label><br>
<label><input type="checkbox" name="A1art" value="Sim"> Fã clube de artista</label><br>
<label><input type="checkbox" name="A1mus" value="Sim"> Grupo de canto coral, banda de música ou semelhante</label><br>
<label><input type="checkbox" name="A1igr" value="Sim"> Grupo de igreja</label><br>
<label><input type="checkbox" name="A1nao" value="Não participa"> Não participa</label><br>
Outra atividade: <input type="text" name="A1o" OnKeyPress="return event.keyCode != 13;"></p>

<p>&nbsp;</p>
<hr>
<p><? echo $ti ?> tem participação
ativa em alguma organização que defende os interesses de um grupo de pessoas,
como uma das listadas abaixo? <span class="inst">(pode marcar mais de um)</span></p>

<input type="hidden" value="Não" name="A2sin">
<input type="hidden" value="Não" name="A2prt">
<input type="hidden" value="Não" name="A2ass">
<input type="hidden" value="NA" name="A2nao">

<p>
<label><input type="checkbox" name="A2sin" value="Sim"> Sindicato ou Conselho de profissionais</label><br>
<label><input type="checkbox" name="A2prt" value="Sim"> Partido político</label><br>
<label><input type="checkbox" name="A2ass" value="Sim"> Associação de moradores ou de comunidade</label><br>
<label><input type="checkbox" name="A2nao" value="Não participa"> Não participa</label><br>
Outra organização: <input type="text" name="A2o" OnKeyPress="return event.keyCode != 13;"></p>

<p>&nbsp;</p>

<h3><a id="rel"></a>Religiosidade</h3>
<hr>

<p><? echo $ti ?> pertence a alguma religião ou grupo religioso? Se sim,
qual?</p>

<input type="hidden" name="V185" value="NR">

<label><input type="radio" name="V185" value="Sem religião" onClick="ck('tV185'); va('V186')">Não pertence a nenhuma religião ou grupo religioso</label><br>
<label><input type="radio" name="V185" value="Católico" onClick="ck('tV185'); va('V186')">Católico Romano</label><br>
<label><input type="radio" name="V185" value="Evangélico" onClick="ck('tV185'); document.getElementById('evan').style.display = 'block'">Evangélico</label><br>
<div id="evan" style="padding-left: 2em; display:none">
   <label><input type="radio" name="V185" value="Ev.: Assembleia de Deus" onClick="ck('tV185'); va('V186')">Assembleia de Deus</label><br>
   <label><input type="radio" name="V185" value="Ev.: Batista" onClick="ck('tV185'); va('V186')">Batista</label><br>
   <label><input type="radio" name="V185" value="Ev.: Adventista" onClick="ck('tV185'); va('V186')">Adventista</label><br>
   <label><input type="radio" name="V185" value="Ev.: Congr. Cristã no Brasil" onClick="ck('tV185'); va('V186')">Congregação Cristã no Brasil</label><br>
   <label><input type="radio" name="V185" value="Ev.: I. U. do Reino de Deus" onClick="ck('tV185'); va('V186')">Igreja Universal do Reino de Deus</label><br>
   <label><input type="radio" name="V185" value="Ev.: Evangelho Quadrangular" onClick="ck('tV185'); va('V186')">Evangelho Quadrangular</label><br>
   <label><input type="radio" name="V185" value="Ev.: Luterano" onClick="ck('tV185'); va('V186')">Luterano</label><br>
   <label><input type="radio" name="V185" value="Ev.: Deus é Amor" onClick="ck('tV185'); va('V186')">Deus é Amor</label><br>
   <label><input type="radio" name="V185" value="Ev.: Presbiteriano" onClick="ck('tV185'); va('V186')">Presbiteriano</label><br>
   <label><input type="radio" name="V185" value="Ev.: Metodista" onClick="ck('tV185'); va('V186')">Metodista</label><br>
   <label><input type="radio" name="V185" value="Ev.: Congregacional" onClick="ck('tV185'); va('V186')">Congregacional</label><br>
   <label><input type="radio" name="V185" value="Ev.: Maranata" onClick="ck('tV185'); va('V186')">Maranata</label><br>
   <label><input type="radio" name="V185" value="Ev.: O Brasil para Cristo" onClick="ck('tV185'); va('V186')">O Brasil para Cristo</label><br>
   &nbsp;&nbsp;&nbsp;&nbsp;Outra: <input type="text" name="V185eo" OnKeyPress="return event.keyCode != 13;" onFocus="limparRadio('V185')">
</div>
<label><input type="radio" name="V185" value="Espírita" onClick="ck('tV185'); va('V186')">Espírita</label><br>
<label><input type="radio" name="V185" value="Africana" onClick="ck('tV185'); va('V186')">Religiões de origem africana (umbanda, candomblé etc.)</label><br>
<label><input type="radio" name="V185" value="Judeu" onClick="ck('tV185'); va('V186')">Judeu</label><br>
<label><input type="radio" name="V185" value="Mulçumano" onClick="ck('tV185'); va('V186')">Muçulmano</label><br>
&nbsp;&nbsp;&nbsp;&nbsp;Outra: <input type="text" name="V185o" OnKeyPress="return event.keyCode != 13;" onFocus="limparRadio('V185')">

<p>&nbsp;</p>
<a id="V186"></a>
<hr>

<p>Sem contar com casamentos e
funerais, com que frequência <? echo $tm ?> participa de atividades religiosas
atualmente?</p>

<input type="hidden" name="V186" value="NR">

<label><input type="radio" name="V186" onClick="ck('tV186'); va('V187')" value="Mais de uma vez por semana">Mais de uma vez por semana</label><br>
<label><input type="radio" name="V186" onClick="ck('tV186'); va('V187')" value="Semanalmente">Uma vez por semana</label><br>
<label><input type="radio" name="V186" onClick="ck('tV186'); va('V187')" value="Quinzenalmente">Quinzenalmente</label><br>
<label><input type="radio" name="V186" onClick="ck('tV186'); va('V187')" value="Mensalmente">Uma vez por mês</label><br>
<label><input type="radio" name="V186" onClick="ck('tV186'); va('V187')" value="Em dias santos">Somente nos dias santos</label><br>
<label><input type="radio" name="V186" onClick="ck('tV186'); va('V187')" value="Anualmente">Uma vez ao ano</label><br>
<label><input type="radio" name="V186" onClick="ck('tV186'); va('V187')" value="Raramente">Muito raramente</label><br>
<label><input type="radio" name="V186" onClick="ck('tV186'); va('V187')" value="Nunca">Nunca ou praticamente nunca</label>

<p>&nbsp;</p>
<a id="V187"></a>
<hr>
<p>Independente de participar de eventos religiosos, <? echo $tm ?> se
considera:</p>

<input type="hidden" name="V187a" value="NR">

<label><input type="radio" name="V187a" onClick="ck('tV187a'); va('V187b')" value="Religiosa">Uma pessoa religiosa</label><br>
<label><input type="radio" name="V187a" onClick="ck('tV187a'); va('V187b')" value="Não religiosa">Uma pessoa que não é religiosa</label><br>

<p>&nbsp;</p>
<a id="V187b"></a>
<hr>

<p>E <? echo $tm ?> é:</p>

<input type="hidden" name="V187b" value="NR">

<label><input type="radio" name="V187b" onClick="ck('tV187b'); va('foninf')" value="Deísta">Uma pessoa que acredita em Deus</label><br>
<label><input type="radio" name="V187b" onClick="ck('tV187b'); va('foninf')" value="Ateia">Uma pessoa que não acredita em Deus</label>

<p>&nbsp;</p>

<a id="foninf"></a>
<h3>Fontes de informação</h3>
<hr>

<p> As pessoas usam diferentes fontes para se
informar sobre o que está acontecendo no Brasil e no mundo. Para cada uma das
seguintes fontes, indique se a usou semana passada ou não para obter
informação. <span class="inst">(pode marcar mais de um)</span></p>

<input type="hidden" name="V223" value="Não">
<input type="hidden" name="V224" value="Não">
<input type="hidden" name="V225" value="Não">
<input type="hidden" name="V226" value="Não">
<input type="hidden" name="V227" value="Não">
<input type="hidden" name="V228" value="Não">
<input type="hidden" name="V229" value="Não">

<label><input type="checkbox" name="V223" value="Sim"> Jornal impresso</label><br>
<label><input type="checkbox" name="V224" value="Sim"> Jornais de TV ou rádio</label><br>
<label><input type="checkbox" name="V225" value="Sim"> Revistas</label><br>
<label><input type="checkbox" name="V226" value="Sim"> Programas de rádio ou TV</label><br>
<label><input type="checkbox" name="V227" value="Sim"> Livros</label><br>
<label><input type="checkbox" name="V228" value="Sim"> Internet e e-mail (correio eletrônico)</label><br>
<label><input type="checkbox" name="V229" value="Sim"> Conversas com amigos ou colegas</label><br>

<p>&nbsp;</p>
<hr>

<p>Com que frequência <? echo $tm ?> usa computador?</p>

<input type="hidden" name="V230" value="NR">

<p><label><input type="radio" name="V230" onClick="ck('tV230'); document.getElementById('temperf').style.display = 'none'; va('FF')" value="Nunca">Nunca</label><br>
<label><input type="radio" name="V230" onClick="ck('tV230'); document.getElementById('temperf').style.display = 'block'; va('FF')" value="Raramente">Raramente</label><br>
<label><input type="radio" name="V230" onClick="ck('tV230'); document.getElementById('temperf').style.display = 'block'; va('FF')" value="Frequentemente">Frequentemente</label></p>

<p>&nbsp;</p>
<a id="FF"></a>
<hr>

<div id="temperf">
<p> <? echo $ti ?> possui perfil em uma das redes
sociais listadas abaixo? <span class="inst">(pode marcar
mais de um)</span></p>

<input type="hidden" name="F1" value="Não">
<input type="hidden" name="F2" value="Não">
<input type="hidden" name="F3" value="Não">
<input type="hidden" name="F4a" value="Não">
<input type="hidden" name="F4b" value="Não">
<input type="hidden" name="F5" value="NA">

<p>
<label><input type="checkbox" name="F1" value="Sim"> Facebook</label><br>
<label><input type="checkbox" name="F2" value="Sim"> Orkut</label><br>
<label><input type="checkbox" name="F3" value="Sim"> Twitter</label><br>
<label><input type="checkbox" name="F4a" value="Sim"> Skype</label><br>
<label><input type="checkbox" name="F4b" value="Sim"> MSN</label><br>
<label><input type="checkbox" name="F5" value="Não possui"> Não possui</label></p>
</div>


<input type="hidden" id="tA198" name="tA198" value="NA">
<input type="hidden" id="tA199" name="tA199" value="NA">
<input type="hidden" id="tA200" name="tA200" value="NA">
<input type="hidden" id="tA201" name="tA201" value="NA">
<input type="hidden" id="tJ1a" name="tJ1a" value="NA">
<input type="hidden" id="tJ1b" name="tJ1b" value="NA">
<input type="hidden" id="tJ1c" name="tJ1c" value="NA">
<input type="hidden" id="tJ1d" name="tJ1d" value="NA">
<input type="hidden" id="tJ2" name="tJ2" value="NA">
<input type="hidden" id="tV96a" name="tV96a" value="NA">
<input type="hidden" id="tV96" name="tV96" value="NA">
<input type="hidden" id="tV97" name="tV97" value="NA">
<input type="hidden" id="tV98" name="tV98" value="NA">
<input type="hidden" id="tV98a" name="tV98a" value="NA">
<input type="hidden" id="tV98b" name="tV98b" value="NA">
<input type="hidden" id="tV185" name="tV185" value="NA">
<input type="hidden" id="tV186" name="tV186" value="NA">
<input type="hidden" id="tV187a" name="tV187a" value="NA">
<input type="hidden" id="tV187b" name="tV187b" value="NA">
<input type="hidden" id="tV230" name="tV230" value="NA">

<p style="text-align:center"><input type="submit" style="font-weight:bold;" value="Enviar e Continuar"></p>

</form>

</div>

<!--
<script language='JavaScript' type='text/javascript'> retirarNumQuest(); </script>
-->

</body>
</html>
