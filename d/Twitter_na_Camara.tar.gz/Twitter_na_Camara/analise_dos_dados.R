# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#                                                                             #
# Este script reproduz os gráficos, as tabelas e mais algumas informações do  #
# artigo:                                                                     #
#                                                                             #
#     PARLAMENTARES, REPRESENTAÇÃO POLÍTICA E REDES SOCIAIS DIGITAIS:         #
#             Perfis de uso do Twitter na Câmara dos Deputados                #
#                                                                             #
#                 Francisco Paulo Jamil Almeida Marques                       #
#                         Jakson Alves de Aquino                              #
#                               Edna Miola                                    #
#                                                                             #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #


options(OutDec = ",")
library(descr)
library(gdata)
library(memisc)


###############################################################################
##  I - Manipulação dos dados
###############################################################################

# Mudanças de endereço durante o período de coleta de dados:
atualizarTwitter <- function(x)
{
    x <- sub("^BrunaFurlan_$",     "DepBrunaFurlan",   x)
    x <- sub("^erundinapsb$",      "luiza_erundina",   x)
    x <- sub("^deputadoamauri$",   "SouMaisAmauri",    x)
    x <- sub("^acmneto_$",         "acmneto_25",       x)
    x <- sub("^acmnetodeputado$",  "acmneto_25",       x)
    x <- sub("^BrunaFurlan_$",     "DepBrunaFurlan",   x)
    x <- sub("^dpmarciomarinho$",  "soumarinho10",     x)
    x <- sub("^VOLTAJAIRO$",       "JAIROPREFEITO25",  x)
    x <- sub("^depcarlinhos$",     "carlinhos13sjc",   x)
    x <- sub("^CELIAROCHA_AL$",    "CELIAROCHA14",     x)
    x <- sub("^eholandajunior$",   "edvaldoholandaj",  x)
    x <- sub("^depgeorgehilton$",  "GEORGEHILTON10",   x)
    x <- sub("^deputadogilmar$",   "GilmarMachado_",   x)
    x <- sub("^DepJairoAtaide$",   "VOLTAJAIRO",       x)
    x <- sub("^depjoaopaulo$",     "JoaoPauloPT13",    x)
    x <- sub("^deplelocoimbra$",   "lelocoimbra_",     x)
    x <- sub("^dep_Setim$",        "Setim25",          x)
    x <- sub("^lfmfederal$",       "lfm45",            x)
    x <- sub("^erundinapsb$",      "luiza_erundina",   x)
    x <- sub("^dep_paulinho$",     "paulinhopdt12",    x)
    x <- sub("^DeputadoRomero$",   "Romero45CG",       x)
    x <- sub("^teresasurita$",     "TeresaSurita15",   x)
    x <- sub("^Dep_Zoinho$",       "Zoinho__22",       x)
    x <- sub("^pedrotaques123$",   "PedroTaquesMT",    x)
    x <- sub("^vanessasenadora$",  "vanessaprefeita",  x)
    x <- sub("^moka_senador$",     "Senador_Moka",     x)
    x
}

xx <- list()
lf <- c("tp_2012-02-23.csv", "tp_2012-03-01.csv", "tp_2012-03-08.csv",
        "tp_2012-03-15.csv", "tp_2012-03-22.csv", "tp_2012-03-29.csv",
        "tp_2012-04-07.csv", "tp_2012-04-12.csv", "tp_2012-04-19.csv",
        "tp_2012-04-26.csv", "tp_2012-05-03.csv", "tp_2012-05-10.csv",
        "tp_2012-05-17.csv", "tp_2012-05-24.csv", "tp_2012-05-31.csv",
        "tp_2012-06-07.csv", "tp_2012-06-14.csv", "tp_2012-06-21.csv",
        "tp_2012-06-28.csv", "tp_2012-07-05.csv")
for(f in lf){
    x <- read.csv2(paste0("dados_Twitter/", f), stringsAsFactors = FALSE)
    x$listed <- NULL
    x$friends <- NULL
    x$favourites <- NULL
    nome <- sub("tp_(.*)\\.csv", "\\1", f)
    xx[[nome]] <- x
}

aaa <- function(x)
{
    x$endereco <- atualizarTwitter(as.character(x$endereco))
    x
}
xx <- lapply(xx, aaa)

# Renomear variáveis para possibilitar o merge().
aaa <- function(x, n)
{
    n <- gsub("-", ".", n)
    colnames(x) <- paste0(names(x), n)
    colnames(x) <- sub("endereco.*", "endereco", names(x))
    x
}
len <- length(xx)
for(i in 1:len){
    xx[[i]] <- aaa(xx[[i]], names(xx)[i])
}

# Juntar bancos
st <- xx[[1]]
for(i in 2:len){
    st <- merge(st, xx[[i]], all = TRUE)
}
rm(lf, f, nome, len, aaa, i, x, xx)




tab <- read.table("parlamentares.csv", sep = "\t", header = TRUE, quote = "", comment.char = "")
tab$sexo <- reorder.factor(tab$sexo, new.order = c(2, 1))
dim(tab)[1] # Número de parlamentares: senadores + deputados
tab <- tab[tab$endereco != "-2", ]
dim(tab)[1] # Número de parlamentares que possuíam conta no Twitter
# Eliminar senadores manter apenas deputados no banco de dados:
tab <- tab[tab$casa == "Câmara dos Deputados", ]
dim(tab)[1]
tab$endereco <- atualizarTwitter(as.character(tab$endereco))

tmp <- tab$endereco
tab <- merge(tab, st)
dim(tab)[1] # Conferir se não houve alteração no número de linhas
nomes4 <- paste(tmp[!(tmp %in% tab$endereco)], collapse = ", ")
nomes4

removerAcentos <- function(x)
{
    x <- gsub("Á", "A", x)
    x <- gsub("É", "E", x)
    x <- gsub("Í", "I", x)
    x <- gsub("Ó", "O", x)
    x <- gsub("Ú", "U", x)
    x <- gsub("Â", "A", x)
    x <- gsub("Ê", "E", x)
    x <- gsub("Ô", "O", x)
    x <- gsub("Ã", "A", x)
    x <- gsub("Õ", "O", x)
    x <- gsub("Ü", "U", x)
    x <- gsub("Ç", "C", x)
}

tab$nome.unico <- paste0(as.character(tab$uf), ":", toupper(tab$nome.civil))
tab$nome.unico <- removerAcentos(tab$nome.unico)

load("props.RData")
votos$nome.unico <- removerAcentos(votos$nome.unico)
props$nome.unico <- removerAcentos(sub("^...", "", rownames(props)))


# Produzir tabela com parlamentares não identificados (se houver algum)
tmp <- tab$nome.unico

# Adicionar números de votos dos parlamentares:
tab <- merge(tab, votos)
dim(tab)[1]

# Continuação da produção de tabela com parlamentares não identificados
nomes5 <- tmp[!(tmp %in% tab$nome.unico)]
nomes5 # É para estar vazio

# Adicionar proporções ponderadas de "eleitores" com nível superior, residindo
# em zona urbana e sua média de renda
tab <- merge(tab, props, all.x = TRUE)
dim(tab)[1] # Não deve alterar o número de linhas

# Verificar se algum parlamentar ficou sem as proporções calculadas:
sum(is.na(tab$propsup))
sum(is.na(tab$propurb))
sum(is.na(tab$rendamd))

# Chamaremos de "b" o banco de dados final:
b <- tab

###############################################################################
##  II - Análise dos dados
###############################################################################

# Número de parlamentares no banco de dados:
nrow(b)


b$nome <- as.character(b$nome)
b$cargo <- as.character(b$cargo.funcao)
b$cargo.funcao <- NULL
b$cargo[b$cargo != "Não"] <- "Possui"
b$cargo[b$cargo == "Não"] <- "Não possui"
b$cargo <- as.factor(b$cargo)

# Cálculo da tuitagem semanal
tw <- b[, grep("statuses", names(b))]
len <- dim(tw)[2]
tw2 <- tw[, 2:len]
len <- len - 1
tw1 <- tw[, 1:len]
tw <- tw2 - tw1
names(tw) <- sub("statuses", "tuitagem", names(tw))

# Lista de deputados que em algum momento tiveram redução na contagens de
# tweets:
negdep <- b$endereco[apply(tw, 1, function(x) any(x < 0, na.rm = TRUE))]
negdep

tw[tw < 0] <- NA
twm <- apply(tw, 1, mean, na.rm = TRUE)
b <- cbind(b, tw, twm)
dias <- names(b)[grep("tuitagem", names(b))]
dias <- sub("tuitagem2012.", "", dias)
dias <- sub("(..)\\.(..)", "\\2/\\1", dias)
rm(votos, props, tw, tw1, tw2, len)

# Corrigir um valor NA em followers2012.07.05:
b$followers2012.07.05[is.na(b$followers2012.07.05)] <- b$followers2012.06.28[is.na(b$followers2012.07.05)]

b$logvotos <- log(b$votos)
b$logtwm <- log(b$twm + 1)
b$logfol <- log(b$followers2012.07.05 + 1)
b$idade <- 2012 - b$ano.de.nascimento
b <- droplevels(b)

#############################################
## Variáveis dependentes

# Parlamentares com maior número de postagens:
bn <- b[order(b$statuses2012.07.05, decreasing = TRUE), c("nome", "partido", "statuses2012.07.05")]
bn <- bn[1:10, ]
cat(paste0(bn$nome, " (", bn$partido, ", ", format(bn$statuses2012.07.05, big.mark = "."), ")"), sep = "\n")


# Parlamentares com maior número de seguidores:
bn <- b[order(b$followers2012.07.05, decreasing = TRUE), c("nome", "partido", "followers2012.07.05")]
bn <- bn[1:10, ]
cat(paste0(bn$nome, " (", bn$partido, ", ", format(bn$followers2012.07.05, big.mark = "."), ")"), sep = "\n")


# Parlamentares com maior tuitagem:
bn <- b[order(b$twm, decreasing = TRUE), c("nome", "partido", "twm")]
bn <- bn[1:10, ]
cat(paste0(bn$nome, " (", bn$partido, ", ", round(bn$twm), ")"), sep = "\n")

# Número de Deputados com menos de 60 seguidores:
sum(b$followers2012.07.05 < 60)


# Tabela 1: Sumário das variáveis dependentes",
summary(b$followers2012.07.05)
summary(b$twm)

# Correlação entre tuitagem e seguidores:
cor(b$twm, b$followers2012.07.05)


#############################################
## Sexo e idade

# Deputadas com maior tuitagem:
bn <- b[b$sexo == "f", c("nome", "partido", "twm")]
bn <- bn[order(bn$twm, decreasing = TRUE), ]
bn <- bn[1:10, ]
cat(paste0(bn$nome, " (", bn$partido, ", ", round(bn$twm), ")"), sep = "\n")

# Deputadas com maior número de seguidores:
bn <- b[b$sexo == "f", c("nome", "partido", "followers2012.07.05")]
bn <- bn[order(bn$followers2012.07.05, decreasing = TRUE), ]
bn <- bn[1:10, ]
cat(paste0(bn$nome, " (", bn$partido, ", ", format(bn$followers2012.07.05, big.mark = "."), ")"), sep = "\n")

# Deputadas com maior número de postagens:
bn <- b[b$sexo == "f", c("nome", "partido", "statuses2012.07.05")]
bn <- bn[order(bn$statuses2012.07.05, decreasing = TRUE), ]
bn <- bn[1:10, ]
cat(paste0(bn$nome, " (", bn$partido, ", ", format(bn$statuses2012.07.05, big.mark = "."), ")"), sep = "\n")

# Figura 1: Logaritmos da média da tuitagem semanal e do número de seguidores
# de acordo com o sexo do parlamentar:
png(filename = "Fig_1_bxSx.png", height=2.3, width=6, units="in", res=300)
par(mfrow = c(1, 2), cex = 0.8, mar = c(2.1, 4.1, 1.1, 2))
compmeans(b$logtwm, b$sexo, col = "lightgray", xlab = "", ylab = "log(tuitagem)")
compmeans(b$logfol, b$sexo, col = "lightgray", xlab = "", ylab = "log(seguidores)")
dev.off()

t.test(b$twm[b$sexo == "m"], b$twm[b$sexo == "f"]) 
t.test(b$followers2012.07.05[b$sexo == "m"], b$followers2012.07.05[b$sexo == "f"]) 
t.test(b$logtwm[b$sexo == "m"], b$logtwm[b$sexo == "f"]) 
t.test(b$logfol[b$sexo == "m"], b$logfol[b$sexo == "f"]) 

# Tabela 2: Média e mediana da tuitagem média segundo o sexo
x <- cbind(tapply(b$twm, b$sexo, mean),
           tapply(b$twm, b$sexo, median))
colnames(x) <- c("média", "mediana")
x

# Tabela 2: Média e mediana do número de seguidores segundo o sexo
x <- cbind(tapply(b$followers2012.07.05, b$sexo, mean),
           tapply(b$followers2012.07.05, b$sexo, median))
colnames(x) <- c("média", "mediana")
x

# Tabela 2: Média e mediana do logaritmo da tuitagem média segundo o sexo
x <- cbind(tapply(b$logtwm, b$sexo, mean),
           tapply(b$logtwm, b$sexo, median))
colnames(x) <- c("média", "mediana")
x

# Tabela 2: Média e mediana do logaritmo do número de seguidores segundo o sexo
x <- cbind(tapply(b$logfol, b$sexo, mean),
           tapply(b$logfol, b$sexo, median))
colnames(x) <- c("média", "mediana")
x

# Significância estatística da correlação entre idade e tuitagem e número de
# seguidores.
summary(lm(logtwm ~ idade, data = b))
summary(lm(logfol ~ idade, data = b))

# Figura 2: Logaritmos da média da tuitagem semanal e do número de seguidores
# segundo a idade do parlamentar
png(filename = "Fig_2_dispTwIdd.png", height = 2.5, width = 6, units='in', res=300)
par(mfrow = c(1, 2), cex = 0.8)
par(mar = c(4, 4, 0, 1.5) + 0.2)
plot(b$logtwm ~ b$idade, xlab = "Idade", ylab = "Média da tuitagem (log)")
abline(lm(b$logtwm ~ b$idade))
text(80, 6, labels = paste0("r = ", format(cor(b$logtwm, b$idade), digits = 2)))
par(mar = c(4, 5.5, 0, 0) + 0.2)
plot(b$logfol ~ b$idade, xlab = "Idade", ylab = "Seguidores (log)")
abline(lm(b$logfol ~ b$idade))
text(80, 12.5, labels = paste0("r = ", format(cor(b$logfol, b$idade, use = "complete.obs"), digits = 2)))
dev.off()


#########################################################
## Cargos de liderança no âmbito da Câmara dos Deputados

# Tabela 3: Média da tuitagem semanal e do número de seguidores segundo o partido
x <- cbind(compmeans(b$twm, b$partido, plot = FALSE),
           compmeans(b$followers2012.07.05, b$partido, plot = FALSE))
x <- x[order(x[, 4], decreasing = TRUE), c(2, 1, 4)]
colnames(x) <- c("N", "Tuitagem", "Seguidores")
x

# Tabela 4: Média e mediana da tuitagem média segundo o cargo
x <- cbind(tapply(b$twm, b$cargo, mean),
           tapply(b$twm, b$cargo, median))
colnames(x) <- c("média", "mediana")
x

# Tabela 4: Média e mediana do número de seguidores segundo o cargo
x <- cbind(tapply(b$followers2012.07.05, b$cargo, mean),
           tapply(b$followers2012.07.05, b$cargo, median))
colnames(x) <- c("média", "mediana")
x

# Tabela 4: Média e mediana do logaritmo da tuitagem média segundo o cargo
x <- cbind(tapply(b$logtwm, b$cargo, mean),
           tapply(b$logtwm, b$cargo, median))
colnames(x) <- c("média", "mediana")
x

# Tabela 4: Média e mediana do logaritmo do número de seguidores segundo o cargo
x <- cbind(tapply(b$logfol, b$cargo, mean),
           tapply(b$logfol, b$cargo, median))
colnames(x) <- c("média", "mediana")
x

# Figura 3: Logaritmos da média da tuitagem semanal e do número de seguidores
# segundo o cargo ou função
png(filename = "Fig_3_bxCarg.png", height=2.4, width=6, units='in', res=300)
par(mfrow = c(1, 2), cex = 0.8, mar = c(2.1, 4.1, 1.1, 2))
compmeans(b$logtwm, b$cargo, col = "lightgray", xlab = "", ylab = "log(tuitagem)")
compmeans(b$logfol, b$cargo, col = "lightgray", xlab = "", ylab = "log(seguidores)")
dev.off()

t.test(b$logtwm[b$cargo == "Não possui"], b$logtwm[b$cargo == "Possui"]) 
t.test(b$logfol[b$cargo == "Não possui"], b$logfol[b$cargo == "Possui"]) 

# Maiores usuários do Twitter ordenados pela tuitagem
bn <- b[, c("nome", "partido", "cargo", "twm", "followers2012.07.05")]
bn <- bn[order(bn$twm, decreasing = TRUE), ]
bn <- bn[1:20, ]
levels(bn$cargo) <- sub("Não possui cargo", "Não", levels(bn$cargo))
levels(bn$cargo) <- sub("Possui cargo", "Sim", levels(bn$cargo))
bn$twm <- round(bn$twm)
names(bn) <- c("Nome", "Partido", "Cargo", "Tuitagem", "Seguidores")
bn


#########################################################
## Número de votos e características do eleitorado

# Figura 4: Logaritmos da média da tuitagem semanal e do número de seguidores
# segundo o logaritmo do número de votos do deputado
png(filename="Fig_4_Votos.png", height = 2.5, width = 6, units='in', res=300)
par(mfrow = c(1, 2), cex = 0.8)
par(mar = c(4, 4, 0, 1.5) + 0.2)
plot(b$logtwm ~ b$votos, xlim = c(0, 700000),  xlab = "Votos", ylab = "Média da tuitagem (log)", xaxt = "n")
axis(1, at = c(0, 300000, 600000), labels = c("0", "300.000", "600.000"))
abline(lm(b$logtwm ~ b$votos))
text(350000, 6, labels = paste0("r = ", format(cor(b$logtwm, b$votos), digits = 2)))
par(mar = c(4, 5.5, 0, 0) + 0.2)
plot(b$logfol ~ b$votos, xlim = c(0, 700000), xlab = "Votos", ylab = "Seguidores (log)", xaxt = "n")
axis(1, at = c(0, 300000, 600000), labels = c("0", "300.000", "600.000"))
abline(lm(b$logfol ~ b$votos))
text(350000, 12.5, labels = paste0("r = ", format(cor(b$logfol, b$votos, use = "complete.obs"), digits = 2)))
dev.off()

summary(lm(logtwm ~ votos, data = b))
summary(lm(logfol ~ votos, data = b))

# Figura 5: Logaritmos da média da tuitagem semanal e do número de seguidores
# segundo a renda média do eleitorado ponderada pela votação do deputado
png(filename = "Fig_5_rendamedia.png", height = 2.5, width = 6, units='in', res=300)
par(mfrow = c(1, 2), cex = 0.8)
par(mar = c(4, 4, 0, 1.5) + 0.2)
plot(b$logtwm ~ b$rendamd, xlab = "Renda do eleitorado", ylab = "Média da tuitagem (log)")
abline(lm(b$logtwm ~ b$rendamd))
text(1500, 6, labels = paste0("r = ", round(cor(b$logtwm, b$rendamd), digits = 2)))
par(mar = c(4, 4, 0, 1.5) + 0.2)
plot(b$logfol ~ b$rendamd, xlab = "Renda do eleitorado", ylab = "Seguidores (log)")
abline(lm(b$logfol ~ b$rendamd))
text(2200, 12.5, labels = paste0("r = ", round(cor(b$logfol, b$rendamd, use = "complete.obs"), digits = 2)))
dev.off()

summary(lm(b$logtwm ~ b$rendamd))
summary(lm(b$logfol ~ b$rendamd))

# Figura 6: Logaritmos da média da tuitagem semanal e do número de seguidores
# de acordo com a proporção do eleitorado urbano ponderada pela votação do
# deputado
png(filename = "Fig_6_propurb.png", height = 2.5, width = 6, units='in', res=300)
par(mfrow = c(1, 2), cex = 0.8)
par(mar = c(4, 4, 0, 1.5) + 0.2)
plot(b$logtwm ~ b$propurb, xlab = "Eleitorado urbano", ylab = "Média da tuitagem (log)")
abline(lm(b$logtwm ~ b$propurb))
text(0.75, 6, labels = paste0("r = ", format(cor(b$logtwm, b$propurb), digits = 2)))
par(mar = c(4, 4, 0, 1.5) + 0.2)
plot(b$logfol ~ b$propurb, xlab = "Eleitorado urbano", ylab = "Seguidores (log)")
abline(lm(b$logfol ~ b$propurb))
text(0.75, 12.5, labels = paste0("r = ", format(cor(b$logfol, b$propurb, use = "complete.obs"), digits = 2)))
dev.off()

summary(lm(b$logtwm ~ b$propurb))
summary(lm(b$logfol ~ b$propurb))

# Figura 7: Logaritmos da média da tuitagem semanal e do número de seguidores
# segundo a proporção do eleitorado com escolaridade de nível superior
# ponderada pela votação do deputado
png(filename = "Fig_7_propsup.png", height = 2.5, width = 6, units='in', res=300)
par(mfrow = c(1, 2), cex = 0.8)
par(mar = c(4, 4, 0, 1.5) + 0.2)
plot(b$logtwm ~ b$propsup, xlab = "Escolaridade superior",
     ylab = "Média da tuitagem (log)")
abline(lm(b$logtwm ~ b$propsup))
text(0.11, 6, labels = paste0("r = ", format(cor(b$logtwm, b$propsup), digits = 2)))
par(mar = c(4, 4, 0, 1.5) + 0.2)
plot(b$logfol ~ b$propsup, xlab = "Escolaridade superior", ylab = "Seguidores (log)")
abline(lm(b$logfol ~ b$propsup))
text(0.06, 12.5, labels = paste0("r = ", format(cor(b$logfol, b$propsup, use = "complete.obs"), digits = 2)))
dev.off()

summary(lm(b$logtwm ~ b$propsup))
summary(lm(b$logfol ~ b$propsup))

# Criar banco de dados com as variáveis a serem usadas nas análises de
# regressão padronizadas de modo a ficarem com média 0 e desvio padrão 1:
b2 <- b
b2$logtwm <- scale(b$logtwm)[, ]
b2$logfol <- scale(b$logfol)[, ]
b2$idade <- scale(b$idade)[, ]
b2$votos <- scale(b$votos)[, ]
b2$rendamd <- scale(b$rendamd)[, ]
b2$propsup <- scale(b$propsup)[, ]
b2$propurb <- scale(b$propurb)[, ]
b2$cargo <- scale(as.numeric(b$cargo == "Possui"))
b2$sexo <- scale(as.numeric(b$sexo == "f"))

# Regressões:
T1 <- lm(logtwm ~ idade + sexo + cargo + votos + rendamd + propsup + propurb, data = b2)
T2 <- lm(logtwm ~ idade + cargo + votos + rendamd + propsup, data = b2)
S1 <- lm(logfol ~ idade + sexo + cargo + votos + rendamd + propsup + propurb, data = b2)
S2 <- lm(logfol ~ idade + cargo + votos + rendamd + propsup, data = b2)


# Tabela 6: Sumários de regressões, tendo o logaritmo da média da tuitagem
# semanal e o logaritmo do número de seguidores como variáveis dependentes
mtable(T1, T2, S1, S2)



# Lista de deputados que são lideranças e têm mais de 10.000 seguidores
bn <- b[b$cargo == "Possui" & b$followers2012.07.05 > 10000, c("nome", "followers2012.07.05", "twm")]
bn <- bn[order(bn$twm), ]
bn$twm <- round(bn$twm, 2)
bn

