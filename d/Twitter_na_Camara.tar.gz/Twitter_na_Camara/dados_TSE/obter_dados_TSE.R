library(memisc)
library(descr)

# Baixar dados do TSE:
for(uf in c("AC", "AL", "AM", "AP", "BA", "CE", "DF", "ES", "GO", "MA", "MG",
            "MS", "MT", "PA", "PB", "PE", "PI", "PR", "RJ", "RN", "RO", "RR",
            "RS", "SC", "SE", "SP", "TO")){
    if(!file.exists(paste0("vmz_candidato_", uf, ".zip")))
       download.file(paste0("http://agencia.tse.jus.br/estatistica/sead/eleicoes/eleicoes2010/vmz_candidato_", uf, ".zip"), 
                     paste0("vmz_candidato_", uf, ".zip"))
}

# Descompactar os arquivos ZIP num diretório temporário:
dir.create("/tmp/br2010")
for(uf in c("AC", "AL", "AM", "AP", "BA", "CE", "DF", "ES", "GO", "MA", "MG",
            "MS", "MT", "PA", "PB", "PE", "PI", "PR", "RJ", "RN", "RO", "RR",
            "RS", "SC", "SE", "SP", "TO")){
    if(file.exists(paste0("vmz_candidato_", uf, ".zip")))
        unzip(paste0("vmz_candidato_", uf, ".zip"), exdir = "/tmp/br2010")
}

# Criar o banco de dados no formato CSV com dados das eleições de todo o país. 
system("./criarCSV.sh")

e <- read.table("/tmp/brasil_2010.csv", sep = ";", header = TRUE, quote = "", as.is = TRUE, stringsAsFactors = FALSE)
e$muni <- toUTF8(e$muni)
e$nome.urna <- toUTF8(e$nome.urna)
e$nome <- toUTF8(e$nome)
e$uf.muni <- paste(e$uf, e$muni, sep = ":")
e$uf.muni <- factor(e$uf.muni)

# Adicionar o código do IBGE dos estados brasileiros:
e$cod.uf <- memisc::recode(e$uf,
                   "12" <- "AC",
                   "27" <- "AL",
                   "13" <- "AM",
                   "16" <- "AP",
                   "29" <- "BA",
                   "23" <- "CE",
                   "53" <- "DF",
                   "32" <- "ES",
                   "52" <- "GO",
                   "21" <- "MA",
                   "31" <- "MG",
                   "50" <- "MS",
                   "51" <- "MT",
                   "15" <- "PA",
                   "25" <- "PB",
                   "26" <- "PE",
                   "22" <- "PI",
                   "41" <- "PR",
                   "33" <- "RJ",
                   "24" <- "RN",
                   "11" <- "RO",
                   "14" <- "RR",
                   "43" <- "RS",
                   "42" <- "SC",
                   "28" <- "SE",
                   "35" <- "SP",
                   "17" <- "TO")
e$cod.uf <- as.numeric(as.character(e$cod.uf))


# O arquivo cod_muni_TSE_IBGE.csv contém os códigos do IBGE para os
# municípios brasileiros. Vamos adicionar esses códigos aos dados do TSE:
cod <- read.table("cod_muni_TSE_IBGE.csv", sep = "\t", header = TRUE,
                  stringsAsFactors = FALSE)

names(cod) <- c("cod.muni", "cod.ibge", "uf.ibge", "muni.ibge")

e <- merge(e, cod, all.x = TRUE)

# Os códigos de alguns municípios estão faltando em cod_muni_TSE_IBGE.csv:
e$cod.ibge[e$uf == "DF" & e$muni == "BRASÍLIA"] <- 5300108
e$cod.ibge[e$uf == "PI" & e$muni == "AROEIRAS DO ITAIM"] <- 2200954
e$cod.ibge[e$uf == "BA" & e$muni == "ÉRICO CARDOSO"] <- 2900504
e$cod.ibge[e$uf == "PE" & e$muni == "FERNANDO DE NORONHA"] <- 2605459
e$cod.ibge[e$uf == "MS" & e$muni == "FIGUEIRÃO"] <- 5003900
e$cod.ibge[e$uf == "MT" & e$muni == "IPIRANGA DO NORTE"] <- 5104526
e$cod.ibge[e$uf == "MT" & e$muni == "ITANHANGÁ"] <- 5104542
# e$cod.ibge[e$uf == "PA" & e$muni == "MOJUÍ DOS CAMPOS"] <- 
e$cod.ibge[e$uf == "PI" & e$muni == "NAZÁRIA"] <- 2206720
# e$cod.ibge[e$uf == "MS" & e$muni == "PARAÍSO DAS ÁGUAS"] <- 
e$cod.ibge[e$uf == "BA" & e$muni == "PINDAÍ"] <- 2924504
e$cod.ibge[e$uf == "MT" & e$muni == "SÃO JOSÉ DOS QUATRO MARCOS"] <- 5107107

# Paraíso das Águas (MS) foi criado em 2009 e Mojuí dos Campos (PA) em
# 2012. Eles não estavam no Censo de 2010.
print(levels(droplevels(e$uf.muni[is.na(e$cod.ibge)])))

save(e, file = "brasil_2010.RData")

