# O objetivo deste script é extrair da Amostra do Censo de 2010 do IBGE os
# dados das variáveis que serão úteis no artigo.

# Os dados usados no artigo foram obtidos no dia 6 de agosto de 2012 de
# ftp://ftp.ibge.gov.br/Censos/Censo_Demografico_2010/Resultados_Gerais_da_Amostra/Microdados

library(bit64)
library(data.table)

# Documentação dos dados:
if(!file.exists("Documentacao.zip"))
    download.file("ftp://ftp.ibge.gov.br/Censos/Censo_Demografico_2010/Resultados_Gerais_da_Amostra/Microdados/Documentacao.zip", 
                  "Documentacao.zip")

# Arquivos a serem baixados:
for(uf in c("AC.zip", "AP.zip", "DF.zip", "MA.zip", "MT.zip", "PE.zip",
            "RJ.zip", "RR.zip", "SE.zip", "TO.zip", "AL.zip", "BA.zip",
            "ES.zip", "MG.zip", "PA.zip", "PI.zip", "RN.zip", "RS.zip",
            "SP1.zip", "AM.zip", "CE.zip", "GO.zip", "MS.zip", "PB.zip",
            "PR.zip", "RO.zip", "SC.zip", "SP2-RM.zip"))
    if(!file.exists(uf))
        download.file(paste0("ftp://ftp.ibge.gov.br/Censos/Censo_Demografico_2010/Resultados_Gerais_da_Amostra/Microdados/", uf),
                      uf)

dir.create("/tmp/censo2010")
extrairDados <- function(nome, numero, compl = "")
{
    arq <- paste0(nome, ".zip")
    if(!file.exists(arq))
        stop(paste("Arquivo não encontrado:", arq))
    unzip(arq, paste0(nome, "/Pessoas/Amostra_Pessoas_", numero, compl, ".txt"), exdir = "/tmp/censo2010", junkpaths = TRUE)
}

extrairDados("AC", 12)
extrairDados("AL", 27)
extrairDados("AM", 13)
extrairDados("AP", 16)
extrairDados("BA", 29)
extrairDados("CE", 23)
extrairDados("DF", 53)
extrairDados("ES", 32)
extrairDados("GO", 52)
extrairDados("MA", 21)
extrairDados("MG", 31)
extrairDados("MS", 50)
extrairDados("MT", 51)
extrairDados("PA", 15)
extrairDados("PB", 25)
extrairDados("PE", 26)
extrairDados("PI", 22)
extrairDados("PR", 41)
extrairDados("RJ", 33)
extrairDados("RN", 24)
extrairDados("RO", 11)
extrairDados("RR", 14)
extrairDados("RS", 43)
extrairDados("SC", 42)
extrairDados("SE", 28)
extrairDados("SP1", 35, "_outras")
extrairDados("SP2-RM", 35, "_RMSP")
extrairDados("TO", 17)

# Concatenar colunas relevantes de todos os arquivos (pode demorar alguns minutos):
system("./criarCSV.sh")

br <- fread(paste0("/tmp/censo_brasil_2010.csv"), header = TRUE, sep = ";")

br$sexo <- factor(br$sexo, levels = c(1, 2), labels = c("Masculino", "Feminino"))
br$urb <- factor(br$urb, levels = c(1, 2), labels = c("Urbana", "Rural"))
br$instr <- factor(br$instr, levels = c(1, 2, 3, 4, 5),
                   labels = c("Sem instrução e fundamental incompleto", "Fundamental completo e médio incompleto",
                              "Médio completo e superior incompleto", "Superior completo", "Não determinado"))

br$peso <- br$peso / 10000000000000

br$muni <- paste0(br$uf, gsub(" ", "0", format(br$muni, width = 5)))

br <- br[br$idade > 16 & br$idade < 80, ]
gc()

br$muni <- as.factor(br$muni)
b <- split(br, br$muni)

calcProp <- function(x)
{
    p <- x$instr == "Superior completo"
    p[is.na(p)] <- FALSE
    p <- as.numeric(p)
    p <- p * x$peso
    sum(p) / sum(x$peso)
}
propsup <- sapply(b, calcProp)

calcProp <- function(x)
{
    p <- x$urb == "Urbana"
    p[is.na(p)] <- FALSE
    p <- as.numeric(p)
    p <- p * x$peso
    sum(p) / sum(x$peso)
}
propurb <- sapply(b, calcProp)

calcRendaMed <- function(x)
{
    x <- x[!is.na(x$renda), ]
    x$renda <- x$renda * x$peso
    sum(x$renda) / sum(x$peso)
}
rendamd <- sapply(b, calcRendaMed)


muni <- names(propsup)
uf <- sub("^(..).*", "\\1", muni)
br <- data.frame(uf, muni, propsup, propurb, rendamd)

save(br, file = "censo2010.RData")

