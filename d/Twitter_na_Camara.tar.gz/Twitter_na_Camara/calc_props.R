

load("dados_Censo_2010/censo2010.RData")

# # Eliminar municípios existentes no Censo e inexistentes nos dados do TSE:
br <- br[ br$muni != "2401305" & br$muni != "2516409" & br$muni != "2903300" & br$muni != "2905107" & br$muni != "2919504", ]

brs <- split(br, br$uf, drop = TRUE)


load("dados_TSE/brasil_2010.RData")
e <- e[e$cargo == "DEPUTADO FEDERAL", ]
votos.uf <- tapply(e$votos, e$uf, sum)
e$nome.unico <- paste(e$uf, e$nome, sep = ":")
votos <- tapply(e$votos, e$nome.unico, sum, na.rm = TRUE)
votos <- data.frame(nome.unico = names(votos), votos = votos, stringsAsFactors = FALSE)
es <- split(e, e$uf, drop = TRUE)

calcProps <- function(elei, censo, uf)
{
    nn <- as.character(censo$muni)
    x <- tapply(elei$votos, list(cod.ibge = as.factor(as.character(elei$cod.ibge)), nome = as.factor(elei$nome.unico)), sum, na.rm = TRUE)
    x[is.na(x)] <- 0
    xp <- prop.table(x, 2)
    ni <- rownames(xp)

    # Identificar municípios que estão no Censo 2010 mas não estão nos dados do TSE:
    i <- 0
    for(n in nn)
        if(length(grep(n, ni)) == 0){
            i <- i + 1
            print(names(censo))
            cat(uf, "::", n, ": ", i, "\n")
        }

    xpp <- xp
    for(n in nn)
        xpp[n, ] <- xpp[n, ] * censo$propsup[censo$muni == n]
    propsup <- apply(xpp, 2, sum)

    xpp <- xp
    for(n in nn)
        xpp[n, ] <- xpp[n, ] * censo$propurb[censo$muni == n]
    propurb <- apply(xpp, 2, sum)

    xpp <- xp
    for(n in nn)
        xpp[n, ] <- xpp[n, ] * censo$rendamd[censo$muni == n]
    rendamd <- apply(xpp, 2, sum)

    list(propsup = propsup, propurb = propurb, rendamd = rendamd)
}

props <- list()
props$AC <- calcProps(es[["AC"]], brs[["12"]], "AC")
props$AL <- calcProps(es[["AL"]], brs[["27"]], "AL")
props$AM <- calcProps(es[["AM"]], brs[["13"]], "AM")
props$AP <- calcProps(es[["AP"]], brs[["16"]], "AP")
props$BA <- calcProps(es[["BA"]], brs[["29"]], "BA")
props$CE <- calcProps(es[["CE"]], brs[["23"]], "CE")
props$DF <- calcProps(es[["DF"]], brs[["53"]], "DF")
props$ES <- calcProps(es[["ES"]], brs[["32"]], "ES")
props$GO <- calcProps(es[["GO"]], brs[["52"]], "GO")
props$MA <- calcProps(es[["MA"]], brs[["21"]], "MA")
props$MG <- calcProps(es[["MG"]], brs[["31"]], "MG")
props$MS <- calcProps(es[["MS"]], brs[["50"]], "MS")
props$MT <- calcProps(es[["MT"]], brs[["51"]], "MT")
props$PA <- calcProps(es[["PA"]], brs[["15"]], "PA")
props$PB <- calcProps(es[["PB"]], brs[["25"]], "PB")
props$PE <- calcProps(es[["PE"]], brs[["26"]], "PE")
props$PI <- calcProps(es[["PI"]], brs[["22"]], "PI")
props$PR <- calcProps(es[["PR"]], brs[["41"]], "PR")
props$RJ <- calcProps(es[["RJ"]], brs[["33"]], "RJ")
props$RN <- calcProps(es[["RN"]], brs[["24"]], "RN")
props$RO <- calcProps(es[["RO"]], brs[["11"]], "RO")
props$RR <- calcProps(es[["RR"]], brs[["14"]], "RR")
props$RS <- calcProps(es[["RS"]], brs[["43"]], "RS")
props$SC <- calcProps(es[["SC"]], brs[["42"]], "SC")
props$SE <- calcProps(es[["SE"]], brs[["28"]], "SE")
props$SP <- calcProps(es[["SP"]], brs[["35"]], "SP")
props$TO <- calcProps(es[["TO"]], brs[["17"]], "TO")

props <- lapply(props, as.data.frame)
props <- do.call("rbind", props)

save(props, votos, votos.uf, file = "props.RData")

