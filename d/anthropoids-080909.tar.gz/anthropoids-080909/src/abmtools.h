#ifndef ABMTOOLS_H
#define ABMTOOLS_H

#ifndef MINGW32
#include <libintl.h>
#include <locale.h>
#define _(String) gettext (String)
#else
#define _(String) (String)
#endif



class Thing
{
  public:
    virtual ~Thing() { }
};

class Eukaryote : public Thing
{
  public:
    virtual void step() { }
};


double getRandDouble(double min, double max);
int getRandInt(int min, int max);
void fatalErr(const char *modulname, int lno, const char *fmt, ...);
void warnMsg(const char *fmt, ...);

// based on swarm code
#define FATALERR( fmt, args...) fatalErr(__FILE__, __LINE__, fmt, ## args)

#endif
