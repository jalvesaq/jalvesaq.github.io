

#include "config.h"
#include <gtkmmconfig.h>
#define GMM_GTKMM_22_24(a,b) b
#include <gtkmm/drawingarea.h>
#include <gtkmm/widget.h>
#include <cairomm/context.h>
#include <gdkmm/general.h>

#include "zoomraster.h"
#include "control.h"
#include "abmtools.h"
#include "Observer.h"

extern bool GUIMode;


ZoomRaster::ZoomRaster(Control *cntrl, Observer *obs, int xsize, int ysize)
{
  control = cntrl;
  observer = obs;
  width = xsize;
  height = ysize;
  zoom = 1;
  minzoom = 1;
  maxzoom = 5;

  // avoid black region if the world is too small
  int w = zoom * width * 5;
  while(w < 220 && zoom < maxzoom){
    zoom++;
    minzoom++;
    w = zoom * width * 5;
  }
  
  add_events(Gdk::EXPOSURE_MASK | Gdk::BUTTON_PRESS_MASK | Gdk::SCROLL_MASK );

  // It's necessary to control the double buffering manually to avoid flickers
  // and to run the simulation faster.
  myRect = new Gdk::Rectangle(0, 0, width * zoom * 5, height * zoom * 5);
  set_double_buffered(false);
}

ZoomRaster::~ZoomRaster()
{
  window->end_paint(); // free the buffer
  delete myRect;
}

void ZoomRaster::setColors()
{
  window = get_window();
  if(window == 0x0){
    GUIMode = false;
    FATALERR("window == NULL : ZoomRaster::setColors");
  }

  window->begin_paint_rect(*myRect); // begin double-buffering
  setNewSize();

  cmap[0].set_rgb_p(0, 0, 0);
  double r, g, b;
  r = 0.787692;
  g = 0.669231;
  b = 0.315385;
  for(int i = 1; i < 11; i++){ // thv: between green and yellow
    cmap[i].set_rgb_p(r, g, b);
    r -= 0.0393846;
    g -= 0.0109231;
    b -= 0.0118462;
  }
  r = 1.0;
  g = 0.0;
  b = 0.0;
  for(int i = 20; i < 30; i++){ // Agents according to sex ratio
    cmap[i].set_rgb_p(r, g, b);
    r -= 0.1;
    b += 0.1;
  }
  r = 1.0;
  g = 1.0;
  b = 1.0;
  for(int i = 30; i < 40; i++){ // Agents according to population density
    cmap[i].set_rgb_p(r, g, b);
    r -= 0.1;
    g -= 0.1;
    b -= 0.05;
  }
  for(int i = 100; i < 120; i++) // Fruits
    cmap[i].set_rgb_p(20.0/(double)(140 - i), 0.6, 0);

  cmap[200].set_rgb_p(0.0, 0.5, 0.0); // Tree - species 0
  cmap[201].set_rgb_p(0.2, 0.4, 0.0); // Tree - species 1
  cmap[202].set_rgb_p(0.3, 0.3, 0.0); // Tree - species 2
  cmap[230].set_rgb_p(1.0, 1.0, 0.0); // Prey
  cmap[250].set_rgb_p(1.0, 1.0, 0.0); // Perimeter
  cmap[255].set_rgb_p(1, 1, 1); // Follow me

  Glib::RefPtr<Gdk::Colormap> colormap = get_default_colormap();
  for(int i = 0; i < 256; i++)
    colormap->alloc_color(cmap[i]);

  window->set_background(cmap[0]);
  gc_ = Gdk::GC::create(window);
}


bool ZoomRaster::on_expose_event(GdkEventExpose* e)
{
  observer->drawWorld();
  return true;
}

void ZoomRaster::setNewSize()
{
  int w, h;
  w = zoom * width * 5;
  h = 38 + (zoom * height * 5);
  myRect->set_width(w);
  myRect->set_height(h-38);
  control->resize(w, h);
  observer->drawWorld();
}

bool ZoomRaster::on_scroll_event(GdkEventScroll* e)
{
  if(e->direction){
    if(zoom < maxzoom){
      zoom++;
      setNewSize();
    }
  } else {
    if(zoom > minzoom){
      zoom--;
      setNewSize();
    }
  }
  return true;
}

bool ZoomRaster::on_button_press_event(GdkEventButton* e)
{
  int bx = (int)e->x;
  int by = (int)e->y;
  int button = (int)e->button;
  switch(button){
    case 1:
    case 2:
      bx = bx / (5 * zoom);
      by = by / (5 * zoom);
      observer->cellClicked(button, bx, by);
      break;
    case 3:
      observer->showPopDensity();
      observer->drawWorld();
      break;
    default:
      fprintf(stderr, "Unknow mouse button: %d\n", button);
  }
  return true;
}

void ZoomRaster::drawLine(int x0, int y0, int x1, int y1, int color)
{
  int X0, Y0, X1, Y1;
  X0 = x0 * zoom;
  Y0 = y0 * zoom;
  X1 = x1 * zoom;
  Y1 = y1 * zoom;
  gc_->set_foreground(cmap[color]);
  window->draw_line(gc_, X0, Y0, X1, Y1);
}

void ZoomRaster::fillRectangle(int x, int y, int w, int h, int color)
{
  int X, Y, W, H;
  X = x * zoom;
  Y = y * zoom;
  W = w * zoom;
  H = h * zoom;
  gc_->set_foreground(cmap[color]);
  window->draw_rectangle(gc_, 1, X, Y, W, H);
}

void ZoomRaster::clearCanvas()
{
  int W, H;
  W = width * zoom * 5;
  H = height * zoom * 5;
  gc_->set_foreground(cmap[0]);
  window->draw_rectangle(gc_, 1, 0, 0, W, H);
  drawSelf();
}

void ZoomRaster::drawSelf()
{
  window->end_paint(); // copy the buffer to the real canvas
  window->begin_paint_rect(*myRect); // begin double-buffering
}

void ZoomRaster::savePNG()
{
  static int i = 1;
  Glib::RefPtr<Gdk::Pixbuf> pxb;
  pxb = Gdk::Pixbuf::create(static_cast< Glib::RefPtr<Gdk::Drawable> >(window), 0, 0, get_width(), get_height());
  char str[64];
  sprintf(str, "world_%d.png", i);
  pxb->save(str, "png");
  i++;
}

