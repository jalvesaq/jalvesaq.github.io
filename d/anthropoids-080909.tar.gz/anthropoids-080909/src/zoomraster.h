
#ifndef ZOOMRASTER_HH
#define ZOOMRASTER_HH

#include <gtkmm/window.h>
#include <gtkmm/drawingarea.h>
#include <gdkmm/rectangle.h>

class Observer;
class Control;

class ZoomRaster : public Gtk::DrawingArea
{
  public:
    ZoomRaster(Control *cntrl, Observer *obs, int xsize, int ysize);
    ~ZoomRaster();
    void setColors();
    void fillRectangle(int x0, int y0, int x1, int y1, int color);
    void drawLine(int x0, int y0, int x1, int y1, int color);
    void clearCanvas();
    void drawSelf();
    void savePNG();

  protected:
    virtual bool on_expose_event(GdkEventExpose* event);
    virtual bool on_button_press_event(GdkEventButton* event);
    virtual bool on_scroll_event(GdkEventScroll* event);

  private:
    int width;
    int height;
    int zoom, minzoom, maxzoom;
    Control *control;
    Observer *observer;
    Glib::RefPtr<Gdk::GC> gc_;
    Gdk::Color cmap[256];
    Gdk::Rectangle *myRect;
    Glib::RefPtr<Gdk::Window> window;
    void setNewSize();
};

#endif
