
#ifndef CONTROL_WINDOW_HH
#define CONTROL_WINDOW_HH

#include <gtkmm/window.h>
#include <gtkmm/tooltips.h>
#include <gtkmm/toolbutton.h>
#include <gtkmm/toolbar.h>
#include <gtkmm/box.h>
#include <gtkmm/main.h>

class Agent;
class ZoomRaster;
class Observer;

class Control : public Gtk::Window
{  
  public:
    Gtk::Tooltips _tooltips;
    Control(Observer *obs, Gtk::Main *m, int xsize, int ysize);
    ~Control();
    ZoomRaster *getZoomRaster();
    void update();

  private:
    Gtk::Main *mainloop;
    Gtk::ToolButton *btRun;
    Gtk::ToolButton *btStep;
    Gtk::ToolButton *btView;
    Gtk::ToolButton *btGraph;
    Gtk::ToolButton *btPict;
    Gtk::ToolButton *btQuit;
    Gtk::Toolbar *toolbar1;
    Gtk::VBox *vbox1;
    ZoomRaster *drWorld;
    Observer *observer;
    bool running;
    bool updateWorld;

    void on_btRun_clicked();
    void on_btStep_clicked();
    void on_btView_clicked();
    void on_btGraph_clicked();
    void on_btPict_clicked();
    void on_btQuit_clicked();
    bool quit(GdkEventAny *ev);
};
#endif
