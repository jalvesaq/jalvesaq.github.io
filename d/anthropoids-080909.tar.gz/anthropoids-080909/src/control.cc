
#include "config.h"
#include <gtkmmconfig.h>
#include <sigc++/compatibility.h>
#define GMM_GTKMM_22_24(a,b) b
#include <gtkmm/accelgroup.h>
#include <gtkmm/image.h>
#include <gtkmm/stockid.h>
#include <gtkmm/drawingarea.h>

#include "control.h"
#include "zoomraster.h"
#include "Observer.h"
#include "Model.h"
#include "abmtools.h"

extern Model *theModel;
extern Observer *theObserver;

Control::Control(Observer *obs, Gtk::Main *m, int xsize, int ysize) : Gtk::Window(Gtk::WINDOW_TOPLEVEL)
{
  observer = obs;
  mainloop = m;
  Gtk::Image *btRun_img = Gtk::manage(new class Gtk::Image(Gtk::StockID("gtk-media-forward"), Gtk::IconSize(3)));
  btRun = Gtk::manage(new class Gtk::ToolButton(*btRun_img, ""));
  Gtk::Image *btStep_img = Gtk::manage(new class Gtk::Image(Gtk::StockID("gtk-media-play"), Gtk::IconSize(3)));
  btStep = Gtk::manage(new class Gtk::ToolButton(*btStep_img, ""));

  const char * world_xpm[] = {
    "24 24 106 2",
    "  	c None",
    ". 	c #C9AB50",
    "+ 	c #B76B58",
    "@ 	c #B1565B",
    "# 	c #BD8056",
    "$ 	c #328B14",
    "% 	c #404040",
    "& 	c #107010",
    "* 	c #207000",
    "= 	c #7F4000",
    "- 	c #876B88",
    "; 	c #71569B",
    "> 	c #9D8076",
    ", 	c #A52B60",
    "' 	c #990066",
    ") 	c #800080",
    "! 	c #206020",
    "~ 	c #406000",
    "{ 	c #FF0000",
    "] 	c #452BC0",
    "^ 	c #1900E6",
    "/ 	c #AE4B5C",
    "( 	c #602060",
    "_ 	c #186818",
    ": 	c #306800",
    "< 	c #BF2000",
    "[ 	c #664BA4",
    "} 	c #452BC1",
    "| 	c #ABA247",
    "1 	c #889C38",
    "2 	c #659628",
    "3 	c #649628",
    "4 	c #649528",
    "5 	c #008000",
    "6 	c #8D9A3E",
    "7 	c #468D1F",
    "8 	c #0E3881",
    "9 	c #1320AC",
    "0 	c #095056",
    "a 	c #97A03C",
    "b 	c #268500",
    "c 	c #999300",
    "d 	c #0C4073",
    "e 	c #338600",
    "f 	c #CC9900",
    "g 	c #0D4073",
    "h 	c #06603A",
    "i 	c #1A8300",
    "j 	c #668C00",
    "k 	c #71559B",
    "l 	c #BAA74C",
    "m 	c #869A3A",
    "n 	c #528E28",
    "o 	c #ABA446",
    "p 	c #A3A341",
    "q 	c #A52B61",
    "r 	c #9C9E42",
    "s 	c #6E9235",
    "t 	c #B2A549",
    "u 	c #C39653",
    "v 	c #C08B54",
    "w 	c #BEA059",
    "x 	c #B39663",
    "y 	c #A88B6C",
    "z 	c #A6A146",
    "A 	c #BFA84D",
    "B 	c #C6AA4F",
    "C 	c #C8A050",
    "D 	c #C4804F",
    "E 	c #776930",
    "F 	c #C3804F",
    "G 	c #B3004C",
    "H 	c #9B883F",
    "I 	c #A09F44",
    "J 	c #B3A449",
    "K 	c #9EA13F",
    "L 	c #B0A646",
    "M 	c #23860F",
    "N 	c #6F8C00",
    "O 	c #1C8300",
    "P 	c #0D7013",
    "Q 	c #33404C",
    "R 	c #266019",
    "S 	c #4C4033",
    "T 	c #395026",
    "U 	c #3E431B",
    "V 	c #DE9900",
    "W 	c #388600",
    "X 	c #1A6026",
    "Y 	c #660099",
    "Z 	c #4D4033",
    "` 	c #43002D",
    " .	c #73204D",
    "..	c #238610",
    "+.	c #A79300",
    "@.	c #2A8500",
    "#.	c #13681D",
    "$.	c #4D2073",
    "%.	c #563839",
    "&.	c #589027",
    "*.	c #559123",
    "=.	c #408D1B",
    "-.	c #809A35",
    ";.	c #538900",
    ">.	c #A69300",
    ",.	c #7D8E00",
    "                                                ",
    "  . . . . + @ # $ % % & * = = $ . . . . - ; >   ",
    "  . . . . , ' @ $ ) ) ! ~ { { $ . . . . ] ^ ;   ",
    "  . . . . / , + $ ( ( _ : < < $ . . . . [ } -   ",
    "  | | | 1 2 2 2 3 4 4 4 5 5 5 $ . . . . . . .   ",
    "  6 6 6 7 8 9 0 a . . . b c c $ - ] [ . . . .   ",
    "  6 6 6 7 9 ^ d a . . . e f f $ ; ^ ] . . . .   ",
    "  6 6 6 7 0 g h a . . . i j j $ > k - . . . .   ",
    "  l l l m n n n o . . . a a a p . . . . . . .   ",
    "  @ ' q r s s s t . . . > ^ ^ . ; ^ ] . . . .   ",
    "  @ ' q r s s s t . . . > ^ ^ . ; ^ } . . . .   ",
    "  u # v r s s s t . . . w > > . x > y . . . .   ",
    "  6 6 6 z A A A B . . . C D D . . . . . . . .   ",
    "  6 6 6 z A E A B . . . F G G . . . . . . . .   ",
    "  6 6 6 z A H A B . . . D G G . . . . . . . .   ",
    "  6 6 6 I J J J K a a a a a a a a a a L . . .   ",
    "  6 6 6 6 6 6 6 M N N O P Q Q 5 R S T 3 . . .   ",
    "  6 6 6 6 6 U 6 M V V W X Y Y 5 Z `  .3 . . .   ",
    "  6 6 6 6 6 6 6 ..+.+.@.#.$.$.5 T  .%.3 . . .   ",
    "  6 6 6 6 6 6 6 &.7 7 7 *.*.*.=.5 5 5 3 . . .   ",
    "  6 6 6 6 6 6 6 6 6 6 6 | | | -.;.>.,.3 . . .   ",
    "  6 6 6 6 6 6 6 6 6 6 6 | | | -.N V >.3 . . .   ",
    "  6 6 6 6 6 6 6 6 6 6 6 | | | -.W N ;.3 . . .   ",
    "                                                "};

  Glib::RefPtr<Gdk::Bitmap> tbIMv;
  Glib::RefPtr<Gdk::Pixmap> tbIPv = Gdk::Pixmap::create_from_xpm(get_default_colormap(), tbIMv, world_xpm);
  Gtk::Image *btView_img = Gtk::manage(new class Gtk::Image(tbIPv, tbIMv));
  btView = Gtk::manage(new class Gtk::ToolButton(*btView_img, ""));

  const char * graph_xpm[] = {
    "24 22 9 1",
    " 	c None",
    ".	c #000000",
    "+	c #FFFFFF",
    "@	c #8080FF",
    "#	c #0000FF",
    "$	c #FF8080",
    "%	c #FF0000",
    "&	c #000080",
    "*	c #800080",
    "........................",
    ".++++++++++++++++++++++.",
    ".++++++++++++++++++++++.",
    ".++++++++++++++++++++++.",
    ".+++++++++++++++++++++@.",
    ".++++++++++++++++++++@#.",
    ".++++++++++++++++++++#@.",
    ".+++++++++++++++++++#@+.",
    ".$$$$$$$+++++++++++@#++.",
    ".%%%%%%%%%$+++++++@#+++.",
    ".+++++++$$%%%$+++@#@+++.",
    ".+++++++++++$%$@##@++++.",
    ".+++++@@@++++@&#*++++++.",
    ".++++#########@$%%+++++.",
    ".++@#@+++++@@++++%%$+++.",
    ".+@#@+++++++++++++$%+++.",
    ".##@+++++++++++++++$%++.",
    ".#++++++++++++++++++%$+.",
    ".++++++++++++++++++++%%.",
    ".+++++++++++++++++++++%.",
    ".++++++++++++++++++++++.",
    "........................"};
  Glib::RefPtr<Gdk::Bitmap> tbIMg;
  Glib::RefPtr<Gdk::Pixmap> tbIPg = Gdk::Pixmap::create_from_xpm(get_default_colormap(), tbIMg, graph_xpm);
  Gtk::Image *btGraph_img = Gtk::manage(new class Gtk::Image(tbIPg, tbIMg));
  btGraph = Gtk::manage(new class Gtk::ToolButton(*btGraph_img, ""));


  const char * photom_xpm[] = {
    "24 24 41 1",
    " 	c None",
    ".	c #B8B8B8",
    "+	c #8E8E80",
    "@	c #F1F1F1",
    "#	c #FFFFFF",
    "$	c #AAAAAA",
    "%	c #E3E3E3",
    "&	c #808080",
    "*	c #555555",
    "=	c #2B3939",
    "-	c #8E8E8E",
    ";	c #717163",
    ">	c #717171",
    ",	c #9CAA9C",
    "'	c #AAB8AA",
    ")	c #AAAA9C",
    "!	c #636363",
    "~	c #718071",
    "{	c #D4D4D4",
    "]	c #9C9C9C",
    "^	c #636355",
    "/	c #637163",
    "(	c #393939",
    "_	c #1C1C1C",
    ":	c #474747",
    "<	c #808E80",
    "[	c #0E0E0E",
    "}	c #0E1C1C",
    "|	c #1C2B2B",
    "1	c #2B2B2B",
    "2	c #474739",
    "3	c #475547",
    "4	c #808071",
    "5	c #556355",
    "6	c #C6C6C6",
    "7	c #555547",
    "8	c #B8B8AA",
    "9	c #8E8080",
    "0	c #E3D4D4",
    "a	c #D4C6C6",
    "b	c #D4D4C6",
    "                        ",
    "                        ",
    "                        ",
    "         .++++.         ",
    "        .+@@@#+$%       ",
    "      &*=+####+=.       ",
    "   -===;$&>>>>>,====&   ",
    "   ='$$$--&&&&&&,)))=   ",
    "   =$>!.$~+>>>;*!>+&=   ",
    "   =$;!${!]--+^**+!>=   ",
    "   =$/!*;-(__:+/*<!>=   ",
    "   =$/!*-([}__:+*&!>=   ",
    "   =$!!!-_}{$|1+*~!>=   ",
    "   =$/!/+__$111<2>!>=   ",
    "   =$/!*-:_|1-3&(!!>=   ",
    "   =$!!*4+:113<(1!~>=   ",
    "  %=)!!!*5>&&^(1*!~;={  ",
    "  6=<-&4>;!*7::;~--&=$% ",
    "  6!================:]% ",
    "  %8-&&&&&&&>>>>>>&9]6  ",
    "    0{a66a{{{{{a6b{0    ",
    "                        ",
    "                        ",
    "                        "};
  Glib::RefPtr<Gdk::Bitmap> tbPm;
  Glib::RefPtr<Gdk::Pixmap> tbPp = Gdk::Pixmap::create_from_xpm(get_default_colormap(), tbPm, photom_xpm);
  Gtk::Image *btPict_img = Gtk::manage(new class Gtk::Image(tbPp, tbPm));
  btPict = Gtk::manage(new class Gtk::ToolButton(*btPict_img, ""));

  Gtk::Image *btQuit_img = Gtk::manage(new class Gtk::Image(Gtk::StockID("gtk-quit"), Gtk::IconSize(3)));
  btQuit = Gtk::manage(new class Gtk::ToolButton(*btQuit_img, ""));
  toolbar1 = Gtk::manage(new class Gtk::Toolbar());
  vbox1 = Gtk::manage(new class Gtk::VBox(false, 0));
  drWorld = Gtk::manage(new class ZoomRaster(this, observer, xsize, ysize));

  toolbar1->append(*btRun);
  toolbar1->append(*btStep);
  toolbar1->append(*btView);
  toolbar1->append(*btGraph);
  toolbar1->append(*btPict);
  toolbar1->append(*btQuit);

  _tooltips.set_tip(*btRun, _("Run"), "");
  btRun->set_visible_horizontal(true);
  btRun->set_visible_vertical(true);
  btRun->set_is_important(false);
  btRun->set_tooltip(_tooltips, _("Run"));
  btRun_img->show();

  _tooltips.set_tip(*btStep, _("Step"), "");
  btStep->set_visible_horizontal(true);
  btStep->set_visible_vertical(true);
  btStep->set_is_important(false);
  btStep->set_tooltip(_tooltips, _("Step"));
  btStep_img->show();

  _tooltips.set_tip(*btView, _("View world"), "");
  btView->set_visible_horizontal(true);
  btView->set_visible_vertical(true);
  btView->set_is_important(false);
  btView->set_tooltip(_tooltips, _("View world"));
  btView_img->show();

  _tooltips.set_tip(*btGraph, _("Run graphics"), "");
  btGraph->set_visible_horizontal(true);
  btGraph->set_visible_vertical(true);
  btGraph->set_is_important(false);
  btGraph->set_tooltip(_tooltips, _("Run graphics"));
  btGraph_img->show();

  _tooltips.set_tip(*btPict, _("Take a picture of the world"), "");
  btPict->set_visible_horizontal(true);
  btPict->set_visible_vertical(true);
  btPict->set_is_important(false);
  btPict->set_tooltip(_tooltips, _("Take a picture"));
  btPict_img->show();

  _tooltips.set_tip(*btQuit, _("Quit"), "");
  btQuit->set_visible_horizontal(true);
  btQuit->set_visible_vertical(true);
  btQuit->set_is_important(false);
  btQuit->set_tooltip(_tooltips, _("Quit"));
  btQuit_img->show();

  toolbar1->set_tooltips(true);
  toolbar1->set_toolbar_style(Gtk::TOOLBAR_ICONS);
  toolbar1->set_orientation(Gtk::ORIENTATION_HORIZONTAL);
  toolbar1->set_show_arrow(true);
  vbox1->pack_start(*toolbar1, Gtk::PACK_SHRINK, 0);
  vbox1->pack_start(*drWorld);

  set_size_request(200, 47);
  set_title(_("Virtual anthropoids"));
  set_modal(false);
  property_window_position().set_value(Gtk::WIN_POS_CENTER);
  set_resizable(true);
  property_destroy_with_parent().set_value(false);
  add(*vbox1);

  resize((5 * xsize), (5 * ysize + 38));

  const char * anthropoids_xpm[] = {
    "32 32 16 1",
    " 	c None",
    ".	c #C9AB50",
    "+	c #008000",
    "@	c #990066",
    "#	c #800080",
    "$	c #FF0000",
    "%	c #1900E6",
    "&	c #8D9A3E",
    "*	c #CC9900",
    "=	c #6E9235",
    "-	c #BFA84D",
    ";	c #B3004C",
    ">	c #000000",
    ",	c #DE9900",
    "'	c #660099",
    ")	c #ABA247",
    "                                ",
    " ..........++++++++++.......... ",
    " ......@@@.+###++$$$+......%%%. ",
    " ......@@@.+###++$$$+......%%%. ",
    " ......@@@.+###++$$$+......%%%. ",
    " ..........++++++++++.......... ",
    " &&&&&+++++.....+++++.......... ",
    " &&&&&+%%%+.....+***+.%%%...... ",
    " &&&&&+%%%+.....+***+.%%%...... ",
    " &&&&&+%%%+.....+***+.%%%...... ",
    " &&&&&+++++.....+++++.......... ",
    " .....=====.................... ",
    " .@@@.=====......%%%..%%%...... ",
    " .@@@.=====......%%%..%%%...... ",
    " .@@@.=====......%%%..%%%...... ",
    " .....=====.................... ",
    " &&&&&-----.................... ",
    " &&&&&-----......;;;........... ",
    " &&&&&-->--......;;;........... ",
    " &&&&&-----......;;;........... ",
    " &&&&&-----.................... ",
    " &&&&&&&&&&+++++++++++++++..... ",
    " &&&&&&&&&&+,,,++'''++@@@+..... ",
    " &&&&&&&>&&+,,,++'''++@>@+..... ",
    " &&&&&&&&&&+,,,++'''++@@@+..... ",
    " &&&&&&&&&&+++++++++++++++..... ",
    " &&&&&&&&&&&&&&&)))))+++++..... ",
    " &&&&&&&&&&&&&&&)))))+,,,+..... ",
    " &&&&&&&&&&&&&&&)))))+,,,+..... ",
    " &&&&&&&&&&&&&&&)))))+,,,+..... ",
    " &&&&&&&&&&&&&&&)))))+++++..... ",
    "                                "};

  set_icon(Gdk::Pixbuf::create_from_xpm_data(anthropoids_xpm));

  btRun->show();
  btStep->show();
  btView->show();
  btGraph->show();
  btPict->show();
  btQuit->show();
  toolbar1->show();
  drWorld->show();
  vbox1->show();
  show();

  btRun->signal_clicked().connect(SigC::slot(*this, &Control::on_btRun_clicked), false);
  btStep->signal_clicked().connect(SigC::slot(*this, &Control::on_btStep_clicked), false);
  btView->signal_clicked().connect(SigC::slot(*this, &Control::on_btView_clicked), false);
  btGraph->signal_clicked().connect(SigC::slot(*this, &Control::on_btGraph_clicked), false);
  btPict->signal_clicked().connect(SigC::slot(*this, &Control::on_btPict_clicked), false);
  btQuit->signal_clicked().connect(SigC::slot(*this, &Control::on_btQuit_clicked), false);
  signal_delete_event().connect(SigC::slot(*this, &Control::quit), false);

  running = false;
  updateWorld = true;
}

Control::~Control()
{
  delete btRun;
  delete btStep;
  delete btView;
  delete btGraph;
  delete btPict;
  delete btQuit;
  delete toolbar1;
  delete vbox1;
}

void Control::update()
{
  while(mainloop->events_pending())
    mainloop->iteration();
}

void Control::on_btRun_clicked()
{  
  if(running)
    return;
  running = true;
  theModel->setStatus(2);
  theModel->go();
}

void Control::on_btStep_clicked()
{  
  theModel->setStatus(1);
  if(running){
    running = false;
  } else{
    theModel->go();
  }
}

void Control::on_btView_clicked()
{  
  if(updateWorld){
    updateWorld = false;
    theObserver->setShowWorld(false);
    drWorld->clearCanvas();
  } else{
    updateWorld = true;
    theObserver->setShowWorld(true);
    theObserver->drawWorld();
  }
}

ZoomRaster *Control::getZoomRaster()
{
  return drWorld;
}

void Control::on_btGraph_clicked()
{  
  theModel->setStatus(3);
  if(!running){
    running = true;
    theModel->go();
  }
}

void Control::on_btPict_clicked()
{  
  if(updateWorld)
    theObserver->saveImg();
  else
    warnMsg(_("The image can be created only if the world is visible."));
}

void Control::on_btQuit_clicked()
{  
  theModel->setStatus(0);
  if(updateWorld)
    theObserver->saveImg();
  hide();
}

bool Control::quit(GdkEventAny *ev) // can't avoid unused parameter ev.
{
  return 0;
}


