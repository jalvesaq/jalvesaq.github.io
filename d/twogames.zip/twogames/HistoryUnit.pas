unit HistoryUnit;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ExtCtrls, StdCtrls;

type
  THistoryForm = class(TForm)
    Label1: TLabel;
    Label2: TLabel;
    CycleLabel: TLabel;
    n_cyclesLabel: TLabel;
    SeeHistoryButton: TButton;
    CheckBox1: TCheckBox;
    CheckBox2: TCheckBox;
    CheckBox3: TCheckBox;
    CheckBox4: TCheckBox;
    CheckBox5: TCheckBox;
    CheckBox6: TCheckBox;
    CheckBox8: TCheckBox;
    Label10: TLabel;
    Label11: TLabel;
    Shape1: TShape;
    CheckBox9: TCheckBox;
    CheckBox10: TCheckBox;
    CheckBox11: TCheckBox;
    CheckBox12: TCheckBox;
    procedure SeeHistoryButtonClick(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  HistoryForm: THistoryForm;

implementation

uses Main, OptionsUnit;

{$R *.DFM}

procedure THistoryForm.SeeHistoryButtonClick(Sender: TObject);
var i, x, y : integer;
begin
with Canvas do
  begin
    Brush.Color := clBlack;
    Pen.Color := clBlack;
    Rectangle(25,96,527,248);
    for i := 1 to (history_index - 1) do
      begin
        x := i + 25;
        if (CheckBox9.Checked = true) and (ca_only = false) then
          begin
            y := 247 - round(150 * history[i,9]);
            Pen.Color := clSilver;
            Ellipse(x,y-1,x+2,y+1);
          end;
        if (CheckBox10.Checked = true) and (ca_only = false) then
          begin
            y := 247 - round(150 * history[i,10]);
            Pen.Color := clWhite;
            Ellipse(x,y-1,x+2,y+1);
          end;
        if (CheckBox8.Checked = true) and (pd_only = false) then
          begin
            y := 247 - round(150 * history[i,7]);
            Pen.Color := clRed;
            Ellipse(x,y-1,x+2,y+1);
          end;
        if CheckBox5.Checked and CheckBox5.Visible and (ca_only = false) then
          begin
            y := 247 - round(15 * history[i,6]);
            Pen.Color := $66FF66;
            Ellipse(x,y-1,x+2,y+1);
          end;
        if CheckBox12.Checked and CheckBox12.Visible then
           begin
             y := 247 - round(15 * history[i,12]);
             Pen.Color := $EE99CC;
             Ellipse(x,y-1,x+2,y+1);
           end;
        if CheckBox3.Checked and CheckBox3.Visible then
          begin
            y := 247 - round(15 * history[i,4]);
            Pen.Color := clYellow;
            Ellipse(x,y-1,x+2,y+1);
          end;
        if CheckBox1.Checked and CheckBox1.Visible then
          begin
            y := 247 - round(15 * history[i,2]);
            Pen.Color := clAqua;
            Ellipse(x,y-1,x+2,y+1);
          end;
        if CheckBox6.Checked and CheckBox6.Visible and (ca_only = false) then
          begin
            y := 247 - round(15 * history[i,5]);
            Pen.Color := $00CC00;
            Ellipse(x,y-1,x+2,y+1);
          end;
        if CheckBox11.Checked and CheckBox11.Visible then
          begin
            y := 247 - round(15 * history[i,11]);
            Pen.Color := clFuchsia;
            Ellipse(x,y-1,x+2,y+1);
          end;
        if CheckBox4.Checked and CheckBox4.Visible then
          begin
            y := 247 - round(15 * history[i,3]);
            Pen.Color := $66CCFF;
            Ellipse(x,y-1,x+2,y+1);
          end;
        if CheckBox2.Checked then
          begin
            y := 247 - round(15 * history[i,1]);
            Pen.Color := $FF9933;
            Ellipse(x,y-1,x+2,y+1);
          end;
      end;
    end;
end;

procedure THistoryForm.FormClose(Sender: TObject;
  var Action: TCloseAction);
begin
  MainForm.MenuHistory.Click;
end;

end.
