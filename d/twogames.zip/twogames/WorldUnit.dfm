object WorldForm: TWorldForm
  Left = 376
  Top = 114
  HelpContext = 55
  BorderStyle = bsDialog
  Caption = 'The World'
  ClientHeight = 140
  ClientWidth = 192
  Color = clBlack
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  FormStyle = fsStayOnTop
  OldCreateOrder = False
  PopupMenu = PopupMenuWorld
  OnClose = FormClose
  OnMouseDown = FormMouseDown
  OnMouseMove = FormMouseMove
  OnMouseUp = FormMouseUp
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object StatusBar1: TStatusBar
    Left = 0
    Top = 121
    Width = 192
    Height = 19
    Panels = <>
    SimplePanel = True
  end
  object PopupMenuWorld: TPopupMenu
    OnPopup = PopupMenuWorldPopup
    Left = 80
    Top = 48
    object Delay: TMenuItem
      Caption = 'Delay'
      object N01: TMenuItem
        Caption = '0'
        RadioItem = True
        OnClick = N01Click
      end
      object N101: TMenuItem
        Caption = '10'
        RadioItem = True
        OnClick = N101Click
      end
      object N201: TMenuItem
        Caption = '20'
        RadioItem = True
        OnClick = N201Click
      end
      object N501: TMenuItem
        Caption = '50'
        RadioItem = True
        OnClick = N501Click
      end
      object N1001: TMenuItem
        Caption = '100'
        RadioItem = True
        OnClick = N1001Click
      end
      object N2001: TMenuItem
        Caption = '200'
        RadioItem = True
        OnClick = N2001Click
      end
      object N3001: TMenuItem
        Caption = '300'
        RadioItem = True
        OnClick = N3001Click
      end
      object N6001: TMenuItem
        Caption = '600'
        RadioItem = True
        OnClick = N6001Click
      end
      object N1002: TMenuItem
        Caption = '1000'
        RadioItem = True
        OnClick = N1002Click
      end
    end
    object Color1: TMenuItem
      Caption = 'Color'
      object BoldnessxVengefulness1: TMenuItem
        Caption = 'Boldness x Vengefulness'
        Checked = True
        RadioItem = True
        OnClick = BoldnessxVengefulness1Click
      end
      object RemembrancexGratefulness1: TMenuItem
        Caption = 'Remembrance x Gratefulness'
        RadioItem = True
        OnClick = RemembrancexGratefulness1Click
      end
    end
  end
end
