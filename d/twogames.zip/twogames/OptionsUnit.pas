unit OptionsUnit;

interface

uses Windows, SysUtils, Classes, Graphics, Forms, Controls, StdCtrls,
  Buttons, ComCtrls, ExtCtrls, Dialogs, ShellAPI, IniFiles;

type
  TOptionsForm = class(TForm)
    Panel1: TPanel;
    Panel2: TPanel;
    TabSheet04: TPageControl;
    TabSheet1: TTabSheet;
    TabSheet2: TTabSheet;
    TabSheet3: TTabSheet;
    HelpBtn: TButton;
    Edit3: TEdit;
    ScrollBar3: TScrollBar;
    GroupBox10: TGroupBox;
    RadioButton9: TRadioButton;
    RadioButton10: TRadioButton;
    RadioButton11: TRadioButton;
    GroupBox13: TGroupBox;
    Label3: TLabel;
    OKButton: TButton;
    GroupBox1: TGroupBox;
    Label1: TLabel;
    Label2: TLabel;
    Edit1: TEdit;
    Edit2: TEdit;
    ScrollBar1: TScrollBar;
    ScrollBar2: TScrollBar;
    GroupBox3: TGroupBox;
    RadioButton1: TRadioButton;
    RadioButton2: TRadioButton;
    GroupBox7: TGroupBox;
    RadioButton7: TRadioButton;
    RadioButton8: TRadioButton;
    TabSheet4: TTabSheet;
    GroupBox12: TGroupBox;
    Label26: TLabel;
    Label27: TLabel;
    Label28: TLabel;
    Label29: TLabel;
    Edit13: TEdit;
    Edit14: TEdit;
    Edit15: TEdit;
    Edit16: TEdit;
    CheckBox13: TCheckBox;
    Label21: TLabel;
    Label22: TLabel;
    GroupBox11: TGroupBox;
    Label23: TLabel;
    Label24: TLabel;
    Label25: TLabel;
    ComboBox14: TComboBox;
    CheckBox8: TCheckBox;
    CheckBox9: TCheckBox;
    GroupBox6: TGroupBox;
    Label34: TLabel;
    Edit19: TEdit;
    GroupBox15: TGroupBox;
    Label19: TLabel;
    Label20: TLabel;
    Edit8: TEdit;
    Edit6: TEdit;
    Label11: TLabel;
    GroupBox17: TGroupBox;
    Label33: TLabel;
    Edit18: TEdit;
    CheckBox10: TCheckBox;
    CheckBox4: TCheckBox;
    CheckBox5: TCheckBox;
    CheckBox11: TCheckBox;
    CheckBox12: TCheckBox;
    GroupBox9: TGroupBox;
    Label17: TLabel;
    Label18: TLabel;
    Edit11: TEdit;
    Edit12: TEdit;
    GroupBox2: TGroupBox;
    CheckBox1: TCheckBox;
    GroupBox5: TGroupBox;
    Label4: TLabel;
    Label7: TLabel;
    Label8: TLabel;
    ComboBox2: TComboBox;
    ComboBox3: TComboBox;
    ComboBox4: TComboBox;
    GroupBox16: TGroupBox;
    Label5: TLabel;
    Label6: TLabel;
    ComboBox5: TComboBox;
    ComboBox6: TComboBox;
    ComboBox7: TComboBox;
    Label10: TLabel;
    CheckBox14: TCheckBox;
    Label9: TLabel;
    Label12: TLabel;
    OpenSummaryButton: TButton;
    GroupBox14: TGroupBox;
    CheckBox6: TCheckBox;
    Label37: TLabel;
    Edit17: TEdit;
    Edit20: TEdit;
    CheckBox7: TCheckBox;
    CheckBox15: TCheckBox;
    OpenDetailedButton: TButton;
    GroupBox8: TGroupBox;
    Label14: TLabel;
    Label15: TLabel;
    Label16: TLabel;
    Edit9: TEdit;
    Edit10: TEdit;
    CheckBox2: TCheckBox;
    CancelButton: TButton;
    RadioButton6: TRadioButton;
    RadioButton5: TRadioButton;
    Edit7: TEdit;
    Edit21: TEdit;
    Edit22: TEdit;
    Edit23: TEdit;
    ComboBox1: TComboBox;
    CheckBox17: TCheckBox;
    GroupBox4: TGroupBox;
    RadioButton3: TRadioButton;
    RadioButton4: TRadioButton;
    Edit4: TEdit;
    CheckBox18: TCheckBox;
    Edit5: TEdit;
    Label13: TLabel;
    Edit25: TEdit;
    CheckBox19: TCheckBox;
    Label31: TLabel;
    BtOpenCycle: TButton;
    Label32: TLabel;
    Edit26: TEdit;
    procedure RadioButton4Click(Sender: TObject);
    procedure RadioButton3Click(Sender: TObject);
    procedure ScrollBar3Change(Sender: TObject);
    procedure Edit3Change(Sender: TObject);
    procedure Edit1Change(Sender: TObject);
    procedure Edit2Change(Sender: TObject);
    procedure Edit1Click(Sender: TObject);
    procedure Edit1DblClick(Sender: TObject);
    procedure Edit2Click(Sender: TObject);
    procedure Edit2DblClick(Sender: TObject);
    procedure ScrollBar1Change(Sender: TObject);
    procedure ScrollBar2Change(Sender: TObject);
    procedure OKButtonClick(Sender: TObject);
    procedure CheckBox4Click(Sender: TObject);
    procedure CheckBox8Click(Sender: TObject);
    procedure CheckBox9Click(Sender: TObject);
    procedure ComboBox5Change(Sender: TObject);
    procedure ComboBox6Change(Sender: TObject);
    procedure ComboBox2Change(Sender: TObject);
    procedure ComboBox3Change(Sender: TObject);
    procedure HelpBtnClick(Sender: TObject);
    procedure CheckBox6Click(Sender: TObject);
    procedure RadioButton7Click(Sender: TObject);
    procedure RadioButton8Click(Sender: TObject);
    procedure OpenDetailedButtonClick(Sender: TObject);
    procedure OpenSummaryButtonClick(Sender: TObject);
    procedure CheckBox2Click(Sender: TObject);
    procedure CheckBox7Click(Sender: TObject);
    procedure CheckBox15Click(Sender: TObject);
    procedure CancelButtonClick(Sender: TObject);
    procedure CheckBox18Click(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure CheckBox19Click(Sender: TObject);
    procedure BtOpenCycleClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  OptionsForm: TOptionsForm;
  scrollposition : integer;
  mutation_rate_STR : string;

procedure FirstSetup;

implementation

uses Main, HistoryUnit, WorldUnit, NewsUnit, NewAgentUnit, AboutBoxUnit,
  PopUpUnit;

{$R *.DFM}

procedure ChangesCancelation;
begin
  with OptionsForm do
    begin
      Visible := false;
      Edit1.Text := IntToStr(world_height);
      Edit2.Text := IntToStr(world_width);
      Edit3.Text := IntToStr(initial_n_agents);
      case delay_time of
           0 : ComboBox1.ItemIndex := 0;
          10 : ComboBox1.ItemIndex := 1;
          20 : ComboBox1.ItemIndex := 2;
          50 : ComboBox1.ItemIndex := 3;
         100 : ComboBox1.ItemIndex := 4;
         200 : ComboBox1.ItemIndex := 5;
         300 : ComboBox1.ItemIndex := 6;
         600 : ComboBox1.ItemIndex := 7;
        1000 : ComboBox1.ItemIndex := 8;
      end;
      if flat then RadioButton2.Checked := true else RadioButton1.Checked := true;
      Edit18.Text := IntToStr(n_cycles);
      if show_world then CheckBox4.Checked := true else CheckBox4.Checked := false;
      if once_a_cycle then CheckBox5.Checked := true else CheckBox5.Checked := false;
      if show_news then CheckBox10.Checked := true else CheckBox10.Checked := false;
      if show_history then CheckBox12.Checked := true else CheckBox12.Checked := false;
      if play_sound then CheckBox11.Checked := true else CheckBox11.Checked := false;
      if choose_seed then RadioButton4.Checked := true else RadioButton3.Checked := true;
      if save_details then CheckBox1.Checked := true else CheckBox1.Checked := false;
      if save_summary then CheckBox14.Checked := true else CheckBox14.Checked := false;
      if save_onecycle then CheckBox19.Checked := true else CheckBox19.Checked := false;
      Edit26.Text := IntToStr(cycle_to_be_saved);
      if ca_only then RadioButton9.Checked := true;
      if pd_only then RadioButton10.Checked := true;
      if (ca_only = false) and (pd_only = false) then RadioButton11.Checked := true;
      Edit11.Text := IntToStr(malthus_max);
      Edit12.Text := IntToStr(malthus_rate);
      if recognize_rel then CheckBox2.Checked := true else CheckBox2.Checked := false;
      Edit9.Text := IntToStr(wealth_to_rel);
      Edit10.Text := IntToStr(wealth_to_socty);
      Edit17.Text := IntToStr(repro_age_av);
      Edit20.Text := IntToStr(repro_age_std);
      Edit6.Text := IntToStr(max_age_av);
      Edit8.Text := IntToStr(max_age_std);
      Edit19.Text := mutation_rate_STR;
      if die_after_repro then CheckBox6.Checked := true else CheckBox6.Checked := false;
      if sexual then RadioButton5.Checked := true else RadioButton6.Checked :=true;
      if trust_game then CheckBox13.Checked := true else CheckBox13.Checked := false;
      if move_randomly then RadioButton7.Checked := true else RadioButton8.Checked := true;
      if towards_the_best then CheckBox7.Checked := true else CheckBox7.Checked := false;
      if avoiding_the_worst then CheckBox15.Checked := true else CheckBox15.Checked := false;
      Edit13.Text := IntToStr(DC);
      Edit14.Text := IntToStr(CC);
      Edit15.Text := IntToStr(DD);
      Edit16.Text := IntToStr(CD);
      ComboBox2.ItemIndex := round(vengefulness_av/10);
      ComboBox5.ItemIndex := round(vengefulness_av/10);
      ComboBox3.ItemIndex := round(boldness_av/10);
      ComboBox6.ItemIndex := round(boldness_av/10);
      ComboBox7.ItemIndex := round(gratefulness_av/10);
      ComboBox4.ItemIndex := round(remembrance_av/10);
      Edit7.Text := IntToStr(cost_coop);
      Edit21.Text := IntToStr(socty_gain);
      if norms then CheckBox8.Checked := true else CheckBox8.Checked := false;
      if metanorms then CheckBox9.Checked := true else CheckBox9.Checked := false;
      ComboBox14.ItemIndex := vigilant_vr;
      Edit22.Text := IntToStr(punishment);
      Edit23.Text := IntToStr(enf_c);
    end;
end;

procedure TOptionsForm.OKButtonClick(Sender: TObject);
var i, j, k : integer;
    r : real;
    s : string;
begin
{-----------------------------------------------}
{----------- Avoiding invalid values -----------}
  if Edit1.Text = '' then Edit1.Text := '0';
  if Edit2.Text = '' then Edit2.Text := '0';
  if Edit3.Text = '' then Edit3.Text := '0';
  if Edit4.Text = '' then Edit4.Text := '0';
  if Edit7.Text = '' then Edit7.Text := '0';
  if Edit9.Text = '' then Edit9.Text := '0';
  if Edit11.Text = '' then Edit11.Text := '0';
  if Edit12.Text = '' then Edit12.Text := '0';
  if Edit18.Text = '' then Edit18.Text := '0';
  if Edit10.Text = '' then Edit10.Text := '0';
  if Edit17.Text = '' then Edit17.Text := '0';
  if Edit19.Text = '' then Edit19.Text := '0';
  if Edit20.Text = '' then Edit20.Text := '0';
  if Edit13.Text = '' then Edit13.Text := '0';
  if Edit14.Text = '' then Edit14.Text := '0';
  if Edit15.Text = '' then Edit15.Text := '0';
  if Edit16.Text = '' then Edit16.Text := '0';
  if Edit21.Text = '' then Edit21.Text := '0';
  if Edit22.Text = '' then Edit22.Text := '0';
  if Edit23.Text = '' then Edit23.Text := '0';
  Edit7.Text := IntToStr(abs(StrToInt(Edit7.Text)));
  Edit21.Text := IntToStr(abs(StrToInt(Edit21.Text)));
  Edit22.Text := IntToStr(abs(StrToInt(Edit22.Text)));
  Edit23.Text := IntToStr(abs(StrToInt(Edit23.Text)));

  if ((ScrollBar1.Position) < 4) then
    begin
      TabSheet04.ActivePage := TabSheet1;
      ShowMessage('The minimum world''s height is 4!');
      Edit1.SelectAll;
      Edit1.SetFocus;
      exit;
    end;
  if ((ScrollBar2.Position) < 4) then
    begin
      ShowMessage('The minimum world''s width is 4!');
      Edit2.SelectAll;
      Edit2.SetFocus;
      exit;
    end;
  if ((StrToInt(Edit3.Text)) < 7) then
    begin
      TabSheet04.ActivePage := TabSheet1;
      ShowMessage('The minimum number of agents is 7!');
      Edit3.SelectAll;
      Edit3.SetFocus;
      exit;
    end;
  if ((StrToInt(Edit11.Text)) > 50) then
    begin
      TabSheet04.ActivePage := TabSheet2;
      ShowMessage('The percentage of occupied cells can''t be bigger than 50%.');
      Edit11.SelectAll;
      Edit11.SetFocus;
      exit;
    end;
  if ((StrToInt(Edit12.Text)) > 50) or ((StrToInt(Edit12.Text)) < 15) then
    begin
      TabSheet04.ActivePage := TabSheet2;
      ShowMessage('During Malthusian correction between 15% and 50% of the population must die!');
      Edit12.SelectAll;
      Edit12.SetFocus;
      exit;
    end;
  if ((StrToInt(Edit17.Text)) < 3) then
    begin
      TabSheet04.ActivePage := TabSheet2;
      ShowMessage('The minimal reproduction age is 3.');
      Edit17.SelectAll;
      Edit17.SetFocus;
      exit;
    end;
  if (CheckBox6.Checked = false) and (StrToInt(Edit6.Text) < (StrToInt(Edit8.Text) + StrToInt(Edit17.Text) + StrToInt(Edit20.Text))) then
    begin
      TabSheet04.ActivePage := TabSheet2;
      ShowMessage('The death age is too small for the chosen reproduction age.');
      Edit17.SelectAll;
      Edit17.SetFocus;
      exit;
    end;
  if StrToInt(Edit13.Text) > 121 then
    begin
      TabSheet04.ActivePage := TabSheet3;
      ShowMessage('The payoff for DC must be less than 121.');
      Edit13.SelectAll;
      Edit13.SetFocus;
      exit;
    end;
  if (StrToInt(Edit16.Text) < -30) then
    begin
      TabSheet04.ActivePage := TabSheet3;
      ShowMessage('The payoff for CD can''t be smaller than -30.');
      Edit16.SelectAll;
      Edit16.SetFocus;
      exit;
    end;
  if StrToInt(Edit15.Text) <= StrToInt(Edit16.Text) then
    begin
      TabSheet04.ActivePage := TabSheet3;
      ShowMessage('The payoff for DD must be bigger than the payoff for CD.');
      Edit15.SelectAll;
      Edit15.SetFocus;
      exit;
    end;
  if StrToInt(Edit14.Text) <= StrToInt(Edit15.Text) then
    begin
      TabSheet04.ActivePage := TabSheet3;
      ShowMessage('The payoff for CC must be bigger than the payoff for DD.');
      Edit14.SelectAll;
      Edit14.SetFocus;
      exit;
    end;
  if StrToInt(Edit13.Text) <= StrToInt(Edit14.Text) then
    begin
      TabSheet04.ActivePage := TabSheet3;
      ShowMessage('The payoff for DC must be bigger than the payoff for CC.');
      Edit13.SelectAll;
      Edit13.SetFocus;
      exit;
    end;
  if ((StrToInt(Edit9.Text) + StrToInt(Edit10.Text)) > 100) then
    begin
      TabSheet04.ActivePage := TabSheet2;
      ShowMessage('The wealth to be inherited can''t be bigger than 100%');
      Edit9.SelectAll;
      Edit9.SetFocus;
      exit;
    end;
  s := Edit19.Text;
  for i := 1 to Length(s) do if ((s[i] = ',') or (s[i] = '.')) and (s[i] <> DecimalSeparator) then
    begin
      s[i] := DecimalSeparator;
      Edit19.Text := s;
    end;
  try
    r := StrToFloat(Edit19.Text);
  Except
    begin
      TabSheet04.ActivePage := TabSheet2;
      ShowMessage('Please, digit a valid real number.');
      Edit19.SetFocus;
      Edit19.SelectAll;
      exit;
    end;
  end;
  if r > 0.3 then
    begin
      TabSheet04.ActivePage := TabSheet2;
      ShowMessage('The mutation rate must be lower than 0.3!');
      Edit19.SetFocus;
      Edit19.SelectAll;
      exit;
    end;
{-----------------------------------------------}
{------ Giving the values to the variables -----}
  scrollposition := ScrollBar3.Position;
  j := world_width;
  k := world_width;
  world_height := StrToInt (Edit1.Text);
  world_width := StrToInt (Edit2.Text);
  n_agents := StrToInt(Edit3.Text);
  initial_n_agents := n_agents;
  n_cycles := StrToInt (Edit18.Text);
  max_age_av := StrToInt (Edit6.Text);
  max_age_std := StrToInt (Edit8.Text);
  wealth_to_rel := StrToInt (Edit9.Text);
  wealth_to_socty := StrToInt (Edit10.Text);
  malthus_max := StrToInt (Edit11.Text);
  malthus_rate := StrToInt (Edit12.Text);
  if CheckBox19.Checked then
    begin
      if StrToInt(Edit26.Text) > n_cycles then
        begin
          TabSheet04.ActivePage := TabSheet1;
          ShowMessage('The number of the cycle to be saved must be at most ' + IntToStr(n_cycles) + '.');
          Edit26.SelectAll;
          Edit26.SetFocus;
          exit;
        end;
      save_onecycle := true;
      cycle_to_be_saved := StrToInt(Edit26.Text);
    end else save_onecycle := false;
  if CheckBox4.Checked then
    begin
      show_world := true;
      MainForm.MenuWorld.Checked := true;
      WorldForm.Visible := true;
    end else
    begin
      MainForm.MenuWorld.Checked := false;
      show_world := false;
      WorldForm.Visible := false;
    end;
  if CheckBox5.Checked then
    begin
      CheckBox5.Checked := true;
      once_a_cycle := true;
    end else
    begin
      CheckBox5.Checked := false;
      once_a_cycle := false;
    end;
  if CheckBox17.Checked then
    begin
      WorldForm.BoldnessxVengefulness1.Checked := true;
      show_Cl1 := true;
    end else
    begin
      WorldForm.RemembrancexGratefulness1.Checked := true;
      show_Cl1 := false;
    end;

  if CheckBox18.Checked then
    begin
      save_pictures := true;
      if Edit5.Text = '' then Edit5.Text := '4';
      if Edit25.Text = '' then Edit25.Text := 'world';
      try
        n_pictures := StrToInt(Edit5.Text);
      except
        Edit5.Text := '4';
        n_pictures := StrToInt(Edit5.Text);
      end;
      pictures_name := Edit25.Text;
    end else save_pictures := false;
  DC := StrToInt (Edit13.Text);
  CC := StrToInt (Edit14.Text);
  DD := StrToInt (Edit15.Text);
  CD := StrToInt (Edit16.Text);
  cost_coop := StrToInt(Edit7.Text);
  socty_gain := StrToInt(Edit21.Text);
  if RadioButton8.Checked then
    begin
      intentional_move := true;
      move_randomly := false;
    end else
    begin
      intentional_move := false;
      move_randomly := true;
    end;
  if CheckBox7.Checked then towards_the_best := true else towards_the_best := false;
  if CheckBox13.Checked then avoiding_the_worst := true else avoiding_the_worst := false;
  vigilant_vr := StrToInt(ComboBox14.Text);
  enf_c := StrToInt(Edit23.Text);
  punishment := StrToInt(Edit22.Text);
  vengefulness_av := 10 * StrToInt(ComboBox2.Text);
  gratefulness_av := 10 * StrToInt(ComboBox7.Text);
  boldness_av := 10 * StrToInt(ComboBox3.Text);
  remembrance_av := 10 * StrToInt(ComboBox4.Text);
  repro_age_av := StrToInt(Edit17.Text);
  repro_age_std := StrToInt(Edit20.Text);
  if RadioButton4.Checked then rand_seed := StrToInt(Edit4.Text);
  mutation_rate := StrToFloat(Edit19.Text);
  mutation_rate_STR := Edit19.Text;
  if CheckBox1.Checked then  save_details := true else save_details := false;
  if CheckBox14.Checked then save_summary := true else save_summary := false;
  if CheckBox2.Checked then recognize_rel := true else recognize_rel := false;
  if RadioButton2.Checked then flat := true else flat := false;
  if RadioButton4.Checked then choose_seed := true else choose_seed := false;
  if RadioButton5.Checked then sexual := true else sexual := false;
  if RadioButton9.Checked then
    begin
      ca_only := true;
      Application.Title := 'Collective Action Game';
      MainForm.Caption := 'Evolutionary CA';
      NewAgentForm.ComboBox3.Visible := false;
      NewAgentForm.ComboBox4.Visible := false;
      NewAgentForm.Label3.Visible := false;
      NewAgentForm.Label4.Visible := false;
      NewAgentForm.ClientHeight := 93;
    end else
    begin
      ca_only := false;
      NewAgentForm.ComboBox2.Visible := true;
      NewAgentForm.ComboBox3.Visible := true;
      NewAgentForm.ComboBox4.Visible := true;
      NewAgentForm.Label3.Visible := true;
      NewAgentForm.Label4.Visible := true;
      NewAgentForm.ClientHeight := 143;
    end;
  if RadioButton10.Checked then
    begin
      pd_only := true;
      Application.Title := 'Prisoner''s Dilemma Game';
      MainForm.Caption := 'Evolutionary PD';
    end else pd_only := false;
  if (pd_only = false) and (ca_only = false) then
    begin
      Application.Title := 'Collective Action and Prisoner''s Dilemma';
      MainForm.Caption := 'Two Evolutionary Games';
    end;
  if CheckBox6.Checked then die_after_repro := true else die_after_repro := false;
  delay_time := StrToInt(ComboBox1.Text);
  case ComboBox1.ItemIndex of
    0 : WorldForm.N01.Checked := true;
    1 : WorldForm.N101.Checked := true;
    2 : WorldForm.N201.Checked := true;
    3 : WorldForm.N501.Checked := true;
    4 : WorldForm.N1001.Checked := true;
    5 : WorldForm.N2001.Checked := true;
    6 : WorldForm.N3001.Checked := true;
    7 : WorldForm.N6001.Checked := true;
    8 : WorldForm.N1002.Checked := true;
  end;
  if CheckBox8.Checked then
    begin
      norms := true;
      if ca_only then
        begin
          NewAgentForm.ComboBox2.Visible := true;
          NewAgentForm.Label2.Visible := true;
          NewAgentForm.ClientHeight := 93;
        end;
    end else
    begin
      norms := false;
      if ca_only then
        begin
          NewAgentForm.ComboBox2.Visible := false;
          NewAgentForm.Label2.Visible := false;
          NewAgentForm.ClientHeight := 66;
        end;
    end;
  if CheckBox9.Checked then metanorms := true else metanorms := false;
  if CheckBox10.Checked then
    begin
      show_news := true;
      NewsForm.Visible := true;
      MainForm.MenuNews.Checked := true;
    end else
    begin
      show_news := false;
      NewsForm.Visible := false;
      MainForm.MenuNews.Checked := false;
    end;
  if n_cycles > 600 then HistoryForm.n_cyclesLabel.Caption := IntToStr(n_cycles) else HistoryForm.n_cyclesLabel.Caption := '600';
  if CheckBox11.Checked then play_sound := true else play_sound := false;
  if CheckBox12.Checked then
    begin
      HistoryForm.Visible := true;
      MainForm.MenuHistory.Checked := true;
      show_history := true;
    end else
    begin
      HistoryForm.Visible := false;
      MainForm.MenuHistory.Checked := false;
      show_history := false;
    end;
  if CheckBox13.Checked then trust_game := true else trust_game := false;
  if wealth_to_rel > 100 then
    begin
      Edit9.Text := '100';
      wealth_to_rel := 100;
    end;
  if (ca_only and norms) or (ca_only = false) then HistoryForm.CheckBox4.Visible := true;
  if ca_only = false then
    begin
      HistoryForm.CheckBox1.Visible := true;
      HistoryForm.CheckBox11.Visible := true;
      HistoryForm.CheckBox6.Visible := true;
      HistoryForm.CheckBox9.Visible := true;
      HistoryForm.CheckBox10.Visible := true;
      HistoryForm.CheckBox8.Top := 40;
      HistoryForm.CheckBox3.Top := 24;
    end else
    begin
      HistoryForm.CheckBox1.Visible := false;
      HistoryForm.CheckBox8.Top := 8;
      HistoryForm.CheckBox3.Top := 8;
    end;
  if recognize_rel then
    begin
      if (ca_only and norms) or (ca_only = false) then HistoryForm.CheckBox3.Visible := true;
      if ca_only = false then
        begin
          HistoryForm.CheckBox1.Visible := true;
          HistoryForm.CheckBox5.Visible := true;
          HistoryForm.CheckBox12.Visible := true;
        end;
    end;
  if pd_only = false then HistoryForm.CheckBox8.Visible := true;
  if ca_only and (norms = false) then
    begin
      HistoryForm.CheckBox3.Visible := false;
      HistoryForm.CheckBox4.Visible := false;
    end;
  if ca_only then
    begin
      HistoryForm.CheckBox5.Visible := false;
      HistoryForm.CheckBox6.Visible := false;
      HistoryForm.CheckBox9.Visible := false;
      HistoryForm.CheckBox10.Visible := false;
      HistoryForm.CheckBox11.Visible := false;
      HistoryForm.CheckBox12.Visible := false;
    end;
  if pd_only then HistoryForm.CheckBox8.Visible := false;
  if recognize_rel = false then
    begin
      HistoryForm.CheckBox1.Visible := false;
      HistoryForm.CheckBox3.Visible := false;
      HistoryForm.CheckBox5.Visible := false;
      HistoryForm.CheckBox12.Visible := false;
    end;
  malthus_limit := round(malthus_max * world_width * world_height / 100);

  Close;
  if (j <> world_width) or (k <> world_height) then
    begin
      Clear_World;
      if show_world then Setup;
    end;
end;

procedure TOptionsForm.RadioButton4Click(Sender: TObject);
begin
  if RadioButton4.Checked = true then Edit4.Visible := true else Edit4.Visible := false;
end;

procedure TOptionsForm.RadioButton3Click(Sender: TObject);
begin
  if RadioButton4.Checked = true then Edit4.Visible := true else Edit4.Visible := false;
end;

procedure TOptionsForm.ScrollBar3Change(Sender: TObject);
begin
  if Edit3.Focused or ScrollBar3.Focused then scrollposition := ScrollBar3.Position;
  Edit3.Text := IntToStr (ScrollBar3.Position);
end;

procedure TOptionsForm.Edit3Change(Sender: TObject);
begin
  if Edit3.Focused or ScrollBar3.Focused then scrollposition := ScrollBar3.Position;
  if Edit3.Text = '' then
    begin
      ScrollBar3.Position := 0;
      Edit3.Text := '';
    end
    else
      ScrollBar3.Position := StrToInt(Edit3.Text);
end;

procedure TOptionsForm.Edit1Change(Sender: TObject);
begin
  if Edit1.Text <> '' then
    begin
      if (StrToInt(Edit1.Text) < 0) then Edit1.Text := '0';
      if (StrToInt(Edit1.Text) > 100) then Edit1.Text := '100';
      ScrollBar3.Max := round (StrToInt(Edit1.Text) * StrToInt(Edit2.Text) * StrToInt(Edit11.Text) / 110);
      ScrollBar3.Position := scrollposition;
      ScrollBar1.Position := StrToInt(Edit1.Text);
    end;
end;

procedure TOptionsForm.Edit2Change(Sender: TObject);
begin
  if Edit2.Text <> '' then
    begin
      if (StrToInt(Edit2.Text) < 0) then Edit2.Text := '1';
      if (StrToInt(Edit2.Text) > 100) then Edit2.Text := '100';
      ScrollBar3.Max := round (StrToInt(Edit1.Text) * StrToInt(Edit2.Text) * StrToInt(Edit11.Text) / 110);
      ScrollBar3.Position := scrollposition;
      ScrollBar2.Position := StrToInt(Edit2.Text);
    end;
end;

procedure TOptionsForm.Edit1Click(Sender: TObject);
begin
  scrollposition := Scrollbar3.Position;
end;

procedure TOptionsForm.Edit1DblClick(Sender: TObject);
begin
  scrollposition := Scrollbar3.Position;
end;

procedure TOptionsForm.Edit2Click(Sender: TObject);
begin
  scrollposition := Scrollbar3.Position;
end;

procedure TOptionsForm.Edit2DblClick(Sender: TObject);
begin
  scrollposition := Scrollbar3.Position;
end;

procedure TOptionsForm.ScrollBar1Change(Sender: TObject);
begin
  Edit1.Text := IntToStr(ScrollBar1.Position);
end;

procedure TOptionsForm.ScrollBar2Change(Sender: TObject);
begin
  Edit2.Text := IntToStr(ScrollBar2.Position);
end;


procedure TOptionsForm.CheckBox4Click(Sender: TObject);
begin
  if CheckBox4.Checked = false then CheckBox5.Enabled := false else CheckBox5.Enabled := true;
end;

procedure TOptionsForm.CheckBox8Click(Sender: TObject);
begin
  if CheckBox8.Checked = false then
    begin
      CheckBox9.Checked := false;
      CheckBox9.Enabled := false;
      ComboBox14.Enabled := false;
      Edit22.Enabled := false;
      Edit23.Enabled := false;
    end else
    begin
      CheckBox9.Enabled := true;
      ComboBox14.Enabled := true;
      Edit22.Enabled := true;
      Edit23.Enabled := true;
    end;
end;

procedure TOptionsForm.CheckBox9Click(Sender: TObject);
begin
  if CheckBox8.Checked = false then CheckBox9.Checked := false;
end;

procedure TOptionsForm.ComboBox5Change(Sender: TObject);
begin
  ComboBox2.ItemIndex := ComboBox5.ItemIndex;
end;

procedure TOptionsForm.ComboBox6Change(Sender: TObject);
begin
  ComboBox3.ItemIndex := ComboBox6.ItemIndex;
end;

procedure TOptionsForm.ComboBox2Change(Sender: TObject);
begin
  ComboBox5.ItemIndex := ComboBox2.ItemIndex;
end;

procedure TOptionsForm.ComboBox3Change(Sender: TObject);
begin
  ComboBox6.ItemIndex := ComboBox3.ItemIndex;
end;

procedure TOptionsForm.HelpBtnClick(Sender: TObject);
begin
  Application.HelpContext(15);
end;

procedure TOptionsForm.CheckBox6Click(Sender: TObject);
begin
 if CheckBox6.Checked then
   begin
     Edit6.Enabled := false;
     Edit8.Enabled := false;
     Label11.Enabled := false;
   end else
   begin
     Edit6.Enabled := true;
     Edit8.Enabled := true;
     Label11.Enabled := true;
   end;
end;

procedure TOptionsForm.RadioButton7Click(Sender: TObject);
begin
  CheckBox7.Enabled := false;
  CheckBox15.Enabled := false;
end;

procedure TOptionsForm.RadioButton8Click(Sender: TObject);
begin
  CheckBox7.Enabled := true;
  CheckBox15.Enabled := true;
  if RadioButton8.Checked and (CheckBox7.Checked = false) and (CheckBox15.Checked = false) then
    begin
      CheckBox7.Checked := true;
      CheckBox15.Checked := true;
    end;
end;

procedure TOptionsForm.OpenDetailedButtonClick(Sender: TObject);
var str : string;
begin
  if not FileExists(details_file) then
    begin
      ShowMessage('The file ' + details_file + ' doesn''t exist.');
      exit;
    end;
  if not FileExists(details_syntax) then
    begin
      str := GetCurrentDir + '\' + details_file;
      AssignFile(F, details_syntax);
      Rewrite(F);
      writeln(F,' *THIS SYNTAX WAS WRITTEN FOR SPSS 10.0');
      writeln(F,' *IN THE MAIN MENU OF THIS SYNTAX WINDOW, CLICK ON "RUN ALL"');
      writeln(F);
      writeln(F,' GET DATA  /TYPE = TXT');
      writeln(F,' /FILE = ''', str, '''');
      writeln(F,' /DELCASE = LINE');
      writeln(F,' /DELIMITERS = "\t"');
      writeln(F,' /ARRANGEMENT = DELIMITED');
      writeln(F,' /FIRSTCASE = 2');
      writeln(F,' /IMPORTCASE = ALL');
      writeln(F,' /VARIABLES =');
      writeln(F,' cycle F2.2');
      writeln(F,' n_agents F2.2');
      writeln(F,' n_games F4.2');
      writeln(F,' av_wealt F7.2');
      writeln(F,' st_wealt F7.2');
      writeln(F,' c_in_CA F5.2');
      writeln(F,' CC F5.2');
      writeln(F,' DD F5.2');
      writeln(F,' b_str F5.2');
      writeln(F,' v_str F5.2');
      writeln(F,' g_str F5.2');
      writeln(F,' r_str F5.2');
      writeln(F,' b_rel F5.2');
      writeln(F,' v_rel F5.2');
      writeln(F,' g_rel F5.2');
      writeln(F,' r_rel F5.2');
      writeln(F,' std_b_st F5.2');
      writeln(F,' std_v_st F5.2');
      writeln(F,' std_g_st F5.2');
      writeln(F,' std_r_st F5.2');
      writeln(F,' std_b_rl F5.2');
      writeln(F,' std_v_rl F5.2');
      writeln(F,' std_g_rl F5.2');
      writeln(F,' std_r_rl F5.2');
      writeln(F,' n_g1_ags F2.2');
      writeln(F,' n_g2_ags F2.2');
      writeln(F,' n_g3_ags F2.2');
      writeln(F,' g1_b_st F5.2');
      writeln(F,' g1_v_str F5.2');
      writeln(F,' g1_g_str F5.2');
      writeln(F,' g1_r_str F5.2');
      writeln(F,' g1_b_rel F5.2');
      writeln(F,' g1_v_rel F5.2');
      writeln(F,' g1_g_rel F5.2');
      writeln(F,' g1_r_rel F5.2');
      writeln(F,' g2_b_str F5.2');
      writeln(F,' g2_v_str F5.2');
      writeln(F,' g2_g_str F5.2');
      writeln(F,' g2_r_str F5.2');
      writeln(F,' g2_b_rel F5.2');
      writeln(F,' g2_v_rel F5.2');
      writeln(F,' g2_g_rel F5.2');
      writeln(F,' g2_r_rel F5.2');
      writeln(F,' g3_b_str F5.2');
      writeln(F,' g3_v_str F5.2');
      writeln(F,' g3_g_str F5.2');
      writeln(F,' g3_r_str F5.2');
      writeln(F,' g3_b_rel F5.2');
      writeln(F,' g3_v_rel F5.2');
      writeln(F,' g3_g_rel F5.2');
      writeln(F,' g3_r_rel F5.2');
      writeln(F,' .');
      writeln(F,'');
      writeln(F,'');
      writeln(F,'Var labels');
      writeln(F,'cycle "Cycle"');
      writeln(F,'/n_agents "Number of Agents"');
      writeln(F,'/n_games "Number of games in Prisoner''s Dilemma"');
      writeln(F,'/av_wealt "Average Wealth"');
      writeln(F,'/st_wealt "Std. Dev. of Wealth"');
      writeln(F,'/c_in_CA "Proportion of cooperation in Collective Action"');
      writeln(F,'/CC "Proportion of CC in Prisoner''s Dilemma"');
      writeln(F,'/DD "Proportion of DD in Prisoner''s Dilemma"');
      writeln(F,'/b_str "Average Boldness towards strangers"');
      writeln(F,'/b_rel "Average Boldness towards relatives"');
      writeln(F,'/v_str "Average Vengefulness towards strangers"');
      writeln(F,'/v_rel "Average Vengefulness towards relatives"');
      writeln(F,'/g_str "Average Gratefulneess towards strangers"');
      writeln(F,'/g_rel "Average Gratefulness towards relatives"');
      writeln(F,'/r_str "Average Remembrance towards strangers"');
      writeln(F,'/r_rel "Average Remembrance towards relatives"');
      writeln(F,'/std_b_st "Std. Dev. of Average Boldness t. str."');
      writeln(F,'/std_b_rl "Std. Dev. of Average Boldness t. rel."');
      writeln(F,'/std_v_st "Std. Dev. of Average Vengefulness t. str."');
      writeln(F,'/std_v_rl "Std. Dev. of Average Vengefulness t. str."');
      writeln(F,'/std_g_st "Std. Dev. of Average Gratefulness t. rel."');
      writeln(F,'/std_g_rl "Std. Dev. of Average Gratefulness t. rel."');
      writeln(F,'/std_r_st "Std. Dev. of Average Remembrance t. str."');
      writeln(F,'/std_r_rl "Std. Dev. of Average Remembrance t. rel."');
      writeln(F,'/n_g1_ags "Number of agents in fitness group 1"');
      writeln(F,'/n_g2_ags "Number of agents in fitness group 2"');
      writeln(F,'/n_g3_ags "Number of agents in fitness group 3"');
      writeln(F,'/g1_b_st "Average Boldness t. str. of group 1"');
      writeln(F,'/g1_b_rel "Average Boldness t. rel. of group 1"');
      writeln(F,'/g1_v_str "Average Vengefulness t. str. of group 1"');
      writeln(F,'/g1_v_rel "Average Vengefulness t. rel. of group 1"');
      writeln(F,'/g1_g_str "Average Gratefulness t. str. of group 1"');
      writeln(F,'/g1_g_rel "Average Gratefulness t. rel. of group 1"');
      writeln(F,'/g1_r_str "Average Remembrance t. str. of group 1"');
      writeln(F,'/g1_r_rel "Average Remembrance t. rel. of group 1"');
      writeln(F,'/g2_b_str "Average Boldness t. str. of group 2"');
      writeln(F,'/g2_b_rel "Average Boldness t. rel. of group 2"');
      writeln(F,'/g2_v_str "Average Vengefulness t. str. of group 2"');
      writeln(F,'/g2_v_rel "Average Vengefulness t. rel. of group 2"');
      writeln(F,'/g2_g_str "Average Gratefulness t. str. of group 2"');
      writeln(F,'/g2_g_rel "Average Gratefulness t. rel. of group 2"');
      writeln(F,'/g2_r_str "Average Remembrance t. str. of group 2"');
      writeln(F,'/g2_r_rel "Average Remembrance t. rel. of group 2"');
      writeln(F,'/g3_b_str "Average Boldness t. str. of group 3"');
      writeln(F,'/g3_b_rel "Average Boldness t. rel. of group 3"');
      writeln(F,'/g3_v_str "Average Vengefulness t. str. of group 3"');
      writeln(F,'/g3_v_rel "Average Vengefulness t. rel. of group 3"');
      writeln(F,'/g3_g_str "Average Gratefulness t. str. of group 3"');
      writeln(F,'/g3_g_rel "Average Gratefulness t. rel. of group 3"');
      writeln(F,'/g3_r_str "Average Remembrance t. str. of group 3"');
      writeln(F,'/g3_r_rel "Average Remembrance t. rel. of group 3" .');
      writeln(F,'');
      writeln(F);
      CloseFile(F);
    end;
  if ShellExecute(0, Nil, details_syntax, Nil, Nil, SW_NORMAL) < 33 then
    ShellExecute(0, Nil, 'Excel', details_file, Nil, SW_NORMAL)
end;

procedure TOptionsForm.OpenSummaryButtonClick(Sender: TObject);
var str : string;
begin
  if not FileExists(summary_file) then
    begin
      ShowMessage('The file ' + summary_file + ' doesn''t exist.');
      exit;
    end;
  if FileExists(summary_syntax) = false then
    begin
      str := GetCurrentDir + '\' + summary_file;
      AssignFile(F, summary_syntax);
      Rewrite(F);
      writeln(F,' *THIS SYNTAX WAS WRITTEN FOR SPSS 10.0');
      writeln(F,' *IN THE MAIN MENU OF THIS SYNTAX WINDOW, CLICK ON "RUN ALL"');
      writeln(F);
      writeln(F,' GET DATA  /TYPE = TXT');
      writeln(F,' /FILE = ''', str, '''');
      writeln(F,' /DELCASE = LINE');
      writeln(F,' /DELIMITERS = "\t"');
      writeln(F,' /ARRANGEMENT = DELIMITED');
      writeln(F,' /FIRSTCASE = 2');
      writeln(F,' /IMPORTCASE = ALL');
      writeln(F,' /VARIABLES =');
      writeln(F,' r_seed F8.2');
      writeln(F,' n_agents F4.2');
      writeln(F,' w_width F2.2');
      writeln(F,' w_height F2.2');
      writeln(F,' n_cycles F3.2');
      writeln(F,' flat F1.2');
      writeln(F,' pd_game F1.2');
      writeln(F,' ca_game F1.2');
      writeln(F,' bold F2.2');
      writeln(F,' veng F2.2');
      writeln(F,' grat F2.2');
      writeln(F,' remb F2.2');
      writeln(F,' die_af_r F2.2');
      writeln(F,' age F2.2');
      writeln(F,' age_std F1.2');
      writeln(F,' repro F2.2');
      writeln(F,' repr_std F2.2');
      writeln(F,' rec_rel F1.2');
      writeln(F,' sexual F1.2');
      writeln(F,' mutation F2.2');
      writeln(F,' malthus1 F2.2');
      writeln(F,' malthus2 F2.2');
      writeln(F,' trust F3.2');
      writeln(F,' gossip F3.2');
      writeln(F,' move_rd F3.2');
      writeln(F,' best_ngb F3.2');
      writeln(F,' DC F3.2');
      writeln(F,' CC F3.2');
      writeln(F,' DD F3.2');
      writeln(F,' CD F3.2');
      writeln(F,' cost_c F3.2');
      writeln(F,' soc_gain F3.2');
      writeln(F,' norms F3.2');
      writeln(F,' metanorm F3.2');
      writeln(F,' vsion_ca F3.2');
      writeln(F,' cost_pun F3.2');
      writeln(F,' cost_bp F3.2');
      writeln(F,' inh_rel F3.2');
      writeln(F,' inh_soc F3.2');
      writeln(F,' av_wealt F7.2');
      writeln(F,' std_weal F6.2');
      writeln(F,' av_bld_s F5.2');
      writeln(F,' av_vg_s F5.2');
      writeln(F,' av_gt_s F5.2');
      writeln(F,' av_rb_s F5.2');
      writeln(F,' av_bld_r F5.2');
      writeln(F,' av_vg_r F5.2');
      writeln(F,' av_gt_r F5.2');
      writeln(F,' av_rb_r F5.2');
      writeln(F,' CC_in_PD F5.2');
      writeln(F,' DD_in_PD F5.2');
      writeln(F,' C_in_CA F5.2');
      writeln(F,' .');
      writeln(F);
      writeln(F,'COMPUTE density = n_agents / (w_width * w_height) .');
      writeln(F,'EXECUTE .');
      writeln(F);
      writeln(F,'var labels');
      writeln(F,'r_seed "Random Seed" ');
      writeln(F,'/  n_agents "Initial number of agents"');
      writeln(F,'/  w_width "World width" ');
      writeln(F,'/  w_height "World height" ');
      writeln(F,'/  n_cycles "Number of cycles" ');
      writeln(F,'/  flat "Flat world" ');
      writeln(F,'/  pd_game "Prisoner''s Dilemma" ');
      writeln(F,'/  ca_game "Collective Action" ');
      writeln(F,'/  bold "Average Boldness in first population" ');
      writeln(F,'/  veng "Average Vengefulness in first population"');
      writeln(F,'/  grat "Average Gratefulness in first population" ');
      writeln(F,'/  remb "Average Remembrance in first population" ');
      writeln(F,'/  age "Average Age of Death" ');
      writeln(F,'/  age_std "Std. Dev. of Age of Death" ');
      writeln(F,'/  repro "Average Age of Reproduction" ');
      writeln(F,'/  repr_std "Std. Dev. of Age of Reproduction" ');
      writeln(F,'/  die_af_r "Die after reproducing"');
      writeln(F,'/  rec_rel "Recognize Relatives" ');
      writeln(F,'/  sexual "Sexual Reproduction" ');
      writeln(F,'/  mutation "Mutation Rate" ');
      writeln(F,'/  malthus1 "Maximum percentage of occupied cells" ');
      writeln(F,'/  malthus2 "Percentage of mortality during Malthusian correction" ');
      writeln(F,'/  trust "Trust Game" ');
      writeln(F,'/  gossip "Gossip Game" ');
      writeln(F,'/  move_rd "Move randomly" ');
      writeln(F,'/  best_ngb "Towards the best neighbor"');
      writeln(F,'/  DC "Payoff for DC" ');
      writeln(F,'/  CC "Payoff for CC" ');
      writeln(F,'/  DD "Payoff for DD" ');
      writeln(F,'/  CD "Payoff for CD" ');
      writeln(F,'/  cost_c "Cost of cooperation" ');
      writeln(F,'/  soc_gain "Society gain with cooperation" ');
      writeln(F,'/  norms "Norms Game" ');
      writeln(F,'/  metanorm "Metanorms Game" ');
      writeln(F,'/  vsion_ca "Vision Range of Vigilant Agents in Collective Action" ');
      writeln(F,'/  cost_pun "Cost of Punishing a defector" ');
      writeln(F,'/  cost_bp "Cost of Being punished for defection" ');
      writeln(F,'/  inh_rel "Percentage of Wealth to Relatives" ');
      writeln(F,'/  inh_soc "Percentage of Wealth to the whole society" ');
      writeln(F,'/  av_wealt "Average Wealth" ');
      writeln(F,'/  std_weal "Std. Dev. from Average Wealth" ');
      writeln(F,'/  av_bld_s "Average Boldness towards strangers" ');
      writeln(F,'/  av_bld_r "Average Boldness towards relatives" ');
      writeln(F,'/  av_vg_s "Average Vengefulness towards strangers" ');
      writeln(F,'/  av_vg_r "Average Vengefulness towards relatives" ');
      writeln(F,'/  av_gt_s "Average Gratefulness towards strangers" ');
      writeln(F,'/  av_gt_r "Average Gratefulness towards relatives" ');
      writeln(F,'/  av_rb_s "Average Remembrance towards strangers" ');
      writeln(F,'/  av_rb_r "Average Remembrance towards relatives" ');
      writeln(F,'/  CC_in_PD "Proportion of CC in Prisoner''s Dilemma" ');
      writeln(F,'/  DD_in_PD "Proportion of DD in Prisoner''s Dilemma" ');
      writeln(F,'/  C_in_CA "Proportion of Cooperation in Collective Action"');
      writeln(F,'/  density "Population Density" .');
      writeln(F,'');
      writeln(F);
      CloseFile(F);
    end;
  if ShellExecute(0, Nil, summary_syntax, Nil, Nil, SW_NORMAL) < 33 then
    ShellExecute(0, Nil, 'Excel', summary_file, Nil, SW_NORMAL);
end;

procedure TOptionsForm.CheckBox2Click(Sender: TObject);
begin
  if CheckBox2.Checked then
    begin
      Edit9.Enabled := true;
      Edit10.Enabled := true;
      Label15.Enabled := true;
      Label16.Enabled := true;
    end else
    begin
      Edit9.Enabled := false;
      Edit10.Enabled := false;
      Label15.Enabled := false;
      Label16.Enabled := false;
    end;
end;

procedure TOptionsForm.CheckBox7Click(Sender: TObject);
begin
  if (CheckBox7.Checked = false) and (CheckBox15.Checked = false) then RadioButton7.Checked := true;
end;

procedure TOptionsForm.CheckBox15Click(Sender: TObject);
begin
  if (CheckBox7.Checked = false) and (CheckBox15.Checked = false) then RadioButton7.Checked := true;
end;

procedure FirstSetup;
var pdcaIni: TIniFile;
    first_time : boolean;
begin
  MainForm.Top := 0;
  MainForm.Left := 0;
  NewsForm.Top := MainForm.Height;
  NewsForm.Left := 0;
  HistoryForm.Top := MainForm.Height + NewsForm.Height - HistoryForm.Height;
  HistoryForm.Left := NewsForm.Width;
  WorldForm.Top := 0;
  WorldForm.Left := MainForm.Width;
  PopUpForm.Height := 440;
  OptionsForm.Label9.Caption := '(' + details_file + ')';
  OptionsForm.label12.Caption := '(' + summary_file + ')';
  OptionsForm.label31.Caption := '(' + one_cycle_file + ')';
  OptionsForm.ComboBox1.ItemIndex := 5;
  OptionsForm.ComboBox2.ItemIndex := 5;
  OptionsForm.ComboBox3.ItemIndex := 5;
  OptionsForm.ComboBox4.ItemIndex := 5;
  OptionsForm.ComboBox5.ItemIndex := 5;
  OptionsForm.ComboBox6.ItemIndex := 5;
  OptionsForm.ComboBox7.ItemIndex := 5;
  OptionsForm.ComboBox14.ItemIndex := 2;

  pdcaIni := TIniFile.Create(ExtractFileDir(Application.ExeName) + '\' + options_file);
  with pdcaIni do
    begin
      first_time := ReadBool('Init','first_time',true);
      world_width := ReadInteger('general','w_width',22);
      world_height := ReadInteger('general','w_height',22);
      initial_n_agents := ReadInteger('general','ini_n_agents',100);
      n_agents := initial_n_agents;
      delay_time := ReadInteger('general','delay',300);
      n_cycles := ReadInteger('general','n_cycles',1200);
      flat := ReadBool('general','flat',false);
      show_world := ReadBool('general','show_world',true);
      once_a_cycle := ReadBool('general','once_a_cycle',false);
      show_history := ReadBool('general','show_history',true);
      show_news := ReadBool('general','show_news',true);
      play_sound := ReadBool('general','play_sound',true);
      save_details := ReadBool('general','save_details',false);
      save_summary := ReadBool('general','save_summary',false);
      save_onecycle := ReadBool('general','save_onecycle',false);
      cycle_to_be_saved := ReadInteger('general','cycletosave',2);
      pd_only := ReadBool('general','pd_only',false);
      ca_only := ReadBool('general','ca_only',false);
      recognize_rel := ReadBool('general','recognize_rel',false);
      die_after_repro := ReadBool('general','die_after_repro',false);
      sexual := ReadBool('general','sexual',true);
      malthus_max := ReadInteger('general','malthus_max',50);
      malthus_rate := ReadInteger('general','malthus_rate',20);
      wealth_to_rel := ReadInteger('general','wealth_to_rel',0);
      wealth_to_socty := ReadInteger('general','wealth_to_socty',0);
      repro_age_av := ReadInteger('general','repro_age',25);
      repro_age_std := ReadInteger('general','repro_std',5);
      max_age_av := ReadInteger('general','age',60);
      max_age_std := ReadInteger('general','age_std',10);
      mutation_rate_STR := ReadString('general','mutation','0.02');
      trust_game := ReadBool('pd','trust_game',true);
      move_randomly := ReadBool('pd','move_rand',false);
      intentional_move := ReadBool('pd','intentional',true);
      towards_the_best := ReadBool('pd','t_best',true);
      avoiding_the_worst := ReadBool('pd','av_worst',true);
      DC := ReadInteger('pd','DC',5);
      CC := ReadInteger('pd','CC',3);
      DD := ReadInteger('pd','DD',0);
      CD := ReadInteger('pd','CD',-3);
      refusal_payoff := ReadInteger('pd','ref_pay',-7);
      boldness_av := ReadInteger('pd','bold',50);
      vengefulness_av := ReadInteger('pd','veng',50);
      gratefulness_av := ReadInteger('pd','grat',50);
      remembrance_av := ReadInteger('pd','remb',50);
      norms := ReadBool('ca','norms',true);
      metanorms := ReadBool('ca','metanorms',true);
      cost_coop := ReadInteger('ca','cost_coop',4);
      socty_gain := ReadInteger('ca','socty_gain',6);
      vigilant_vr := ReadInteger('ca','v_vr',2);
      punishment := ReadInteger('ca','punishment',4);
      enf_c := ReadInteger('ca','enf_c',3);
      NewAgentForm.ComboBox1.ItemIndex := ReadInteger('NewAgent','bold',5);
      NewAgentForm.ComboBox2.ItemIndex := ReadInteger('NewAgent','veng',5);
      NewAgentForm.ComboBox3.ItemIndex := ReadInteger('NewAgent','grat',5);
      NewAgentForm.ComboBox4.ItemIndex := ReadInteger('NewAgent','remb',5);
    end;
  pdcaIni.Free;
  if first_time then
    begin
      AboutBox.ShowModal;
      ShowMessage('If you need help to understand something, please press the key "F1".');
    end;
  ChangesCancelation;
  OptionsForm.OKButton.Click;
  Setup;
  MainForm.RunButton.SetFocus;
  show_Cl1 := true;
end;

procedure TOptionsForm.CancelButtonClick(Sender: TObject);
begin
  Close;
end;

procedure TOptionsForm.CheckBox18Click(Sender: TObject);
begin
  if CheckBox18.Checked then
    begin
      Edit5.Visible := true;
      Edit25.Visible := true;
      Label13.Visible := true;
    end else
    begin
      Edit5.Visible := false;
      Edit25.Visible := false;
      Label13.Visible := false;
    end;
end;

procedure TOptionsForm.FormClose(Sender: TObject;
  var Action: TCloseAction);
begin
  ChangesCancelation;
end;

procedure TOptionsForm.CheckBox19Click(Sender: TObject);
begin
  if CheckBox19.Checked then
    begin
      Edit26.Visible := true;
      Label32.Visible := true;
    end else
    begin
      Edit26.Visible := false;
      Label32.Visible := false;
    end;
end;

procedure TOptionsForm.BtOpenCycleClick(Sender: TObject);
var str : string;
begin
  if not FileExists(one_cycle_file) then
    begin
      ShowMessage('The file ' + one_cycle_file + ' doesn''t exist.');
      exit;
    end;
  if not FileExists(one_cycle_syntax) then
    begin
      str := GetCurrentDir + '\' + one_cycle_file;
      AssignFile(F, one_cycle_syntax);
      Rewrite(F);
      writeln(F,' *THIS SYNTAX WAS WRITTEN FOR SPSS 10.0');
      writeln(F,' *IN THE MAIN MENU OF THIS SYNTAX WINDOW, CLICK ON "RUN ALL"');
      writeln(F);
      writeln(F, 'GET DATA  /TYPE = TXT');
      writeln(F, ' /FILE = ''', str, '''');
      writeln(F, ' /DELCASE = LINE');
      writeln(F, ' /DELIMITERS = ";"');
      writeln(F, ' /ARRANGEMENT = DELIMITED');
      writeln(F, ' /FIRSTCASE = 2');
      writeln(F, ' /IMPORTCASE = ALL');
      writeln(F, ' /VARIABLES =');
      writeln(F, ' agent F2.2');
      writeln(F, ' age F2.2');
      writeln(F, ' wealth F8.2');
      writeln(F, ' bold_str F1.2');
      writeln(F, ' bold_rel F1.2');
      writeln(F, ' veng_str F1.2');
      writeln(F, ' veng_rel F1.2');
      writeln(F, ' grat_str F1.2');
      writeln(F, ' grat_rel F1.2');
      writeln(F, ' remb_str F1.2');
      writeln(F, ' remb_rel F1.2');
      writeln(F, ' .');
      writeln(F);
      writeln(F, 'Var labels');
      writeln(F, ' agent "Agent number"');
      writeln(F, '/age "Age"');
      writeln(F, '/wealth "Wealth"');
      writeln(F, '/bold_str "Boldness towards strangers"');
      writeln(F, '/bold_rel "Boldness towards relatives"');
      writeln(F, '/veng_str "Vengefulness towards strangers"');
      writeln(F, '/veng_rel "Vengefulness towards relatives"');
      writeln(F, '/grat_str "Gratefulness towards strangers"');
      writeln(F, '/grat_rel "Gratefulness towards relatives"');
      writeln(F, '/remb_str "Remembrance towards strangers"');
      writeln(F, '/remb_rel "Remembrance towards relatives"');
      writeln(F, '.');
      writeln(F);
      writeln(F, 'COMPUTE wealth = (wealth / 100000) / age .');
      writeln(F, 'EXECUTE .');
      writeln(F);
      CloseFile(F);
    end;
  if ShellExecute(0, Nil, one_cycle_syntax, Nil, Nil, SW_NORMAL) < 33 then
    ShellExecute(0, Nil, 'Excel', one_cycle_file, Nil, SW_NORMAL);
end;

end.

