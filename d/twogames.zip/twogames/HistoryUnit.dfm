object HistoryForm: THistoryForm
  Left = 192
  Top = 270
  HelpContext = 30
  BorderStyle = bsDialog
  Caption = 'History'
  ClientHeight = 272
  ClientWidth = 559
  Color = clBlack
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWhite
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  FormStyle = fsStayOnTop
  OldCreateOrder = False
  OnClose = FormClose
  PixelsPerInch = 96
  TextHeight = 13
  object Shape1: TShape
    Left = 24
    Top = 95
    Width = 504
    Height = 154
    Brush.Style = bsClear
    Pen.Color = clWhite
  end
  object Label1: TLabel
    Left = 12
    Top = 244
    Width = 6
    Height = 13
    Caption = '0'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
  end
  object Label2: TLabel
    Left = 8
    Top = 88
    Width = 12
    Height = 13
    Caption = '10'
  end
  object CycleLabel: TLabel
    Left = 264
    Top = 256
    Width = 26
    Height = 13
    Caption = 'Cycle'
  end
  object n_cyclesLabel: TLabel
    Left = 512
    Top = 256
    Width = 24
    Height = 13
    Caption = '0000'
  end
  object Label10: TLabel
    Left = 536
    Top = 88
    Width = 6
    Height = 13
    Caption = '1'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
  end
  object Label11: TLabel
    Left = 536
    Top = 240
    Width = 6
    Height = 13
    Caption = '0'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
  end
  object SeeHistoryButton: TButton
    Left = 432
    Top = 8
    Width = 98
    Height = 25
    Caption = 'Plot History Again'
    Enabled = False
    TabOrder = 0
    OnClick = SeeHistoryButtonClick
  end
  object CheckBox1: TCheckBox
    Left = 168
    Top = 8
    Width = 153
    Height = 17
    Caption = 'Boldness towards relatives'
    Checked = True
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clAqua
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
    State = cbChecked
    TabOrder = 1
  end
  object CheckBox2: TCheckBox
    Left = 8
    Top = 8
    Width = 153
    Height = 17
    Caption = 'Boldness towards strangers'
    Checked = True
    Font.Charset = DEFAULT_CHARSET
    Font.Color = 16750899
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
    State = cbChecked
    TabOrder = 2
  end
  object CheckBox3: TCheckBox
    Left = 168
    Top = 24
    Width = 145
    Height = 17
    Caption = 'Vengefulness towards rel.'
    Checked = True
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clYellow
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
    State = cbChecked
    TabOrder = 3
  end
  object CheckBox4: TCheckBox
    Left = 8
    Top = 24
    Width = 145
    Height = 17
    Caption = 'Vengefulness towards str.'
    Checked = True
    Font.Charset = DEFAULT_CHARSET
    Font.Color = 6737151
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
    State = cbChecked
    TabOrder = 4
  end
  object CheckBox5: TCheckBox
    Left = 168
    Top = 56
    Width = 113
    Height = 17
    Caption = 'Remembrance t. rel.'
    Checked = True
    Font.Charset = DEFAULT_CHARSET
    Font.Color = 6750054
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
    State = cbChecked
    TabOrder = 5
  end
  object CheckBox6: TCheckBox
    Left = 8
    Top = 56
    Width = 113
    Height = 17
    Caption = 'Remembrance t. str.'
    Checked = True
    Font.Charset = DEFAULT_CHARSET
    Font.Color = 52224
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
    State = cbChecked
    TabOrder = 6
  end
  object CheckBox8: TCheckBox
    Left = 344
    Top = 40
    Width = 81
    Height = 17
    Caption = 'Coop. in CA'
    Checked = True
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clRed
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
    State = cbChecked
    TabOrder = 7
  end
  object CheckBox9: TCheckBox
    Left = 344
    Top = 24
    Width = 70
    Height = 17
    Caption = 'DD in PD'
    Checked = True
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clSilver
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
    State = cbChecked
    TabOrder = 8
  end
  object CheckBox10: TCheckBox
    Left = 344
    Top = 8
    Width = 70
    Height = 17
    Caption = 'CC in PD'
    Checked = True
    State = cbChecked
    TabOrder = 9
  end
  object CheckBox11: TCheckBox
    Left = 8
    Top = 40
    Width = 97
    Height = 17
    Caption = 'Gratefulness t. str.'
    Checked = True
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clFuchsia
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
    State = cbChecked
    TabOrder = 10
  end
  object CheckBox12: TCheckBox
    Left = 168
    Top = 40
    Width = 145
    Height = 17
    Caption = 'Gratefulness towards rel.'
    Checked = True
    Font.Charset = DEFAULT_CHARSET
    Font.Color = 15636940
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
    State = cbChecked
    TabOrder = 11
  end
end
