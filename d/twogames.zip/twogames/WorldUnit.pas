unit WorldUnit;

interface

uses
  Windows, Messages, Math, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  Menus, ComCtrls;

type
  TWorldForm = class(TForm)
    PopupMenuWorld: TPopupMenu;
    Delay: TMenuItem;
    N101: TMenuItem;
    N201: TMenuItem;
    N501: TMenuItem;
    N1001: TMenuItem;
    N2001: TMenuItem;
    N3001: TMenuItem;
    N6001: TMenuItem;
    N1002: TMenuItem;
    N01: TMenuItem;
    Color1: TMenuItem;
    BoldnessxVengefulness1: TMenuItem;
    RemembrancexGratefulness1: TMenuItem;
    StatusBar1: TStatusBar;
    procedure FormMouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure FormMouseUp(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormShow(Sender: TObject);
    procedure N101Click(Sender: TObject);
    procedure N201Click(Sender: TObject);
    procedure N501Click(Sender: TObject);
    procedure N1001Click(Sender: TObject);
    procedure N2001Click(Sender: TObject);
    procedure N3001Click(Sender: TObject);
    procedure N6001Click(Sender: TObject);
    procedure N1002Click(Sender: TObject);
    procedure N01Click(Sender: TObject);
    procedure BoldnessxVengefulness1Click(Sender: TObject);
    procedure RemembrancexGratefulness1Click(Sender: TObject);
    procedure PopupMenuWorldPopup(Sender: TObject);
    procedure FormMouseMove(Sender: TObject; Shift: TShiftState; X,
      Y: Integer);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WorldForm: TWorldForm;
  Mouse_Down, Mouse_Up : TPoint;
  main_pause_working, MenuWorld_working: boolean;
implementation

uses Main, PopUpUnit, OptionsUnit, NewAgentUnit;

{$R *.DFM}

procedure Draw_Obstacle(i,j:integer);
begin
  WorldForm.Canvas.Brush.Color := clBlue;
  if (world[i,j] = 0) then
    begin
      WorldForm.Canvas.Pen.Color := clBlack;
      WorldForm.Canvas.Brush.Color := clBlue;
      world[i,j] := 1;
      WorldForm.Canvas.Rectangle((i*ag_size - ag_size + 3),(j*ag_size - ag_size + 3),(i*ag_size + 3),(j*ag_size + 3));
    end else if (world[i,j] = 1) then
    begin
      WorldForm.Canvas.Pen.Color := clBlack;
      WorldForm.Canvas.Brush.Color := clBlack;
      world[i,j] := 0;
      WorldForm.Canvas.Rectangle((i*ag_size - ag_size + 3),(j*ag_size - ag_size + 3),(i*ag_size + 3),(j*ag_size + 3));
    end;
end;

procedure Create_Obstacles(i,j,k,l:integer);
var m : integer;
begin
  if k < i then
    begin
      m := i;
      i := k;
      k := m;
    end;
  if l < j then
    begin
      m := j;
      j := l;
      l := m;
    end;
  for m := i to k do Draw_Obstacle(m,j);
  if j <> l then for m := i to k do Draw_Obstacle(m,l);
  j := j + 1;
  l := l - 1;
  for m := j to l do Draw_Obstacle(i,m);
  if i <> k then for m := j to l do Draw_Obstacle(k,m);
end;

procedure Create_New_Agent(i,j:integer);
var g, k, k2, ij : integer;
begin
  if world[i,j] = 0 then
    begin
      ij := 1;
      repeat ij := ij + 1; until agent[ij].Cl = 0;
      world[i,j] := ij;
      agent[ij].x := i;
      agent[ij].y := j;
      ID := ID + 1;
      agent[ij].ID := ID;
      agent[ij].p1ID := ID + 100000;
      agent[ij].p2ID := ID + 100000;
      agent[ij].gp1ID  := ID + 110000;
      agent[ij].gp2ID := ID + 110000;
      agent[ij].gp3ID := ID + 130000;
      agent[ij].gp4ID := ID + 130000;
      agent[ij].age := 1;
      repeat agent[ij].repro_age := round(randG(repro_age_av, repro_age_std)) until (agent[ij].repro_age > 1) and (agent[ij].repro_age >= (repro_age_av - repro_age_std)) and (agent[ij].repro_age <= (repro_age_av + repro_age_std));
      agent[ij].reproduced := false;
      repeat agent[ij].death := round(randG(max_age_av, max_age_std)) until (agent[ij].death > agent[ij].repro_age) and (agent[ij].death <= (max_age_av + max_age_std));
      for k := 1 to 10 do
        begin
          agent[ij].memo[k].ID := 0;
          for k2 := 1 to 10 do
            begin
              agent[ij].memo[k].payoff[k2] := -31;
              agent[ij].memo[k].date[k2] := 0;
            end;
        end;
      for g := 1 to 10 do
        begin
          agent[ij].gene.bold_st[g] := 0;
          agent[ij].gene.bold_rl[g] := 0;
          agent[ij].gene.veng_st[g] := 0;
          agent[ij].gene.veng_rl[g] := 0;
          agent[ij].gene.grat_st[g] := 0;
          agent[ij].gene.grat_rl[g] := 0;
          agent[ij].gene.remb_st[g] := 0;
          agent[ij].gene.veng_rl[g] := 0;
        end;
      for g := 1 to StrToInt(NewAgentForm.ComboBox2.Text) do
        begin
          agent[ij].gene.veng_rl[g] := 1;
          agent[ij].gene.veng_st[g] := 1;
        end;
      for g := 1 to StrToInt(NewAgentForm.ComboBox1.Text) do
        begin
          agent[ij].gene.bold_rl[g] := 1;
          agent[ij].gene.bold_st[g] := 1;
        end;
      for g := 1 to StrToInt(NewAgentForm.combobox3.Text) do
        begin
          agent[ij].gene.grat_rl[g] := 1;
          agent[ij].gene.grat_st[g] := 1;
        end;
      for g := 1 to StrToInt(NewAgentForm.combobox4.Text) do
        begin
          agent[ij].gene.remb_rl[g] := 1;
          agent[ij].gene.remb_st[g] := 1;
        end;
      What_Color(ij);
      WorldForm.Canvas.Pen.Color := clBlack;
      if show_Cl1 then WorldForm.Canvas.Brush.Color := agent[ij].Cl else WorldForm.Canvas.Brush.Color := agent[ij].Cl2;
      WorldForm.Canvas.Ellipse((i*ag_size - ag_size + 3),(j*ag_size - ag_size + 3),(i*ag_size + 3),(j*ag_size + 3));
      n_agents := n_agents + 1;
    end;
end;

procedure PopUp_Information(i,j:integer);
var g, h, r, xy : integer;
    found : boolean;
begin
  if world[i,j] > 1 then
    begin
      i := world[i,j];
      if not PopUpForm.Visible then PopUpForm.Show;
      PopUpForm.RichEdit1.SetFocus;
      with PopUpForm.RichEdit1 do
        begin
          Clear;
          SelAttributes.Style := SelAttributes.Style + [fsBold];
          SelText := 'x,y: ';
          SelAttributes.Style := SelAttributes.Style - [fsBold];
          SelText := '(' + IntToStr(agent[i].x) + ', ' + IntToStr(agent[i].y) + ')';
          Lines.Add('');
          Lines.Add('');
          SelAttributes.Style := SelAttributes.Style + [fsBold];
          SelText := 'ID: ';
          SelAttributes.Style := SelAttributes.Style - [fsBold];
          SelText := IntToStr(agent[i].ID);
          Lines.Add('');
          if sexual then
            begin
              SelAttributes.Style := SelAttributes.Style + [fsBold];
              SelText := '  p1_ID: ';
              SelAttributes.Style := SelAttributes.Style - [fsBold];
              SelText := IntToStr(agent[i].p1ID);
              Lines.Add('');
              SelAttributes.Style := SelAttributes.Style + [fsBold];
              SelText := '  p2_ID: ';
              SelAttributes.Style := SelAttributes.Style - [fsBold];
              SelText := IntToStr(agent[i].p2ID);
              Lines.Add('');
              SelAttributes.Style := SelAttributes.Style + [fsBold];
              SelText := '  gp1_ID: ';
              SelAttributes.Style := SelAttributes.Style - [fsBold];
              SelText := IntToStr(agent[i].gp1ID);
              Lines.Add('');
              SelAttributes.Style := SelAttributes.Style + [fsBold];
              SelText := '  gp2_ID: ';
              SelAttributes.Style := SelAttributes.Style - [fsBold];
              SelText := IntToStr(agent[i].gp2ID);
              Lines.Add('');
              SelAttributes.Style := SelAttributes.Style + [fsBold];
              SelText := '  gp3_ID: ';
              SelAttributes.Style := SelAttributes.Style - [fsBold];
              SelText := IntToStr(agent[i].gp3ID);
              Lines.Add('');
              SelAttributes.Style := SelAttributes.Style + [fsBold];
              SelText := '  gp4_ID: ';
              SelAttributes.Style := SelAttributes.Style - [fsBold];
              SelText := IntToStr(agent[i].gp4ID);
              Lines.Add('');
            end else
            begin
              SelAttributes.Style := SelAttributes.Style + [fsBold];
              SelText := '  p_ID: ';
              SelAttributes.Style := SelAttributes.Style - [fsBold];
              SelText := IntToStr(agent[i].p1ID);
              Lines.Add('');
              SelAttributes.Style := SelAttributes.Style + [fsBold];
              SelText := '  gp1_ID: ';
              SelAttributes.Style := SelAttributes.Style - [fsBold];
              SelText := IntToStr(agent[i].gp1ID);
              Lines.Add('');
              SelAttributes.Style := SelAttributes.Style + [fsBold];
              SelText := '  gp2_ID: ';
              SelAttributes.Style := SelAttributes.Style - [fsBold];
              SelText := IntToStr(agent[i].gp3ID);
              Lines.Add('');
            end;
          SelAttributes.Style := SelAttributes.Style + [fsBold];
          SelText := 'Age: ';
          SelAttributes.Style := SelAttributes.Style - [fsBold];
          SelText := IntToStr(agent[i].age);
          Lines.Add('');
          if ca_only = false then
            begin
              SelAttributes.Style := SelAttributes.Style + [fsBold];
              SelText := 'N. of PD Games played: ';
              SelAttributes.Style := SelAttributes.Style - [fsBold];
              SelText := IntToStr(agent[i].n_game);
              Lines.Add('');
            end;
          SelAttributes.Style := SelAttributes.Style + [fsBold];
          SelText := 'Wealth: ';
          SelAttributes.Style := SelAttributes.Style - [fsBold];
          SelText := FloatToStrF(agent[i].wealth, ffFixed,9,2);
          Lines.Add('');
          SelAttributes.Style := SelAttributes.Style + [fsBold];
          SelText := 'Genetic Code: ';
          Lines.Add('');
          SelText := '  Bold. Str.: ';
          SelAttributes.Style := SelAttributes.Style - [fsBold];
          for g := 1 to 10 do SelText := IntToStr(agent[i].gene.bold_st[g]);
          Lines.Add('');
          if (ca_only and norms) or (ca_only = false) then
            begin
              SelAttributes.Style := SelAttributes.Style + [fsBold];
              SelText := '  Veng. Str.: ';
              SelAttributes.Style := SelAttributes.Style - [fsBold];
              for g := 1 to 10 do SelText := IntToStr(agent[i].gene.veng_st[g]);
              Lines.Add('');
            end;
          if ca_only = false then
            begin
              SelAttributes.Style := SelAttributes.Style + [fsBold];
              SelText := '  Remb. Str.: ';
              SelAttributes.Style := SelAttributes.Style - [fsBold];
              for g := 1 to 10 do SelText := IntToStr(agent[i].gene.remb_st[g]);
              Lines.Add('');
              SelAttributes.Style := SelAttributes.Style + [fsBold];
              SelText := '  Grat. Str.: ';
              SelAttributes.Style := SelAttributes.Style - [fsBold];
              for g := 1 to 10 do SelText := IntToStr(agent[i].gene.grat_st[g]);
              Lines.Add('');
            end;
          if recognize_rel then
            begin
              SelAttributes.Style := SelAttributes.Style + [fsBold];
              SelText := '  Bold. Rel.: ';
              SelAttributes.Style := SelAttributes.Style - [fsBold];
              for g := 1 to 10 do SelText := IntToStr(agent[i].gene.bold_rl[g]);
              Lines.Add('');
              if (ca_only and norms) or (ca_only = false) then
                begin
                  SelAttributes.Style := SelAttributes.Style + [fsBold];
                  SelText := '  Veng. Rel.: ';
                  SelAttributes.Style := SelAttributes.Style - [fsBold];
                  for g := 1 to 10 do SelText := IntToStr(agent[i].gene.veng_rl[g]);
                  Lines.Add('');
                end;
              if ca_only = false then
                begin
                  SelAttributes.Style := SelAttributes.Style + [fsBold];
                  SelText := '  Remb. Rel.: ';
                  SelAttributes.Style := SelAttributes.Style - [fsBold];
                  for g := 1 to 10 do SelText := IntToStr(agent[i].gene.remb_rl[g]);
                  Lines.Add('');
                  SelAttributes.Style := SelAttributes.Style + [fsBold];
                  SelText := '  Grat. Rel.: ';
                  SelAttributes.Style := SelAttributes.Style - [fsBold];
                  for g := 1 to 10 do SelText := IntToStr(agent[i].gene.grat_rl[g]);
                  Lines.Add('');
                end;
            end;
          if ca_only = false then
            begin
              SelAttributes.Style := SelAttributes.Style + [fsBold];
              SelText := 'Memory: ';
              Lines.Add('');
              SelAttributes.Style := SelAttributes.Style - [fsBold];
              SelText := '  ID   Payoffs';
              for g := 1 to 10 do if (agent[i].memo[g].ID > 0) then
                begin
                  Lines.Add('  ');
                  xy := 1;
                  found := false;
                  repeat
                    xy := xy + 1;
                    if (agent[xy].Cl > 1) and (agent[xy].ID = agent[i].memo[g].ID) then found := true;
                  until (found = true) or (xy = area);
                  if xy = area then r := 3 else r := Are_Agents_Relatives(i,xy);
                  case r of
                    0 : SelAttributes.Color := clRed;
                    1 : SelAttributes.Color := clGreen;
                    2 : SelAttributes.Color := clBlue;
                    3 : SelAttributes.Color := clBlack;
                  end;
                  SelText := IntToStr(agent[i].memo[g].ID) + '  ';
                  SelAttributes.Color := clBlack;
                  for h := 1 to 10 do if ((agent[i].memo[g].payoff[h]) > -31) then
                   SelText := IntToStr(agent[i].memo[g].payoff[h]) + ', ';
                end;
              Lines.Add(' ');
              SelAttributes.Size := 8;
              Lines.Add('  ');
              SelAttributes.Style := SelAttributes.Style + [fsUnderline];
              SelText := 'Color legend';
              SelAttributes.Style := SelAttributes.Style - [fsUnderline];
              SelText := ':';
              SelAttributes.Color := clRed; Lines.Add('    strangers');
              SelAttributes.Color := clGreen; Lines.Add('    close relatives');
              SelAttributes.Color := clBlue; Lines.Add('    more distant relatives');
              SelAttributes.Color := clBlack; Lines.Add('    unknown (already dead)');
              SelAttributes.Size := 9;
              Lines.Add(' ');
            end;
        end;
  end;
end;

procedure TWorldForm.FormMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  GetCursorPos(Mouse_Down);
  if pause_now = false then
    begin
      pause_now := true;
      main_pause_working := false;
    end else main_pause_working := true;
end;

procedure TWorldForm.FormMouseUp(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
var i, j, k, l : integer;
begin
  if MenuWorld_working = false then
    begin
      GetCursorPos(Mouse_Up);
      i := round((Mouse_Down.x - WorldForm.Left - 2)/ ag_size);
      j := round((Mouse_Down.y - WorldForm.Top - 22)/ ag_size);
      k := round((Mouse_Up.x - WorldForm.Left - 2)/ ag_size);
      l := round((Mouse_Up.y - WorldForm.Top - 22)/ ag_size);
      if (i >= 1) and (i <= world_width) and (j >= 1) and (j <= world_height) then
        if (k >= 1) and (k <= world_width) and (l >= 1) and (l <= world_height) then
          if creating_obstacles then Create_Obstacles(i,j,k,l) else
            if creating_new_agent then Create_New_Agent(k,l) else PopUp_Information(k,l);
    end;
  if main_pause_working = false then pause_now := false;
  MenuWorld_working := false;
end;

procedure TWorldForm.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  if creating_obstacles then MainForm.ObstacleButton.Click;
  if creating_new_agent then MainForm.NewAgentButton.Click;
  MainForm.MenuWorld.Click;
end;

procedure TWorldForm.FormShow(Sender: TObject);
begin
  if (Screen.Width - MainForm.Left - MainForm.Width) > WorldForm.Width then
    WorldForm.Left := MainForm.Left + MainForm.Width;
  WorldForm.Top := 0;
end;

procedure TWorldForm.N01Click(Sender: TObject);
begin
  WorldForm.N01.Checked := true;
  OptionsForm.ComboBox1.ItemIndex := 0;
  delay_time := 0;
end;

procedure TWorldForm.N101Click(Sender: TObject);
begin
  WorldForm.N101.Checked := true;
  OptionsForm.ComboBox1.ItemIndex := 1;
  delay_time := StrToInt(OptionsForm.ComboBox1.Text);
end;

procedure TWorldForm.N201Click(Sender: TObject);
begin
  WorldForm.N201.Checked := true;
  OptionsForm.ComboBox1.ItemIndex := 2;
  delay_time := StrToInt(OptionsForm.ComboBox1.Text);
end;

procedure TWorldForm.N501Click(Sender: TObject);
begin
  WorldForm.N501.Checked := true;
  OptionsForm.ComboBox1.ItemIndex := 3;
  delay_time := StrToInt(OptionsForm.ComboBox1.Text);
end;

procedure TWorldForm.N1001Click(Sender: TObject);
begin
  WorldForm.N1001.Checked := true;
  OptionsForm.ComboBox1.ItemIndex := 4;
  delay_time := StrToInt(OptionsForm.ComboBox1.Text);
end;

procedure TWorldForm.N2001Click(Sender: TObject);
begin
  WorldForm.N2001.Checked := true;
  OptionsForm.ComboBox1.ItemIndex := 5;
  delay_time := StrToInt(OptionsForm.ComboBox1.Text);
end;

procedure TWorldForm.N3001Click(Sender: TObject);
begin
  WorldForm.N3001.Checked := true;
  OptionsForm.ComboBox1.ItemIndex := 6;
  delay_time := StrToInt(OptionsForm.ComboBox1.Text);
end;

procedure TWorldForm.N6001Click(Sender: TObject);
begin
  WorldForm.N6001.Checked := true;
  OptionsForm.ComboBox1.ItemIndex := 7;
  delay_time := StrToInt(OptionsForm.ComboBox1.Text);
end;

procedure TWorldForm.N1002Click(Sender: TObject);
begin
  WorldForm.N1002.Checked := true;
  OptionsForm.ComboBox1.ItemIndex := 8;
  delay_time := StrToInt(OptionsForm.ComboBox1.Text);
end;


procedure TWorldForm.BoldnessxVengefulness1Click(Sender: TObject);
begin
  WorldForm.BoldnessxVengefulness1.Checked := true;
  OptionsForm.CheckBox17.Checked := true;
  show_Cl1 := true;
  ShowWorld;
end;

procedure TWorldForm.RemembrancexGratefulness1Click(Sender: TObject);
begin
  WorldForm.RemembrancexGratefulness1.Checked := true;
  OptionsForm.CheckBox17.Checked := false;
  show_Cl1 := false;
  ShowWorld;
end;

procedure TWorldForm.PopupMenuWorldPopup(Sender: TObject);
begin
  MenuWorld_working := true;
end;

procedure TWorldForm.FormMouseMove(Sender: TObject; Shift: TShiftState; X,
  Y: Integer);
var p1 : TPoint;
begin
  GetCursorPos(p1);
  p1.x := round((p1.x - WorldForm.Left - 2)/ ag_size);
  p1.y := round((p1.y - WorldForm.Top - 22)/ ag_size);
  StatusBar1.SimpleText := '(' +  IntToStr(p1.x) + ',' + IntToStr(p1.y) + ')';
end;

end.
