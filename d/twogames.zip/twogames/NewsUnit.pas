unit NewsUnit;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ExtCtrls, TeeProcs, TeEngine, Chart, Series, StdCtrls;

type
  TNewsForm = class(TForm)
    Label8: TLabel;
    Label9: TLabel;
    Edit1: TEdit;       
    Edit2: TEdit;
    Image1: TImage;
    Label1: TLabel;
    Label2: TLabel;
    Label33: TLabel;
    Label6: TLabel;
    Label10: TLabel;
    Label14: TLabel;
    Label15: TLabel;
    Label18: TLabel;
    Label20: TLabel;
    Label21: TLabel;
    Label22: TLabel;
    Label23: TLabel;
    Label24: TLabel;
    Label25: TLabel;
    Label26: TLabel;
    Label27: TLabel;
    HelpButton: TButton;
    Label31: TLabel;
    Label32: TLabel;
    Label34: TLabel;
    Label16: TLabel;
    Label17: TLabel;
    Label30: TLabel;
    Label3: TLabel;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure HelpButtonClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  NewsForm: TNewsForm;

implementation

uses MAIN;

{$R *.DFM}

procedure TNewsForm.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  MainForm.MenuNews.Click;
end;

procedure TNewsForm.HelpButtonClick(Sender: TObject);
begin
  Application.HelpContext(11);
end;

end.
