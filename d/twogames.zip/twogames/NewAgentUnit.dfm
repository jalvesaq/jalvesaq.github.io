object NewAgentForm: TNewAgentForm
  Left = 254
  Top = 109
  BorderStyle = bsDialog
  Caption = 'New Agent'
  ClientHeight = 143
  ClientWidth = 129
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  FormStyle = fsStayOnTop
  OldCreateOrder = False
  OnResize = FormResize
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object Label2: TLabel
    Left = 8
    Top = 36
    Width = 64
    Height = 13
    Caption = 'Vengefulness'
  end
  object Label1: TLabel
    Left = 29
    Top = 12
    Width = 43
    Height = 13
    Caption = 'Boldness'
  end
  object Label3: TLabel
    Left = 13
    Top = 60
    Width = 59
    Height = 13
    Caption = 'Gratefulness'
  end
  object Label4: TLabel
    Left = 3
    Top = 84
    Width = 69
    Height = 13
    Caption = 'Remembrance'
  end
  object DoneButton: TButton
    Left = 37
    Top = 112
    Width = 55
    Height = 25
    Caption = 'Done'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 4
    OnClick = DoneButtonClick
  end
  object ComboBox2: TComboBox
    Left = 80
    Top = 32
    Width = 41
    Height = 21
    Style = csDropDownList
    ItemHeight = 13
    TabOrder = 1
    Items.Strings = (
      '0'
      '1'
      '2'
      '3'
      '4'
      '5'
      '6'
      '7'
      '8'
      '9'
      '10')
  end
  object ComboBox1: TComboBox
    Left = 80
    Top = 8
    Width = 41
    Height = 21
    Style = csDropDownList
    ItemHeight = 13
    TabOrder = 0
    Items.Strings = (
      '0'
      '1'
      '2'
      '3'
      '4'
      '5'
      '6'
      '7'
      '8'
      '9'
      '10')
  end
  object ComboBox3: TComboBox
    Left = 80
    Top = 56
    Width = 41
    Height = 21
    Style = csDropDownList
    ItemHeight = 13
    TabOrder = 2
    Items.Strings = (
      '0'
      '1'
      '2'
      '3'
      '4'
      '5'
      '6'
      '7'
      '8'
      '9'
      '10')
  end
  object ComboBox4: TComboBox
    Left = 80
    Top = 80
    Width = 41
    Height = 21
    Style = csDropDownList
    ItemHeight = 13
    TabOrder = 3
    Items.Strings = (
      '0'
      '1'
      '2'
      '3'
      '4'
      '5'
      '6'
      '7'
      '8'
      '9'
      '10')
  end
end
