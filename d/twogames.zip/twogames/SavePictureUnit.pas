unit SavePictureUnit;

interface

uses
  Windows, SysUtils, Classes, Controls, Forms, ExtCtrls;

type
  TSavePictureForm = class(TForm)
    Image1: TImage;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  SavePictureForm: TSavePictureForm;

implementation

{$R *.DFM}

end.
