unit PopUpUnit;

interface

uses
  Windows, SysUtils, Classes, Graphics, Controls, Forms,
  StdCtrls, ComCtrls, Dialogs;

type
  TPopUpForm = class(TForm)
    CloseButton: TButton;
    RichEdit1: TRichEdit;
    procedure CloseButtonClick(Sender: TObject);
    procedure FormResize(Sender: TObject);
    procedure FormShow(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  PopUpForm: TPopUpForm;

implementation

uses WorldUnit, MAIN;

{$R *.DFM}

procedure TPopUpForm.CloseButtonClick(Sender: TObject);
begin
  PopUpForm.Close;
end;

procedure TPopUpForm.FormResize(Sender: TObject);
begin
  RichEdit1.Width := ClientWidth;
  RichEdit1.Height := ClientHeight;
  CloseButton.Top := 5;
  CloseButton.Left := 170;
end;

procedure TPopUpForm.FormShow(Sender: TObject);
begin
  if Screen.Width - (WorldForm.Left + WorldForm.Width) > PopUpForm.Width then
    begin
      Left := WorldForm.Left + WorldForm.Width;
      Top := WorldForm.Top
    end else
    begin
      Left := WorldForm.Left - PopUpForm.Width;
      if MainForm.Top > PopUpForm.Height then Top := 0 else
        Top := MainForm.Top + MainForm.Height;
    end;
end;

end.
