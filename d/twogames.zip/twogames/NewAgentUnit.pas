unit NewAgentUnit;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls;

type
  TNewAgentForm = class(TForm)
    DoneButton: TButton;
    Label2: TLabel;
    ComboBox2: TComboBox;
    Label1: TLabel;
    ComboBox1: TComboBox;
    Label3: TLabel;
    ComboBox3: TComboBox;
    Label4: TLabel;
    ComboBox4: TComboBox;
    procedure DoneButtonClick(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure FormResize(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  NewAgentForm: TNewAgentForm;

implementation

uses MAIN, WorldUnit;

{$R *.DFM}

procedure TNewAgentForm.DoneButtonClick(Sender: TObject);
begin
  creating_new_agent := false;
  NewAgentForm.Visible := false;
  WorldForm.Cursor := crCross;
  MainForm.NewAgentButton.Down := false;
  NewAgentForm.Close;
end;

procedure TNewAgentForm.FormShow(Sender: TObject);
begin
  if Screen.Width - (WorldForm.Left + WorldForm.Width) > NewAgentForm.Width then
    begin
      Left := WorldForm.Left + WorldForm.Width;
      Top := WorldForm.Top
    end else
    begin
      Left := WorldForm.Left - NewAgentForm.Width;
      if MainForm.Top > NewAgentForm.Height then Top := 0 else
        Top := MainForm.Top + MainForm.Height;
    end;
end;

procedure TNewAgentForm.FormResize(Sender: TObject);
begin
  DoneButton.Top := NewAgentForm.ClientHeight - 31;
end;

end.
