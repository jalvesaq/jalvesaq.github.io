# Este script replica os resultados de:

# ABREU, Domingos; AQUINO, Jakson Alves de.
# Contexto familiar e cumprimento da condicionalidade de frequência escolar
# no Programa Bolsa Família no Ceará.
# Educar em Revista, Curitiba, Brasil,
# v. 33, n. especial 2, p. 55-69, set. 2017.

# Necessário para algumas tabelas
library("descr")

## Carregar dados
load("Dados_entrevistas.RData")

d$nfilhos[is.na(d$nfilhos)] <- 2

d$temmarido[is.na(d$temmarido) & !is.na(d$esc.marido)] <- 1
d$temmarido[is.na(d$temmarido)] <- 0

d$ndoentes[is.na(d$ndoentes) & (is.na(d$doente.tratado) | d$doente.tratado == 0)] <- 0

d$menortrabalha <- 0
d$menortrabalha[!is.na(d$menor14trabalha) & d$menor14trabalha] <- 1
d$menortrabalha[!is.na(d$menor16trabalha) & d$menor16trabalha] <- 1
d$menortrabalha[!is.na(d$menor18trabalha) & d$menor18trabalha] <- 1
attr(d$menortrabalha, "label") <- "Há menor de idade trabalhando?"

d$tem.ajuda <- as.numeric(d$ajuda.tarefas | d$alguem.ajuda)
d$tem.ajuda[is.na(d$tem.ajuda)] <- 0
attr(d$tem.ajuda, "label") <- "Alguém ajuda nas tarefas escolares (entrevistada ou outra pessoa)"


## Resultados

freq(d$cumpre)

freq(d$entrev.trabalha)

## Tabela 1:
summary(d$npessoas)
summary(d$nfilhos)
summary(d$ncomodos)
summary(d$nbanheiros)
summary(d$renda.bolsafam)
summary(d$renda.total)

## Tabela 2:
crosstab(d$temmarido, d$cumpre, prop.c=TRUE, chisq=TRUE)
crosstab(d$menortrabalha, d$cumpre, prop.c=TRUE, chisq=TRUE)

## Comentário da Tabela 2:
with(d[!is.na(d$cumpre), ],
     freq(menortrabalha))

## Comentário da Tabela 3:
with(d[!is.na(d$cumpre), ],
     sum(nfilhos <= 2, na.rm = TRUE) / length(nfilhos))

## Tabela 3::
nf <- d$nfilhos
nf[nf > 5] <- 5
crosstab(nf, d$cumpre, prop.c=TRUE, chisq = TRUE)

## Comentário da tabela 4:
with(d[!is.na(d$cumpre), ],
     freq(conhece.dir))
with(d[!is.na(d$cumpre), ],
     freq(!is.na(progrm.esc)))

## Tabela 4::
crosstab(d$conhece.dir, d$cumpre, prop.c=TRUE, chisq=TRUE)
crosstab(d$progrm.esc, d$cumpre, prop.c=TRUE, chisq=TRUE)

## Comentário após a Tabela 4::
crosstab(d$conhece.profs, d$cumpre, prop.c=TRUE, chisq=TRUE)


## Comentários antes da Tabela 5::
x <- freq(d$esc.entrev[!is.na(d$cumpre)])
x <- cbind(x[1:14, ],
           "Acumulado C" = x[1:14, 3],
           "Acumulado D" = x[1:14, 3])
for(i in 2:nrow(x))
    x[i, 4] <- x[i-1, 4] + x[i, 4]
for(i in (nrow(x)-1):1)
    x[i, 5] <- x[i+1, 5] + x[i, 5]
x

with(d[!is.na(d$cumpre), ],
     freq(d$esc.mae.entrev))
with(d[!is.na(d$cumpre), ],
     freq(d$esc.pai.entrev))

## Tabela 5:
esc <- as.numeric(d$esc.entrev[!is.na(d$cumpre)]) - 1
esc[esc == 13] <- 15
mean(esc, na.rm=TRUE)
sd(esc, na.rm=TRUE)
esc <- as.numeric(d$esc.mae.entrev[!is.na(d$cumpre)]) - 1
esc[esc == 13] <- 15
mean(esc, na.rm=TRUE)
sd(esc, na.rm=TRUE)

## Tabela 6:
with(d[!is.na(d$cumpre), ],
     crosstab(cumpre, esc.entrev, prop.c=TRUE))

## Tabela 7:
with(d[!is.na(d$cumpre), ],
     crosstab(ajuda.tarefas, cumpre, prop.c=TRUE, chisq=TRUE))
with(d[!is.na(d$cumpre), ],
     crosstab(tem.ajuda, cumpre, prop.c=TRUE, chisq=TRUE))
