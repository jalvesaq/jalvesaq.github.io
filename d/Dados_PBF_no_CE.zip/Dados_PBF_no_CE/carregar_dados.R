# Este script converte o arquivo Dados_entrevistas.txt em
# DadosEntrevistas.RData. Ele é necessário apenas se houver dificuldade para
# leitura direta do Dados_entrevistas.RData ou do Dados_entrevistas.sav.

d <- read.delim("Dados_entrevistas.txt", quote = "", as.is = TRUE)

d$esc.entrev <- factor(d$esc.entrev, levels = 1:14,
  labels = c("0", "1f", "2f", "3f", "4f", "5f", "6f", "7f", "8f", "9f", "1m", "2m", "3m", "s"))
d$esc.marido <- factor(d$esc.marido, levels = 1:14,
  labels = c("0", "1f", "2f", "3f", "4f", "5f", "6f", "7f", "8f", "9f", "1m", "2m", "3m", "s"))
d$esc.mae.entrev <- factor(d$esc.mae.entrev, levels = 1:14,
  labels = c("0", "1f", "2f", "3f", "4f", "5f", "6f", "7f", "8f", "9f", "1m", "2m", "3m", "s"))
d$esc.pai.entrev <- factor(d$esc.pai.entrev, levels = 1:14,
  labels = c("0", "1f", "2f", "3f", "4f", "5f", "6f", "7f", "8f", "9f", "1m", "2m", "3m", "s"))
d$esc.mae.marido <- factor(d$esc.mae.marido, levels = 1:14,
  labels = c("0", "1f", "2f", "3f", "4f", "5f", "6f", "7f", "8f", "9f", "1m", "2m", "3m", "s"))
d$esc.pai.marido <- factor(d$esc.pai.marido, levels = 1:14,
  labels = c("0", "1f", "2f", "3f", "4f", "5f", "6f", "7f", "8f", "9f", "1m", "2m", "3m", "s"))
d$religiao.quem <- factor(d$religiao.quem, levels = 1:3,
  labels = c("e", "f", "fe"))
d$drogas.quem <- factor(d$drogas.quem, levels = 1:3,
  labels = c("e", "f", "fe"))
d$sexualdd.quem <- factor(d$sexualdd.quem, levels = 1:3,
  labels = c("e", "f", "fe"))
attr(d$cumpre, "label") <- "Cumpre as condicionalidades?"
attr(d$local, "label") <- "Local da entrevista (município)"
attr(d$npessoas, "label") <- "Sua família tem quantas pessoas em casa?"
attr(d$temmarido, "label") <- "Você vive maritalmente com alguém?"
attr(d$nfilhos, "label") <- "Número de filhos"
attr(d$ncomodos, "label") <- "Número de cômodos na casa"
attr(d$nbanheiros, "label") <- "Número de banheiros na cas"
attr(d$luz, "label") <- "A casa tem energia elétrica?"
attr(d$entrev.trabalha, "label") <- "Você exerce alguma atividade remunerada?"
attr(d$entrev.ocupacao, "label") <- "Qual sua ocupação?"
attr(d$marido.ocupacao, "label") <- "Qual a ocupação do seu marido"
attr(d$entrev.tempo.desemprgd, "label") <- "Está desempregada há quanto tempo"
attr(d$marido.tempo.desemprgd, "label") <- "Seu marido está desempregado há quanto tempo?"
attr(d$menor14trabalha, "label") <- "Algum filho menor de 14 anos trabalha?"
attr(d$menor16trabalha, "label") <- "Algum filho entre 14 e 16 anos trabalha?"
attr(d$menor18trabalha, "label") <- "Algum filho com idade entre 16 e 18 anos trabalha?"
attr(d$renda.bolsafam, "label") <- "Quanto da renda vem do Bolsa Família?"
attr(d$renda.total, "label") <- "Qual a renda total da família?"
attr(d$ndoentes, "label") <- "Existem doentes em casa? Quantos?"
attr(d$doente.tratado, "label") <- "Os doentes de casa recebem os cuidados necessários?"
attr(d$local.nasc, "label") <- "Local de nascimento da entrevistada"
attr(d$esc.entrev, "label") <- "Escolaridade da entrevistada: 0, 1-9f, 2-3m, s"
attr(d$esc.marido, "label") <- "Escolaridade do marido"
attr(d$esc.mae.entrev, "label") <- "Escolaridade da mãe da entrevistada"
attr(d$esc.pai.entrev, "label") <- "Escolaridade do pai da entrevistada"
attr(d$esc.mae.marido, "label") <- "Escolaridade da mãe do marido da entrevistada"
attr(d$esc.pai.marido, "label") <- "Escolaridade do pai do marido da entrevistada"
attr(d$religiao.quem, "label") <- "Quem deve conversar sobre religião? f=família, e=escola. fe=ambos"
attr(d$drogas.quem, "label") <- "Quem deve conversar sobre drogas? f=familia, e=escola, fe=ambos"
attr(d$sexualdd.quem, "label") <- "Quem deve conversar sobre sexualidade? f=familia, e=escola, fe=ambos"
attr(d$ajuda.tarefas, "label") <- "Você ajuda nas tarefas escolares dos filhos?"
attr(d$alguem.ajuda, "label") <- "Alguuma outra pessoa ajuda nas tarefas escolares"
attr(d$desemp.na.escola, "label") <- "Seus filhos estão com bom desempenho na escola?"
attr(d$freq.na.escola, "label") <- "Seus filhos estão com frequência adequada na escola?"
attr(d$dificuldades, "label") <- "Existem dificuldades para manter os filhos na escola?"
attr(d$transporte, "label") <- "Escola tem transporte escolar para os alunos?"
attr(d$progrm.esc, "label") <- "Que você saiba, a escola realiza algum programa (ex. reforço)?"
attr(d$escola.merenda, "label") <- "A escola tem merenda"
attr(d$conhece.profs, "label") <- "Você conhece professores do seu filho"
attr(d$conhece.dir, "label") <- "Você conhece a diretora da escola"
attr(d$bf.favor, "label") <- "O Programa Bolsa Família é um favor do governo?"
attr(d$bf.direito, "label") <- "O Programa Bolsa Família é um direito da sua família?"
attr(d$bf.ser.dinh, "label") <- "É bom o benefício ser pago em dinheiro?"
attr(d$bf.quem.paga, "label") <- "Respondeu corretamente sobre quem paga o benefício?"
attr(d$bf.nao.merece, "label") <- "Acha que existem beneficiários que não deveriam receber?"
attr(d$bf.nao.recebe, "label") <- "Acha que existem pessoas que merecem e não recebem o benefício?"
attr(d$voto.sempre, "label") <- "Você sempre vota?"
attr(d$votava.sempre, "label") <- "Você sempre votava?"
attr(d$bf.influencia.voto, "label") <- "O bolsa famĩlia influenciou no seu voto?"
attr(d$cadastro.quem, "label") <- "Alguém facilitou seu cadastro?"
attr(d$quem.facilitou, "label") <- "Quem facilitou seu cadastro?"
attr(d$tempo.bf, "label") <- "Por quanto tempo acha que vai precisar do BF?"
save(d, file = "DadosEntrevistas.RData")
