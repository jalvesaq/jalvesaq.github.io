###############################################################################
## POLÍTICA E ETNICIDADE NA NAÇÃO MOÇAMBICANA NO CONTEXTO DAS ELEIÇÕES DE 2019
###############################################################################

# Carregar pacotes
library("haven")     # read_spss()
library("dplyr")     # filter(), select(), mutate()
library("sjPlot")    # tab_model()
library("terra")     # plot(mapa)
library("car")       # vif()
library("ggplot2")   # ggsave()
library("ggeffects") # ggpredict()
library("MASS")      # polr()
library("gridExtra") # grid.arrange()

###############################################################################
#####  Informação introdutória sobre número de casos e de países na primeira
#####  Rodada do Afrobarômetro

# Round 1: não tem Moçambique
a1 <- read_spss("merged_r1_data.sav")

# Número de entrevistados na primeira rodada do Afrobarômetro:
nrow(a1)

# Número de países na primeira rodada do Afrobarômetro
length(table(a1$country))

rm(a1)

###############################################################################
##### Dados de Moçambique coletados na Round 7

m7 <- read_spss("moz_r7_data_english.sav") |>
    as_factor() |>
    dplyr::select(REGION, URBRUR, Q2A, Q12A, Q12B, Q12C, Q12D, Q12E, Q13,
                  Q25A, Q25B, Q25C, Q25D, Q25E, Q25F, Q26A, Q26B, Q26E, Q27A,
                  Q27B, Q27C, Q28, Q35, Q36, Q84, Q85B, Q85B, Q88B, Q97, Q98,
                  Q99)

# Criar novas variáveis, deletando as antigas
m7 <- mutate(m7,
    urbano = as.numeric(URBRUR == "Urban"),

    # Convenientemente, Cabo Delgado é a primeira província em ordem alfabética
    # e apresenta a mediana em apoio à Frelimo e, portanto, a mais indicada como
    # categoria de referência na regressão tendo Apoio à Frelimo como variável
    # dependente.
    provincia = factor(case_match(REGION,
            "Maputo Provincia" ~ "Maputo Província",
            "Cidade de Maputo" ~ "Maputo Cidade",
            "Zambezia" ~ "Zambézia",
            .default = as.character(REGION)),
        levels = c("Cabo Delgado", "Maputo Cidade", "Gaza", "Inhambane",
            "Manica", "Maputo Província", "Nampula", "Niassa", "Sofala",
            "Tete", "Zambézia")),

    # Unificaremos algumas etnias tal como feito pelo próprio Afrobarômetro no
    # banco de dados r7_merged_data_34ctry.release.sav porque algumas etnias
    # aparecem no banco de dados de Moçambique com mais de um nome.
    # Por exemplo, "Manhungue" é o plural de "Nhungue".
    etnia = factor(case_match(Q84,
            c("Mozambican only, or “doesn’t think of self in those terms”",
              "Missing", "Other", "Refused", "Don't know") ~ "Outra ou não se aplica",
            # Tradução e unificação de alguns nomes:
            "Cinyungue" ~ "Cinhungue",
            "Lomue" ~ "Lomué",
            "Makonde" ~ "Maconde",
            "Makua" ~ "Macua",
            "Nyanja" ~ "Nianja",
            c("Machewa", "Chichewa") ~ "Chicheua",
            c("Nhungue", "Manhungue") ~ "Manhungue",
            c("Matswa", "Xitswa") ~ "Xitsua",
            .default = as.character(Q84)),
        levels = c("Outra ou não se aplica", "Ajaua", "Bitonga", "Changana",
            "Chicheua", "Chope", "Chuabo", "Cinhungue", "Lomué",
            "Maconde", "Macua", "Manhaua", "Manhungue", "Ndau",
            "Nianja", "Ronga", "Sena", "Shona", "Xitsua")),

    lingua = factor(case_match(Q2A,
            c("Other", "Don't know") ~ "Outra",
            # Tradução e correção de nomes:
            "Chichewa" ~ "Chicheua",
            "Cinyungwe" ~ "Cinhungue",
            "Ekoti" ~ "Ecoti",
            "Kimwani" ~ "Quimuani",
            "Lomue" ~ "Lomué",
            "Makonde" ~ "Maconde",
            "Makua" ~ "Macua",
            "Nyanja" ~ "Nianja",
            "Swahili" ~ "Suahili",
            "Xironga" ~ "Ronga",
            "Xitswa" ~ "Xitsua",
            .default = as.character(Q2A)),
        levels = c("Portuguese", "Ajaua", "Bitonga", "Changana", "Chicheua",
            "Chope", "Chuabo", "Cinhungue", "Ciyao", "Ecoti", "Lomué",
            "Maconde", "Macua", "Manhaua", "Ndau", "Nhungue", "Nianja",
            "Quimuani", "Ronga", "Sena", "Shona", "Suahili", "Xitsua",
            "Outra")),

    # Variável indicadora de que a língua materna tem a mesma denominação da etnia:
    lingua.etnia = factor(as.character(lingua) == as.character(etnia),
        levels = c(FALSE, TRUE), labels = c("Outra ou não se aplica", "Mesma da etnia")),

    escola = case_match(Q97,
        c("No formal schooling", "Refused", "Don’t know") ~ 0,
        c("Informal schooling only", "Some primary schooling") ~ 1,
        c("Primary school completed", "Some secondary school / high school") ~ 2,
        c("Secondary school / high school completed",
          "Post-secondary qualifications, other than university",
          "Some university") ~ 3,
        "University completed" ~ 4,
        "Post-graduate" ~ 5),

    nacional = case_match(Q85B,
        c("I feel more (national identity) than (ethnic group)",
           "I feel only (national identity)") ~ 1,
        c("I feel only (ethnic group)",
           "I feel more (ethnic group) than (national identity)",
           "I feel equally (national identity) and (ethnic group)") ~ 0,
        c("Missing", "Not applicable", "Refused", "Don't know") ~ NA),

    # Não usaremos a variável reli_cond (nativa do banco de dados)
    # porque nela Assembleia de Deus e a New Apostolic Church (Igreja
    # Nova Apostólica) estão erroneamente classificadas como não cristãs
    relig = factor(case_match(Q98,
            c("None", "Other", "Refused", "Don't know",
              "Traditional / ethnic religion", "Jewish",
              "Atheist") ~ 1,
            c("Christian only", "Roman Catholic", "Anglican",
              "Lutheran", "Methodist", "Presbyterian", "Baptist",
              "Quaker / Friends", "Mennonite", "Evangelical",
              "Pentecostal", "Independent", "Jehovah’s Witness",
              "Seventh Day Adventist", "Mormon", "Dutch Reformed",
              "Church of Christ", "Zionist Christian Church",
              "New Apostolic Church", "Assembly of God",
              "Orthodox", "Coptic") ~ 2,
            c("Muslim only", "Sunni only", "Ismaeli",
              "Tijaniya Brotherhood",
              "Qadiriya Brotherhood", "Shia") ~ 3),
        levels = c(1, 2, 3), labels = c("Outra", "Cristã", "Islâmica")),

    partidopref = factor(case_match(Q88B,
            "Frelimo (Frente de Libertação de Moçambique)" ~ "Frelimo",
            "Renamo (Resistência Nacional Moçambicana)" ~ "Renamo",
            "MDM (Movimento Democrático Moçambicano)" ~ "MDM",
            "PDD (Partido para Paz, Democracia e Desenvolvimento)" ~ "PDD",
            c("Not applicable", "Refused to answer", "Don't know") ~ "NA/NS/NR"),
        levels = c("NA/NS/NR", "Frelimo", "Renamo", "MDM", "PDD")),

    partidovoto = factor(case_match(Q99,
            "Frelimo (Frente de Libertação de Moçambique)" ~ "Frelimo",
            "Renamo (Resistência Nacional Moçambicana)" ~ "Renamo",
            "MDM (Movimento Democrático Moçambicano)" ~ "MDM",
            c("Missing", "Other", "Would not vote",
              "PDD (Partido para Paz, Democracia e Desenvolvimento)",
              "PIMO (Partido Independente Moçambicano)",
              "Refused to answer", "Don't know") ~ "Outro/NA/NS/NR"),
        levels = c("Outro/NA/NS/NR", "Frelimo", "MDM", "Renamo")),

    prefFrelimo = partidopref == "Frelimo",

    votoFrelimo = partidovoto == "Frelimo",

    radio = case_match(Q12A,
        c("Never", "Refused", "Don't know") ~ 0,
        "Less than once a month" ~ 1,
        "A few times a month" ~ 2,
        "A few times a week" ~ 3,
        "Every day" ~ 4),

    tv = case_match(Q12B,
        c("Never", "Refused", "Don't know") ~ 0,
        "Less than once a month" ~ 1,
        "A few times a month" ~ 2,
        "A few times a week" ~ 3,
        "Every day" ~ 4),

    jornal = case_match(Q12C,
        c("Never", "Refused", "Don't know") ~ 0,
        "Less than once a month" ~ 1,
        "A few times a month" ~ 2,
        "A few times a week" ~ 3,
        "Every day" ~ 4),

    internet = case_match(Q12D,
        c("Never", "Refused", "Don't know") ~ 0,
        "Less than once a month" ~ 1,
        "A few times a month" ~ 2,
        "A few times a week" ~ 3,
        "Every day" ~ 4),

    smedia = case_match(Q12E,
        c("Never", "Refused", "Don't know") ~ 0,
        "Less than once a month" ~ 1,
        "A few times a month" ~ 2,
        "A few times a week" ~ 3,
        "Every day" ~ 4),

    discute.pol = case_match(Q13,
        c("Never", "Refused", "Don't know") ~ 0,
        "Occasionally" ~ 1,
        "Frequently" ~ 2),

    ctt.local = case_match(Q25A,
        c("Never", "Refused", "Don’t know") ~ 0,
        "Only once" ~ 1,
        "A few times" ~ 2,
        "Often" ~ 3),

    ctt.mp = case_match(Q25B,
        c("Never", "Refused", "Don’t know") ~ 0,
        "Only once" ~ 1,
        "A few times" ~ 2,
        "Often" ~ 3),

    ctt.gov = case_match(Q25C,
        c("Never", "Refused", "Don’t know") ~ 0,
        "Only once" ~ 1,
        "A few times" ~ 2,
        "Often" ~ 3),

    ctt.party = case_match(Q25D,
        c("Never", "Refused", "Don’t know") ~ 0,
        "Only once" ~ 1,
        "A few times" ~ 2,
        "Often" ~ 3),

    ctt.trad = case_match(Q25E,
        c("Never", "Refused", "Don’t know") ~ 0,
        "Only once" ~ 1,
        "A few times" ~ 2,
        "Often" ~ 3),

    ctt.relig = case_match(Q25F,
        c("Never", "Refused", "Don’t know") ~ 0,
        "Only once" ~ 1,
        "A few times" ~ 2,
        "Often" ~ 3),

    acao.uniao = case_match(Q26A,
        c("No, would never do this", "Refused", "Don't know") ~ 0,
        "No, but would do if had the chance" ~ 1,
        "Yes, once or twice" ~ 2,
        "Yes, several times" ~ 3,
        "Yes, often" ~ 4),

    acao.media = case_match(Q26B,
        c("No, would never do this", "Refused", "Don't know") ~ 0,
        "No, but would do if had the chance" ~ 1,
        "Yes, once or twice" ~ 2,
        "Yes, several times" ~ 3,
        "Yes, often" ~ 4),

    acao.protesto = case_match(Q26E,
        c("No, would never do this", "Refused", "Don't know") ~ 0,
        "No, but would do if had the chance" ~ 1,
        "Yes, once or twice" ~ 2,
        "Yes, several times" ~ 3,
        "Yes, often" ~ 4),

    rej.oneparty = case_match(Q27A,
        c("Strongly Disapprove", "Disapprove") ~ 1,
        c("Neither Approve Nor Disapprove",
          "Approve", "Strongly Approve", "Don’t know") ~ 0),

    rej.mili = case_match(Q27B,
        c("Strongly Disapprove", "Disapprove") ~ 1,
        c("Neither Approve Nor Disapprove",
          "Approve", "Strongly Approve", "Don’t know") ~ 0),

    rej.oneman = case_match(Q27C,
        c("Strongly Disapprove", "Disapprove") ~ 1,
        c("Neither Approve Nor Disapprove",
          "Approve", "Strongly Approve", "Don’t know") ~ 0),

    apoio.dem = case_match(Q28,
        "STATEMENT 1: Democracy preferable" ~ 1,
        c("Don't know", "STATEMENT 3: Doesn't matter",
          "STATEMENT 2: Sometimes non-democratic preferable") ~ 0),

    ext.dem = case_match(Q35,
        c("A democracy, but with minor problems", "A full democracy") ~ 1,
        c("Not a democracy", "A democracy, with major problems",
          "Do not understand question / democracy", "Don't know") ~ 0),

    satisf.dem = case_match(Q36,
        c("Fairly satisfied", "Very satisfied") ~ 1,
        c("The country is not a democracy", "Not at all satisfied",
          "Not very satisfied", "Do not know") ~ 0),

    .keep = "unused")


# Criar índices
m7 <- mutate(m7,
    # Índice de informação sobre política
    informado = (radio + tv + jornal + internet + smedia) / 20,

    # Índice de contato político
    contato.pol = (ctt.local + ctt.mp + ctt.gov + ctt.party) / 16,

    # Índice de contato com lideranças tradicionais
    contato.trad = (ctt.trad + ctt.relig) / 8,

    # Índice de propensão a protestar
    protesto = log(((acao.uniao + acao.media + acao.protesto) / 6) + 1),

    # Índice de apoio à Frelimo
    frelimo = (prefFrelimo + votoFrelimo) / 2,

    # Índice de demanda por democracia
    demdem = rej.oneparty + rej.mili + rej.oneman + apoio.dem,

    # Índice de satisfação com a democracia
    oferta.dem = ext.dem + satisf.dem,

    .keep = "unused")


# Em variável alternativa, reter somente etnias com mais de 50 respondentes:
tmp <- table(m7$etnia)
tmp <- names(tmp[tmp < 50])
m7$etnia.r <- as.character(m7$etnia)
# Prefixar _ para que "Outras" seja a categoria de referência
m7$etnia.r[m7$etnia.r %in% tmp] <- "_Outras"
m7$etnia.r[m7$etnia.r == "Outra ou não se aplica"] <- "_Outras"
m7$etnia.r <- factor(m7$etnia.r)
levels(m7$etnia.r) <- sub("_", "", levels(m7$etnia.r))

# Em variável alternativa, reter somente etnias com mais de 100 respondentes:
tmp <- table(m7$etnia)
tmp <- names(tmp[tmp < 100])
m7$etnia.r2 <- as.character(m7$etnia)
# Prefixar _ para que "Outras" seja a categoria de referência
m7$etnia.r2[m7$etnia.r2 %in% tmp] <- "_Outras"
m7$etnia.r2[m7$etnia.r2 == "Outra ou não se aplica"] <- "_Outras"
m7$etnia.r2 <- factor(m7$etnia.r2)
levels(m7$etnia.r2) <- sub("_", "", levels(m7$etnia.r2))

# Em variável alternativa, reter somente províncias com mais de 150 respondentes:
tmp <- table(m7$provincia)
tmp <- names(tmp[tmp < 150])
m7$provincia2 <- as.character(m7$provincia)
m7$provincia2[m7$provincia2 %in% tmp] <- "_Outras"
m7$provincia2 <- factor(m7$provincia2)
levels(m7$provincia2) <- sub("_", "", levels(m7$provincia2))

rm(tmp)

m7$demdem.f <- factor(m7$demdem)
m7$oferta.dem.f <- factor(m7$oferta.dem)
m7$frelimo.f <- factor(m7$frelimo)

# Rótulos das variáveis
attr(m7$etnia,         "label") <- "Etnia"
attr(m7$etnia.r,       "label") <- "Etnia"
attr(m7$etnia.r2,      "label") <- "Etnia"
attr(m7$lingua,        "label") <- "Língua mãe do entrevistado"
attr(m7$relig,         "label") <- "Religião"
attr(m7$provincia,     "label") <- "Província"
attr(m7$partidopref,   "label") <- "Preferência partidária"
attr(m7$partidovoto,   "label") <- "Partido no qual votou"
attr(m7$lingua.etnia,  "label") <- "A língua mãe é a mesma da etnia?"
attr(m7$informado,     "label") <- "Acompanha noticiários"
attr(m7$discute.pol,   "label") <- "Discute política"
attr(m7$contato.pol,   "label") <- "Contato com políticos"
attr(m7$contato.trad,  "label") <- "Contato com líderes tradicionais"
attr(m7$protesto,      "label") <- "Propensão a protestar"
attr(m7$demdem,        "label") <- "Demanda por democracia"
attr(m7$demdem.f,      "label") <- "Demanda por democracia"
attr(m7$oferta.dem,    "label") <- "Avaliação da democracia"
attr(m7$oferta.dem.f,  "label") <- "Avaliação da democracia"
attr(m7$urbano,        "label") <- "Urbano"
attr(m7$escola,        "label") <- "Escolaridade"
attr(m7$nacional,      "label") <- "Identidade nacional"
attr(m7$frelimo,       "label") <- "Apoio à Frelimo"
attr(m7$frelimo.f,     "label") <- "Apoio à Frelimo"


###############################################################################
#####  RESULTADOS

# Normalidade das variáveis dependentes:
ggplot(m7, aes(demdem)) +
    geom_bar(fill = "#70a0c0")
ggplot(m7, aes(oferta.dem)) +
    geom_bar(fill = "#70a0c0")
ggplot(m7, aes(frelimo)) +
    geom_bar(fill = "#70a0c0")

# Número de entrevistados em Moçambique na sétima rodada do Afrobarômetro:
format(nrow(m7), big.mark = ".", decimal.mark = ",")

# Número de pessoas de outras etnias ou de etnia não definida:
sum(m7$etnia == "Outra ou não se aplica")

# Apêndice. Número de entrevistados por etnia e por província --- Moçambique, 2018
tabA <- table(m7$etnia, m7$provincia)
tabA <- tabA[rownames(tabA) != "Outra ou não se aplica", ]
colnames(tabA) <- sub("Maputo Província", "Maputo P.", colnames(tabA))
colnames(tabA) <- sub("Maputo Cidade", "Maputo C.", colnames(tabA))
colnames(tabA) <- sub("Delgado", "D.", colnames(tabA))
tabA <- cbind(tabA, "Total" = margin.table(tabA, 1))
tabA <- rbind(tabA, "Total" = margin.table(tabA, 2))
tabA

# Tabela 2. Língua falada, religião e identificação com a nação por etnia ---
# Moçambique, 2018
# A tabela seguinte mostra o percentual de entrevistados cuja língua é a mesma
# da etnia ou outra língua, segundo a etnia.
tab <- with(m7, tapply(lingua.etnia, etnia,
            function(x) round(100 * table(x) / length(x))))
tab <- do.call("rbind", tab)
Tab1 <- data.frame(Etnia = rownames(tab), Mesma = tab[, "Mesma da etnia"])
tab <- with(m7, tapply(lingua, etnia,
                       function(x) round(100 * sum(x == "Portuguese") / length(x))))
Tab2 <- data.frame(Etnia = rownames(tab), "Português" = unname(tab))
Tab <- merge(Tab1, Tab2)
Tab <- Tab[Tab$Etnia != "Outra ou não se aplica", ]
rownames(Tab) <- NULL

tmp <- table(m7$etnia, m7$relig)
tmp <- round(prop.table(tmp, 1) * 100)
tmp <- data.frame(Etnia = rownames(tmp),
                  Cristã = tmp[, "Cristã"],
                  Islâmica = tmp[, "Islâmica"],
                  Outra = tmp[, "Outra"])
Tab <- merge(Tab, tmp)

tab <- with(m7, tapply(nacional, etnia, mean, na.rm = TRUE))
tab <- data.frame("Etnia" = names(tab), "IdNacional" = round(100 * tab))
tab2 <- merge(Tab, tab)
colnames(tab2) <- c("Etnia", "da etnia", "Português", "Cristã", "Islâmica",
                    "Outra", "Nacional")
rm(Tab1, Tab2, Tab)
tab2


# Tabela 3. Proximidade de partido e partido em que votaria se as eleições
# fossem amanhã por etnia --- Moçambique, 2018
# Preferência partidária e etnia em Moçambique
# Etnia x partidos
tab <- with(m7, table(etnia, partidopref))
tab <- round(prop.table(tab, 1) * 100)
Tab <- data.frame(etnia = rownames(tab),
                  Frelimo = tab[, "Frelimo"],
                  Renamo = tab[, "Renamo"],
                  MDM = tab[, "MDM"],
                  PDD = tab[, "PDD"],
                  "NS/NR" = tab[, "NA/NS/NR"])

tab <- with(m7, table(etnia, partidovoto))
tab <- round(prop.table(tab, 1) * 100)
tab <- data.frame(etnia = rownames(tab),
                  VFrelimo = tab[, "Frelimo"],
                  VRenamo = tab[, "Renamo"],
                  VMDM = tab[, "MDM"],
                  "V.NS/NR" = tab[, "Outro/NA/NS/NR"])

tab3 <- merge(Tab, tab)
colnames(tab3) <- c("Etnia", "Frelimo", "Renamo", "MDM", "PDD", "NS/NR",
                    "Frelimo", "Renamo", "MDM", "NS/NR")
rm(tab, Tab)
tab3


# Tabela 4. Nacionalismo e apoio à Frelimo segundo a religião --- Moçambique, 2018
tab4 <- cbind("Nacionalismo" = tapply(m7$nacional, m7$relig, mean,
                                      na.rm = TRUE),
             "Apoio à Frelimo" = tapply(m7$frelimo, m7$relig, mean,
                                        na.rm = TRUE))
round(tab4, 2)

# Figura 1. Etnia, religião, identidade nacional e preferência partidária em Moçambique
if (!file.exists("mz.shp")) {
    # https://simplemaps.com/gis/country/mz
    # Acesso em 02 de novembro de 2024
    if (!file.exists("/tmp/mz_shp.zip"))
        download.file("https://simplemaps.com/static/svg/country/mz/admin1/mz_shp.zip",
                      "/tmp/mz_shp.zip")
    unzip("/tmp/mz_shp.zip", c("mz.shp", "mz.dbf", "mz.shx", "mz.prj"))
}

map <- vect("mz.shp")
map$name <- sub("Zambezia", "Zambézia", map$name)

tmp <- m7$etnia
tmp[tmp == "Outra ou não se aplica"] <- NA
tab <- data.frame("etnia" = tapply(tmp, m7$provincia,
                      function(x) names(sort(table(x), decreasing = TRUE))[1]),
                  "relig" = tapply(m7$relig, m7$provincia,
                      function(x) sum(x == "Islâmica", na.rm = TRUE) / length(x)),
                  "nacional" = tapply(m7$nacional, m7$provincia,
                      function(x) mean(x, na.rm = TRUE)),
                  "frelimo" = tapply(m7$frelimo, m7$provincia,
                      function(x) mean(x, na.rm = TRUE)))

tab$name <- rownames(tab)
tab$name <- sub("Maputo Província", "Maputo", tab$name)

tab$relig.cor <- rgb(1 - tab$relig, 1.0, 1 - tab$relig)
tab$nacional.cor <- rgb(0.8, 0.6, 0.2, tab$nacional)
tab$frelimo.cor <- rgb(0.7, 0, 0, tab$frelimo)

etnias <- levels(factor(tab$etnia))
cores <- c("#FFCCCC", "#CCFFFF", "#FFCC99", "#CCFFCC", "#FFFFCC", "#CCCCFF", "#FFCCFF")
etnia.cores <- cores[1:length(etnias)]
names(etnia.cores) <- etnias

tab$etnia.cor <- tab$etnia
for (nm in names(etnia.cores))
    tab$etnia.cor <- sub(nm, unname(etnia.cores[nm]), tab$etnia.cor)

m <- merge(map, tab)

coord <- rbind("Cabo\nDelgado"    = c(39.27, -12.50),
               "Gaza"             = c(32.45, -23.29),
               "Inham-\nbane"     = c(34.59, -22.81),
               "Manica"           = c(31.50, -18.63),
               "Maputo"           = c(30.90, -26.12),
               "Cidade de Maputo" = c(34.80, -25.84),
               "Nampula"          = c(39.22, -14.89),
               "Niassa"           = c(36.49, -13.20),
               "Sofala"           = c(34.98, -18.55),
               "Tete"             = c(32.84, -15.36),
               "Zambézia"         = c(37.25, -16.58))

# pdf(file = "Figura_1_Mapas.pdf")
par(mar = c(0, 0, 0, 0) + 0.1, mfrow = c(2, 2), cex = 0.4)
plot(m, col = m$etnia.cor, axes = FALSE, box = FALSE,
     clip = FALSE, xlim = c(28.5, 41))
text(coord, rownames(coord))
text(32, -11.5, "Etnia", cex = 2.5)
legend(37, -18.5, bty = "n", cex = 1.5,
       title = "Etnia com maior\nnúmero de\nentrevistados",
       legend = names(etnia.cores),
       fill =   unname(etnia.cores))

plot(m, col = m$relig.cor, axes = FALSE, box = FALSE,
     clip = FALSE, xlim = c(28.5, 41))
text(coord, rownames(coord))
text(32, -11.5, "Religião", cex = 2.5)
y1 <- seq(-23, -20.8, 0.4)
ocol <- seq(min(m$relig), max(m$relig), (max(m$relig) - min(m$relig)) / 6)
for (i in 1:6)
    rect(37.4, y1[i], 37.9, y1[i] - 0.4, col = rgb(1 - ocol[i], 1, 1 - ocol[i]),
         lwd = 0, lty = NULL)
rect(37.4, -23.4, 37.9, -21)
text(38.1, -21.2, paste0(round(max(m$relig) * 100), "%"), cex = 1.5, adj = c(0, 0.5))
text(38.1, -23.2, paste0(round(min(m$relig) * 100), "%"), cex = 1.5, adj = c(0, 0.5))
text(38.1, -20.3, "Islamismo", cex = 1.5)

plot(m, col = m$nacional.cor, axes = FALSE, box = FALSE,
     clip = FALSE, xlim = c(28.5, 41))
text(coord, rownames(coord))
text(31.3, -11.5, "Naciona-\nlismo", cex = 2.5)
ocol <- seq(min(m$nacional), max(m$nacional), (max(m$nacional) - min(m$nacional)) / 6)
for (i in 1:6)
    rect(37.4, y1[i], 37.9, y1[i] - 0.4,
         col = rgb(0.8, 0.6, 0.2, ocol[i]), lwd = 0, lty = NULL)
rect(37.4, -23.4, 37.9, -21)
text(38.1, -21.2, paste0(round(max(m$nacional) * 100), "%"), cex = 1.5, adj = c(0, 0.5))
text(38.1, -23.2, paste0(round(min(m$nacional) * 100), "%"), cex = 1.5, adj = c(0, 0.5))
text(38.1, -20.0, "Sente-se\nmoçambicano", cex = 1.5)

plot(m, col = m$frelimo.cor, axes = FALSE, box = FALSE,
     clip = FALSE, xlim = c(28.5, 41))
text(coord, rownames(coord))
text(31.7, -11.5, "Preferência\npartidária", cex = 2.5)
ocol <- seq(min(m$frelimo), max(m$frelimo), (max(m$frelimo) - min(m$frelimo)) / 6)
for (i in 1:6)
    rect(37.4, y1[i], 37.9, y1[i] - 0.4,
         col = rgb(0.7, 0, 0, ocol[i]), lwd = 0, lty = NULL)
rect(37.4, -23.4, 37.9, -21)
text(38.1, -21.2, paste0(round(max(m$frelimo) * 100), "%"), cex = 1.5, adj = c(0, 0.5))
text(38.1, -23.2, paste0(round(min(m$frelimo) * 100), "%"), cex = 1.5, adj = c(0, 0.5))
text(38.1, -20.0, "Preferência\npela Frelimo", cex = 1.5)
# dev.off()

rm(tmp, tab, cores, etnias, etnia.cores, ocol, map, i, coord, y1)

# Regressoes

# Devido a não haver dados sobre nacionalismo dos Lomues, criamos um banco de
# dados sem os respondentes da etnia Lomué
table(m7$etnia, is.na(m7$nacional))
m7l <- filter(m7, !is.na(nacional))
m7l$etnia.r <- droplevels(m7l$etnia.r)
attr(m7l$etnia.r, "label") <- "Etnia"

# Substituir valores omissos:
sapply(m7l, function(x) sum(is.na(x))) # Número de valores omissos por variável
m7l$demdem[is.na(m7l$demdem)] <-
    sample(m7l$demdem[!is.na(m7l$demdem)], sum(is.na(m7l$demdem)))
m7l$oferta.dem[is.na(m7l$oferta.dem)] <-
    sample(m7l$oferta.dem[!is.na(m7l$oferta.dem)], sum(is.na(m7l$oferta.dem)))

mNac <- glm(nacional ~ escola + urbano + relig + frelimo + contato.pol +
              contato.trad + informado + discute.pol + protesto + oferta.dem +
              demdem + provincia + etnia.r, family = binomial(), data = m7l)

mDemDem <- polr(demdem.f ~ escola + urbano + relig + frelimo +
                 contato.pol + contato.trad + informado + discute.pol +
                 protesto + oferta.dem + provincia + etnia.r, data = m7)

mOfertaDem <- polr(oferta.dem.f ~ escola + urbano + relig + frelimo +
                      contato.pol + contato.trad + informado + discute.pol +
                      protesto + demdem + provincia + etnia.r, data = m7)

mFrelimo <- polr(frelimo.f ~ escola + urbano + relig + contato.pol +
                   contato.trad + informado + discute.pol + protesto +
                   provincia + etnia.r, data = m7)

# Existe alta multicolinearidade entre Etnia e Província (GVIF > 5) mas os
# modelos ainda são usáveis (GVIF^(1/(2*Df)) < 2) (Fox, Weisberg, 2019).
vif(mNac)
vif(mDemDem)
vif(mOfertaDem)
vif(mFrelimo)

# Modelos com províncias agregadas em regiões e somente com etnias com
# mais 100 entrevistados
mNac2 <- glm(nacional ~ escola + urbano + relig + frelimo + contato.pol +
              contato.trad + informado + discute.pol + protesto + oferta.dem +
              demdem + provincia2 + etnia.r2, family = binomial(), data = m7l)
mDemDem2 <- polr(demdem.f ~ escola + urbano + relig + frelimo +
                      contato.pol + contato.trad + informado + discute.pol +
                      protesto + oferta.dem + provincia2 + etnia.r2, data = m7)
mOfertaDem2 <- polr(oferta.dem.f ~ escola + urbano + relig + frelimo +
                      contato.pol + contato.trad + informado + discute.pol +
                      protesto + demdem + provincia2 + etnia.r2, data = m7)
mFrelimo2 <- polr(frelimo.f ~ escola + urbano + relig + contato.pol +
                   contato.trad + informado + discute.pol + protesto +
                   provincia2 + etnia.r2, data = m7)


# Menor multicolinearidade:
vif(mNac2)
vif(mDemDem2)
vif(mOfertaDem2)
vif(mFrelimo2)

# Figura 2: Identidade nacional predita segundo a etnia
npred <- ggpredict(mNac, terms = "etnia.r")
gi <- ggplot(npred, aes(x, predicted)) +
    geom_point() +
    geom_linerange(aes(ymin = conf.low, ymax = conf.high)) +
    geom_errorbar(aes(ymin = conf.low, ymax = conf.high, width = 0.25)) +
    labs(x = "", y = "Identidade nacional") +
    theme(axis.text.x = element_text(angle = 30, hjust = 1))
gi

# Figura 3: Variáveis dependentes preditas segundo a etnia recodificada
npred <- ggpredict(mNac2, terms = "etnia.r2")
g1 <- ggplot(npred, aes(x, predicted)) +
    geom_point() +
    geom_linerange(aes(ymin = conf.low, ymax = conf.high)) +
    geom_errorbar(aes(ymin = conf.low, ymax = conf.high, width = 0.25)) +
    labs(x = "", y = "Identidade nacional") +
    theme(axis.text.x = element_text(angle = 30, hjust = 1))
npred <- ggpredict(mDemDem2, terms = "etnia.r2")
g2 <- ggplot(npred, aes(x, predicted,
                        group = response.level, color = response.level)) +
    geom_point() +
    geom_linerange(aes(ymin = conf.low, ymax = conf.high)) +
    geom_errorbar(aes(ymin = conf.low, ymax = conf.high), width = 0.25) +
    labs(x = "", y = "Demanda por democracia", color = "Nível") +
    theme(axis.text.x = element_text(angle = 30, hjust = 1))
npred <- ggpredict(mOfertaDem2, terms = "etnia.r2")
g3 <- ggplot(npred, aes(x, predicted,
                        group = response.level, color = response.level)) +
    geom_point() +
    geom_linerange(aes(ymin = conf.low, ymax = conf.high)) +
    geom_errorbar(aes(ymin = conf.low, ymax = conf.high), width = 0.25) +
    labs(x = "", y = "Oferta democrática", color = "Nível") +
    theme(axis.text.x = element_text(angle = 30, hjust = 1))
npred <- ggpredict(mFrelimo2, terms = "etnia.r2")
g4 <- ggplot(npred, aes(x, predicted,
                        group = response.level, color = response.level)) +
    geom_point() +
    geom_linerange(aes(ymin = conf.low, ymax = conf.high)) +
    geom_errorbar(aes(ymin = conf.low, ymax = conf.high), width = 0.25) +
    labs(x = "", y = "Apoio à Frelimo", color = "Nível") +
    theme(axis.text.x = element_text(angle = 30, hjust = 1))
grid.arrange(g1, g2, g3, g4)
# dev.off()

# A identidade nacional predita é menor entre os Macuas:
npredl <- npred$predicted
names(npredl) <- attr(npred, "x.axis.labels")
npredl

# Reordenando as categorias de modo a Macua ser a categoria de referência:
npredl <- sort(npredl)
m7l$etnia.r <- factor(m7l$etnia.r, levels = names(npredl))

mNacM <- glm(nacional ~ escola + urbano + relig + frelimo + contato.pol +
              contato.trad + informado + discute.pol + protesto + oferta.dem + demdem +
              provincia + etnia.r, family = binomial(), data = m7l)

# E reordenando de modo a Chope ser a categoria de referência:
npredl <- sort(npredl, decreasing = TRUE)
m7l$etnia.r <- factor(m7l$etnia.r, levels = names(npredl))

mNacC <- glm(nacional ~ escola + urbano + relig + frelimo + contato.pol +
              contato.trad + informado + discute.pol + protesto + oferta.dem + demdem +
              provincia + etnia.r, family = binomial(), data = m7l)

summary(mNacM)
summary(mNacC)
