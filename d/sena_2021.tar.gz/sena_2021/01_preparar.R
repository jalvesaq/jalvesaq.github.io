
# Ler o arquivo baixado do Google Forms:
d <- read.csv("Democracia_contemporanea_no_Brasil.csv",
              stringsAsFactors = FALSE)

# O Google Forms salva o texto completo das questões como nome das
# variáveis mas é inviável usar nomes tão longos. Então, vamos converter
# os nomes em rótulos ("labels"). Mas, antes, vamos reduzir o tamanho de
# alguns rótulos.
vlab <- names(d)
vlab <- gsub("\\.", " ", vlab)
vlab <- gsub(" +", " ", vlab)
vlab <- gsub(" $", "", vlab)
vlab <- sub("Em relação ao nível de confiança indique não confio confio pouco ou confio muito para cada fonte de informação", "Confiança:", vlab)
vlab <- sub("Em relação às seguintes categorias de pessoas marque se os governos do PT fizeram pouco por essas pessoas fizeram o que era possível fizeram o suficiente ou não deveriam ter feito nada", "O que o PT fez por:", vlab)
vlab <- sub("Na sua opinião o governo deve ampliar a quantidade de famílias que recebem o Bolsa Família manter como está diminuir ou acabar com o Programa Bolsa Família",
            "O que o governo deve fazer com o Bolsa Família?", vlab)
vlab <- sub("Da lista de formas de atuação política abaixo marque se já fez alguma dessas coisas se poderia vir a fazer ou se não faria nunca", "Participação:", vlab)
vlab <- sub("Responda para cada forma de organização política se você não pertence pertence mas não participa pertence e participa", "Organização:", vlab)
vlab <- sub("Você acredita que as instituições de segurança do Estado brasileiro devem ter ações mais rígidas no combate à violência como abordagens policiais mais duras e maior liberdade para a polícia agir como achar melhor",
            "Polícia mais rígida", vlab)
vlab <- sub("Dos valores disponíveis abaixo que nota de 0 a 10 você daria para cada um dos seguintes partidos", "Nota para partido:", vlab)
vlab <- sub("Algumas empresas como o supermercado Carrefour decidiram contratar pessoas transexuais e travestis a fim de dar suporte a grupos minoritários A respeito disso você", "O que acha do Carrefour contratar pessoas trans?", vlab)
vlab <- sub("Algumas empresas quando fazem propaganda dos seus produtos no dia dos namorados estão mostrando casais do mesmo sexo formado por dois homens ou por duas mulheres Você acha que", "O que acha de propagandas com casais homossexuais?", vlab)
vlab <- sub("^X ", "", vlab)
vlab <- sub("Sobre seu comportamento nas redes sociais para cada uma dessas situações responda se você não faz realiza com pouca frequência ou faz com bastante frequência",
            "Frequência:", vlab)
vlab <- sub("Organização: Conselho fórum de discussão política específico", "Organização: Fórum de discussão política", vlab)
vlab <- sub("Organização: Movimento social aqui não existe distinção ideológica", "Organização: Movimento social", vlab)
vlab <- sub("Organização: Associação comunitária de bairro defesa dos direitos dos animais ecológica defesa de direitos básicos", "Organização: Associação", vlab)
vlab <- sub("Organização: Algum outro tipo de organização da sociedade civil", "Organização: Algum outro tipo", vlab)
vlab <- sub("Contando com você quantas pessoas residem em sua casa", "Quantas pessoas residem em sua casa", vlab)
vlab <- sub("Qual é a sua renda mensal individual aproximada", "Renda mensal individual", vlab)
vlab <- sub("Qual é a sua renda mensal familiar aproximada", "Renda mensal familiar", vlab)
vlab <- sub("Você ou alguém em sua casa é beneficiário do Programa Bolsa Família", "Beneficiário do Programa Bolsa Família", vlab)
vlab <- sub("Você é beneficiário do programa Minha Casa Minha Vida", "Beneficiário do programa Minha Casa Minha Vida", vlab)
vlab <- sub("Você ou alguém da sua família mais próxima ingressou na universidade por meio de cotas", "Ingresso na universidade por meio de cotas", vlab)
vlab <- sub("Você ou alguém da sua família já deixou de entrar na universidade por conta das cotas", "Deixou de entrar na universidade por conta das cotas", vlab)
vlab <- sub("Você já teve empregada doméstica mesmo que tenha sido há muito tempo por exemplo quando era criança", "Você já teve empregada doméstica", vlab)
vlab <- sub("Comparando com 10 anos atrás você acha que a situação financeira da sua família está", "Situação financeira comparando com 10 anos atrás", vlab)
vlab <- sub("Você sente dificuldade de aumentar seu padrão de vida de aumentar sua renda", "Sente dificuldade de aumentar padrão de vida", vlab)
vlab <- sub("Na sua opinião qual dos itens abaixo é o principal responsável pela sua dificuldade de aumentar seu padrão de vida", "Principal responsável pela dificuldade", vlab)
vlab <- sub("Participação: Financiou doou dinheiro a algum movimento civil contra ou a favor do governo", "Participação: Doou dinheiro", vlab)
vlab <- sub("Se você pudesse escolher o país em que nasceria você teria escolhido", "Onde nasceria", vlab)
vlab <- sub("Sobre a afirmação As abordagens policiais são mais violentas em bairros mais pobres Você", "Policiais mais violentos em bairros mais pobres", vlab)
vlab <- sub("Você acha que a democracia funcionaria melhor sem partidos políticos ou os partidos são necessários", "Democracia precisa de partidos", vlab)
vlab <- sub("Na sua opinião qual é o partido mais corrupto do Brasil", "Partido mais corrupto do Brasil", vlab)
vlab <- sub("Se você pudesse EXCLUIR partidos políticos das próximas eleições quais seriam", "Quais partidos excluiria", vlab)
vlab <- sub("Em geral o quanto você considera prioritário que um partido político defenda causas raciais como pautas negras e indígenas", "Prioritário que um partido defenda causas raciais", vlab)
vlab <- sub("Algumas pessoas defendem o fechamento do congresso Na sua opinião", "Fechamento do congresso", vlab)
vlab <- sub("Marque o motivo pelo qual você acha que o congresso deve ser extinto", "Motivo pelo qual congresso deve ser extinto", vlab)
vlab <- sub("Em quem você votou no primeiro turno das eleições de 2018", "Voto no primeiro turno das eleições de 2018", vlab)
vlab <- sub("Se houvesse uma eleição hoje para Presidente da República em qual tipo de candidato você votaria", "Se fosse hoje, em qual tipo de candidato votaria", vlab)
vlab <- sub("De acordo com a sua opinião um Presidente deve ser você pode marcar mais de uma opção", "Presidente deve ser", vlab)
vlab <- sub("Você acredita que a presença de militares no governo federal faz com que a política seja", "Presença de militares no governo federal", vlab)
vlab <- sub("Confiança: Aplicativos de mensagem instantânea Whatsapp Messenger Telegram", "Confiança: Aplicativos de mensagem", vlab)
vlab <- sub("Confiança: Redes sociais Instagram Twitter Facebook", "Confiança: Redes sociais", vlab)
vlab <- sub("Confiança: Meios de comunicação tradicionais Jornais televisivos rádio", "Confiança: Meios de comunicação tradicionais", vlab)
vlab <- sub("Frequência: Segue alguma página pessoa que fala sobre política", "Frequência: Segue página sobre política", vlab)
vlab <- sub("Frequência: Participa de grupos online que discutem política", "Frequência: Participa de grupos que discutem política", vlab)
vlab <- sub("Frequência: Comenta em postagens que falam sobre política", "Frequência: Comenta em postagens sobre política", vlab)
vlab <- sub("Frequência: Cria suas próprias postagens que falam sobre política", "Frequência: Cria postagens sobre política", vlab)
vlab <- sub("Frequência: Compartilha postagens que falam sobre política", "Frequência: Compartilha postagens sobre política", vlab)
vlab <- sub("Você considera o discurso de Bolsonaro e de seus apoiadores com relação a mulheres negros indígenas LGBTs como agressivos", "Discurso de Bolsonaro agressivo", vlab)
vlab <- sub("Sobre o tema ideologia de gênero você acha que pode marcar mais de uma opção", "Ideologia de gênero", vlab)
vlab <- sub("Você acha que o presidente Bolsonaro defende as mulheres", "Bolsonaro defende as mulheres", vlab)
vlab <- sub("Marque os motivos pelos quais você acha que o presidente Bolsonaro defende as mulheres", "Motivos pelos quais Bolsonaro defende as mulheres", vlab)
vlab <- sub("Quando os homens realizam atividades domésticas você considera que", "Quando os homens realizam atividades domésticas", vlab)
vlab <- sub("Você acha que as feministas são pode marcar mais de uma opção", "As feministas são", vlab)
vlab <- sub("Sobre o aborto você acha que pode marcar mais de uma opção", "Sobre o aborto", vlab)
vlab <- sub("Você concorda ou discorda que o governo deveria incentivar outras empresas a contratarem pessoas transexuais e travestis", "Governo deveria incentivar contratação de trans", vlab)
vlab <- sub("A lei brasileira determina que para cada partido pelo menos 30 das candidaturas devem ser de mulheres Você concorda ou discorda com esta lei", "30% das candidaturas devem ser de mulheres", vlab)
vlab <- sub("Você concorda ou discorda que também deveria haver um percentual mínimo de candidatos negros", "Percentual mínimo de candidatos negros", vlab)
vlab <- sub("Confiança: Aplicativos de mensagem", "Confiança em app de mensagem", vlab)
vlab <- sub("Confiança: Redes sociais", "Confiança em redes sociais", vlab)
vlab <- sub("Confiança: Meios de comunicação tradicionais", "Confiança em mídia tradicional", vlab)

# Criar nomes novos para as variáveis, formados pela letra "q" seguida do
# número da coluna.
names(d) <- paste0("q", 1:ncol(d))

# Fazer algumas correções nas variáveis que são do tipo character: eliminar
# espaços em branco no início e no final e, se o número de valores distintos
# for menor do que 16, converter em variável categórica ("factor").
for(i in 1:ncol(d)){
    if(is.character(d[[i]])){
        d[[i]] <- sub(" *$", "", d[[i]])
        d[[i]] <- sub("^ *", "", d[[i]])
        d[[i]][d[[i]] == ""] <- NA
        if(sum(grepl(";", d[[i]])))
            cat("Questão de múltipla escolha: q", i, "\n", sep = "")
        if(length(levels(factor(d[[i]]))) < 16)
            d[[i]] <- factor(d[[i]])
    }
}

# Assegurar que as questões de múltipla escolha permaneceram sendo objetos do
# tipo "character".
d$q47 <- as.character(d$q47)
d$q50 <- as.character(d$q50)
d$q54 <- as.character(d$q54)
d$q70 <- as.character(d$q70)
d$q71 <- as.character(d$q71)
d$q73 <- as.character(d$q73)
d$q75 <- as.character(d$q75)
d$q78 <- as.character(d$q78)
d$q79 <- as.character(d$q79)

# Questionários com respostas abertas repetidas, ou seja, respondidos mais de
# uma vez pela mesma pessoa:
i1 <- grep("Habilitado para o cargo", d$q54)
i2 <- grep("O tema orienta e ajuda", d$q70)
i3 <- grep("Depende da idade e da abordagem", d$q71)
i4 <- grep("Acredito que ainda é um tema que precisa ser debatido fora do ambiente escolar", d$q73)
i5 <- grep("As escolas não devem interferir na sexualidade, mas devem respeitar e impor respeito", d$q73)
i6 <- grep("Deixa o adolescente fazer o que quiser", d$q73)
i7 <- grep("O tema deve ser debatido em casa", d$q73)
i8 <- grep("Ele defende dessa forma, ele defende qualquer pessoa, independente do gênero", d$q75)
i9 <- grep("Igualdade entre os sexos , com mulheres assumindo cargos e tendo voz no seu governo", d$q75)

ii <- c(i1[2:length(i1)],
        i2[2:length(i2)],
        i3[2:length(i3)],
        i4[2:length(i4)],
        i5[2:length(i5)],
        i6[2:length(i6)],
        i7[2:length(i7)],
        i8[2:length(i8)],
        i9[2:length(i9)])

ii <- sort(ii)
ii <- sort(ii[!duplicated(ii)])
info <- nrow(d)
names(info) <- "Número total de questionários respondidos"
d <- d[-ii, ]
info <- c(info, "Respondidos mais de uma vez" = length(ii))

# Corrigir ordem em categóricas ordenáveis e reduzir rótulos de categorias
d$q4 <- factor(d$q4, levels = c("Fundamental incompleto",
                                "Fundamental completo",
                                "Ensino médio incompleto",
                                "Ensino médio completo",
                                "Superior incompleto",
                                "Superior completo", 
                                "Pós-graduação"))

# Considerar pardos os que deram respostas abertas:
d$q5[d$q5 %in% c("A classificação oficial não contempla minha origem nortista e nordestina", 
                 "Brasileiro", "Mulato")] <- "Pardo"
d$q5 <- droplevels(d$q5)

levels(d$q8) <- sub("Ela é importante, mas nem sempre deve ser considerado tudo o que está escrito nela",
                    "Importante", levels(d$q8))
levels(d$q8) <- sub("Ela é muito importante, pois é a palavra de Deus", "Muito importante", levels(d$q8))
levels(d$q8) <- sub("Não é importante", "Não importante", levels(d$q8))

d$q9 <- factor(d$q9, levels = c("Nunca",
                                "Raramente",
                                "Em dias festivos ou sagrados",
                                "Semanalmente",
                                "Mais de uma vez por semana",
                                "Diariamente"))

d$q11 <- factor(d$q11, levels = c("Sem renda",
                                  "Até R$ 600",
                                  "Entre R$ 600 e R$ 1100,00",
                                  "R$ 1.100 - R$ 2.000",
                                  "R$ 2.000 - R$ 4.000",
                                  "R$ 4.000 - R$ 6.000",
                                  "R$ 6.000 - R$ 10.000",
                                  "Mais de R$10.000"))

d$q12 <- factor(d$q12, levels = c("Até R$600",
                                  "Entre R$ 600 e R$ 1100,00",
                                  "R$ 1.100 - R$ 2.000",
                                  "R$ 2.000 - R$ 4.000",
                                  "R$ 4.000 - R$ 6.000",
                                  "R$ 6.000 - R$ 10.000",
                                  "Mais de R$10.000"))

levels(d$q14) <- sub("Acabar com o programa", "Acabar", levels(d$q14))
levels(d$q14) <- sub("Manter como está", "Manter", levels(d$q14))

d$q20 <- factor(d$q20, levels = c("Pior", "Igual", "Melhor"))

levels(d$q21) <- sub("Não sinto dificuldade", "Não", levels(d$q21))
levels(d$q21) <- sub("Não. Estou feliz com o que tenho", "Estou feliz",
                     levels(d$q21))
levels(d$q21) <- sub("Sim. Sinto dificuldade", "Sim", levels(d$q21))

levels(d$q23) <- sub("\\.", "", levels(d$q23))
levels(d$q24) <- sub("\\.", "", levels(d$q24))
levels(d$q25) <- sub("\\.", "", levels(d$q25))
levels(d$q26) <- sub("\\.", "", levels(d$q26))
levels(d$q27) <- sub("\\.", "", levels(d$q27))

d$q23 <- factor(d$q23, levels = c("Nunca faria", "Poderia fazer", "Já fiz"))
d$q24 <- factor(d$q24, levels = c("Nunca faria", "Poderia fazer", "Já fiz"))
d$q25 <- factor(d$q25, levels = c("Nunca faria", "Poderia fazer", "Já fiz"))
d$q26 <- factor(d$q26, levels = c("Nunca faria", "Poderia fazer", "Já fiz"))
d$q27 <- factor(d$q27, levels = c("Nunca faria", "Poderia fazer", "Já fiz"))

FactorPPP <- function(x) {
    levels(x) <- sub("Pertence e participa", "Participa", levels(x))
    levels(x) <- sub("Pertence mas não participa", "Pertence", levels(x))
    x <- factor(x, c("Não pertence", "Pertence", "Participa"))
    x
}

d$q28 <- FactorPPP(d$q28)
d$q29 <- FactorPPP(d$q29)
d$q30 <- FactorPPP(d$q30)
d$q31 <- FactorPPP(d$q31)
d$q32 <- FactorPPP(d$q32)
d$q33 <- FactorPPP(d$q33)
d$q34 <- FactorPPP(d$q34)
d$q35 <- FactorPPP(d$q35)

levels(d$q37) <- sub("Não estou satisfeito, mas não vejo opção melhor.",
                     "Conformado", levels(d$q37))

levels(d$q38) <- sub("Não tenho conhecimento sobre o assunto",
                     "Não sei", levels(d$q38))
levels(d$q38) <- sub("Não, não acho que a ciência brasileira seja confiável",
                     "Não", levels(d$q38))
levels(d$q38) <- sub("Sim, acredito parcialmente", "Parcialmente",
                     levels(d$q38))
levels(d$q38) <- sub("Sim, acredito plenamente", "Plenamente", levels(d$q38))
d$q38 <- factor(d$q38, c("Não", "Não sei", "Parcialmente", "Plenamente"))

levels(d$q41) <- sub("A democracia precisa de partidos", "Precisa",
                     levels(d$q41))
levels(d$q41) <- sub("Funcionaria melhor sem partidos políticos",
                     "Melhor sem", levels(d$q41))
d$q41 <- factor(d$q41, c("Melhor sem", "Precisa"))

levels(d$q48) <- sub("Essas causas não precisam ser defendidas", "Não",
                     levels(d$q48))
levels(d$q48) <- sub("Nada prioritário", "Nada", levels(d$q48))
levels(d$q48) <- sub("Pouco prioritário", "Pouco", levels(d$q48))
levels(d$q48) <- sub("Parcialmente prioritário", "Parcialmente", levels(d$q48))

d$q48 <- factor(d$q48,
                c("Não", "Nada", "Pouco", "Parcialmente", "Prioritário"))

levels(d$q49) <- sub("O congresso deve permanecer aberto e os deputados e senadores devem concluir os seus mandatos.",
                     "Aberto", levels(d$q49))
levels(d$q49) <- sub("O congresso deveria ser extinto, fechado para sempre.",
                     "Extinto", levels(d$q49))
levels(d$q49) <- sub("O congresso deveria ser fechado e ser convocadas novas eleições.",
                     "Renovado", levels(d$q49))
d$q49 <- factor(d$q49, c("Extinto", "Renovado", "Aberto"))

levels(d$q53) <- sub("Alguém jovem e que está se candidatando a um cargo político pela primeira vez e nunca se envolveu com política antes",
                     "Jovem", levels(d$q53))
levels(d$q53) <- sub("Alguém mais experiente, que já tenha ocupado algum cargo político",
                     "Experiente", levels(d$q53))
levels(d$q53) <- sub("Alguém que seja de um partido político criado recentemente",
                     "Recente", levels(d$q53))
levels(d$q53) <- sub("Alguém que seja famoso, mas que nunca se envolveu com política antes",
                     "Famoso", levels(d$q53))
d$q53 <- factor(d$q53, c("Experiente", "Recente", "Famoso", "Jovem"))

d$q55 <- factor(d$q55, c("Menos corrupta", "Não muda", "Mais corrupta"))

levels(d$q56) <- sub("Confio Muito", "Muito", levels(d$q56))
levels(d$q56) <- sub("Confio pouco", "Pouco", levels(d$q56))
levels(d$q56) <- sub("Não confio", "Não", levels(d$q56))
d$q56 <- factor(d$q56, c("Não", "Pouco", "Muito"))

levels(d$q57) <- sub("Confio Muito", "Muito", levels(d$q57))
levels(d$q57) <- sub("Confio pouco", "Pouco", levels(d$q57))
levels(d$q57) <- sub("Não confio", "Não", levels(d$q57))
d$q57 <- factor(d$q57, c("Não", "Pouco", "Muito"))

levels(d$q58) <- sub("Confio Muito", "Muito", levels(d$q58))
levels(d$q58) <- sub("Confio pouco", "Pouco", levels(d$q58))
levels(d$q58) <- sub("Não confio", "Não", levels(d$q58))
d$q58 <- factor(d$q58, c("Não", "Pouco", "Muito"))

levels(d$q59) <- sub("Faz com bastante frequência", "Bastante", levels(d$q59))
levels(d$q59) <- sub("Realiza com pouca frequência", "Pouca", levels(d$q59))
d$q59 <- factor(d$q59, c("Não faz", "Pouca", "Bastante"))

levels(d$q60) <- sub("Faz com bastante frequência", "Bastante", levels(d$q60))
levels(d$q60) <- sub("Realiza com pouca frequência", "Pouca", levels(d$q60))
d$q60 <- factor(d$q60, c("Não faz", "Pouca", "Bastante"))

levels(d$q61) <- sub("Faz com bastante frequência", "Bastante", levels(d$q61))
levels(d$q61) <- sub("Realiza com pouca frequência", "Pouca", levels(d$q61))
d$q61 <- factor(d$q61, c("Não faz", "Pouca", "Bastante"))

levels(d$q62) <- sub("Faz com bastante frequência", "Bastante", levels(d$q62))
levels(d$q62) <- sub("Realiza com pouca frequência", "Pouca", levels(d$q62))
d$q62 <- factor(d$q62, c("Não faz", "Pouca", "Bastante"))

levels(d$q63) <- sub("Faz com bastante frequência", "Bastante", levels(d$q63))
levels(d$q63) <- sub("Realiza com pouca frequência", "Pouca", levels(d$q63))
d$q63 <- factor(d$q63, c("Não faz", "Pouca", "Bastante"))

levels(d$q64) <- sub("Fizeram o que era possível", "Possível", levels(d$q64))
levels(d$q64) <- sub("Não deveriam ter feito nada", "Demasiado", levels(d$q64))
levels(d$q64) <- sub("Pouco, deveriam ter feito mais", "Pouco", levels(d$q64))
d$q64 <- factor(d$q64, c("Demasiado", "Suficiente", "Possível", "Pouco"))

levels(d$q65) <- sub("Fizeram o que era possível", "Possível", levels(d$q65))
levels(d$q65) <- sub("Não deveriam ter feito nada", "Demasiado", levels(d$q65))
levels(d$q65) <- sub("Pouco, deveriam ter feito mais", "Pouco", levels(d$q65))
d$q65 <- factor(d$q65, c("Demasiado", "Suficiente", "Possível", "Pouco"))

levels(d$q66) <- sub("Fizeram o que era possível", "Possível", levels(d$q66))
levels(d$q66) <- sub("Não deveriam ter feito nada", "Demasiado", levels(d$q66))
levels(d$q66) <- sub("Pouco, deveriam ter feito mais", "Pouco", levels(d$q66))
d$q66 <- factor(d$q66, c("Demasiado", "Suficiente", "Possível", "Pouco"))

levels(d$q67) <- sub("Fizeram o que era possível", "Possível", levels(d$q67))
levels(d$q67) <- sub("Não deveriam ter feito nada", "Demasiado", levels(d$q67))
levels(d$q67) <- sub("Pouco, deveriam ter feito mais", "Pouco", levels(d$q67))
d$q67 <- factor(d$q67, c("Demasiado", "Suficiente", "Possível", "Pouco"))



levels(d$q68) <- sub("Não há agressividade no discurso de Bolsonaro nesses casos", "Não", levels(d$q68))
levels(d$q68) <- sub("Não, ele apenas faz brincadeiras sobre esses temas", "Brincadeira", levels(d$q68))
levels(d$q68) <- sub("Não, ele é apenas sincero", "Sincero", levels(d$q68))
levels(d$q68) <- sub("Sim, muito agressivo", "Muito", levels(d$q68))
levels(d$q68) <- sub("Sim, um pouco agressivos", "Pouco", levels(d$q68))
d$q68 <- factor(d$q68, c("Não", "Brincadeira", "Sincero", "Pouco", "Muito"))

levels(d$q69) <- sub("Não conhece o tema", "Não sabe", levels(d$q69))
d$q69 <- factor(d$q69, c("Contra", "Não sabe", "A favor"))

levels(d$q76) <- sub("Estão cumprindo com sua obrigação pois os homens devem realizar tarefas domésticas.", "Cumprindo obrigação", levels(d$q76))
levels(d$q76) <- sub("Estão fazendo mais do que sua obrigação porque as tarefas domésticas são responsabilidade das mulheres.", "Mais que obrigação", levels(d$q76))

levels(d$q77) <- sub("Prejudicial à sociedade", "Prejudicial", levels(d$q77))
d$q77 <- factor(d$q77, c("Prejudicial", "Desnecessário",
                         "Importante", "Muito importante"))

levels(d$q80) <- sub("Concorda com tais práticas de contratação", "Concorda", levels(d$q80))
levels(d$q80) <- sub("Discorda de tais práticas de contratação", "Discorda", levels(d$q80))
d$q80 <- relevel(d$q80, c("Discorda"))

d$q81 <- relevel(d$q81, "Discordo")

levels(d$q82) <- sub("O Brasil era melhor quando não existiam essas propagandas", "Pior", levels(d$q82))
levels(d$q82) <- sub("O Brasil está melhor assim","Melhor", levels(d$q82))

d$q83 <- relevel(d$q83, "Discordo")

d$q84 <- relevel(d$q84, "Discordo")

# Atribuir rótulos às colunas do banco de dados:
for(i in 1:ncol(d))
    attr(d[[i]], "label") <- vlab[i]


# Salvar banco de dados
save(d, info, file = "dados.RData")
