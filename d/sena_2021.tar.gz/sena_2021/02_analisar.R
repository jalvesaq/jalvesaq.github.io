library("descr")
library("psych")
library("ggplot2")
library("sjPlot")
library("tidyverse")

set.seed(2020)

load("dados.RData")

d <- select(d,
            q1, q2, q3, q4, q5, q6, q8, q9, q11, q12, q51, q70, q71,
            q72, q73, q75, q76, q77, q78, q79, q80, q81, q82, q83)

d <- mutate(d,

            # Na variável "sexo", considerar NA as duas respostas abertas:
            sexo = factor(case_match(q2,
                              "Feminino" ~ "Feminino",
                              "Masculino" ~ "Masculino")),

            idade = q3,

            escola = as.numeric(q4) / 8,

            branco = case_match(q5,
                                "Branco" ~ TRUE,
                                .default = FALSE),

            # Reduzir o número de categorias da variável "Religião"
            religiao = factor(case_match(q6,
                                         c("Sem religião",
                                           "É ateu/Não acredita em Deus") ~ 1,
                                         "Católica" ~ 2,
                                         "Evangélica" ~ 3,
                                         .default = 4),
                              levels = c(1, 2, 3, 4),
                              labels = c("Sem religião", "Católica",
                                         "Evangélica", "Outra")),

            biblia = case_match(q8,
                                "Muito importante" ~ 1,
                                .default = 0),

            freq.igreja = as.numeric(q9),

            renda = case_match(q11,
                               "Sem renda" ~ 0,
                               "Até R$ 600" ~ 1,
                               "Entre R$ 600 e R$ 1100,00" ~ 2,
                               "R$ 1.100 - R$ 2.000" ~ 3,
                               "R$ 2.000 - R$ 4.000" ~ 4,
                               "R$ 4.000 - R$ 6.000" ~ 5,
                               "R$ 6.000 - R$ 10.000" ~ 6,
                               "Mais de R$10.000" ~ 7),

            renda.fam = case_match(q12,
                                   # "Sem renda" ~ 0,
                                   "Até R$600" ~ 1,
                                   "Entre R$ 600 e R$ 1100,00" ~ 2,
                                   "R$ 1.100 - R$ 2.000" ~ 3,
                                   "R$ 2.000 - R$ 4.000" ~ 4,
                                   "R$ 4.000 - R$ 6.000" ~ 5,
                                   "R$ 6.000 - R$ 10.000" ~ 6,
                                   "Mais de R$10.000" ~ 7),

            emprego.trans = case_match(q80,
                                       "Discorda" ~ FALSE,
                                       .default = TRUE),

            propaganda.homo = case_match(q82,
                                         "Pior" ~ 0,
                                         .default = 1),

            voto1 = factor(case_match(q51,
                                      "Jair Bolsonaro" ~ 2,
                                      "Fernando Haddad" ~ 3,
                                      "Ciro Gomes" ~ 4,
                                      .default = 1),
                           levels = c(1, 2, 3, 4),
                           labels = c("Outros", "Bolsonaro", "Haddad", "Ciro")),

            .keep = "unused")

# Não aceitar que a renda familiar seja inferior à renda do indivíduo:
d$renda.fam[!is.na(d$renda.fam) & d$renda.fam < d$renda] <-
    d$renda[!is.na(d$renda.fam) & d$renda.fam < d$renda]
d$renda.fam <- d$renda.fam / 7

# Não precisamos mais da variável "Renda individual":
d$renda <- NULL

d$freqreli <- 1
d$freqreli[d$freq.igreja > 1 & d$religiao == "Católica"] <- 2
d$freqreli[d$freq.igreja > 1 & d$religiao == "Evangélica"] <- 3
d$freqreli <- factor(d$freqreli, levels = c(1, 2, 3),
                     labels = c("Nenhuma", "Cat", "Evan"))

# Não precisamos mais da variável "freq.igreja":
d$freq.igreja <- NULL

# Q71 - ÍNDICE DE CONTRARIEDADE À EDUCAÇÃO SEXUAL
expoe <- grepl("O tema expõe os alunos a um assunto que não condiz com a idade", d$q71)
inst <- grepl("O tema instiga os alunos a iniciarem sua vida sexual muito cedo", d$q71)
induz <- grepl("O tema induz os alunos à homossexualidade", d$q71)
pais <- rep(FALSE, nrow(d))
for(p in c("casa", "pais", "família", "vida comum", "conteúdo", "científicas"))
    pais[grepl(p, d$q71)] <- TRUE
d$educ.sex.ncontra <- expoe + inst + induz + pais
attr(d$educ.sex.ncontra, "label") <- "N motivos contra educação sexual"
rm(p, expoe, inst, induz, pais)

# Q79 - ÍNDICE CONTRA AO ABORTO
deus <- grepl("O aborto vai contra os princípios de Deus", d$q79)
saude <- grepl("O governo deveria se preocupar em primeiro lugar com a saúde da mulher", d$q79)
assassino <- grepl("Quem faz/incentiva o aborto é assassino/a", d$q79)
consequencias <- grepl("ela deve arcar com as consequências", d$q79)
d$antiaborto <- deus + consequencias + assassino
attr(d$antiaborto, "label") <- "N motivos para ser contra aborto"
rm(deus, saude, assassino, consequencias)

# Q78 - ÍNDICE ANTIFEMINISMO  
mais <- grepl("Mulheres que querem mais privilégios do que deveriam ter", d$q78)
burra <- grepl("Mulheres burras", d$q78)
deus <- grepl("Mulheres rebeldes que desobedecem Deus", d$q78)
hig <- grepl("Mulheres sem higiene", d$q78)
resp <- grepl("Mulheres que não se dão o respeito", d$q78)
desne <- grepl("As mulheres já conquistaram todos os direitos, então não há necessidade de o feminismo existir", d$q78)
d$antifem2 <- mais + burra + deus + hig + resp + desne
attr(d$antifem2, "label") <- "N motivos contra feminismo"
rm(mais, burra, deus, hig, resp, desne)

# Q73 - ÍNDICE IDEOLOGIA DE GÊNERO
# write.table(d[, c("q1", "q73")], row.names = FALSE, sep="\t", file="sub.q73.tab")
b <- read.csv("sub_q73_.csv")
b$q73 <- NULL
b$debater <- factor(b$debater)
d <- left_join(d, b)

rm(b)

# Eliminar dados de respondentes com menos de 16 anos
menor <- d$idade < 16
info <- c(info, "Menor de 16 anos" = sum(menor))
d <- filter(d, idade >= 16)

info <- c(info, "Não binário" = sum(is.na(d$sexo)))
d <- filter(d, !is.na(sexo))

info <- c(info, "N final" = nrow(d))

info

attr(d$religiao, "label") <- "Religião"
attr(d$escola, "label") <- "Escolaridade"
attr(d$branco, "label") <- "Cor branca"
attr(d$sexo, "label") <- "Sexo"
attr(d$biblia, "label") <- "A Bíblia é muito importante"
attr(d$renda.fam, "label") <- "Renda familiar"
attr(d$emprego.trans, "label") <- "Contratação de pessoa trans"
attr(d$freqreli, "label") <- "Igreja que frequenta"
attr(d$voto1, "label") <- "Voto no 1º turno"
attr(d$debater, "label") <- "Favorável a discussão de gênero na escola"

# Período da pesquisa:
c(min(sort(d$q1[d$sexo == "Feminino"])), max(sort(d$q1[d$sexo == "Feminino"])))

ide.gen.esc <- grepl("O tema deve ser combatido nas escolas", d$q73)
ide.gen.homo <- grepl("O tema induz à homossexualidade", d$q73)
ide.gen.fam <- grepl("O tema possibilita o ataque à constituição das famílias", d$q73)
contra.debater <- !is.na(d$debater) & d$debater == "n"
d$ideologia <- ide.gen.esc + ide.gen.homo + ide.gen.fam + contra.debater
attr(d$ideologia, "label") <- "N motivos para ser contra ideologia de gênero"
rm(ide.gen.esc, ide.gen.homo,  ide.gen.fam, contra.debater)

# CONSERVADORISMO EM RELAÇÃO AO GÊNERO 
d$idade.educ <- grepl("O tema expõe os alunos a um assunto que não condiz com a idade", d$q71)
d$cedo.educ <- grepl("O tema instiga os alunos a iniciarem sua vida sexual muito cedo", d$q71)
d$homossexualidade.educ <- grepl("O tema induz os alunos à homossexualidade", d$q71)
d$atividades.domesticas <- (!is.na(d$q76) & d$q76 == "Mais que obrigação")
d$feministas.prejudicial <- (!is.na(d$q77) & d$q77 == "Prejudicial")
d$minorias <- d$emprego.trans == FALSE
d$minorias.incentivo <- (!is.na(d$q81) & d$q81 == "Discordo")
d$propaganda.sex <- d$propaganda.homo == 0
d$candidaturas <- (!is.na(d$q83) & d$q83 == "Discordo")

# Figura 1: 
fig1 <- crosstab(d$sexo, d$voto1, inv.y = TRUE)

# Figura 2:
fig2 <- with(d[d$sexo == "Feminino", ],
             crosstab(antiaborto, voto1, inv.y = TRUE,
                      xlab = "Voto no primeiro turno",
                      ylab = "N motivos para ser contra aborto"))

# Figura 3:
fig3 <- with(d[d$sexo == "Feminino", ],
             crosstab(antifem2, voto1, inv.y = TRUE,
                      xlab = "Voto no primeiro turno",
                      ylab = "Antifeminismo"))

# Figura 4:
fig4 <- with(d[d$sexo == "Feminino", ],
             crosstab(educ.sex.ncontra, voto1, inv.y = TRUE,
                      xlab = "Voto no primeiro turno",
                      ylab = "N motivos contra educação sexual"))

# Figura 5:
fig5 <- with(d[d$sexo == "Feminino", ],
             crosstab(ideologia, voto1, inv.y = TRUE,
                      xlab = "Voto no primeiro turno",
                      ylab = "N motivos contra ideologia de gênero"))

# Figura 6:
d$emprgtrans <- factor(d$emprego.trans, levels = c(FALSE, TRUE),
                       labels = c("Discorda", "Concorda"))
fig6 <- with(d[d$sexo == "Feminino", ],
             crosstab(emprgtrans, voto1, inv.y = TRUE,
                      xlab = "Voto no primeiro turno",
                      ylab = "Contratação de pessoa trans"))

# Figura 7:
d$prpgdhomo <- factor(d$propaganda.homo, levels = c(0, 1),
                      labels = c("Pior", "Melhor"))
fig7 <- with(d[d$sexo == "Feminino", ],
             crosstab(prpgdhomo, voto1, inv.y = TRUE,
                      xlab = "Voto no primeiro turno",
                      ylab = "Propaganda com casais homossexuais"))

# Figura 8
d$candidaturas.r <- factor(d$candidaturas,
                           levels = c(FALSE, TRUE),
                           labels = c("Concordo", "Discordo"))
fig8 <- with(d[d$sexo == "Feminino", ],
             crosstab(candidaturas.r, voto1,
                      xlab = "Voto no primeiro turno",
                      ylab = "Candidaturas de mulheres"))

# ANÁLISE DOS COMPONENTES PRINCIPAIS
p <- d[, c("idade.educ", "cedo.educ", "homossexualidade.educ",
           "atividades.domesticas", "feministas.prejudicial", "minorias",
           "minorias.incentivo", "propaganda.sex", "candidaturas")]

pc <- principal(p, 1)
pcTab <- loadings(pc)
rownames(pcTab) <- sub("^idade.educ$", "Assunto que não condiz com a idade", rownames(pcTab))
rownames(pcTab) <- sub("^cedo.educ$", "Instiga vida sexual muito cedo", rownames(pcTab))
rownames(pcTab) <- sub("^homossexualidade.educ$", "O tema induz os alunos à homossexualidade", rownames(pcTab))
rownames(pcTab) <- sub("^atividades.domesticas$", "Atividades domésticas", rownames(pcTab))
rownames(pcTab) <- sub("^feministas.prejudicial$", "Feminismo é prejudicial", rownames(pcTab))
rownames(pcTab) <- sub("^minorias$", "Carrefour contratar pessoas trans", rownames(pcTab))
rownames(pcTab) <- sub("^minorias.incentivo$", "Governo incentivar contratação de pessoas trans", rownames(pcTab))
rownames(pcTab) <- sub("^propaganda.sex$", "Propagada com casais homossexuais", rownames(pcTab))
rownames(pcTab) <- sub("^candidaturas$", "Candidaturas de mulheres", rownames(pcTab))

# Tabela 1:
pcTab

d$conservador.genero <- d$idade.educ + d$cedo.educ + d$homossexualidade.educ +
    d$feministas.prejudicial + d$minorias + d$minorias.incentivo +
    d$propaganda.sex + d$candidaturas
attr(d$conservador.genero, "label") <- "Conservadorismo de gênero"

# Figura 9:
fig9 <- crosstab(d$sexo, d$conservador.genero, inv.y = TRUE,
                 xlab = "Conservadorismo de gênero",
                 ylab = "Sexo")

# ANÁLISE DE REGRESSÃO

d$evan <- as.numeric(d$freqreli == "Evan")
d$catl <- as.numeric(d$freqreli == "Cat")
attr(d$evan, "label") <- "Frequenta igreja: Evangélica"
attr(d$catl, "label") <- "Frequenta igreja: Católica"

d$idade <- d$idade / 10
attr(d$idade, "label") <- "Idade em décadas"

d$votob <- as.numeric(d$voto1 == "Bolsonaro")
attr(d$votob, "label") <- "Voto em Bolsonaro no 1º turno"

f <- d[d$sexo == "Feminino", ]

m1 <- glm(votob ~ conservador.genero + idade + escola + branco + renda.fam +
          catl + evan + biblia, family = binomial(link = "logit"), data = f)

m2 <- lm(conservador.genero ~ idade + escola + branco + renda.fam + catl +
         evan + biblia, data = f)

# Figura 10:
plot_model(m1, transform = NULL, axis.title = "Estimativas")

# Figura 11:
plot_model(m2, axis.title = "Estimativas")

# Tabelas correspondentes às figuras:
# fig1
# fig2
# fig3
# fig4
# fig5
# fig6
# fig7
# fig8
# fig9
# summary(m1)
# summary(m2)
