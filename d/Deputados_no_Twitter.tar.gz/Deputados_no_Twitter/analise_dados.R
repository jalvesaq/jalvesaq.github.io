# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#                                                                             #
# Este script produz as tabelas e figuras apresentadas no artigo:             #
#                                                                             #
#                   DEPUTADOS BRASILEIROS NO TWITTER:                         #
#      um estudo quantitativo dos padrões de adoção e uso da ferramenta       #
#                                                                             #
#                 Francisco Paulo Jamil Almeida Marques                       #
#                         Jakson Alves de Aquino                              #
#                               Edna Miola                                    #
#                                                                             #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #



library(descr)
library(gdata)
library(memisc)

###############################################################################
##  I - Manipulação dos Dados
###############################################################################

# Mudanças de endereço:
atualizarTwitter <- function(x)
{
    x <- sub("^BrunaFurlan_$",     "DepBrunaFurlan",   x)
    x <- sub("^erundinapsb$",      "luiza_erundina",   x)
    x <- sub("^deputadoamauri$",   "DeputadoAmauri",   x)
    x <- sub("^acmneto_25$",       "acmneto_",         x)
    x <- sub("^acmnetodeputado$",  "acmneto_",         x)
    x <- sub("^BrunaFurlan_$",     "DepBrunaFurlan",   x)
    x <- sub("^soumarinho10$",     "dpmarciomarinho",  x)
    x <- sub("^VOLTAJAIRO$",       "JAIROPREFEITO25",  x)
    x <- sub("^depcarlinhos$",     "carlinhos13sjc",   x)
    x <- sub("^CELIAROCHA_AL$",    "CELIAROCHA14",     x)
    x <- sub("^eholandajunior$",   "edvaldoholandaj",  x)
    x <- sub("^depgeorgehilton$",  "GEORGEHILTON10",   x)
    x <- sub("^deputadogilmar$",   "GilmarMachado_",   x)
    x <- sub("^DepJairoAtaide$",   "JAIROPREFEITO25",  x)
    x <- sub("^JoaoPauloPT13$",    "depjoaopaulo",     x)
    x <- sub("^deplelocoimbra$",   "lelocoimbra_",     x)
    x <- sub("^dep_Setim$",        "Setim25",          x)
    x <- sub("^lfm45$",            "lfmfederal",       x)
    x <- sub("^erundinapsb$",      "luiza_erundina",   x)
    x <- sub("^paulinhopdt12$",    "dep_paulinho",     x)
    x <- sub("^SouMaisAmauri$",    "DeputadoAmauri",   x)
    x <- sub("^DeputadoRomero$",   "Romero45CG",       x)
    x <- sub("^teresasurita$",     "Teresa_Surita",    x)
    x <- sub("^TeresaSurita15$",   "Teresa_Surita",    x)
    x <- sub("^Dep_Zoinho$",       "Zoinho__22",       x)
    x <- sub("^pedrotaques123$",   "PedroTaquesMT",    x)
    x <- sub("^vanessasenadora$",  "vanessaprefeita",  x)
    x <- sub("^moka_senador$",     "Senador_Moka",     x)
    x <- sub("^chicodangelo13$",   "chico_dangelo",    x)
    x <- sub("^deputadamanuela$",  "manudeputada",     x)
    x <- sub("^_manuela65$",       "manudeputada",     x)
    x <- sub("^martasenadora$",    "MartaSuplicy_",    x)
    x <- sub("^dep_Audifax$",      "prefeitoAUDIFAX",  x)
    x <- sub("^CELIAROCHA14$",     "PREF_CELIAROCHA",  x)
    x <- sub("^DepOdairCunha$",    "odaircunha_",      x)
    x <- sub("^depsantiago$",      "santiagofederal",  x)
    x
}



pls <- read.csv2("lista_de_parlamentares.csv", stringsAsFactors = FALSE)
pls <- pls[pls$endereco != "-2", ]
pls <- pls[pls$temtwitter != "Teve", ]
xx <- list()

lf <- c("tp_2012-02-23.csv", "tp_2012-03-01.csv", "tp_2012-03-08.csv", "tp_2012-03-15.csv",
        "tp_2012-03-22.csv", "tp_2012-03-29.csv", "tp_2012-04-07.csv", "tp_2012-04-12.csv",
        "tp_2012-04-19.csv", "tp_2012-04-26.csv", "tp_2012-05-03.csv", "tp_2012-05-10.csv",
        "tp_2012-05-17.csv", "tp_2012-05-24.csv", "tp_2012-05-31.csv", "tp_2012-06-07.csv",
        "tp_2012-06-14.csv", "tp_2012-06-21.csv", "tp_2012-06-28.csv", "tp_2012-07-05.csv",
        "tp_2012-07-12.csv", "tp_2012-07-19.csv", "tp_2012-07-26.csv", "tp_2012-08-03.csv",
        "tp_2012-08-09.csv", "tp_2012-08-16.csv", "tp_2012-08-23.csv", "tp_2012-08-30.csv",
        "tp_2012-09-06.csv", "tp_2012-09-13.csv", "tp_2012-09-20.csv", "tp_2012-09-27.csv",
        "tp_2012-10-04.csv", "tp_2012-10-12.csv", "tp_2012-10-18.csv", "tp_2012-10-25.csv",
        "tp_2012-11-02.csv", "tp_2012-11-08.csv", "tp_2012-11-15.csv", "tp_2012-11-22.csv",
        "tp_2012-11-29.csv", "tp_2012-12-06.csv", "tp_2012-12-13.csv", "tp_2012-12-21.csv",
        "tp_2012-12-27.csv", "tp_2013-01-03.csv", "tp_2013-01-10.csv", "tp_2013-01-17.csv",
        "tp_2013-01-24.csv", "tp_2013-01-31.csv", "tp_2013-02-07.csv", "tp_2013-02-14.csv")

for(f in lf){
    x <- read.csv2(paste0("dados_Twitter/", f), stringsAsFactors = FALSE)
    x$listed <- NULL
    x$friends <- NULL
    x$favourites <- NULL
    nome <- sub("tp_(.*)\\.csv", "\\1", f)
    xx[[nome]] <- x
}

aaa <- function(x)
{
    x$endereco <- atualizarTwitter(as.character(x$endereco))
    x
}
xx <- lapply(xx, aaa)

# Renomear variáveis para possibilitar o merge().
aaa <- function(x, n)
{
    n <- gsub("-", ".", n)
    colnames(x) <- paste0(names(x), n)
    colnames(x) <- sub("endereco.*", "endereco", names(x))
    x
}
len <- length(xx)
for(i in 1:len){
    xx[[i]] <- aaa(xx[[i]], names(xx)[i])
    err <- pls$endereco %in% xx[[i]]$endereco
    err <- pls$endereco[!err]
    if(length(err) > 0){
        cat("\nERRO", names(xx)[i], "(nome não encontrado em lista_de_parlamentares.csv):",
            paste(err), "\n\n")
    }
}

# Juntar bancos
st <- xx[[1]]
for(i in 2:len){
    nrst <- nrow(st)
    oldaddr <- st$endereco
    st <- merge(st, xx[[i]], all = TRUE)
    if(nrst != nrow(st)){
        cat("\n\nERROR: nrow(st)", nrst, nrow(st), names(xx)[i], "\n\n")
        cat(oldaddr, sep = "\n", file = "/tmp/oldaddr")
        cat(st$endereco, sep = "\n", file = "/tmp/newaddr")
    }
}

idx <- grep("statuses", names(st))
stls <- names(st)[idx]
stls <- sub("statuses", "", stls)
ultimodia <- stls[length(stls)]
ultimodiabr <- sub("([0-9][0-9][0-9][0-9])\\.([0-9][0-9])\\.([0-9][0-9])", "\\3/\\2\\/\\1", ultimodia)
primeirodia <- stls[1]
primeirodiabr <- sub("([0-9][0-9][0-9][0-9])\\.([0-9][0-9])\\.([0-9][0-9])", "\\3/\\2\\/\\1", primeirodia)

rm(lf, f, nome, len, aaa, i, x, xx, idx, stls)



# Preencher dados não coletados com médias calculadas
st$followers2012.11.29 <- round(st$followers2012.11.22 + (0.33 * (st$followers2012.12.13 - st$followers2012.11.22)))
st$followers2012.12.06 <- round(st$followers2012.11.22 + (0.66 * (st$followers2012.12.13 - st$followers2012.11.22)))
st$statuses2012.11.29 <- round(st$statuses2012.11.22 + (0.33 * (st$statuses2012.12.13 - st$statuses2012.11.22)))
st$statuses2012.12.06 <- round(st$statuses2012.11.22 + (0.66 * (st$statuses2012.12.13 - st$statuses2012.11.22)))



tab <- read.table("parlamentares.csv", sep = "\t", header = TRUE, quote = "", comment.char = "")
tab$data.inicio <- NULL
tab$sexo <- reorder.factor(tab$sexo, new.order = c(2, 1))
n1 <- nrow(tab)
tab <- tab[tab$endereco != "-2", ]
n2 <- nrow(tab)
tab <- tab[tab$casa == "Câmara dos Deputados", ]
n3 <- nrow(tab)
tab$endereco <- atualizarTwitter(as.character(tab$endereco))

# Adicionar data de início do uso do Twitter
di <- read.table("info_2013-01-29.csv", header = TRUE, sep = ";", stringsAsFactors = FALSE)
di$endereco <- atualizarTwitter(di$endereco)
di$created <- as.Date(sub(" .*", "", di$created), format = "%Y-%m-%d")
di$tempo.twitter <- as.numeric((as.Date(ultimodia, format = "%Y.%m.%d") - di$created) / 365)
tab <- merge(tab, di)
n4 <- nrow(tab)

tmp <- tab$endereco
tab <- merge(tab, st)
n5 <- nrow(tab)
nomes4 <- paste(tmp[!(tmp %in% tab$endereco)], collapse = ", ")
if(nomes4 == "")
    nomes4 <- "nenhum"

# Eliminar parlamentares com muitos valores omissos na coleta de dados:
ntabna <- apply(tab, 1, function(x) sum(is.na(x)))
nomes5 <- paste(tab$endereco[ntabna > 10], collapse = ", ")
tab <- tab[ntabna < 11, ]
n6 <- nrow(tab)

tab$nome.unico <- paste0(as.character(tab$uf), ":", toupper(tab$nome.civil))
tab$nome.unico <- iconv(tab$nome.unico, to = "ASCII//TRANSLIT")

load("props.RData")
votos$nome.unico <- iconv(votos$nome.unico, to = "ASCII//TRANSLIT")
props$nome.unico <- iconv(sub("^...", "", rownames(props)), to = "ASCII//TRANSLIT")

# produzir tabela com parlamentares não identificados
tmp <- tab$nome.unico
tab <- merge(tab, votos)
n7 <- dim(tab)[1]
nomes6 <- paste(tmp[!(tmp %in% tab$nome.unico)], collapse = "\n")

tab <- merge(tab, props, all.x = TRUE)
n8 <- dim(tab)[1]



# número de votos dos deputados por Estado
nvd <- data.frame(uf = c("AC", "AL", "AM", "AP", "BA", "CE", "DF", "ES", "GO",
                         "MA", "MG", "MS", "MT", "PA", "PB", "PE", "PI", "PR",
                         "RJ", "RN", "RO", "RR", "RS", "SC", "SE", "SP", "TO"),
                  ndep = c(8, 9, 8, 8, 39, 22, 8, 10, 17, 18, 53, 8, 8, 17,
                           12, 25, 10, 30, 46, 8, 8, 8, 31, 16, 8, 70, 8))
tnv <- data.frame(uf = names(votos.uf), votos.uf = votos.uf)
tnv <- merge(tnv, nvd)
tab <- merge(tab, tnv)

# Adicionar ideologia dos partidos
ideo <- read.csv2("ideologia_tarouco.csv")
ideo$ideo2 <- reorder.factor(ideo$ideo2, new.order = c(3, 1, 2))
ideo$ideo3 <- reorder.factor(ideo$ideo3, new.order = c(5, 3, 1, 2, 4))
tab <- merge(tab, ideo, all.x = TRUE)
tab$ideo1[tab$partido == "PSD"] <- 4.4
tab$ideo2[tab$partido == "PSD"] <- "Centro"
tab$ideo3[tab$partido == "PSD"] <- "Centro"


b <- tab

b$nome <- as.character(b$nome)
b$cargo <- as.character(b$cargo.funcao)
b$cargo.funcao <- NULL
b$cargo[b$cargo != "Não"] <- "Possui"
b$cargo[b$cargo == "Não"] <- "Não possui"
b$cargo <- as.factor(b$cargo)
b$maisdeum <- b$legislaturas.deputados > 1

### Corrigindo/eliminando falhas da coleta:

# Deputada Manuela e Deputado João Carlos Bacelar
b <- b[-grep("^manudeputada$", b$endereco), ]
b <- b[-grep("^JoaoCBacelar$", b$endereco), ]
n9 <- nrow(b)


# Cálculo da tuitagem semanal
tw <- b[, grep("statuses", names(b))]
nna <- apply(tw, 1, function(x) sum(is.na(x)))
if(sum(nna > 5) > 0){
    cat("\n\nOs seguintes parlamentares estão com muitos valores omissos e serão elliminados da base de dados:",
        b$endereco[nna > 5])
}
b <- b[nna < 6, ]

tw <- b[, grep("statuses", names(b))]
len <- ncol(tw)
tw2 <- tw[, 2:len]
len <- len - 1
tw1 <- tw[, 1:len]
tw <- tw2 - tw1
names(tw) <- sub("statuses", "tuitagem", names(tw))

neglim <- -15
negdep <- b$endereco[apply(tw, 1, function(x) any(x < neglim, na.rm = TRUE))]

tw[tw < 0] <- NA
twm <- apply(tw, 1, mean, na.rm = TRUE)
twsd <- apply(tw, 1, sd, na.rm = TRUE)
b <- cbind(b, tw, twm, twsd)
dias <- names(b)[grep("tuitagem", names(b))]
dias <- sub("tuitagem2012.", "", dias)
dias <- sub("tuitagem2013.", "", dias)
dias <- sub("(..)\\.(..)", "\\2/\\1", dias)
rm(votos, props, tw, twsd, tw1, tw2, len)

# Corrigir um valor NA em followers2013.01.24:
b$followers2013.01.24[is.na(b$followers2013.01.24)] <- b$followers2012.06.28[is.na(b$followers2013.01.24)]

b$logvotos <- log(b$votos)
b$logstt <- log(b[[paste0("statuses", ultimodia)]] + 1)
b$logtwm <- log(b$twm + 1)
b$logfol <- log(b[[paste0("followers", ultimodia)]] + 1)
b$idade <- 2012 - b$ano.de.nascimento
b <- droplevels(b)
write.table(b, file = "/tmp/dados_deputados.csv", sep = "\t", row.names = FALSE)


###############################################################################
##  I - Análise dos Dados
###############################################################################


# Número de deputados na base de dados:
nrow(b)

# Soma de todos os tweets postados no período:
sum(b$statuses2013.02.14 - b$statuses2012.02.23)

# Soma incluindo período não coberto por esta pesquisa:
sum(b$statuses2013.02.14)

# Soma de todos os seguidores no último dia de coleta:
sum(b$followers2013.02.14)



b2 <- b

b2$logtwm <- as.numeric(scale(b$logtwm))
b2$logfol <- as.numeric(scale(b$logfol))
b2$idade <- as.numeric(scale(b$idade))
b2$votos <- as.numeric(scale(b$votos))
b2$rendamd <- as.numeric(scale(b$rendamd))
b2$propsup <- as.numeric(scale(b$propsup))
b2$propurb <- as.numeric(scale(b$propurb))
b2$tempo.twitter <- as.numeric(scale(b$tempo.twitter))
b2$ideo1 <- as.numeric(scale(b$ideo1))
b2$prop.voto <- as.numeric(scale(b$votos / b$votos.uf))
b2$prop.votop <- as.numeric(scale(b$votos / (b$votos.uf / b$ndep)))
b2$maisdeum <- as.numeric(scale(as.numeric(b$maisdeum)))
b2$cargo <- as.numeric(scale(as.numeric(b$cargo == "Possui")))


t1 <- lm(logtwm ~ tempo.twitter + idade + maisdeum + cargo + rendamd + propsup + ideo1 + votos, data = b2)
t2 <- lm(logtwm ~ tempo.twitter + idade + maisdeum + cargo + rendamd + propsup + ideo1 + prop.votop, data = b2)
t3 <- lm(logtwm ~ tempo.twitter + idade + maisdeum + cargo + prop.votop + rendamd + propsup + ideo1, data = b2)
t4 <- lm(logtwm ~ tempo.twitter + idade + maisdeum + cargo + prop.votop + propsup + ideo1, data = b2)
t5 <- lm(logtwm ~ tempo.twitter + idade + maisdeum + cargo + prop.votop + rendamd + ideo1, data = b2)



# Tabela 2: Sumários de regressões, tendo o logaritmo da média da tuitagem
# semanal variável dependente
print(relabel(mtable(t1, t2, summary.stats = c("N", "adj. R-squared", "F")),
              "tempo.twitter" = "Tempo de uso do Twitter",
              "idade" = "Idade",
              "maisdeum" = "Mais de uma legislatura (Sim)",
              "cargo" = "Cargo (Possui)",
              "rendamd" = "Renda média do eleitorado",
              "propsup" = "Eleitorado com nível superior",
              "ideo1" = "Ideologia partidária",
              "votos" = "Votos",
              "prop.votop" = "Votos dep. / (votos UF / n. dep.)"))



s1 <- lm(logfol ~ tempo.twitter + idade + maisdeum + cargo + rendamd + propsup + ideo1 + votos, data = b2)
s2 <- lm(logfol ~ tempo.twitter + idade + maisdeum + cargo + rendamd + propsup + ideo1 + prop.votop, data = b2)
s3 <- step(s2)


# Tabela 3: Sumários de regressões, tendo o logaritmo do número de seguidores
# como variável dependente
print(relabel(mtable(s1, s2, s3, summary.stats = c("N", "adj. R-squared", "F")),
              "tempo.twitter" = "Tempo de uso do Twitter",
              "idade" = "Idade",
              "maisdeum" = "Mais de uma legislatura (Sim)",
              "cargo" = "Cargo (Possui)",
              "rendamd" = "Renda média do eleitorado",
              "propsup" = "Eleitorado com nível superior",
              "ideo1" = "Ideologia partidária",
              "votos" = "Votos",
              "prop.votop" = "Votos dep. / (votos UF / n. dep.)"))


# Figura 1: Cargo, ideologia e tempo de uso do Twitter
png("Fig_1_cargo_ideologia.png", width = 6, height = 2.5, res=300, units= "in")
par(mfrow = c(1, 2), mar = c(5, 4, 0, 1) + 0.2)
x <- compmeans(b$ideo1, b$cargo, ylab = "Ideologia", sub = "(a)", xlab = "Possui cargo")
par(mar = c(5, 5, 0, 0) + 0.2)
x <- compmeans(b$tempo.twitter, b$cargo, ylab = "Tempo de Twitter", sub = "(b)", xlab = "Possui cargo")
dev.off()

